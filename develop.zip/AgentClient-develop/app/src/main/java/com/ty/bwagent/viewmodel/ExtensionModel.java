package com.ty.bwagent.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.DictTypeEntity;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class ExtensionModel extends ViewModel {

    public NetLiveData<BaseEntity<List<ExtensionEntity>>> entityNetLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity<List<DictTypeEntity>>> dictTypeH5NetLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity<List<DictTypeEntity>>> dictTypeWebNetLiveData = new NetLiveData<>();
    public static MutableLiveData<String> typeChangeUpNetLiveData = new MutableLiveData<>();


    /**
     * //推广连接
     *
     * @param clientType
     */
    public void domainByClientType(String clientType) {
        NetSdk.create(Api.class)
                .domainByClientType()
                .params("clientType", clientType)
                .asJSONType()
                .send(entityNetLiveData);
    }

    /**
     * //域名筛选类型 h5 web
     *
     * @param type 1: agent_private_domain_h5 2:agent_private_domain_web
     */
    public void dictTypeQuery(int type, NetLiveData<BaseEntity<List<DictTypeEntity>>> dictTypeNetLiveData) {
        String dictCode = "";
        if (type == 1) {
            dictCode = "agent_private_domain_h5";
        } else {
            dictCode = "agent_private_domain_web";
        }
        NetSdk.create(Api.class)
                .dictTypeQuery()
                .params("dictCode", dictCode)
                .asJSONType()
                .send(dictTypeNetLiveData);

    }


}
