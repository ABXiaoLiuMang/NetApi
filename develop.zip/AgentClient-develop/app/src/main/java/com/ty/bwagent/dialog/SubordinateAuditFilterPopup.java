package com.ty.bwagent.dialog;

import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lxj.xpopup.impl.PartShadowPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.view.SelectTimeView;
import com.ty.pickerview.builder.OptionsPickerBuilder;
import com.ty.pickerview.view.OptionsPickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;

import java.util.ArrayList;
import java.util.Date;

import androidx.annotation.NonNull;

/**
 * 下级筛选对话框
 */
public class SubordinateAuditFilterPopup extends PartShadowPopupView implements View.OnClickListener {


    private SelectTimeView mSelectTimeViewApply;
    private EditText mEtName;
    private TextView mTvState;

    Context context;
    private OnFilterCallBackListener onFilterCallBackListener;
    private ArrayList<String> stateList;
    private TextView mTvReset;
    private TextView mTvSure;
    private OptionsPickerView statusOptions;
    private LinearLayout llItem;

    public SubordinateAuditFilterPopup(@NonNull Context context, OnFilterCallBackListener onFilterCallBackListener) {
        super(context);
        this.context = context;
        this.onFilterCallBackListener = onFilterCallBackListener;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_sub_filter;
    }

    @Override
    protected void onCreate() {
        super.onCreate();

        mSelectTimeViewApply = findViewById(R.id.selectTimeView_apply);
        mEtName = findViewById(R.id.et_name);
        mTvState = findViewById(R.id.tv_sec_state);
        mTvReset = findViewById(R.id.tv_reset);
        mTvSure = findViewById(R.id.tv_sure);
        llItem = findViewById(R.id.ll_item);

        mTvState.setOnClickListener(this);
        mTvSure.setOnClickListener(this);
        mTvReset.setOnClickListener(this);
        llItem.setOnClickListener(this);

        mTvReset.setTextColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        mTvReset.setBackgroundColor(ResUtils.getColor(SiteSdk.ins().btnEnableColor()));
        mTvSure.setBackgroundColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        mSelectTimeViewApply.setInitTime(new Date());

        initState();

    }

    private void initState() {
        stateList = new ArrayList();
        stateList.add("全部");
        stateList.add("待审核");
        stateList.add("审核成功");
        stateList.add("审核拒绝");
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_sec_state:
                KeyboardUtils.hideSoftInput(v);
                buildSizeOptionsPicker();
                break;
            case R.id.tv_reset://重置
                resert();
                if (onFilterCallBackListener != null) {
                    onFilterCallBackListener.OnDateBack(mSelectTimeViewApply.getStartTime(), mSelectTimeViewApply.getEndTime(),
                            mEtName.getText().toString().trim(), getApplyStatus(mTvState.getText().toString().trim())
                    );
                }
                dismiss();
                break;
            case R.id.tv_sure://确定
                if (checkDate()) {
                    if (onFilterCallBackListener != null) {
                        onFilterCallBackListener.OnDateBack(mSelectTimeViewApply.getStartTime(), mSelectTimeViewApply.getEndTime(),
                                mEtName.getText().toString().trim(), getApplyStatus(mTvState.getText().toString().trim())
                        );
                    }
                    dismiss();
                }
                break;
            case R.id.ll_item:
                KeyboardUtils.hideSoftInput(v);
                break;
        }
    }

    /**
     * 检查数据是否正确
     *
     * @return
     */
    private boolean checkDate() {
        if (!mSelectTimeViewApply.daysBetween(mSelectTimeViewApply.getStartTime(), mSelectTimeViewApply.getEndTime())) {
            ToastUtils.showLong("结束时间不能早于开始时间");
            return false;
        }
        return true;
    }


    private void buildSizeOptionsPicker() {
        if (statusOptions == null) {
            statusOptions = new OptionsPickerBuilder(getContext(), (options1, options2, options3, v) -> {
                mTvState.setText(stateList.get(options1));
            })
                    .setSubmitText("确定")
                    .setSubmitColor(ResUtils.getColor(R.color.site_style_color))
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(R.color.site_style_color))
                    .setTitleText("状态")
                    .setTitleColor(ResUtils.getColor(R.color.generic_heise))
                    .setLabels("", "", "")
                    .setCyclic(false, false, false)
                    .setSelectOptions(0, 0, 0)
                    .build();
            statusOptions.setPicker(stateList);
        }
        statusOptions.show();
    }


    public void resert() {
        mTvState.setText("全部");
        mSelectTimeViewApply.onReset();
        mSelectTimeViewApply.setInitTime(new Date());
        mEtName.setText("");
    }

    /**
     * 申请状态
     *
     * @param status 审核状态0待审核1审核拒绝2审批通过
     * @return
     */
    public String getApplyStatus(String status) {
        String applyStatus = "";
        switch (status) {
            case "全部":
                applyStatus = "";
                break;
            case "待审核":
                applyStatus = "0";
                break;
            case "审核成功"://
                applyStatus = "2";
                break;
            case "审核拒绝"://
                applyStatus = "1";
                break;
        }
        return applyStatus;
    }


    @Override
    protected void onDismiss() {
        super.onDismiss();

    }

    public interface OnFilterCallBackListener {
        void OnDateBack(String startTime, String endTime, String name, String state);
    }
}
