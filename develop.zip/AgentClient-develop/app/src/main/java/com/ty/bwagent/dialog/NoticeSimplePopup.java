package com.ty.bwagent.dialog;

import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.DialogTextHeightChangeShow;

public class NoticeSimplePopup extends ConfirmPopupView {

    public NoticeSimplePopup(@NonNull Context context) {
        super(context);
    }


    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_member_center;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_content.setMovementMethod(ScrollingMovementMethod.getInstance());
        tv_content.setScrollbarFadingEnabled(true);

        LinearLayout ll_main = findViewById(R.id.ll_main);
        TextView contentView = getContentTextView();
        String trim = contentView.getText().toString().trim();
        DialogTextHeightChangeShow dialogTextHeightChangeShow = new DialogTextHeightChangeShow(ll_main, tv_content,4.5);
        dialogTextHeightChangeShow.setTextHeight(trim);
    }
}
