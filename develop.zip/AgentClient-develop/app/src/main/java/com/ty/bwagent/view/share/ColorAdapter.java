package com.ty.bwagent.view.share;

import android.graphics.drawable.GradientDrawable;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;
import java.util.Arrays;


/**
 * 描述:推广素材颜色切换适配器
 */
public class ColorAdapter extends BaseQuickAdapter<ColorModel, BaseViewHolder> {

    int postion = 7;

    public ColorAdapter() {
        super(R.layout.recycle_share_color);
        ArrayList<ColorModel> arrayList = new ArrayList<>();
        arrayList.add(new ColorModel("红色",R.color.color_ff2133));
        arrayList.add(new ColorModel("橙色",R.color.color_ff5b00));
        arrayList.add(new ColorModel("黄色",R.color.color_ff9c00));
        arrayList.add(new ColorModel("绿色",R.color.color_00b73f));
        arrayList.add(new ColorModel("青色",R.color.color_009ab0));
        arrayList.add(new ColorModel("蓝色",R.color.color_007cde));
        arrayList.add(new ColorModel("紫色",R.color.color_7b3bf0));
        arrayList.add(new ColorModel("黑色",R.color.black));
        arrayList.add(new ColorModel("白色",R.color.white));
        arrayList.add(new ColorModel("灰色",R.color.color_f5f5f5));
        setNewData(arrayList);
    }

    public void setPostion(int postion) {
        this.postion = postion;
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, ColorModel item) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setCornerRadius(SizeUtils.sp2px(9));
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setStroke(SizeUtils.dp2px(0.5f),ResUtils.getColor(R.color.generic_huise));
        drawable.setColor(ResUtils.getColor(item.getColor()));
        RelativeLayout rl_Bg = helper.getView(R.id.rl_Bg);
        rl_Bg.setBackground(drawable);
        helper.setGone(R.id.iv_select,helper.getAdapterPosition() == postion);
    }


}
