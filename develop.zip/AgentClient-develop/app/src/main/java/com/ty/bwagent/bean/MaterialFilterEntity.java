package com.ty.bwagent.bean;

/**
 * 推广素材筛选条件
 */
public class MaterialFilterEntity {
    String type;
    String title;
    String size;

    public MaterialFilterEntity(String type, String title, String size) {
        this.type = type;
        this.title = title;
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "MaterialFilterEntity{" +
                "type='" + type + '\'' +
                ", title='" + title + '\'' +
                ", size='" + size + '\'' +
                '}';
    }
}
