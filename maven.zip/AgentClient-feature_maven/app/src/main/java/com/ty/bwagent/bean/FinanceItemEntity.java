package com.ty.bwagent.bean;

public class FinanceItemEntity {

    String typeName;//类别名字
    double monty;//金额
    boolean showInfo;//是否显示查看按钮

    public FinanceItemEntity(String typeName, double monty, boolean showInfo) {
        this.typeName = typeName;
        this.monty = monty;
        this.showInfo = showInfo;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public double getMonty() {
        return monty;
    }

    public void setMonty(double monty) {
        this.monty = monty;
    }

    public boolean isShowInfo() {
        return showInfo;
    }

    public void setShowInfo(boolean showInfo) {
        this.showInfo = showInfo;
    }
}
