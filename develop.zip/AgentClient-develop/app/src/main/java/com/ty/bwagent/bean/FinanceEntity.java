package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 描述: 佣金月度详情数据
 * <p>
 * author:Dale
 */
public class FinanceEntity implements Parcelable {

    /**
     * balance : 0.0
     * commission : 0.0
     * commissionDate : 2020-02
     * commissionStatus : 0
     * correction : 0.0
     * czProfit : 0.0
     * id :
     * lastBalance : 0.0
     * netProfit : 0.0
     * profit : 0.0
     * promo : 0.0
     * rate : 0.0
     * rebate : 0.0
     * releaseAt : 佣金发放时间
     * riskAdjust : 0.0
     * thirdPartySpend : 0.0
     */

    private double balance;//结余
    private double commission;//佣金
    private String commissionDate;//佣金月份
    private int commissionStatus;//佣金发放状态：0记录；1已发放
    private double correction;//佣金调整
    private double czProfit;//冲正后净输赢
    private String id;
    private double lastBalance;//上月结余
    private double netProfit;//净输赢
    private double profit;//总输赢
    private double promo;//优惠
    private double rate;//佣金比例（单位%）
    private double rebate;//返水
    private String releaseAt;//佣金发放时间
    private double riskAdjust;//输赢调整
    private double thirdPartySpend;//平台费
    private double deposit;//存款
    private double draw;//提款
    private int showCommissionRate;//是否显示佣金比例 0展示 1隐藏

    protected FinanceEntity(Parcel in) {
        balance = in.readDouble();
        commission = in.readDouble();
        commissionDate = in.readString();
        commissionStatus = in.readInt();
        correction = in.readDouble();
        czProfit = in.readDouble();
        id = in.readString();
        lastBalance = in.readDouble();
        netProfit = in.readDouble();
        profit = in.readDouble();
        promo = in.readDouble();
        rate = in.readDouble();
        rebate = in.readDouble();
        releaseAt = in.readString();
        riskAdjust = in.readDouble();
        thirdPartySpend = in.readDouble();
        deposit = in.readDouble();
        draw = in.readDouble();
        showCommissionRate = in.readInt();
    }

    public int getShowCommissionRate() {
        return showCommissionRate;
    }

    public void setShowCommissionRate(int showCommissionRate) {
        this.showCommissionRate = showCommissionRate;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public double getDraw() {
        return draw;
    }

    public void setDraw(double draw) {
        this.draw = draw;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeDouble(balance);
        dest.writeDouble(commission);
        dest.writeString(commissionDate);
        dest.writeInt(commissionStatus);
        dest.writeDouble(correction);
        dest.writeDouble(czProfit);
        dest.writeString(id);
        dest.writeDouble(lastBalance);
        dest.writeDouble(netProfit);
        dest.writeDouble(profit);
        dest.writeDouble(promo);
        dest.writeDouble(rate);
        dest.writeDouble(rebate);
        dest.writeString(releaseAt);
        dest.writeDouble(riskAdjust);
        dest.writeDouble(thirdPartySpend);
        dest.writeDouble(draw);
        dest.writeDouble(deposit);
        dest.writeInt(showCommissionRate);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<FinanceEntity> CREATOR = new Creator<FinanceEntity>() {
        @Override
        public FinanceEntity createFromParcel(Parcel in) {
            return new FinanceEntity(in);
        }

        @Override
        public FinanceEntity[] newArray(int size) {
            return new FinanceEntity[size];
        }
    };

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getCommission() {
        return commission;
    }

    public void setCommission(double commission) {
        this.commission = commission;
    }

    public String getCommissionDate() {
        return commissionDate;
    }

    public void setCommissionDate(String commissionDate) {
        this.commissionDate = commissionDate;
    }

    public int getCommissionStatus() {
        return commissionStatus;
    }

    public void setCommissionStatus(int commissionStatus) {
        this.commissionStatus = commissionStatus;
    }

    public double getCorrection() {
        return correction;
    }

    public void setCorrection(double correction) {
        this.correction = correction;
    }

    public double getCzProfit() {
        return czProfit;
    }

    public void setCzProfit(double czProfit) {
        this.czProfit = czProfit;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getLastBalance() {
        return lastBalance;
    }

    public void setLastBalance(double lastBalance) {
        this.lastBalance = lastBalance;
    }

    public double getNetProfit() {
        return netProfit;
    }

    public void setNetProfit(double netProfit) {
        this.netProfit = netProfit;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public double getPromo() {
        return promo;
    }

    public void setPromo(double promo) {
        this.promo = promo;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getRebate() {
        return rebate;
    }

    public void setRebate(double rebate) {
        this.rebate = rebate;
    }

    public String getReleaseAt() {
        return releaseAt;
    }

    public void setReleaseAt(String releaseAt) {
        this.releaseAt = releaseAt;
    }

    public double getRiskAdjust() {
        return riskAdjust;
    }

    public void setRiskAdjust(double riskAdjust) {
        this.riskAdjust = riskAdjust;
    }

    public double getThirdPartySpend() {
        return thirdPartySpend;
    }

    public void setThirdPartySpend(double thirdPartySpend) {
        this.thirdPartySpend = thirdPartySpend;
    }
}
