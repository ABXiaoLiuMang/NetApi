package com.ty.bwagent.adapter;

import android.util.ArrayMap;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.AddBankCardEntity;
import com.ty.bwagent.bean.MaterialEntity;

import java.util.List;


/**
 * 描述 素材列表适配器
 * <p>
 * author:Dale
 */
public class MaterialAdapter extends BaseQuickAdapter<MaterialEntity.ListBean, BaseViewHolder> {


    ArrayMap<Integer, String> arrayMap = new ArrayMap<>();

    public MaterialAdapter() {
        super(R.layout.recycle_item_material);
        arrayMap.put(1, "综合推广图");
        arrayMap.put(2, "app推广图");
        arrayMap.put(3, "赞助推广图");
        arrayMap.put(4, "赠送推广图");
    }

    public void setTypeKey(List<AddBankCardEntity> list){
         for (AddBankCardEntity entity : list){
             arrayMap.put(entity.getId(),entity.getDictValue());
         }
         notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, MaterialEntity.ListBean listBean) {
        ImageView iv_share_icon = helper.getView(R.id.iv_share_icon);
        RequestOptions requestOptions = new RequestOptions()
                .placeholder(R.mipmap.icon_share_bg)
                .error(R.mipmap.icon_share_bg);
        Glide.with(mContext).load(listBean.getImageUrl()).apply(requestOptions).into(iv_share_icon);
        helper.setText(R.id.tv_share_title,listBean.getImageTitle());
        helper.setText(R.id.tv_share_size,getTypeName(listBean) +" " +  listBean.getImageSize());
        helper.addOnClickListener(R.id.tv_big_pic,R.id.tv_code_pic,R.id.iv_share_icon);
    }

    private String getTypeName(MaterialEntity.ListBean listBean){
        if(arrayMap.containsKey(listBean.getImageType())){
            return arrayMap.get(listBean.getImageType());
        }
        return "全部";
    }

}
