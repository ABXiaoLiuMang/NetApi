package com.ty.bwagent.fragment;

import android.content.Intent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.config.PictureConfig;
import com.luck.picture.lib.entity.LocalMedia;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tianyu.updater.entity.UpdateEntity;
import com.ty.bwagent.App;
import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.UnRendTypeEntity;
import com.ty.bwagent.bean.UpFileEntity;
import com.ty.bwagent.bean.UserEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.dialog.UpHeadPopup;
import com.ty.bwagent.fragment.finance.fragment.DrawingTabFragment;
import com.ty.bwagent.fragment.finance.fragment.RecordTabFragment;
import com.ty.bwagent.fragment.login.ChangePassWordFragment;
import com.ty.bwagent.fragment.login.PayPassWordFragment;
import com.ty.bwagent.fragment.login.PayPassWordSetFragment;
import com.ty.bwagent.fragment.news.MessageTabFragment;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.Key;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.MoneyViewModel;
import com.ty.bwagent.viewmodel.MyCenterViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.SingleOnClickListener;
import com.ty.common.view.TitleBar;
import com.ty.common.view.ValueView;
import com.ty.net.bean.LiveResult;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteSdk;
import com.ty.tysite.utils.ImageResoureSiteUtils;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.FileUtils;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.CircleImageView;
import com.ty.view.switchbnt.FSwitchButton;
import com.ty.view.switchbnt.SwitchButton;

import java.io.File;
import java.util.List;

import butterknife.BindView;
import me.yokeyword.fragmentation.ISupportFragment;

/**
 * 我的
 */
public class MyCenterFragment extends ABBaseFragment implements OnRefreshListener {

    MyCenterViewModel mMyCenterViewModel;
    MoneyViewModel moneyViewModel;
    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.center_userHead)
    CircleImageView centerUserHead;
    @BindView(R.id.center_userName)
    TextView centerUserName;
    @BindView(R.id.center_join_days)
    TextView centerJoinDays;
    @BindView(R.id.center_iv_commmiss)
    ImageView centerIvCommmiss;
    @BindView(R.id.center_commiss_money)
    TextView centerCommissMoney;
    @BindView(R.id.center_eye_commiss)
    ImageView centerEyeCommiss;
    @BindView(R.id.center_drawing)
    TextView centerDrawing;
    @BindView(R.id.valueview_notice)
    ValueView valueviewNotice;
    @BindView(R.id.valueview_drawing)
    ValueView valueviewDrawing;
    @BindView(R.id.valueview_phone)
    ValueView valueviewPhone;
    @BindView(R.id.valueview_email)
    ValueView valueviewEmail;
    @BindView(R.id.valueview_qq)
    ValueView valueviewQq;
    @BindView(R.id.valueview_password)
    ValueView valueviewPassword;
    @BindView(R.id.valueview_vip)
    ValueView valueviewVip;
    @BindView(R.id.valueview_setting)
    ValueView valueviewSetting;
    @BindView(R.id.center_msg_point)
    ImageView centerMsgPoint;
    @BindView(R.id.center_setting_point)
    ImageView centerSettingPoint;
    @BindView(R.id.tv_inviteCode)
    TextView tv_inviteCode;
    @BindView(R.id.valueview_pay_password)
    ValueView valueviewPayPassword;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    @BindView(R.id.qq_switch)
    FSwitchButton qq_switch;
    Commission commission;//佣金余额和冻结金额

    boolean hideMoney;//true 隐藏金额
    double money = 0.00;//佣金余额

    public static MyCenterFragment getInstance() {
        MyCenterFragment fragment = new MyCenterFragment();
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_my_center;
    }

    @Override
    protected void createProvider() {
        mMyCenterViewModel = new ViewModelProvider(this).get(MyCenterViewModel.class);
        moneyViewModel = new ViewModelProvider(getActivity()).get(MoneyViewModel.class);

        //未读消息数量
        XLiveDataManager.getInstance().unreadTypeLiveData.observe(this, new SimpleObserver<BaseEntity<UnRendTypeEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<UnRendTypeEntity> baseEntity) {
                UnRendTypeEntity unRendTypeEntity = baseEntity.getData();
                int unRead = unRendTypeEntity.getActivityCount() + unRendTypeEntity.getNoticeCount();
                if (unRead > 0) {//有未读消息数量
                    centerMsgPoint.setVisibility(View.VISIBLE);//显示消息通知
                } else {
                    centerMsgPoint.setVisibility(View.GONE);//显示消息通知
                }
            }
        });

        //检查更新监听
        XLiveDataManager.getInstance().updateResult.observe(this, new NetObserver<UpdateEntity>() {
            @Override
            protected void onSuccess(UpdateEntity updateEntity) {
                if (updateEntity != null && !StringUtils.isEmpty(updateEntity.getUpdateInfo().getVersion()) && updateEntity.getUpdateInfo().getCode() > BuildConfig.VERSION_CODE) {
                    centerSettingPoint.setVisibility(View.VISIBLE);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //监听个人信息(加入天数等)
        XLiveDataManager.getInstance().userLiveData.observe(this, new SimpleObserver<BaseEntity<UserEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<UserEntity> baseEntity) {

                UserEntity userEntity = baseEntity.getData();
                if (userEntity == null) {
                    return;
                }
                String inviteCode = userEntity.getInviteCode();
                MMKVUtil.put(Key.INVITE_CODE, inviteCode);
                tv_inviteCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_invitecode), inviteCode));

                centerUserName.setText(userEntity.getName());

                centerJoinDays.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_center_joins), SiteSdk.ins().getSiteName(), userEntity.getJoinedDays()));

                if (!StringUtils.isEmpty(userEntity.getEmail())) {
                    valueviewEmail.setTextValue(Utils.getHideEmail(userEntity.getEmail()));
                    valueviewEmail.setTextValueImg(null);
                    valueviewEmail.setEnabled(false);
                } else {
                    valueviewEmail.setTextValue("");
                    valueviewEmail.setTextValueImg(getResources().getDrawable(R.drawable.x_right_arraw));
                    valueviewEmail.setEnabled(true);
                }
                if (!StringUtils.isEmpty(userEntity.getPhone())) {
                    valueviewPhone.setTextValue(Utils.getHidePhone(userEntity.getPhone()));
                    valueviewPhone.setTextValueImg(null);
                    valueviewPhone.setEnabled(false);
                } else {
                    valueviewPhone.setTextValue("");
                    valueviewPhone.setTextValueImg(getResources().getDrawable(R.drawable.x_right_arraw));
                    valueviewPhone.setEnabled(true);
                }

                if (!StringUtils.isEmpty(userEntity.getQq())) {
                    valueviewQq.setTextValue(userEntity.getQq());
                } else {
                    valueviewQq.setTextValue("");
                }

                //qq号是否展示 0是 1否
                if (userEntity.getQqType() != null && userEntity.getQqType().equals("0")) {
                    qq_switch.setChecked(true, false, false);
                } else {
                    qq_switch.setChecked(false, false, false);
                }

                Glide.with(mContext).load(userEntity.getAvatar()).into(centerUserHead);

                if ("0".equals(userEntity.getPaymentPassword()) || StringUtils.isEmpty(userEntity.getPaymentPassword())) {//0未设置，1已设置
                    //  valueviewPayPassword.setTextValue("");
                } else {
                    valueviewPayPassword.setTextValue(" ");
                }


                /**
                 * 可能绑定了用户真实姓名，刷新保存
                 */
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                if (!StringUtils.isEmpty(userEntity.getRealName())) {
                    userInfo.setRealName(userEntity.getRealName());
                }
                userInfo.setPaymentPassword(userEntity.getPaymentPassword());
                userInfo.setSysType(userEntity.getSysType());
                userInfo.setPhone(userEntity.getPhone());
                userInfo.setQq(userEntity.getQq());
                userInfo.setQqType(userEntity.getQqType());
                UserInfoCache.getInstance().saveUserInfo(userInfo);
            }
        });

        //监听（全局）个人信息
        XLiveDataManager.getInstance().userInfo.observe(this, new NetObserver<UserInfo>() {
            @Override
            protected void onSuccess(UserInfo userInfo) {
                if (!StringUtils.isEmpty(userInfo.getEmail())) {
                    valueviewEmail.setTextValue(Utils.getHideEmail(userInfo.getEmail()));
                    valueviewEmail.setTextValueImg(null);
                    valueviewEmail.setEnabled(false);
                }
                if (!StringUtils.isEmpty(userInfo.getPhone())) {
                    valueviewPhone.setTextValue(userInfo.getPhone());
                    valueviewPhone.setTextValueImg(null);
                    valueviewPhone.setEnabled(false);
                }
                if (!StringUtils.isEmpty(userInfo.getQq())) {//qq绑定后还可以再绑定
                    valueviewQq.setTextValue(userInfo.getQq());
                } else {
                    valueviewQq.setTextValue("");
                }

                //qq号是否展示 0是 1否
                if (userInfo.getQqType() != null && userInfo.getQqType().equals("0")) {
                    qq_switch.setChecked(true, false, false);
                } else {
                    qq_switch.setChecked(false, false, false);
                }

                Glide.with(mContext).load(userInfo.getAvatar()).into(centerUserHead);

                if ("0".equals(userInfo.getPaymentPassword()) || StringUtils.isEmpty(userInfo.getPaymentPassword())) {//0未设置，1已设置
                    //  valueviewPayPassword.setTextValue("");
                } else {
                    valueviewPayPassword.setTextValue("  ");
                }

                /**
                 * 可能绑定了用户真实姓名，刷新保存
                 */
                UserInfo userInfo1 = UserInfoCache.getInstance().getUserInfo();
                if (!StringUtils.isEmpty(userInfo.getRealName())) {
                    userInfo1.setRealName(userInfo.getRealName());
                }
                userInfo1.setPaymentPassword(userInfo.getPaymentPassword());
                userInfo1.setSysType(userInfo.getSysType());
                userInfo1.setPhone(userInfo.getPhone());
                UserInfoCache.getInstance().saveUserInfo(userInfo1);

                KeyboardUtils.hideSoftInput(rootView);
            }

            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //佣金余额
        moneyViewModel.commissLiveData.observe(this, new SimpleObserver<BaseEntity<Commission>>() {
            @Override
            protected void onSuccess(BaseEntity<Commission> baseEntity) {
                refreshLayout.finishRefresh();
                commission = baseEntity.getData();
                money = commission.getAgentMoney();
                showHidePassWord();
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                refreshLayout.finishRefresh(false);
            }
        });

        //修改头像（上传文件）
        mMyCenterViewModel.uploadLiveData.observe(this, new SimpleObserver<BaseEntity<UpFileEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<UpFileEntity> baseEntity) {
                ToastUtils.showLong("头像设置成功");
                UpFileEntity upFileEntity = baseEntity.getData();
                mMyCenterViewModel.insertMemberAvatar(upFileEntity.getFileUrl());
                Glide.with(mContext).load(upFileEntity.getFileUrl()).into(centerUserHead);
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                userInfo.setAvatar(upFileEntity.getFileUrl());
                UserInfoCache.getInstance().saveUserInfo(userInfo);
                XLiveDataManager.getInstance().userInfo.postNext(userInfo);
            }

            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                ToastUtils.showLong(errMsg);
            }
        });

        //上传头像(第二步)
        mMyCenterViewModel.insertAvatarLiveData.observe(this, new SimpleObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                dismissProgressDialog();
                if (upHeadPopup != null) {
                    upHeadPopup.dismiss();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                ToastUtils.showLong(errMsg);
            }
        });

        qq_switch.setOnCheckedChangeCallback(new SwitchButton.OnCheckedChangeCallback() {
            @Override
            public void onCheckedChanged(boolean checked, SwitchButton switchButton) {
                mMyCenterViewModel.updateQqType(checked ? "0" : "1");

            }
        });


        mMyCenterViewModel.updateQqTypeLiveData.observe(this, new SimpleObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ToastUtils.showToast("操作成功");
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                if (qq_switch.isChecked()) {
                    qq_switch.setChecked(false, false, false);
                } else {
                    qq_switch.setChecked(true, false, false);
                }
            }
        });

    }


    @Override
    protected void initViewsAndEvents() {
        mMyCenterViewModel.getUnreadForType();//获取未读消息数量（总数）
        hideMoney = MMKVUtil.getBoolean(CacheKey.USER_SHOW_MONEY, true);
        showHidePassWord();
        String inviteCode = MMKVUtil.getString(Key.INVITE_CODE);
        tv_inviteCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_invitecode), inviteCode));
        centerDrawing.setOnClickListener(singleOnClickListener);
        centerUserHead.setOnClickListener(singleOnClickListener);
        centerEyeCommiss.setOnClickListener(singleOnClickListener);
        valueviewNotice.setOnClickListener(singleOnClickListener);
        valueviewDrawing.setOnClickListener(singleOnClickListener);
        valueviewPhone.setOnClickListener(singleOnClickListener);
        valueviewEmail.setOnClickListener(singleOnClickListener);
        valueviewQq.setOnClickListener(singleOnClickListener);
        valueviewPassword.setOnClickListener(singleOnClickListener);
        valueviewVip.setOnClickListener(singleOnClickListener);
        valueviewSetting.setOnClickListener(singleOnClickListener);
        valueviewPayPassword.setOnClickListener(singleOnClickListener);
        titleBar.setRightOnClickListener(view -> {
            if (DoubleClickUtils.isLongDoubleClick()) {
                return;
            }
            goActivity(OnlineActivity.class);
        });


        refreshLayout.setOnRefreshListener(this);
        refreshLayout.setEnableRefresh(true);
        refreshLayout.setEnableLoadMore(false);

        centerIvCommmiss.setBackgroundResource(ImageResoureSiteUtils.centerMoneyBg());


        moneyViewModel.initMoney();//获取佣金余额
        XLiveDataManager.getInstance().getUserInfo();//刷新用户信息
    }

    SingleOnClickListener singleOnClickListener = new SingleOnClickListener() {
        @Override
        public void onSingleClick(View view) {
            switch (view.getId()) {
                case R.id.center_drawing://提款按钮
                    drawingMoney();
                    break;
                case R.id.center_userHead:
                    showHeadDialog();
                    break;
                case R.id.center_eye_commiss:
                    hideMoney = !hideMoney;
                    showHidePassWord();
                    break;
                case R.id.valueview_notice:
                    goFragment(MessageTabFragment.getInstance(0));
                    break;
                case R.id.valueview_drawing://提款记录
                    goFragment(RecordTabFragment.getInstance());
                    break;
                case R.id.valueview_phone:
                    DialogUtil.showBindPhoneDailog(MyCenterFragment.this);
                    break;
                case R.id.valueview_email:
                    DialogUtil.showBindEmailDailog(MyCenterFragment.this);
                    break;
                case R.id.valueview_qq:
                    DialogUtil.showBindQQDailog(MyCenterFragment.this);
                    break;
                case R.id.valueview_password:
                    goFragment(ChangePassWordFragment.getInstance());
                    break;
                case R.id.valueview_vip:
                    ToastUtils.showLong(ResUtils.getString(R.string.generic_open));
                    break;
                case R.id.valueview_setting:
                    goFragment(SettingFragment.getInstance());
                    break;
                case R.id.valueview_pay_password:
                    UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                    if ("0".equals(userInfo.getPaymentPassword()) || StringUtils.isEmpty(userInfo.getPaymentPassword())) {//0未设置，1已设置
                        goFragment(PayPassWordSetFragment.getInstance());
                    } else {
                        goFragment(PayPassWordFragment.getInstance());
                    }
                    break;
            }
        }
    };


    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        mMyCenterViewModel.getUnreadForType();//获取未读消息数量（总数）
        moneyViewModel.initMoney();//获取佣金余额
        XLiveDataManager.getInstance().checkUpdate();//检查更新
        //刷新用户信息(测试说的多个手机同时登陆一个账号，在其中一个手机绑定了邮箱其他终端下拉刷新在没有更新状态，瞎搞)
        XLiveDataManager.getInstance().getUserInfo();
    }


    private void drawingMoney() {
        UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
        String phone = userInfo.getPhone();
        if (StringUtils.isEmpty(phone)) {
            ToastUtils.showLong("请绑定手机号后操作");
            return;
        }
        if (commission == null) {
            return;
        }
        goFragment(DrawingTabFragment.getInstance());
    }


    private void showHidePassWord() {
        String hideMoney = MathUtil.parseNumber(money);
        if (this.hideMoney) {
            centerEyeCommiss.setImageResource(R.mipmap.center_eyes_close);
            centerCommissMoney.setText(Utils.getHideMoney(hideMoney));
        } else {
            centerCommissMoney.setText(hideMoney);
            centerEyeCommiss.setImageResource(R.mipmap.center_eye_open);
        }
        MMKVUtil.put(CacheKey.USER_SHOW_MONEY, this.hideMoney);
    }


    /**
     * 用户选择头像弹窗
     */
    UpHeadPopup upHeadPopup;

    private void showHeadDialog() {
        upHeadPopup = DialogUtil.upHeadPopupDailog(this, new UpHeadPopup.Builder().setEnableCrop(true));
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PictureConfig.CHOOSE_REQUEST && data == null) {
            App.goPhoto = true;
        }
        if (requestCode == PictureConfig.CHOOSE_REQUEST && data != null) {

            List<LocalMedia> selectList = PictureSelector.obtainMultipleResult(data);

            String path = selectList.get(0).getCutPath();
            File file = new File(path);
            FileUtils.createOrExistsFile(file);
            showProgressDialog();
            mMyCenterViewModel.uploadFile(file);
        }

        if (requestCode == 10 && resultCode == 1001) {//支付密码绑定成功
            valueviewPayPassword.setTextValue("");
        }
    }


    private void goFragment(ISupportFragment supportFragment) {
        ((ABBaseFragment) getParentFragment()).start(supportFragment);
    }

}
