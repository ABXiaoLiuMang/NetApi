package com.ty.bwagent.bean;

/**
 * 提款记录筛选弹窗数据
 */
public class RecordFilterEntity {
    private String startDate;
    private String endDate;
    private int status;
    private int position;

    /**
     * 提款记录 使用
     * @param startDate
     * @param endDate
     * @param status
     * @param position
     */
    public RecordFilterEntity(String startDate, String endDate, int status,int position) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.position = position;
    }

    /**
     * 代理代存 代理转账 使用
     * @param startDate
     * @param endDate
     * @param status
     */
    public RecordFilterEntity(String startDate, String endDate, int status) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
