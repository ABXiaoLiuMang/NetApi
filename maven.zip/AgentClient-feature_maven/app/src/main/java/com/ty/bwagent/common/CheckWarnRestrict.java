package com.ty.bwagent.common;

/**
 * create by Mango on 2020/1/23
 */
public class CheckWarnRestrict {
    /**
     * address : 中国|香港|香港
     * ip : 218.189.125.130
     */

    private String address;
    private String ip;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
}