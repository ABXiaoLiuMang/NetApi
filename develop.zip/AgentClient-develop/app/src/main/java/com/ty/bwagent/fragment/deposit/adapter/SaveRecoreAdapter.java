package com.ty.bwagent.fragment.deposit.adapter;

import android.widget.TextView;

import androidx.annotation.LayoutRes;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.deposit.bean.DepositRecord;
import com.ty.bwagent.utils.Utils;


/**
 * 描述 代理代存记录 适配器
 * <p>
 * author:Dale
 */
public class SaveRecoreAdapter extends BaseQuickAdapter<DepositRecord.ListBean, BaseViewHolder> {


    public SaveRecoreAdapter() {
        super(R.layout.recycle_item_save);
    }

    @Override
    protected void convert(BaseViewHolder helper, DepositRecord.ListBean listBean) {
        helper.setText(R.id.tv_deposit_time,listBean.getCreatedAt());
        TextView deposit_state = helper.getView(R.id.tv_deposit_state);
        //403表示成功 其他表示失败，失败还有其他状态
        if(listBean.getDrawStatus() == 403){
            deposit_state.setText("成功");
            deposit_state.setBackgroundResource(R.mipmap.record_state_succ);
        }else {
            deposit_state.setText("失败");
            deposit_state.setBackgroundResource(R.mipmap.record_state_fail);
        }
        helper.setText(R.id.tv_deposit_account, listBean.getTransferMemberName());
        helper.setText(R.id.tv_deposit_money, Utils.roundDownMoney(listBean.getAmount()));
        helper.setText(R.id.tv_deposit_order, listBean.getBillNo());
        helper.setText(R.id.tv_deposit_note, listBean.getRemark());
        helper.setText(R.id.tv_save_type, listBean.getWithdrawType() == 20206 ? "佣金代存" : "额度代存");// 代存类型 20206 佣金代存 20205额度代存
    }

}
