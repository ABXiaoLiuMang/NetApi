package com.ty.bwagent.adapter;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.MMessage;
import com.ty.bwagent.bean.MessageSys;
import com.ty.utils.StringUtils;
import com.ty.view.CircleImageView;


/**
 * 描述 消息中心系统公告适配器
 * <p>
 * author:Dale
 */
public class MessageSysAdapter extends BaseQuickAdapter<MessageSys.ListBean, BaseViewHolder> {

    public MessageSysAdapter() {
        super(R.layout.recycle_item_message);
    }

    @Override
    protected void convert(BaseViewHolder helper, MessageSys.ListBean entity) {
        CircleImageView messageHead = helper.getView(R.id.message_head);
        helper.setText(R.id.message_title, entity.getTitle());
        helper.setText(R.id.message_time, entity.getCreatedAt());
        helper.setText(R.id.message_text, entity.getContent());
        helper.setVisible(R.id.message_dot, false);
//         messageHead.setImageResource(R.mipmap-xxhdpi.icon_message_cz_bg);
//         messageHead.setImageResource(R.mipmap-xxhdpi.icon_message_nba_bg);
//         messageHead.setImageResource(R.mipmap-xxhdpi.icon_message_sys_bg);
//         messageHead.setImageResource(R.mipmap-xxhdpi.icon_message_vip_bg);
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.mipmap.icon_message_cz_bg)
                .error(R.mipmap.icon_message_cz_bg);
        Glide.with(mContext).load(entity.getAppImageUrl()).apply(requestOptions).into(messageHead);
    }

}
