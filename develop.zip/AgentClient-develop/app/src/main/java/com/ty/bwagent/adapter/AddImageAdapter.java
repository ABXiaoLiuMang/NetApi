package com.ty.bwagent.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.Target;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.config.PictureMimeType;
import com.luck.picture.lib.entity.LocalMedia;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.ty.bwagent.R;
import com.ty.utils.FileUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.ToastUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 *
 */
public class AddImageAdapter extends RecyclerView.Adapter<AddImageAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<String> images = new ArrayList<>();//所以显示的图片 包括ADDI_MAGE
    private OnItemClickListener onItemClickListener;
    public static String ADDI_MAGE = "addimage";//显示+的图片
    private List<LocalMedia> selectMediaList = new ArrayList<>();
    private boolean isEdite = true;//是否是可编辑的

    public AddImageAdapter(Context context) {
        this.context = context;
    }

    public List<LocalMedia> getSelectMediaList() {
        return selectMediaList;
    }

    public void setEdite(boolean edite) {
        isEdite = edite;
    }

    //获取显示的图片 除了ADDI_MAGE
    public List<String> getImages() {
        ArrayList arrayList = new ArrayList();
        for (String image : images) {
            if (!image.equals(ADDI_MAGE)) {
                arrayList.add(image);
            }
        }
        return arrayList;
    }

    //获取需要上传服务器本地的图片
    public ArrayList<File> getNeedUpImages() {
        ArrayList<File> arrayList = new ArrayList();
        for (String image : images) {
            if (!PictureMimeType.isHttp(image) && !image.equals(ADDI_MAGE)) {
                File file = new File(image);
                FileUtils.createOrExistsFile(file);
                arrayList.add(file);
            }
        }
        return arrayList;
    }

    //放入数据
    public void setDate(ArrayList<String> images) {
        this.images = images;
        notifyDataSetChanged();
    }

    public String getItem(int postion) {
        return images.get(postion);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_youji_image, null));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        String imagPath = images.get(position);
        Glide.with(context).clear(holder.iv_image);
        if (imagPath.equals(ADDI_MAGE)) {
            holder.iv_image.setImageResource(R.mipmap.icon_pic_add);
            holder.iv_delete.setVisibility(View.GONE);
        } else {
            if (isEdite) {
                holder.iv_delete.setVisibility(View.VISIBLE);
            } else {
                holder.iv_delete.setVisibility(View.GONE);
            }
            Glide.with(context).load(imagPath).placeholder(R.mipmap.icon_image_error)
                    .error(R.mipmap.icon_image_error).override(Target.SIZE_ORIGINAL).into(holder.iv_image);
        }

        holder.iv_delete.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.OnDeleteClick(position, imagPath);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(holder.iv_image,position);
            }
        });

    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public int getItemCount() {
        int size = 0;
        if (images == null) {
            size = 0;
        } else if (images.size() < 6) {
            size = images.size();
        } else {
            size = 6;
        }
        return size;
    }

    //加入本地相册图片
    public void setLoacationDate(List<LocalMedia> selectMediaList) {
        if (selectMediaList == null) {
            return;
        }
        this.selectMediaList = selectMediaList;
        ArrayList<LocalMedia> imageMoreBig = new ArrayList<>();
        if (selectMediaList != null) {

            if (images.contains(ADDI_MAGE)) {
                images.remove(ADDI_MAGE);
            }

            for (int i = 0; i < selectMediaList.size(); i++) {
                if (new File(!selectMediaList.get(i).isCompressed() ? selectMediaList.get(i).getPath() : selectMediaList.get(i).getCompressPath()).length() / 1024 > 5 * 1024) {
                    imageMoreBig.add(selectMediaList.get(i));
                } else {
                    if (!images.contains(selectMediaList.get(i).getCompressPath())) {
                        images.add(selectMediaList.get(i).getCompressPath());
                    }
                }
            }
            if (images.size() < 6) {
                images.add(ADDI_MAGE);
            }
        }
        if (imageMoreBig.size() > 0) {
            selectMediaList.removeAll(imageMoreBig);
            PictureSelector.saveSelectorList(new Bundle(), selectMediaList);
            ToastUtils.showLong("图片压缩后大于5M");
        }
        notifyDataSetChanged();
    }

    //删除图片
    public void deletePosition(int position, String imagPath) {
        for (int i = 0; i < selectMediaList.size(); i++) {
            if (selectMediaList.get(i).getCompressPath().equals(imagPath)) {
                selectMediaList.remove(i);
            }
        }
        for (int i = 0; i < images.size(); i++) {
            if (images.get(i).equals(imagPath)) {
                images.remove(i);
            }
        }
        PictureSelector.saveSelectorList(new Bundle(), selectMediaList);
        if (images.size() < 6) {
            if (!images.contains(ADDI_MAGE)) {
                images.add(ADDI_MAGE);
            }
        }
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(ImageView imageView,int position);

        void OnDeleteClick(int position, String imagPath);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public final ImageView iv_image;
        public final ImageView iv_delete;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_image = itemView.findViewById(R.id.iv_image);

            iv_image.getLayoutParams().width = (ScreenUtils.getAppScreenWidth() - DensityUtil.dp2px(114 + 10 * 3)) / 3;
            iv_image.getLayoutParams().height = (ScreenUtils.getAppScreenWidth() - DensityUtil.dp2px(114 + 10 * 3)) / 3;

            iv_delete = itemView.findViewById(R.id.iv_delete);
        }
    }
}
