package com.ty.bwagent.fragment.finance.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.finance.bean.FinanceDetails;
import com.ty.bwagent.utils.Utils;
import com.ty.utils.MathUtil;
import com.ty.utils.StringUtils;


/**
 * 描述 :佣金 -冲正后输赢 - 净输赢
 * <p>
 * author:Dale
 */
public class FinanceDetailsAdapter extends BaseQuickAdapter<FinanceDetails, BaseViewHolder> {

    public FinanceDetailsAdapter() {
        super(R.layout.recycle_item_finance_details);
    }

    @Override
    protected void convert(BaseViewHolder helper, FinanceDetails entity) {
        helper.setText(R.id.tv_table_l, StringUtils.parseString(entity.getLevel()));//等级
        String money = Utils.roundDownMoney(entity.getMinAmount());
        helper.setText(R.id.tv_table_2, "≥" + money);//公司总输赢
        helper.setText(R.id.tv_table_3, "≥" + StringUtils.parseString(entity.getNum()));//活跃人数
        helper.setText(R.id.tv_table_4, MathUtil.twoNumber(entity.getRate() * 100) +"%");//佣金比例


        if(getItemCount() == 2){//表示只有一行数据，因为第一行是headView
            helper.setBackgroundRes(R.id.finance_rootView,R.drawable.finance_buttom_corners_w_bg);
        }else{
            if(helper.getAdapterPosition() % 2 == 0){

                if(helper.getAdapterPosition() + 1 == getItemCount()){//表示是最后一个
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_buttom_corners_x_bg);
                }else {
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_center_corners_x_bg);
                }

            }else {
                if(helper.getAdapterPosition() + 1 == getItemCount()){//表示是最后一个
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_buttom_corners_w_bg);
                }else {
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_center_corners_w_bg);
                }
            }
        }
    }

}
