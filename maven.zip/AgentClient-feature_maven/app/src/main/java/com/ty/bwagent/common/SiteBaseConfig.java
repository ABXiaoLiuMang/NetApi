package com.ty.bwagent.common;

public class SiteBaseConfig {
    private String agentAppDomainUrl;
    private String agentPcDomainUrl;
    private String agentQq;
    private String agentSkype;
    private String agentSugram;
    private String h5DomainUrl;

    private String name;
    private String pcDomainUrl;
    private String siteDomainUrl;
    private String siteLogoUrl;
    private String sportAppDomainUrl;

    private int submitMoreUnorde;
    private String title;
    private String webAppUrl;
    private String webLogoTitleUrl;
    private String webLogoUrl;

    public SiteBaseConfig() {
    }

    private String customerService;

    public String getAgentAppDomainUrl() {
        return agentAppDomainUrl;
    }

    public void setAgentAppDomainUrl(String agentAppDomainUrl) {
        this.agentAppDomainUrl = agentAppDomainUrl;
    }

    public String getAgentPcDomainUrl() {
        return agentPcDomainUrl;
    }

    public void setAgentPcDomainUrl(String agentPcDomainUrl) {
        this.agentPcDomainUrl = agentPcDomainUrl;
    }

    public String getAgentQq() {
        return agentQq;
    }

    public void setAgentQq(String agentQq) {
        this.agentQq = agentQq;
    }

    public String getAgentSkype() {
        return agentSkype;
    }

    public void setAgentSkype(String agentSkype) {
        this.agentSkype = agentSkype;
    }

    public String getAgentSugram() {
        return agentSugram;
    }

    public void setAgentSugram(String agentSugram) {
        this.agentSugram = agentSugram;
    }

    public String getH5DomainUrl() {
        return h5DomainUrl;
    }

    public void setH5DomainUrl(String h5DomainUrl) {
        this.h5DomainUrl = h5DomainUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPcDomainUrl() {
        return pcDomainUrl;
    }

    public void setPcDomainUrl(String pcDomainUrl) {
        this.pcDomainUrl = pcDomainUrl;
    }

    public String getSiteDomainUrl() {
        return siteDomainUrl;
    }

    public void setSiteDomainUrl(String siteDomainUrl) {
        this.siteDomainUrl = siteDomainUrl;
    }

    public String getSiteLogoUrl() {
        return siteLogoUrl;
    }

    public void setSiteLogoUrl(String siteLogoUrl) {
        this.siteLogoUrl = siteLogoUrl;
    }

    public String getSportAppDomainUrl() {
        return sportAppDomainUrl;
    }

    public void setSportAppDomainUrl(String sportAppDomainUrl) {
        this.sportAppDomainUrl = sportAppDomainUrl;
    }

    public int getSubmitMoreUnorde() {
        return submitMoreUnorde;
    }

    public void setSubmitMoreUnorde(int submitMoreUnorde) {
        this.submitMoreUnorde = submitMoreUnorde;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getWebAppUrl() {
        return webAppUrl;
    }

    public void setWebAppUrl(String webAppUrl) {
        this.webAppUrl = webAppUrl;
    }

    public String getWebLogoTitleUrl() {
        return webLogoTitleUrl;
    }

    public void setWebLogoTitleUrl(String webLogoTitleUrl) {
        this.webLogoTitleUrl = webLogoTitleUrl;
    }

    public String getWebLogoUrl() {
        return webLogoUrl;
    }

    public void setWebLogoUrl(String webLogoUrl) {
        this.webLogoUrl = webLogoUrl;
    }

    public String getCustomerService() {
        return customerService;
    }

    public void setCustomerService(String customerService) {
        this.customerService = customerService;
    }
}
