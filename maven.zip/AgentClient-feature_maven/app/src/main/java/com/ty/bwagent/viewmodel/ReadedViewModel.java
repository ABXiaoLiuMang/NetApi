package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UnRendTypeEntity;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

/**
 * 消息中心未读消息数量
 */
public class ReadedViewModel extends ViewModel {


    //分类类型消息未读量（通知，活动等）
    public void getUnreadForType() {
        NetSdk.create(Api.class)
                .getUnreadForType()
                .params("userSystem","2")//用户体系(空默认为会员)1会员，2代理
                .asJSONType()
                .send(XLiveDataManager.getInstance().unreadTypeLiveData);
    }
}
