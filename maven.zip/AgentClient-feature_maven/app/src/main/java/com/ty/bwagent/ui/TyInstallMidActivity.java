package com.ty.bwagent.ui;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.tianyu.tyinstall.TYInstall;
import com.tianyu.tyinstall.dao.TYInstallData;
import com.ty.utils.LogUtils;

import java.util.Map;

/**
 * 分发TyInstall跳转的中间页
 */
public class TyInstallMidActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 中间页，专门用来分发浏览器scheme携带回的intent数据
        // 或者可以根据返回的path进行分发跳转
        if (getIntent().getExtras() != null) {
            TYInstallData bean = TYInstall.getTyData();
            if (bean != null && bean.getParams() != null) {
                StringBuilder content = new StringBuilder();
                for (Map.Entry<String, String> entry : bean.getParams().entrySet()) {
                    content.append("key：").append(entry.getKey()).append("   value：").append(entry.getValue()).append("\n");
                }
                LogUtils.d("---> data = " + content.toString());
            }
        }
        finish();
    }
}
