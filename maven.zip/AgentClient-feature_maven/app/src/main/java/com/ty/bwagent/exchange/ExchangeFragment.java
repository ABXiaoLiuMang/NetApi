package com.ty.bwagent.exchange;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.GoUtils;
import com.ty.common.ui.ABBaseFragment;
import com.ty.utils.AppConfig;
import com.ty.utils.LogUtils;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.SpanBuilder;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ExchangeFragment extends ABBaseFragment implements View.OnClickListener{

    /**
     * View Tag
     */
    private static final String ONE = "1";
    private static final String tow = "2";
    private static final String three = "3";
    private static final String four = "4";
    private static final String five = "5";
    private static final String six = "6";
    private static final String seven = "7";
    private static final String eight = "8";
    private static final String nine = "9";
    private static final String zero = "0";
    private static final String addOrJian = "+/-";
    private static final String cheng = "x";
    private static final String chu = "÷";
    private static final String deng = "deng";
    private static final String back = "back";
    private static final String dot = "dot";

    public static final String TOP_RATE = "TOP_RATE";
    //    public static final String TOP_EXP = "TOP_EXP";
//    public static final String TOP_RESULT = "TOP_RESULT";
//    public static final String BOTTOM_EXP = "BOTTOM_EXP";
//    public static final String BOTTOM_RESULT = "BOTTOM_RESULT";
    public static final String BOTTOM_RATE = "BOTTOM_RATE";
    private static final String TOP_RATE_NAME = "日元";//跳登录界面的上部货币名字
    private static final String BOTTOM_RATE_NAME = "欧元";//跳登录界面的下部货币名字
    private static final String DEFAULT_RESULT = "18507";//跳登录界面的结果

    /**
     * 界面控件
     */
    private RelativeLayout ryTopExChange;//top 汇率总布局
    private RelativeLayout ryBottomExChange;//bottom 汇率总布局

    private EditText mEdBottomCalculatedExpression;//底部表达式
    private EditText mEdTopResult;//顶部editText结果
    private EditText mEdTopCalculatedExpression;//顶部达式
    private EditText mEdBottomResult;//底部editText结果
    public EditText mEdTopInputRate;//顶部汇率输入
    public EditText mEdBottomInputRate;//顶部汇率输入

    private TextView m7Btn;
    private TextView m8Btn;
    private TextView m9Btn;
    private TextView m4Btn;
    private TextView m5Btn;
    private TextView m6Btn;
    private TextView m1Btn;
    private TextView m2Btn;
    private TextView m3Btn;
    private TextView m0Btn;
    private TextView mDotBtn;
    private TextView tvTopRateAcronym;
    private TextView tvBottomRateAcronym;
    private RelativeLayout ryExchange;
    private RelativeLayout mAddJianBtn;
    private RelativeLayout mChengBtn;
    private RelativeLayout mChuBtn;
    private RelativeLayout mBackBtn;
    private RelativeLayout mDengBtn;
    private ConstraintLayout mCalculateButtonLy;
    private ConstraintLayout mCyBottomInputRate;
    private ExchangePopupWindow popupWindow;
    private TextView mTvTopRateName;//顶部汇率名称
    private TextView mTvBottomRateName;//底部汇率名称
    private View mainLines;//中间分割线
    private EditText edCurrentExpression;//当前选中计算表达式editText
    public EditText edCurrentResult;//当前选中结果editText
    private EditText edCurrentRate;//当前选中汇率
    private RelativeLayout ryBottomBlock;//动画底部区块
    private TextView tvMainTop;//顶部离/在线转换
    private RecyclerView recyclerView;
    private TextView tvSelectNameCurrent;//当前选择popupWindow 货币名称
    private TextView tvSelectAcronym;//当前选择popupWindow 货币名称缩写

    /**
     * 全局变量
     */

    boolean isOperateDown = false;//运算符是否已经按过一次，默认没有按过 false
    boolean isDotDown = false;//. 是否已经按过一次，默认没有按过 false
    private List<CurrencyData> dataLists;//popupWindow列表数据


    private CalculateState calculateState = new CalculateState();//计算逻辑标志位实体
    private boolean isStartAnimate = false;//动画标志位
    private Map<String, String> rateMap = new HashMap<>();//汇率集合
    private String topKey = "USD";//初始化汇率key
    private String bottomKey = "CNY";//初始化汇率key
//    private String requestKey = "USD_CNY";//初始化汇率key
    private String addOrJianS = "+";//初始化加号
    private int addOrJianSClick = 0;//初始化化0
    private boolean isOnlineRate = true;//是否在线标志位
    private String lastUpdateTime = "暂未更新";

    public String topRateString = "";
    public String bottomRateString = "";
    public boolean isConnectChange = true;
    private boolean isReRequestFoucs = false;//是否是重新进入掩护页,不需要清除控件数据


    @Override
    protected int getLayoutId() {
        return R.layout.exchange_fragment_save;
    }

    @Override
    protected void createProvider() {

    }

    @Override
    protected void initViewsAndEvents() {

        initView();
        isReRequestFoucs = false;
        hideSoftInputMethod(mEdTopCalculatedExpression);
        hideSoftInputMethod(mEdBottomCalculatedExpression);

        hideSoftInputMethod(mEdTopResult);
        hideSoftInputMethod(mEdBottomResult);

        hideSoftInputMethod(mEdTopInputRate);
        hideSoftInputMethod(mEdBottomInputRate);
        tvSelectNameCurrent = mTvTopRateName;

        mBackBtn.setOnLongClickListener(view -> {
            isDotDown = false;
            isOperateDown = false;
            if (mEdTopResult.isFocused() || mEdBottomResult.isFocused()) {
                clearResultAndExp();
                setEdEnable(true);
            }
            return false;
        });

        ryTopExChange.setOnClickListener(view -> popupWindow(ryTopExChange));
        ryBottomExChange.setOnClickListener(view -> popupWindow(ryBottomExChange));


        dataLists = new ArrayList<>();
        dataLists.add(new CurrencyData().setCode("USD").setName("美元"));
        dataLists.add(new CurrencyData().setCode("CNY").setName("人民币"));
        dataLists.add(new CurrencyData().setCode("AUD").setName("澳大利亚元"));
        dataLists.add(new CurrencyData().setCode("RUB").setName("俄罗斯卢布"));
        dataLists.add(new CurrencyData().setCode("PHP").setName("菲律宾比索"));
        dataLists.add(new CurrencyData().setCode("KRW").setName("韩元"));
        dataLists.add(new CurrencyData().setCode("CAD").setName("加拿大元"));
        dataLists.add(new CurrencyData().setCode("JPY").setName("日元"));
        dataLists.add(new CurrencyData().setCode("SEK").setName("瑞典克朗"));
        dataLists.add(new CurrencyData().setCode("THB").setName("泰铢"));
        dataLists.add(new CurrencyData().setCode("SGD").setName("新加坡元"));
        dataLists.add(new CurrencyData().setCode("GBP").setName("英镑"));
        dataLists.add(new CurrencyData().setCode("MYR").setName("马来西亚元"));
        dataLists.add(new CurrencyData().setCode("EUR").setName("欧元"));


        mEdTopResult.requestFocus();

        Map<String, String> rate = CacheRate.getRate();
        if (rate != null) {
            rateMap = rate;
        }

//        if (!TextUtils.isEmpty(lastUpdateTime)) {
            lastUpdateTime = CacheRate.getUpdateTime();
//        }
        tvMainTop.setText(lastUpdateTime);

        mEdTopInputRate.setText("1");
        mEdBottomInputRate.setText(rateMap.get(bottomKey));
//        presenter.exChange(requestKey);
        mEdTopResult.setHint("1");
        calculateExchange(true);
        if (!AppConfig.hasAtBgLimit()) {
            mTvTopRateName.setText(TOP_RATE_NAME);
            mTvBottomRateName.setText(BOTTOM_RATE_NAME);
            mEdTopResult.setText(DEFAULT_RESULT);
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    private void initView() {
        ryTopExChange = rootView.findViewById(R.id.ry_change_source);
        ryTopExChange.setOnClickListener(this);
        ryBottomExChange = rootView.findViewById(R.id.ry_change_target);
        ryBottomExChange.setOnClickListener(this);

        ryBottomBlock = rootView.findViewById(R.id.ry_bottom_block);
        tvMainTop = rootView.findViewById(R.id.tv_top);
        tvMainTop.setOnClickListener(view -> {
            if (!isOnlineRate) {
                setOnline();
//                presenter.exChange(requestKey);
            } else {
                setOffLine();
            }
        });

        mCyBottomInputRate = rootView.findViewById(R.id.cy_bottom_input);

        mainLines = rootView.findViewById(R.id.main_line);

        mEdBottomCalculatedExpression = rootView.findViewById(R.id.ed_calculated_expression_bottom);
        mEdBottomCalculatedExpression.setOnClickListener(this);

        mEdTopResult = rootView.findViewById(R.id.tv_top_result);
        mEdTopResult.addTextChangedListener(new EdResultWatcher(mEdTopResult, this));
        mEdTopResult.setOnFocusChangeListener((view, isFocus) -> {
            if (isFocus) {
                edCurrentExpression = mEdTopCalculatedExpression;
                edCurrentResult = (EditText) view;
                restAnimate();
                if (!isReRequestFoucs) {
                    clearResultAndExp();
                }
            }
        });

        mEdBottomResult = rootView.findViewById(R.id.tv_top_result_2);
        mEdBottomResult.addTextChangedListener(new EdResultWatcher(mEdBottomResult, this));
        mEdBottomResult.setOnFocusChangeListener((view, isFocus) -> {
            if (isFocus) {
                edCurrentExpression = mEdBottomCalculatedExpression;
                edCurrentResult = (EditText) view;
                startAnimate();
                clearResultAndExp();
            }
        });


        mEdTopCalculatedExpression = rootView.findViewById(R.id.ed_calculated_expression);
        mEdTopCalculatedExpression.setOnClickListener(this);


        /**
         * 头部部汇率输入Ed
         */
        mEdTopInputRate = rootView.findViewById(R.id.ed_top_input_rate);
        mEdTopInputRate.addTextChangedListener(new EdRateWatcher(mEdTopInputRate, this));
        mEdTopInputRate.setOnFocusChangeListener((view, isFocus) -> {
            if (isFocus) {
                isConnectChange = false;
                edCurrentRate = (EditText) view;
                topRateString = ((EditText) view).getText().toString();
            }
        });

        /**
         * 底部汇率输入Ed
         */
        mEdBottomInputRate = rootView.findViewById(R.id.ed_bottom_input_rate);
        mEdBottomInputRate.addTextChangedListener(new EdRateWatcher(mEdBottomInputRate, this));
        mEdBottomInputRate.setOnFocusChangeListener((view, isFocus) -> {
            if (isFocus) {
                isConnectChange = false;
                edCurrentRate = (EditText) view;
                bottomRateString = ((EditText) view).getText().toString();
            }
        });
        edCurrentRate = mEdTopInputRate;

        m7Btn = rootView.findViewById(R.id.btn_7);
        m7Btn.setOnClickListener(this);
        m8Btn = rootView.findViewById(R.id.btn_8);
        m8Btn.setOnClickListener(this);
        m9Btn = rootView.findViewById(R.id.btn_9);
        m9Btn.setOnClickListener(this);
        mAddJianBtn = rootView.findViewById(R.id.btn_add_jian);
        mAddJianBtn.setOnClickListener(this);
        m4Btn = rootView.findViewById(R.id.btn_4);
        m4Btn.setOnClickListener(this);
        m5Btn = rootView.findViewById(R.id.btn_5);
        m5Btn.setOnClickListener(this);
        m6Btn = rootView.findViewById(R.id.btn_6);
        m6Btn.setOnClickListener(this);
        mChengBtn = rootView.findViewById(R.id.btn_cheng);
        mChengBtn.setOnClickListener(this);
        m1Btn = rootView.findViewById(R.id.btn_1);
        m1Btn.setOnClickListener(this);
        m2Btn = rootView.findViewById(R.id.btn_2);
        m2Btn.setOnClickListener(this);
        m3Btn = rootView.findViewById(R.id.btn_3);
        m3Btn.setOnClickListener(this);
        mChuBtn = rootView.findViewById(R.id.btn_chu);
        mChuBtn.setOnClickListener(this);
        m0Btn = rootView.findViewById(R.id.btn_0);
        m0Btn.setOnClickListener(this);
        mDotBtn = rootView.findViewById(R.id.btn_dot);
        mDotBtn.setOnClickListener(this);
        mBackBtn = rootView.findViewById(R.id.btn_back);
        mBackBtn.setOnClickListener(this);
        mDengBtn = rootView.findViewById(R.id.btn_deng);
        mDengBtn.setOnClickListener(this);
        mCalculateButtonLy = rootView.findViewById(R.id.ly_calculate_button);
        mCalculateButtonLy.setOnClickListener(this);
        mTvTopRateName = rootView.findViewById(R.id.tv_source_bi);
        mTvBottomRateName = rootView.findViewById(R.id.tv_target_bi);
        ryExchange = rootView.findViewById(R.id.ry_exchange);

        tvTopRateAcronym = rootView.findViewById(R.id.tv_top_rate);
        tvBottomRateAcronym = rootView.findViewById(R.id.tv_bottom_rate);

        ryExchange.setOnClickListener(view -> exChangeRate());
    }


    public void reQuestResultFocus() {
        if (mEdTopResult != null) {
            isReRequestFoucs = true;
            mEdTopResult.requestFocus();
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    private void hideSoftInputMethod(EditText editText) {
        editText.setLongClickable(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            editText.setCustomInsertionActionModeCallback(new ActionModeCallbackInterceptor());
        }
        Class<EditText> cls = EditText.class;
        Method method;
        try {
            method = cls.getMethod("setShowSoftInputOnFocus", boolean.class);
            method.setAccessible(true);
            method.invoke(editText, false);
        } catch (Exception e) {
        }
    }

    /**
     * desc: 不可以加fastclick,影响键盘输入体验
     *
     * @author Jeff created on 2018/10/19 10:33
     */
    @Override
    public void onClick(View v) {
        if (v.getTag() instanceof String) {
            switch ((String) v.getTag()) {
                case ONE:
                case tow:
                case three:
                case four:
                case five:
                case six:
                case seven:
                case eight:
                case nine:
                case zero:
                    addOrJianSClick = 0;
                    if (isRateEd()) {
                        ExchangeProcessor.numDown(((TextView) v).getText().toString(), edCurrentExpression, edCurrentRate, calculateState, this);
                    } else {
                        ExchangeProcessor.numDown(((TextView) v).getText().toString(), edCurrentExpression, edCurrentResult, calculateState, this);
                    }
                    break;
                case dot:
                    addOrJianSClick = 0;
                    if (isRateEd()) {
                        ExchangeProcessor.dotDown(edCurrentExpression, edCurrentRate);
                    } else {
                        ExchangeProcessor.dotDown(edCurrentExpression, edCurrentResult);
                    }
                    break;
                case addOrJian:
                    addOrJianSClick++;
                    if (addOrJianSClick == 2) {
                        addOrJianSClick = 0;
                        if (addOrJianS.equals("+")) {
                            addOrJianS = "-";
                        } else {
                            addOrJianS = "+";
                        }
                    }
                    if (isRateEd()) {
                        ExchangeProcessor.operatorDown(addOrJianS, edCurrentExpression, edCurrentRate, calculateState);
                    } else {
                        ExchangeProcessor.operatorDown(addOrJianS, edCurrentExpression, edCurrentResult, calculateState);
                    }
                    break;
                case cheng:
                    addOrJianSClick = 0;
                    if (!isRateEd()) {
                        ExchangeProcessor.operatorDown("×", edCurrentExpression, edCurrentResult, calculateState);
                    }
                    break;
                case chu:
                    addOrJianSClick = 0;
                    if (!isRateEd()) {
                        ExchangeProcessor.operatorDown("÷", edCurrentExpression, edCurrentResult, calculateState);
                    }
                    break;
                case deng:
                    edCurrentResult.requestFocus();
                    addOrJianSClick = 0;
                  /*  if (!isFirstEq) {
                        isFirstEq = true;
                    }*/
                    go2Login();
                    ExchangeProcessor.equal(edCurrentExpression, edCurrentResult, calculateState);
                    String s = edCurrentResult.getText().toString();
                    if ("0".equals(s)) {
                        edCurrentResult.setText("");
                        edCurrentResult.setHint("1000");
                    }
                    if (s.length() == 0) {
                        calculateExchange(true);
                    } else {
                        calculateExchange(false);
                    }
                    if (isClear()) {
                        setEdEnable(true);
                    } else {
                        setEdEnable(false);
                    }
                    break;
                case back:
                    addOrJianSClick = 0;
                    if (isClear()) {
                        setEdEnable(true);
                    } else {
                        setEdEnable(false);
                    }
                    if (isRateEd()) {
                        ExchangeProcessor.backSpace(edCurrentExpression, edCurrentRate, calculateState, this);
                    } else {
                        if (isCurrentEmpty()) {
                            clearResultAndExp();
                            setEdEnable(true);
                        }
                        ExchangeProcessor.backSpace(edCurrentExpression, edCurrentResult, calculateState, this);
                    }
                    break;
                default:
                    break;
            }
        }

    }


    private void popupWindow(View view) {
        if (view == ryTopExChange) {
            tvSelectNameCurrent = mTvTopRateName;//货币名称TextView
            tvSelectAcronym = tvTopRateAcronym;//货币缩写TextView
        } else if (view == ryBottomExChange) {
            tvSelectNameCurrent = mTvBottomRateName;//货币名称TextView
            tvSelectAcronym = tvBottomRateAcronym;//货币缩写TextView
        }
        ExchangePopupWindow.Builder builder = new ExchangePopupWindow.Builder(getActivity());
        popupWindow = builder.setWidthAndHeight(SizeUtils.dp2px(92), SizeUtils.dp2px(160)).setView(R.layout.exchange_popu).setAnimationStyle(R.style.AnimTop).create();
        View contentView = popupWindow.getContentView();
        RecyclerView recyclerView = contentView.findViewById(R.id.recycler_view);
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(R.layout.exchange_item, dataLists);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        popupWindow.showAsDropDown(view);
    }

    public void onRate() {
        if (tvSelectNameCurrent == mTvTopRateName) {

            BigDecimal topDecimal = new BigDecimal(rateMap.get(topKey));
            double top = topDecimal.setScale(4,BigDecimal.ROUND_DOWN).doubleValue();

            BigDecimal bottomDecimal = new BigDecimal(rateMap.get(bottomKey));
            double bottom = bottomDecimal.setScale(4,BigDecimal.ROUND_DOWN).doubleValue();
            String value = MathUtil.twoNumber(MathUtil.divide(bottom,top,4));

            mEdTopInputRate.setText("1");
            topRateString = "1";
            mEdBottomInputRate.setText(value);
            bottomRateString = value;
        } else {
            BigDecimal topDecimal = new BigDecimal(rateMap.get(topKey));
            double top = topDecimal.setScale(4,BigDecimal.ROUND_DOWN).doubleValue();

            BigDecimal bottomDecimal = new BigDecimal(rateMap.get(bottomKey));
            double bottom = bottomDecimal.setScale(4,BigDecimal.ROUND_DOWN).doubleValue();
            String value = MathUtil.twoNumber(MathUtil.divide(top,bottom,4));

            mEdTopInputRate.setText(value);
            topRateString = value;
            mEdBottomInputRate.setText("1");
            bottomRateString = "1";
        }

        isConnectChange = true;
        if (edCurrentResult.getText().toString().length() == 0) {
            calculateExchange(true);
        } else {
            calculateExchange(false);
        }
    }
    public void onRate(String key, String value) {
//        rateMap.put(key, value);
        if (tvSelectNameCurrent == mTvTopRateName) {
            mEdTopInputRate.setText("1");
            mEdBottomInputRate.setText(value);
            topRateString = "1";
            bottomRateString = value;
        } else {
            mEdTopInputRate.setText(value);
            mEdBottomInputRate.setText("1");
            bottomRateString = "1";
            topRateString = value;
        }

//        if (this.isOnlineRate) {
//            formatTime();
//        }
        isConnectChange = true;
        if (edCurrentResult.getText().toString().length() == 0) {
            calculateExchange(true);
        } else {
            calculateExchange(false);
        }
    }

//    @Override
//    public boolean isOnlineRate() {
//        return this.isOnlineRate;
//    }
//
//    @Override
//    public Map<String, String> getRateMap() {
//        return rateMap;
//    }
//
//    @Override
//    public void getVersionSuc(VersionInfoEntity versionInfoEntity) {
////        UpdateUtil.showUpdateDialog(getActivity(), versionInfoEntity);
//    }
//
//    @Override
//    public void Error() {
//
//    }

    class RecyclerViewAdapter extends BaseQuickAdapter<CurrencyData, BaseViewHolder> {
        private String selected;

        public RecyclerViewAdapter(int layoutResId, @Nullable List<CurrencyData> data) {
            super(layoutResId, data);
            selected = tvSelectAcronym.getText().toString();
        }

        @Override
        protected void convert(BaseViewHolder helper, CurrencyData item) {
            TextView content = helper.getView(R.id.tv_content);
            TextView code = helper.getView(R.id.tv_code);
            code.setText(item.getCode());
            content.setText(item.getName());
            LinearLayout linearLayout = helper.getView(R.id.ly_item);
            if (item.getCode().equals(selected)) {
                linearLayout.setBackground(ResUtils.getDrawable(R.drawable.exchange_pull_down_list_text_bg));
            } else {
                linearLayout.setBackground(null);
            }

            linearLayout.setOnClickListener(v -> {
                linearLayout.setBackground(ResUtils.getDrawable(R.drawable.exchange_pull_down_list_text_bg));
                tvSelectNameCurrent.setText(item.getName());
                tvSelectAcronym.setText(item.getCode());

                if (tvSelectNameCurrent == mTvTopRateName) {
                    topKey = item.getCode();
//                    requestKey = item.getCode() + "_" + tvBottomRateAcronym.getText().toString();
                } else {
                    bottomKey = item.getCode();
//                    requestKey = item.getCode() + "_" + tvTopRateAcronym.getText().toString();
                }
                onRate();
                if (popupWindow != null) {
                    popupWindow.dismiss();
                }
//                presenter.exChange(requestKey);
            });
        }
    }


    private void startAnimate() {
        if (!isStartAnimate) {
            AnimationFactory.startExChangeIcon(ryExchange);
            AnimationFactory.startLineBlock(mainLines);
            AnimationFactory.startLineBlock(mEdTopResult);
            AnimationFactory.startSelect(ryBottomBlock);
            AnimationFactory.startSelect(ryBottomExChange);
            AnimationFactory.startSelect(mCyBottomInputRate);
            mEdBottomResult.setTextSize(38);
            mEdBottomResult.setTextColor(ResUtils.getColor(R.color.exchange_white));
            mEdTopResult.setTextSize(30);
            mEdTopResult.setTextColor(ResUtils.getColor(R.color.exchange_888888));
            mEdBottomResult.setSelection(mEdBottomResult.getText().toString().length());
            isStartAnimate = true;
        }
    }

    private void restAnimate() {
        if (isStartAnimate) {
            AnimationFactory.restExChangeIcon(ryExchange);
            AnimationFactory.restLineBlock(mainLines);
            AnimationFactory.restLineBlock(mEdTopResult);
            AnimationFactory.restSelect(ryBottomBlock);
            AnimationFactory.restSelect(ryBottomExChange);
            AnimationFactory.restSelect(mCyBottomInputRate);
            mEdBottomResult.setTextSize(30);
            mEdBottomResult.setTextColor(ResUtils.getColor(R.color.exchange_888888));

            mEdTopResult.setTextSize(38);
            mEdTopResult.setTextColor(ResUtils.getColor(R.color.exchange_white));
            mEdTopResult.setSelection(mEdTopResult.getText().toString().length());
            isStartAnimate = false;
        }
    }

    private void exChangeRate() {

        //变换货币名称
        String rateName = mTvTopRateName.getText().toString();
        mTvTopRateName.setText(mTvBottomRateName.getText().toString());
        mTvBottomRateName.setText(rateName);
        //变换货币缩写名称
        String rateAcronym = tvTopRateAcronym.getText().toString();
        tvTopRateAcronym.setText(tvBottomRateAcronym.getText().toString());
        tvBottomRateAcronym.setText(rateAcronym);
        //变换货币输入汇率
        String inputRate = mEdTopInputRate.getText().toString();
        mEdTopInputRate.setText(mEdBottomInputRate.getText().toString());
        mEdBottomInputRate.setText(inputRate);

        //变换输入值框结果
        String result = mEdTopResult.getText().toString();
        mEdTopResult.setText(mEdBottomResult.getText().toString());
        mEdTopResult.setSelection(mEdTopResult.getText().toString().length());
        mEdBottomResult.setText(result);
        mEdBottomResult.setSelection(mEdBottomResult.getText().toString().length());

        //变换表达式
        String exp = mEdTopCalculatedExpression.getText().toString();
        mEdTopCalculatedExpression.setText(mEdBottomCalculatedExpression.getText().toString());
        mEdBottomCalculatedExpression.setText(exp);

    }

    public void calculateExchange(boolean isHint) {
        try {
            String top = mEdTopInputRate.getText().toString();
            String bottom = mEdBottomInputRate.getText().toString();
            double topValue = new BigDecimal(top).doubleValue();
            double bottomValue = new BigDecimal(bottom).doubleValue();
            String rate;
            if (edCurrentResult == mEdTopResult) {
                String s = new BigDecimal(bottomValue / topValue).toPlainString();
                rate = ExchangeProcessor.calculateRate(s, isHint ? edCurrentResult.getHint().toString() : edCurrentResult.getText().toString(), true);
                if (isHint) {
                    mEdBottomResult.setHint(rate);
                } else {
                    mEdBottomResult.setText(rate);
                }
                format(mEdBottomResult, isHint);
                mEdBottomResult.setSelection(mEdBottomResult.getText().toString().length());
            } else {
                String s = new BigDecimal(topValue / bottomValue).toPlainString();
                rate = ExchangeProcessor.calculateRate(s, isHint ? edCurrentResult.getHint().toString() : edCurrentResult.getText().toString(), true);
                if (isHint) {
                    mEdTopResult.setHint(rate);
                } else {
                    mEdTopResult.setText(rate);
                }
                mEdTopResult.setSelection(mEdTopResult.getText().toString().length());
                format(mEdTopResult, isHint);
            }
        } catch (Exception e) {
        }
    }

    private void go2Login() {
        String topRateName = mTvTopRateName.getText().toString();
        String bottomRateName = mTvBottomRateName.getText().toString();
        String sTopResult = mEdTopResult.getText().toString().replace(",", "");
        if (TextUtils.equals(topRateName, TOP_RATE_NAME) && TextUtils.equals(bottomRateName, BOTTOM_RATE_NAME) && TextUtils.equals(sTopResult, DEFAULT_RESULT)) {
            GoUtils.checkSwitch(getActivity());
        }
//        else if (TextUtils.equals(sTopResult, "888811118888")) {
////            ArrayList<EnviromentType> arrayList = new ArrayList<>();
////
////            arrayList.add(EnviromentType.DEBUG);
////            arrayList.add(EnviromentType.GELI_PRE_RELEASE);
////            arrayList.add(EnviromentType.PRE_RELEASE);
////            arrayList.add(EnviromentType.RELEASE);
////            mAdapter = new ListAdapter();
////            mAdapter.setNewData(arrayList);
////            mBankListDialog = new BottomMenuListDialog.Builder(getContext())
////                    .setCanCancel(false)
////                    .setShadow(true)
////                    .setTitle("选择环境")
////                    .setAdapter(mAdapter)
////                    .create();
////            mBankListDialog.show();
////
////
////            mAdapter.setOnItemClickListener((adapter, view, position) -> {
////                if (arrayList != null && arrayList.size() > 0) {
////                    EnviromentType platIte = arrayList.get(position);
////                    if (null != platIte) {
////                        ToastUtil.show("环境已设置，请退出重新进入");
////                        SharedPreferencesUtil.setPrefString("enviros", platIte.getSort());
////                    }
////                    mBankListDialog.dismiss();
////                }
////            });
////        }


    }


    public void clearResultAndExp() {
        if (mEdTopResult != null) {
            mEdTopResult.setText("");
        }
        if (mEdBottomResult != null) {
            mEdBottomResult.setText("");
        }
        if (mEdTopCalculatedExpression != null) {
            mEdTopCalculatedExpression.setText("");
        }
        if (mEdBottomCalculatedExpression != null) {
            mEdBottomCalculatedExpression.setText("");
        }
    }

    private void format(EditText format, boolean isHint) {
        if (isHint) {
            String coma = StringUtils.addComa(format.getHint().toString().trim().replaceAll(",", ""));
            format.setHint(coma);
            format.setSelection(format.getText().toString().length());
        } else {
            format.setText(StringUtils.addComa(format.getText().toString().trim().replaceAll(",", "")));
            format.setSelection(format.getText().toString().length());
        }
    }

    private boolean isClear() {
        return mEdTopResult.getText().toString().length() == 0
                && mEdTopCalculatedExpression.getText().toString().length() == 0
                && mEdBottomResult.getText().toString().length() == 0
                && mEdBottomCalculatedExpression.getText().toString().length() == 0;
    }

    private boolean isCurrentEmpty() {
        return edCurrentExpression.getText().toString().length() == 0 && edCurrentResult.getText().toString().length() == 0;
    }


    public void setEdEnable(boolean isFocus) {
        if (!isFocus) {
            if (edCurrentResult == mEdTopResult) {
                mEdBottomResult.setEnabled(false);
            } else {
                mEdTopResult.setEnabled(false);
            }
        } else {
            mEdBottomResult.setEnabled(true);
            mEdTopResult.setEnabled(true);
        }
    }
//
//    private void formatTime() {
//        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
//        String format1 = format.format(new Date());
//        lastUpdateTime = "更新于" + format1;
//        tvMainTop.setText(lastUpdateTime);
//    }

    private boolean isRateEd() {
        return mEdTopInputRate.isFocused() || mEdBottomInputRate.isFocused();
    }

    public void setOnline() {
        isOnlineRate = true;
        tvMainTop.setText(lastUpdateTime);
        tvMainTop.setTextColor(ResUtils.getColor(R.color.exchange_888888));
        tvMainTop.setAutoLinkMask(0);
    }

    public void setOffLine() {
        isOnlineRate = false;
        tvMainTop.setTextColor(ResUtils.getColor(R.color.exchange_top_text));
        SpanBuilder spanBuilder = StringUtil.getSpanBuilder();
        spanBuilder.append(ResUtils.getString(R.string.exchange_online_recover)).setUnderline();
        tvMainTop.setText(spanBuilder.create());
    }



    @Override
    public void onPause() {
        super.onPause();
        CacheRate.saveRate(rateMap);
        CacheRate.setUpdateTime(lastUpdateTime);
    }

    @Override
    public void onSupportInvisible() {
        super.onSupportInvisible();

    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtils.e("onStop");
        if (popupWindow != null) {
            popupWindow.dismiss();
        }
    }

}
