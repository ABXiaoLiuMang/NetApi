package com.ty.bwagent.dialog;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.lxj.xpopup.impl.PartShadowPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 推广筛选对话框
 */
public class ExtensionFilterPopup extends PartShadowPopupView implements View.OnClickListener {

    private List<String> titleName;
    Context mContext;
    public MutableLiveData<String> filterYuMingLiveData = new MutableLiveData<>();
    private List<String> stateList = new ArrayList<>();
    private TextView tv_fliter;

    public ExtensionFilterPopup(@NonNull Context context) {
        super(context);
        this.mContext = context;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_extension_filter;
    }


    @Override
    protected void onCreate() {
        super.onCreate();

        initView();
        initDate();
        addStates();
    }

    private void initView() {
        TextView tv_sure = findViewById(R.id.tv_sure);
        tv_fliter = findViewById(R.id.tv_fliter);
        tv_sure.setOnClickListener(this);
        tv_fliter.setOnClickListener(this);
    }

    private void initDate() {
        titleName = Arrays.asList("全部", "主站H5", "主站PC", "全站APP", "体育APP");
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_sure:
                filterYuMingLiveData.postValue(tv_fliter.getText().toString().trim());
                dismiss();
                break;
            case R.id.tv_fliter:
                DialogUtil.createSelectItemDailog(mContext, new SelectDialogItemPopup.Builder().setTitle("状态")
                        .setDateList(stateList).setHasShadowBg(false).setSelectName(tv_fliter.getText().toString().trim()).setOnClickListener(currentItem -> {
                            tv_fliter.setText(stateList.get(currentItem));
                        })
                );
                break;
        }
    }

    private void addStates() {
        stateList.add("全部");
        stateList.add("无法申请");
        stateList.add("可以申请");
        stateList.add("待审核");
        stateList.add("审核通过");
        stateList.add("审核拒绝");
        stateList.add("系统驳回");
    }


}
