package com.ty.bwagent.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.MemberFinalCommissionAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.TeamCommissionEntity;
import com.ty.bwagent.viewmodel.NewMemberCenterViewModel;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;


public class MemberFinacialCommisionFragment extends ABRefreshFragment<TeamCommissionEntity.ListBean> {

    NewMemberCenterViewModel mNewMemberCenterViewModel;
    TextView tv_message;
    ImageView iv_logo;

    private String searchAgentName;
    private String searchCommissionDate;
    int pageNum = 1;
    int pageSize = 15;

    private int fragPosition;
    private List<TeamCommissionEntity.ListBean> listBeans;


    /**
     * @param position
     * @return
     */
    public static MemberFinacialCommisionFragment getInstance(int position) {
        MemberFinacialCommisionFragment fragment = new MemberFinacialCommisionFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ABConfig.KEY_TAG, position);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void createProvider() {
        mNewMemberCenterViewModel = new ViewModelProvider(this).get(NewMemberCenterViewModel.class);

        mNewMemberCenterViewModel.teamCommissionListLiveData.observe(this, new NetObserver<BaseEntity<TeamCommissionEntity>>() {

            @Override
            protected void onSuccess(BaseEntity<TeamCommissionEntity> teamCommissionInfo) {
                dismissProgressDialog();
                if (teamCommissionInfo == null || (teamCommissionInfo != null && teamCommissionInfo.getData() == null)) {
                    return;
                }
                listBeans = teamCommissionInfo.getData().getList();
                if (pageNum == 1) {
                    if (fragPosition == 2) {//团队佣金要增加团队这个信息
                        TeamCommissionEntity.TotalSumVo totalSumVo = teamCommissionInfo.getData().getTotalSumVo();
                        if (totalSumVo != null) {
                            TeamCommissionEntity.ListBean listBean = new TeamCommissionEntity.ListBean();
                            listBean.setAgentName("团队");
                            listBean.setSubordinateUserCount(totalSumVo.getSubordinateUserCountSum());//下级人数
                            listBean.setRate(totalSumVo.getRate());//佣金比例
                            listBean.setActive(totalSumVo.getActiveSum());//活跃人数
                            listBean.setNetProfit(totalSumVo.getNetProfitSum());//净输赢
                            listBean.setCzProfit(totalSumVo.getCzProfitSum());//冲正后净输赢
                            listBean.setLastBalance(totalSumVo.getLastBalanceSum());//上月结余
                            listBean.setCorrection(totalSumVo.getCorrectionSum());//佣金调整
                            listBean.setCommission(totalSumVo.getCommissionSum());//佣金
                            listBeans.add(0,listBean);
                        }
                    }
                    listAdapter.setNewData(listBeans);
                    refreshLayout.finishRefresh();
                } else {
                    listAdapter.addData(listBeans);
                    refreshLayout.finishLoadMore();
                }
                if (teamCommissionInfo != null && teamCommissionInfo.getData() != null) {
                    pageNum = teamCommissionInfo.getData().getPageNum();
                    if (pageNum == teamCommissionInfo.getData().getPages()) {
                        refreshLayout.finishLoadMoreWithNoMoreData();
                    }
                }
                iv_logo.setImageResource(R.mipmap.message_empty_bg);
                tv_message.setText("暂无数据");
            }

            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                ToastUtils.showLong(errMsg);
                if (pageNum == 1) {
                    iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
                    tv_message.setText("网络不给力");
                    refreshLayout.finishLoadMoreWithNoMoreData();
                    refreshLayout.finishRefresh();
                } else {
                    refreshLayout.finishLoadMore();
                }
            }
        });

    }

    private boolean isFirst = true;

    @Override
    public void onResume() {
        super.onResume();
        if (isFirst) {//懒加载处理
            isFirst = false;
            initView();
        }
    }

    private void initView() {
        fragPosition = bundle.getInt(ABConfig.KEY_TAG);
        searchAgentName = "";
        searchCommissionDate = TimeUtils.getDiffMonth(-1);
        mNewMemberCenterViewModel.commissionList(searchAgentName, searchCommissionDate, pageNum, pageSize);
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_member_center;
    }


    public void searchDate(String searchAgentName, String searchCommissionDate) {
        pageNum = 1;
        KeyboardUtils.hideSoftInput(getActivity());
        this.searchAgentName = searchAgentName;
        this.searchCommissionDate = searchCommissionDate;
        showProgressDialog();
        mNewMemberCenterViewModel.commissionList(searchAgentName, searchCommissionDate, pageNum, pageSize);
    }


    @Override
    public BaseQuickAdapter<TeamCommissionEntity.ListBean, BaseViewHolder> getListAdapter() {
        return new MemberFinalCommissionAdapter(bundle.getInt(ABConfig.KEY_TAG));
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {

    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }


    @Override
    public View getEmptyView() {
        View empty = View.inflate(mContext, R.layout.empty_message, null);
        iv_logo = empty.findViewById(R.id.iv_image);
        tv_message = empty.findViewById(R.id.tv_message);
        tv_message.setText("暂无数据");
        return empty;
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum++;
        mNewMemberCenterViewModel.commissionList(searchAgentName, searchCommissionDate, pageNum, pageSize);
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        pageNum = 1;
        mNewMemberCenterViewModel.commissionList(searchAgentName, searchCommissionDate, pageNum, pageSize);
    }

}
