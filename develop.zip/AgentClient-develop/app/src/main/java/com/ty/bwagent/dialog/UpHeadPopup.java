package com.ty.bwagent.dialog;

import android.content.pm.ActivityInfo;
import android.view.View;
import android.widget.TextView;

import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.config.PictureConfig;
import com.luck.picture.lib.config.PictureMimeType;
import com.luck.picture.lib.entity.LocalMedia;
import com.luck.picture.lib.style.PictureCropParameterStyle;
import com.lxj.xpopup.core.BottomPopupView;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.GlideEngine;
import com.ty.constant.PermissionConstants;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

/**
 * 上传头像选择对话框
 */
public class UpHeadPopup extends BottomPopupView implements View.OnClickListener {

    TextView tv_image_sdcard;
    TextView tv_image_photo;
    TextView tv_image_cancel;
    Fragment fragment;
    private Builder builder;

    private int maxNum;//最大数量
    private int mixMum;//最少数量
    public boolean enableCrop;//是否需要剪切
    private List<LocalMedia> selectList;//默认图片
    public boolean enablePreview = false;//是否需要图片预览

    private PictureCropParameterStyle mCropParameterStyle;

    public UpHeadPopup(@NonNull Fragment fragment, Builder builder) {
        super(fragment.getContext());
        this.fragment = fragment;
        this.builder = builder;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_up_head;
    }

    @Override
    protected void onCreate() {
        super.onCreate();

        maxNum = builder.getMaxNum();
        mixMum = builder.getMixMum();
        enableCrop = builder.isEnableCrop();
        selectList = builder.getSelectList();
        enablePreview = builder.isEnablePreview();

        tv_image_sdcard = findViewById(R.id.tv_image_sdcard);
        tv_image_photo = findViewById(R.id.tv_image_photo);
        tv_image_cancel = findViewById(R.id.tv_image_cancel);
        tv_image_sdcard.setOnClickListener(this);
        tv_image_photo.setOnClickListener(this);
        tv_image_cancel.setOnClickListener(this);

        // 裁剪主题
        mCropParameterStyle = new PictureCropParameterStyle(
                ContextCompat.getColor(getContext(), R.color.picture_color_grey),
                ContextCompat.getColor(getContext(), R.color.picture_color_grey),
                ContextCompat.getColor(getContext(), R.color.picture_color_white),
                true);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_image_sdcard:
                PermissionUtils.permission(PermissionConstants.STORAGE)
                        .callback(new PermissionUtils.SimpleCallback() {
                            @Override
                            public void onGranted() {
                                go2selectImage(false);
                            }

                            @Override
                            public void onDenied() {
                                App.goPhoto = true;
                                dismiss();
                                ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn));
                            }
                        }).request();
                break;
            case R.id.tv_image_photo:
                PermissionUtils.permission(PermissionConstants.STORAGE, PermissionConstants.CAMERA)
                        .callback(new PermissionUtils.SimpleCallback() {
                            @Override
                            public void onGranted() {
                                App.goPhoto = true;
                                go2selectImage(true);
                            }

                            @Override
                            public void onDenied() {
                                App.goPhoto = true;
                                dismiss();
                                ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn));
                            }
                        }).request();
                break;
            case R.id.tv_image_cancel:
                dismiss();
                break;
        }
    }


    /**
     * @param photo 是否直接打开照相机
     */
    private void go2selectImage(boolean photo) {
        if (photo) {
            App.goPhoto = true;
            PictureSelector.create(fragment)
                    .openCamera(PictureMimeType.ofImage())
                    .theme(R.style.picture_default_style)
                    .compress(true)// 是否压缩
                    .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)// 设置相册Activity方向，不设置默认使用系统
                    .previewImage(enablePreview)
                    .isGif(false)
                    .selectionMedia(selectList)
                    .setPictureCropStyle(mCropParameterStyle)
                    .enableCrop(enableCrop)
                    .circleDimmedLayer(true)// 是否圆形裁剪
                    .loadImageEngine(GlideEngine.createGlideEngine()) // 请参考Demo GlideEngine.java
                    .forResult(PictureConfig.CHOOSE_REQUEST);
            dismiss();
        } else {
            App.goPhoto = false;
            PictureSelector.create(fragment)
                    .openGallery(PictureMimeType.ofImage())
                    .theme(R.style.picture_default_style)
                    .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)// 设置相册Activity方向，不设置默认使用系统
                    .compress(true)// 是否压缩
                    .minSelectNum(mixMum)// 最小选择数量
                    .maxSelectNum(maxNum)// 最大选择数量
                    .selectionMode(maxNum == 1 ? PictureConfig.SINGLE : PictureConfig.MULTIPLE)
                    .isCamera(false)
                    .previewImage(enablePreview)
                    .isGif(false)
                    .enablePreviewAudio(false)
                    .setPictureCropStyle(mCropParameterStyle)
                    .previewVideo(false)
                    .enableCrop(enableCrop)
                    .selectionMedia(selectList)
                    .circleDimmedLayer(true)// 是否圆形裁剪
                    .loadImageEngine(GlideEngine.createGlideEngine()) // 请参考Demo GlideEngine.java
                    .forResult(PictureConfig.CHOOSE_REQUEST);
            dismiss();
        }

    }


    public void preImage() {

    }

    public static class Builder {
        private int maxNum = 1;//最大数量
        private int mixMum = 1;//最少数量
        public boolean enableCrop = false;//是否需要剪切
        public boolean enablePreview = false;//是否需要图片预览
        private List<LocalMedia> selectList = new ArrayList<>();//默认图片


        public boolean isEnablePreview() {
            return enablePreview;
        }

        public Builder setEnablePreview(boolean enablePreview) {
            this.enablePreview = enablePreview;
            return this;
        }

        public int getMaxNum() {
            return maxNum;
        }

        public Builder setMaxNum(int maxNum) {
            this.maxNum = maxNum;
            return this;
        }

        public int getMixMum() {
            return mixMum;
        }

        public Builder setMixMum(int mixMum) {
            this.mixMum = mixMum;
            return this;
        }

        public boolean isEnableCrop() {
            return enableCrop;
        }

        public Builder setEnableCrop(boolean enableCrop) {
            this.enableCrop = enableCrop;
            return this;
        }

        public List<LocalMedia> getSelectList() {
            return selectList;
        }

        public Builder setSelectList(List<LocalMedia> selectList) {
            this.selectList = selectList;
            return this;
        }
    }


    @Override
    protected void onShow() {
        super.onShow();
        App.goPhoto = true;
        MainActivity.isDialogShow = true;
    }

    @Override
    protected void onDismiss() {
        super.onDismiss();
        App.goPhoto = false;
        MainActivity.isDialogShow = false;
    }

}
