package com.ty.bwagent.dialog;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.lxj.xpopup.impl.PartShadowPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.RecordFilterEntity;
import com.ty.bwagent.view.ExpandableLayout;
import com.ty.bwagent.view.XPickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

/**
 * 提款记录筛选对话框
 */
public class DepositFilterPopup extends PartShadowPopupView implements View.OnClickListener {

    TextView tvStartTime;
    XPickerView topPickerView;
    ExpandableLayout topExpandableLayout;
    TextView tvEndTime;
    XPickerView bottomPickerView;
    ExpandableLayout buttomExpandableLayout;
    TextView preTextView;//记录当前选中
    int status = 0;//0 全部，403，成功 99 失败
    TextView tvRecordAll;
    TextView tvRecordSucc;
    TextView tvRecordFail;
    TextView tv_screen;
    TextView tv_reset;
    GradientDrawable holdDrawable;

    //刷新时间回调
    MutableLiveData<RecordFilterEntity> filterLiveData;

    //重置
    MutableLiveData<RecordFilterEntity> resetLiveData;


    public DepositFilterPopup(@NonNull Context context, MutableLiveData<RecordFilterEntity> filterLiveData, MutableLiveData<RecordFilterEntity> resetLiveData) {
        super(context);
        this.filterLiveData = filterLiveData;
        this.resetLiveData = resetLiveData;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_deposit_filter;
    }

    @Override
    protected void onCreate() {
        super.onCreate();

        holdDrawable = new GradientDrawable();
        holdDrawable.setColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        holdDrawable.setShape(GradientDrawable.RECTANGLE);
        holdDrawable.setCornerRadius(SizeUtils.dp2px(4));

        tvRecordAll = findViewById(R.id.tv_record_all);
        tvRecordAll.setOnClickListener(this);

        tvRecordSucc = findViewById(R.id.tv_record_succ);
        tvRecordSucc.setOnClickListener(this);
        tvRecordFail = findViewById(R.id.tv_record_fail);
        tvRecordFail.setOnClickListener(this);
        tv_reset = findViewById(R.id.tv_reset);
        tv_reset.setOnClickListener(this);
        tv_reset.setTextColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        tv_reset.setBackgroundColor(ResUtils.getColor(SiteSdk.ins().btnEnableColor()));

        tv_screen = findViewById(R.id.tv_screen);
        tv_screen.setOnClickListener(this);
        tv_screen.setBackgroundColor(ResUtils.getColor(SiteSdk.ins().styleColor()));

        tvStartTime = findViewById(R.id.tv_startTime);
        tvEndTime = findViewById(R.id.tv_endTime);

        topPickerView = findViewById(R.id.top_PickerView);
        topExpandableLayout = findViewById(R.id.topExpandableLayout);
        bottomPickerView = findViewById(R.id.bottom_PickerView);
        buttomExpandableLayout = findViewById(R.id.buttomExpandableLayout);
        preTextView = tvRecordAll;
        topPickerView.setSelectChangeCallback(() -> {
            tvStartTime.setText(topPickerView.getTime());
        });
        bottomPickerView.setSelectChangeCallback(() -> {
            tvEndTime.setText(bottomPickerView.getTime());
        });

        tvRecordAll.setBackground(holdDrawable);
        tvRecordAll.setTextColor(ResUtils.getColor(R.color.white));

        initExpandable();
        initDate();

    }

    public void startDate(int year, final int month, int day) {
        topPickerView.setSolar(year, month, day);
        //等于-1初始化不要设置时间
        if(startDay == -1){
            tvStartTime.setText("");
        }else {
            tvStartTime.setText(topPickerView.getTime());
        }

    }

    public void endDate(int year, final int month, int day) {
        bottomPickerView.setSolar(year, month, day);

        //等于-1初始化不要设置时间
        if(startDay == -1){
            tvEndTime.setText("");
        }else {
            tvEndTime.setText(bottomPickerView.getTime());
        }
    }

    /**
     * 处理折叠布局,展开,收缩，滚动等逻辑
     */
    private void initExpandable() {
        topExpandableLayout.setConsTraintLayout(buttomExpandableLayout);
        buttomExpandableLayout.setConsTraintLayout(topExpandableLayout);
        topExpandableLayout.setOnExpansionUpdateListener((expansionFraction, state) -> {
            if(state ==3){//展开
                tvStartTime.setText(topPickerView.getTime());
            }
        });
        buttomExpandableLayout.setOnExpansionUpdateListener((expansionFraction, state) -> {
            if(state ==3){//展开
                tvEndTime.setText(bottomPickerView.getTime());
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_record_all://全部
                preTextView.setTextColor(ResUtils.getColor(R.color.color_cbced8));
                preTextView.setBackgroundResource(R.drawable.etittext_select_bg);
                status = 0;
                preTextView = tvRecordAll;
                tvRecordAll.setBackground(holdDrawable);
                tvRecordAll.setTextColor(ResUtils.getColor(R.color.white));
                break;
            case R.id.tv_record_succ://成功
                preTextView.setTextColor(ResUtils.getColor(R.color.color_cbced8));
                preTextView.setBackgroundResource(R.drawable.etittext_select_bg);
                status = 403;
                preTextView = tvRecordSucc;
                tvRecordSucc.setBackground(holdDrawable);
                tvRecordSucc.setTextColor(ResUtils.getColor(R.color.white));
                break;
            case R.id.tv_record_fail://失败
                preTextView.setTextColor(ResUtils.getColor(R.color.color_cbced8));
                preTextView.setBackgroundResource(R.drawable.etittext_select_bg);
                status = 99;
                preTextView = tvRecordFail;
                tvRecordFail.setBackground(holdDrawable);
                tvRecordFail.setTextColor(ResUtils.getColor(R.color.white));
                break;
            case R.id.tv_reset://重置
                startDay = -1;
                status = 0;
                initDate();
                resetLiveData.postValue(new RecordFilterEntity(getFormatTime(topPickerView.getTime()),getFormatTime(bottomPickerView.getTime()),status));
                tvRecordAll.performClick();
                if(topExpandableLayout.isExpanded()){
                    topExpandableLayout.getHideView().toggle(false);
                }
                if(buttomExpandableLayout.isExpanded()){
                    buttomExpandableLayout.getHideView().toggle(false);
                }
                dismiss();
                break;
            case R.id.tv_screen://筛选
                if(daysBetween()){
                    filterLiveData.postValue(new RecordFilterEntity(getFormatTime(topPickerView.getTime()),getFormatTime(bottomPickerView.getTime()),status));
                    dismiss();
                }
                break;
        }
    }

    int startDay = -1;
    public void setStartDay(int startDay){
        this.startDay = startDay;
    }

    /**
     * 初始化选中时间
     */
    public void initDate(){
        //设置开始时间
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        if(startDay == -1){
            calendar.add(Calendar.DAY_OF_MONTH, 0);
        }else {
            calendar.add(Calendar.DAY_OF_MONTH, -startDay);
        }

        startDate(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        //设置结束时间
        calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        endDate(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
    }



    Calendar startCalendar;
    Calendar endCalendar;

    public void setStartCalendar(Calendar startCalendar) {
        this.startCalendar = startCalendar;
    }

    public void setEndCalendar(Calendar endCalendar) {
        this.endCalendar = endCalendar;
    }

    /**
     * 初始化选中时间
     */
    public void initLastDate(){
        //设置开始时间
        startDate(startCalendar.get(Calendar.YEAR), startCalendar.get(Calendar.MONTH), startCalendar.get(Calendar.DAY_OF_MONTH));
        endDate(endCalendar.get(Calendar.YEAR), endCalendar.get(Calendar.MONTH), endCalendar.get(Calendar.DAY_OF_MONTH));
    }


    @Override
    protected void onShow() {
        if(startDay == 0){
            initLastDate();
        }else {
            initDate();
        }
        super.onShow();
    }

    private boolean daysBetween(){
        try {
            Date smdate = TimeUtils.DATE_FORMAT_DATE.parse(topPickerView.getTime());
            Date bdate = TimeUtils.DATE_FORMAT_DATE.parse(bottomPickerView.getTime());
            Calendar cal = Calendar.getInstance();
            cal.setTime(smdate);
            long time1 = cal.getTimeInMillis();
            cal.setTime(bdate);
            long time2 = cal.getTimeInMillis();
            long between_days = (time2 - time1) / (1000 * 3600 * 24);
            if(between_days < 0){
                ToastUtils.showLong("结束时间不能早于开始时间");
                return false;
            }else  if(between_days > 30){
                ToastUtils.showLong("时间跨度不能超过30天");
                return false;
            }else {
                return true;
            }
        }catch (ParseException e){
            return true;
        }

    }

    private String getFormatTime(String time) {
        String[] arrs = time.split("-");
        if (arrs.length == 3) {
            StringBuilder sb = new StringBuilder();
            sb.append(arrs[0]);
            sb.append("-");
            if (StringUtils.parseInt(arrs[1]) < 10) {
                sb.append("0");
                sb.append(arrs[1]);
            } else {
                sb.append(arrs[1]);
            }
            sb.append("-");
            if (StringUtils.parseInt(arrs[2]) < 10) {
                sb.append("0");
                sb.append(arrs[2]);
            } else {
                sb.append(arrs[2]);
            }
            return sb.toString();
        } else {
            return time;
        }
    }
}
