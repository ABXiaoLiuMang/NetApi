package com.ty.bwagent.fragment.finance.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.finance.bean.FinanceAccount;
import com.ty.bwagent.utils.Utils;


/**
 * 描述 佣金报表，账号调整界面
 * <p>
 * author:Dale
 */
public class FinanceAccountAdapter extends BaseQuickAdapter<FinanceAccount, BaseViewHolder> {

    public FinanceAccountAdapter() {
        super(R.layout.recycle_item_finance_account);
    }

    @Override
    protected void convert(BaseViewHolder helper, FinanceAccount entity) {


        helper.setText(R.id.account_type,entity.getCategory());//红利类型
        helper.setText(R.id.account_money, Utils.roundDownMoney(entity.getMoney()));//金额



        if(getItemCount() == 2){//表示只有一行数据，因为第一行是headView
            helper.setBackgroundRes(R.id.finance_rootView,R.drawable.finance_buttom_corners_w_bg);
        }else{
            if(helper.getAdapterPosition() % 2 == 0){

                if(helper.getAdapterPosition() + 1 == getItemCount()){//表示是最后一个
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_buttom_corners_x_bg);
                }else {
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_center_corners_x_bg);
                }

            }else {
                if(helper.getAdapterPosition() + 1 == getItemCount()){//表示是最后一个
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_buttom_corners_w_bg);
                }else {
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_center_corners_w_bg);
                }
            }
        }

    }

}
