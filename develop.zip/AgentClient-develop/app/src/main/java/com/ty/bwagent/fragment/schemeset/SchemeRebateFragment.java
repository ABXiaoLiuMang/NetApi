package com.ty.bwagent.fragment.schemeset;

import android.os.Bundle;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.SchemeSetRebateEntity;
import com.ty.bwagent.utils.EditRateInputFilter;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.viewmodel.SchemeSetViewModle;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;

import java.util.List;

import androidx.lifecycle.ViewModelProvider;
import butterknife.BindView;

/**
 * 返水方案
 */
public class SchemeRebateFragment extends ABBaseFragment {

    @BindView(R.id.ll_content)
    protected LinearLayout ll_content;
    @BindView(R.id.ll_main)
    protected LinearLayout ll_main;
    @BindView(R.id.ll_net)
    protected LinearLayout ll_net;
    @BindView(R.id.bnt_nonet)
    protected TextView bnt_nonet;

    private SchemeSetViewModle schemeSetViewModle;
    private int pagePositon;
    private int appScreenHeight;

    private SchemeSetRebateEntity rebateEntityBaseEntity;//列表展示的对象
    private SchemeSetTabFragment.OnChildFragListener onChildFragListener;

    private BaseEntity<List<SchemeSetRebateEntity>> rebateMineEntityBaseEntity;
    private int llContentTop;

    public static SchemeRebateFragment getInstance(int pagePositon) {
        SchemeRebateFragment fragment = new SchemeRebateFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ABConfig.KEY_TAG, pagePositon);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_rebate_scheme;
    }

    @Override
    protected void createProvider() {
        schemeSetViewModle = new ViewModelProvider(this).get(SchemeSetViewModle.class);

        //返水-我的方案
        schemeSetViewModle.discountLivaData.observe(this, new NetObserver<BaseEntity<List<SchemeSetRebateEntity>>>() {

            @Override
            protected void onSuccess(BaseEntity<List<SchemeSetRebateEntity>> rebateEntityBaseEntity) {
                if (rebateEntityBaseEntity != null && rebateEntityBaseEntity.getData() != null && rebateEntityBaseEntity.getData().size() > 0) {
                    SchemeRebateFragment.this.rebateMineEntityBaseEntity = rebateEntityBaseEntity;
                    if (pagePositon == 0) {//我的界面
                        setDate(rebateEntityBaseEntity.getData().get(0));
                    } else {//直属下属
                        if (SchemeRebateFragment.this.rebateEntityBaseEntity == null) {
                            setDate(rebateEntityBaseEntity.getData().get(0));
                        } else {
                            ll_content.setVisibility(View.VISIBLE);
                            setDate(SchemeRebateFragment.this.rebateEntityBaseEntity);
                        }
                    }
                }

                if (ll_net != null) {
                    ll_net.setVisibility(View.GONE);
                    ll_content.setVisibility(View.VISIBLE);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showToast(errMsg);
                if (ll_net != null) {
                    ll_net.setVisibility(View.VISIBLE);
                    ll_content.setVisibility(View.GONE);
                }
            }
        });

        //返水-下属方案
        schemeSetViewModle.lowerDiscountLivaData.observe(this, new NetObserver<BaseEntity<List<SchemeSetRebateEntity>>>() {
            @Override
            protected void onLoading(boolean show) {
                super.onLoading(show);
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onSuccess(BaseEntity<List<SchemeSetRebateEntity>> listBaseEntity) {
                if (listBaseEntity != null && listBaseEntity.getData() != null) {
                    if (listBaseEntity.getData().size() > 0 && listBaseEntity.getData().get(0).getRebateDetail() != null && listBaseEntity.getData().get(0).getRebateDetail().size() > 0) {
                        if (onChildFragListener != null) {
                            onChildFragListener.onTitleRedDotShow(1, pagePositon, false);//红点不显示了
                            if (UserInfoCache.getInstance().getUserInfo().getAgentLevel() == 20) {//末级代理可以多次编辑
                                onChildFragListener.onTitleRightShow(1, pagePositon, true);
                            } else {
                                onChildFragListener.onTitleRightShow(1, pagePositon, false);
                            }
                        }
                    } else {
                        if (onChildFragListener != null) {
                            onChildFragListener.onTitleRedDotShow(1, pagePositon, true);//红点显示了
                            onChildFragListener.onTitleRightShow(1, pagePositon, true);
                        }
                    }

                    if (pagePositon == 1) {
                        SchemeRebateFragment.this.rebateEntityBaseEntity = listBaseEntity.getData().get(0);
                        schemeSetViewModle.myDiscount();//操他妈蛋的 末级代理比例上限要从返水我的获取
                    }
                }

                if (ll_net != null) {
                    ll_net.setVisibility(View.GONE);
                    ll_content.setVisibility(View.VISIBLE);
                }
            }


            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showToast(errMsg);
                if (ll_net != null) {
                    ll_net.setVisibility(View.VISIBLE);
                    ll_content.setVisibility(View.GONE);
                }
            }
        });

        //无限代web-返佣-更新方案
        schemeSetViewModle.updateDiscountLivaData.observe(this, new NetObserver<BaseEntity>() {

            @Override
            protected void onLoading(boolean show) {
                super.onLoading(show);
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if (onChildFragListener != null) {
                    onChildFragListener.onTitleRedDotShow(1, pagePositon, false);
                    if (UserInfoCache.getInstance().getUserInfo().getAgentLevel() == 20) {//末级代理可以多次编辑
                        onChildFragListener.onTitleRightShow(1, pagePositon, true);
                        onChildFragListener.onTitleEditeShow(1, pagePositon, true);
                    } else {
                        onChildFragListener.onTitleEditeShow(1, pagePositon, false);
                        onChildFragListener.onTitleRightShow(1, pagePositon, false);
                    }
                }
                setEiteStateChange(false);
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showToast(errMsg);
            }
        });

    }


    @Override
    protected void initViewsAndEvents() {

        pagePositon = getArguments().getInt(ABConfig.KEY_TAG, 0);
        appScreenHeight = ScreenUtils.getAppScreenHeight();
        ll_main.setOnClickListener(v -> {
            if (etFoucus != null) {
                etFoucus.clearFocus();
            }
            KeyboardUtils.hideSoftInput(rootView);
        });

        bnt_nonet.setOnClickListener(v -> {
            if (pagePositon == 0) {
                schemeSetViewModle.myDiscount();
                schemeSetViewModle.myLowerDiscount();
            } else {
                schemeSetViewModle.myLowerDiscount();
            }
        });

        ll_content.setVisibility(View.GONE);
    }


    public boolean isFirst = true;

    //返水方案 第一次加载
    public void loadDate() {
        if (isFirst) {
            isFirst = false;
            if (pagePositon == 0) {//返水我的
                schemeSetViewModle.myDiscount();
                schemeSetViewModle.myLowerDiscount();
            } else {//返水直属下属
                schemeSetViewModle.myLowerDiscount();
            }
        }
    }

    public void setOnChildFragListener(SchemeSetTabFragment.OnChildFragListener onChildFragListener) {
        this.onChildFragListener = onChildFragListener;
    }

    /**
     * 点击保存和编辑
     */
    public void setIsEditeState(boolean isEditeState, boolean isInsertOrUpdate) {
        //保存请求网络
        if (isEditeState) {
            setEiteStateChange(true);
        } else {
            if (isInsertOrUpdate) {//新增
                schemeSetViewModle.insertMyLowerDiscount(rebateEntityBaseEntity);
            } else {//更新
                schemeSetViewModle.updateMyLowerDiscount(rebateEntityBaseEntity);
            }
        }
    }

    /**
     * 设置EditeText 输入状态改变
     *
     * @param isEditeState
     */
    private void setEiteStateChange(boolean isEditeState) {
        for (int i = 0; i < ll_content.getChildCount(); i++) {
            LinearLayout rootView = (LinearLayout) ll_content.getChildAt(i);
            FrameLayout framelayout = (FrameLayout) rootView.findViewById(R.id.framelayout);
            if (framelayout != null) {
                EditText et_input = framelayout.findViewById(R.id.et_input);
                if (isEditeState) {
                    et_input.setEnabled(true);
                    et_input.setBackground(getResources().getDrawable(R.drawable.etittext_select_bg));
                } else {
                    et_input.setEnabled(false);
                    et_input.setBackgroundColor(getResources().getColor(R.color.transparent));
                }
            }
        }
    }


    public EditText etFoucus;

    private void setDate(SchemeSetRebateEntity schemeSetCommissionEntities) {
        rebateEntityBaseEntity = schemeSetCommissionEntities;

        int[] position = new int[2];
        ll_content.getLocationInWindow(position);
        llContentTop = position[1];

        for (int i = 0; i < schemeSetCommissionEntities.getRebateDetail().size(); i++) {
            setItemView(schemeSetCommissionEntities, i);
        }


    }


    //列表Item的展示
    private void setItemView(SchemeSetRebateEntity schemeSetCommissionEntities, int i) {

        try {
            final SchemeSetRebateEntity.RebateDetailBean rebateDetailBean = schemeSetCommissionEntities.getRebateDetail().get(i);
            if (rebateDetailBean == null) {
                return;
            }
            View rootView = LayoutInflater.from(getContext()).inflate(R.layout.item_rebate_scheme, null);
            ll_content.addView(rootView);

            EditText et_input = rootView.findViewById(R.id.et_input);
            TextView tv_name = rootView.findViewById(R.id.tv_name);
            tv_name.setText(rebateDetailBean.getName());

            rootView.getLayoutParams().height = (int) getResources().getDimension(R.dimen.dp_50);

            //item背景颜色修改
            if (i == schemeSetCommissionEntities.getRebateDetail().size() - 1) {
                if (i % 2 == 1) {
                    rootView.setBackground(getResources().getDrawable(R.drawable.commuite_bottom_corners_grey_bg));
                } else {
                    rootView.setBackground(getResources().getDrawable(R.drawable.commuite_bottom_corners_white_bg));
                }
            } else if (i % 2 == 1) {
                rootView.setBackgroundColor(getResources().getColor(R.color.color_E8E8E8));
            } else {
                rootView.setBackgroundColor(getResources().getColor(R.color.white));
            }

            et_input.setEnabled(false);
            et_input.setBackgroundColor(getResources().getColor(R.color.transparent));

            String rate = "";
            if (pagePositon == 1 && UserInfoCache.getInstance().getUserInfo().getAgentLevel() == 20) {
                if (rebateMineEntityBaseEntity != null && rebateMineEntityBaseEntity.getData() != null && rebateMineEntityBaseEntity.getData().get(0) != null) {
                    // 直属下属的比例范围 是根据返水我的接口返回的
                    rate = rebateMineEntityBaseEntity.getData().get(0).getRebateDetail().get(i).getRate();
                } else {
                    rate = rebateDetailBean.getRate();
                }
            } else {
                rate = rebateDetailBean.getRate();
            }

            et_input.setText(!StringUtils.isEmpty(rebateDetailBean.getRate()) ? ((Double.parseDouble(rebateDetailBean.getRate()) * 100) + "") : "0.00");
            et_input.setHint("请输入0~" + (!StringUtils.isEmpty(rebateDetailBean.getRate()) ? ((Double.parseDouble(rate) * 100) + "") : "0"));

            //输入的正则匹配
            InputFilter[] filters = {new EditRateInputFilter().setPointerLength(4).setMaxValue(Double.parseDouble(!StringUtils.isEmpty(rate) ? rate : "0") * 100)};
            et_input.setFilters(filters);

            et_input.setTypeface(TypefaceUtils.DIN_MEDIUM);

            et_input.setOnFocusChangeListener((v, hasFocus) -> {
                if (hasFocus) {
                    etFoucus = et_input;

                    //输入键盘的弹框的高度计算 屏幕高度 - ll_content到顶部的高度- rootView的高度到ll_content的高度
                    SchemeSetFragment.keybordUp = appScreenHeight - llContentTop - rootView.getLayoutParams().height * (i + 2);
                    if (onChildFragListener != null) {
                        onChildFragListener.onSoftKeyboardScroll(SchemeSetFragment.keybordUp);
                    }
                } else {
                    //输入为空时候 失去焦点就显示0.00
                    if (StringUtils.isEmpty(et_input.getText().toString().trim()) ||
                            et_input.getText().toString().trim().equals("0.0") ||
                            et_input.getText().toString().trim().equals("0.") ||
                            et_input.getText().toString().trim().equals("0.000") ||
                            et_input.getText().toString().trim().equals("0.00")
                    ) {
                        et_input.setText("0.0");
                        return;
                    }
                    //输入以小数点结尾时 失去焦点就去除小数点
                    if (et_input.getText().toString().trim().endsWith(".")) {
                        et_input.setText(et_input.getText().toString().trim().substring(0, et_input.getText().toString().trim().length() - 1));
                    }

                    //如果是整数 就加.0
                    if (!et_input.getText().toString().trim().contains(".")) {
                        et_input.setText(et_input.getText().toString().trim() + ".0");
                    }
                }
            });

            //监听修改的返佣比例 更改数据
            et_input.addTextChangedListener(new SimpleTextWatcher() {
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    super.onTextChanged(s, start, before, count);
                    if (s.length() == 0) {
                        rebateDetailBean.setRate("0.0");
                    } else {
                        rebateDetailBean.setRate((Double.parseDouble(s.toString()) / 100) + "");
                    }
                }
            });
        } catch (Exception e) {

        }

    }

}
