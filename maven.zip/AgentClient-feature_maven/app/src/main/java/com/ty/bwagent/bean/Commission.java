package com.ty.bwagent.bean;

/**
 * 佣金余额
 */
public class Commission {

    /**
     * agentFreezedMoney : 300.0
     * agentMoney : 998.0
     */

    private double agentFreezedMoney;
    private double agentMoney;

    public double getAgentFreezedMoney() {
        return agentFreezedMoney;
    }

    public void setAgentFreezedMoney(double agentFreezedMoney) {
        this.agentFreezedMoney = agentFreezedMoney;
    }

    public double getAgentMoney() {
        return agentMoney;
    }

    public void setAgentMoney(double agentMoney) {
        this.agentMoney = agentMoney;
    }
}
