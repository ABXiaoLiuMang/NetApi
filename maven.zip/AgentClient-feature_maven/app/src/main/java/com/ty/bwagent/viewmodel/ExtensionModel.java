package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class ExtensionModel extends ViewModel {

    public NetLiveData<BaseEntity<List<ExtensionEntity>>> entityNetLiveData = new NetLiveData<>();

    //推广连接
    public void domainByClientType(String clientType){
        NetSdk.create(Api.class)
                .domainByClientType()
                .params("clientType",clientType)
                .asJSONType()
                .send(entityNetLiveData);
    }

}
