package com.ty.bwagent.utils;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 *对话框文字要显示4.5行时 使用可以支持中文 和中英文数字结合 但不支持全部都是数字 或者英文
 */
public class DialogTextHeightChangeShow {

    private ViewGroup viewGroup;
    private TextView textView;
    private double lines;

    /**
     * @param viewGroup 改变大小的跟布局
     * @param textView  要改的大小textView高度
     */
    public DialogTextHeightChangeShow(ViewGroup viewGroup, TextView textView, double lines) {
        this.viewGroup = viewGroup;
        this.textView = textView;
        this.lines = lines;

    }

    float lineHeight = 0;

    public void setTextHeight(String content) {
        if (textView == null) {
            return;
        }
        textView.setText(content);
        textView.post(() -> {
            int textViewLines = textView.getLineCount();
            if (textViewLines >= Math.floor(lines)) {
                getTextViewMoreLineHeight();
                textView.setText(content);
                textView.getLayoutParams().height = (int) lineHeight;
            } else {
                getSingleLineHeight();
                textView.setText(content);
                textView.getLayoutParams().height = (int) lineHeight * textViewLines;
            }
            textView.requestLayout();
            viewGroup.requestLayout();
        });
    }


    public void getTextViewMoreLineHeight() {
        if (textView == null) {
            return;
        }
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < Math.floor(lines); i++) {
            sb.append("哈\n哈");
        }
        textView.setText(sb.toString());
        int intw = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        int inth = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        textView.measure(intw, inth);
        lineHeight = textView.getMeasuredHeight();

        float lineSpacingExtra = 0;
        if (Math.ceil(lines) > lines) {
            lineSpacingExtra = textView.getLineHeight() / 2;
        }
        lineHeight = lineHeight - lineSpacingExtra;

    }

    public void getSingleLineHeight() {
        if (textView == null) {
            return;
        }
        StringBuffer sb = new StringBuffer();
        sb.append("哈");
        textView.setText(sb.toString());
        int intw = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        int inth = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        textView.measure(intw, inth);
        lineHeight = textView.getMeasuredHeight();
    }


}
