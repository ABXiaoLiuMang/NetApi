package com.ty.bwagent.bean;

public class FinanceItemEntity {

    String typeName;//类别名字
    double monty;//金额
    boolean showInfo;//是否显示查看按钮
    public String fragmentName;//跳的对应fragment

    public FinanceItemEntity(String typeName, double monty,  boolean showInfo,String fragmentName) {
        this.typeName = typeName;
        this.monty = monty;
        this.fragmentName = fragmentName;
        this.showInfo = showInfo;
    }

    public String getTypeName() {
        return typeName;
    }

    public String getFragmentName() {
        return fragmentName;
    }

    public void setFragmentName(String fragmentName) {
        this.fragmentName = fragmentName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public double getMonty() {
        return monty;
    }

    public void setMonty(double monty) {
        this.monty = monty;
    }

    public boolean isShowInfo() {
        return showInfo;
    }

    public void setShowInfo(boolean showInfo) {
        this.showInfo = showInfo;
    }
}
