package com.ty.bwagent.fragment;


import android.content.res.ColorStateList;

import com.tianyu.updater.entity.UpdateEntity;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.Data;
import com.ty.bwagent.bean.ProInfoEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.update.XDialogManager;
import com.ty.bwagent.update.XUpdateManager;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.HomeViewModel;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.tab.ABMainTabFragment;
import com.ty.common.tab.MainTab;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.SimpleObserver;
import com.ty.net.utils.JsonUtils;
import com.ty.tysite.SiteSdk;
import com.ty.tysite.utils.ResourceSiteUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

import androidx.lifecycle.ViewModelProvider;

public class MainFragment extends ABMainTabFragment {

    HomeViewModel mHomeViewModel;
    private XDialogManager xDialogManager = new XDialogManager();

    public static MainFragment getInstance() {
        return new MainFragment();
    }


    @Override
    protected void createProvider() {
        mHomeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);
        //监听更新
        XLiveDataManager.getInstance().updateResult.observe(this, new SimpleObserver<UpdateEntity>() {
            @Override
            protected void onSuccess(UpdateEntity updateEntity) {
                if (currentIndex == 0) {//首页
                    if (!App.is_showing_update_dialog && !StringUtils.isEmpty(updateEntity.getVersionName()) && isSupportVisible()) {
                        App.is_showing_update_dialog = true;
                        XUpdateManager.showUpdateDialog(mContext, xDialogManager, updateEntity, new XUpdateManager.UpdateCallBack() {
                            @Override
                            public void onUpdateonDismiss() {
                                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                                if (userInfo != null && userInfo.getFirstLogin() == 0) {//第一登录先谈isFistLogin()
                                    mHomeViewModel.querySpecialNotice();//重要通告
                                }
                            }

                            @Override
                            public void onDoweLoadFinish() {
                                mHomeViewModel.isShowNoticeLiveData.postValue(false);
                            }
                        });
                    } else {
                        UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                        if (userInfo != null && userInfo.getFirstLogin() == 0) {//第一登录先谈isFistLogin()
                            mHomeViewModel.querySpecialNotice();//重要通告
                        }
                    }
                } else if (currentIndex == 4) {//我的
                    if (updateEntity.getUpdateInfo().getForce() == 2 && isSupportVisible()) {//我的界面是强制更新在弹窗
                        XUpdateManager.showUpdateDialog(mContext, null, updateEntity, null);
                    }
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                if (userInfo != null && userInfo.getFirstLogin() == 0) {//第一登录先谈isFistLogin()
                    mHomeViewModel.querySpecialNotice();//重要通告
                }
            }
        });

        mHomeViewModel.proInfoLiveData.observe(this,new SimpleObserver<String>(){
            @Override
            protected void onSuccess(String result) {
                ProInfoEntity proInfoEntity = JsonUtils.fromJson(result, ProInfoEntity.class);
                if(proInfoEntity != null && proInfoEntity.getData() != null){
                    Data dataBean =  proInfoEntity.getData();
                    int code = -1;
                    if(dataBean.getMaintainConfig().getStatus() == 0){
                        code = 10401;
                    }else if(proInfoEntity.getCode() == 10402){
                        code = 10402;
                    }
//                    else if(proInfoEntity.getCode() == 10403){
//                        code = 10403;
//                    }
                    if(code != -1){
                        MMKVUtil.put(CacheKey.SYSTEM_MAIN_PROINFO, true);
                        XLiveDataManager.getInstance().proInfoLiveData.postNext(proInfoEntity);
                        SystemModel.areaWarnResult.postValue(code);
                    }
                }
            }
        });
    }


    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        mHomeViewModel.getPerInfo();
    }

    @Override
    protected MainTab[] getMainTabs() {
        MainTab[] mainTabs = new MainTab[5];
        mainTabs[0] = new MainTab("首页", "", R.mipmap.main_tab_home_normal, ResourceSiteUtils.getMainTabsSecColor(0));
        mainTabs[1] = new MainTab("成员", "", R.mipmap.main_tab_member_normal, ResourceSiteUtils.getMainTabsSecColor(1));
        mainTabs[2] = new MainTab("推广", "", R.mipmap.main_tab_share_normal, ResourceSiteUtils.getMainTabsSecColor(2));
        mainTabs[3] = new MainTab("佣金", "", R.mipmap.main_tab_charge_normal, ResourceSiteUtils.getMainTabsSecColor(3));
        mainTabs[4] = new MainTab("我的", "", R.mipmap.main_tab_my_normal, ResourceSiteUtils.getMainTabsSecColor(4));
        return mainTabs;
    }

    protected ColorStateList getTextColor() {
        int[] colors = new int[]{ResUtils.getColor(R.color.generic_main_tab_normal), ResUtils.getColor(SiteSdk.ins().styleColor())};
        int[][] states = new int[2][];
        states[0] = new int[]{-android.R.attr.state_selected};
        states[1] = new int[]{android.R.attr.state_selected};
        return new ColorStateList(states, colors);
    }

    @Override
    protected ABBaseFragment[] getFragments() {
        ABBaseFragment[] fragments = new ABBaseFragment[5];
        fragments[0] = HomeFragment.getInstance();
        fragments[1] = MemberFragment.getInstance();
        fragments[2] = ExtensionTabFragment.getInstance();
        fragments[3] = FinanceFragment.getInstance();
        fragments[4] = MyCenterFragment.getInstance();
        return fragments;
    }


    public boolean isShowNotice = false;
    protected int currentIndex = 0;

    @Override
    public void selectFragment(int postion) {
        currentIndex = postion;
        if (postion == 0) {//首页特殊公告的展示
            mHomeViewModel.isShowNoticeLiveData.postValue(true);
            super.selectFragment(postion);
        }

        if (isShowNotice) {
        } else {
            super.selectFragment(postion);
        }
    }


    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        if (isShowNotice) {//到了首页 特殊弹框 还没有弹时 弹框
            mHomeViewModel.isShowNoticeLiveData.postValue(true);
        }
    }


    @Override
    public void onStop() {
        super.onStop();
        if (getActivity() != null && getActivity().isFinishing()) {
            //记得清空列表
            xDialogManager.clear();
            xDialogManager = null;
        }
    }

}
