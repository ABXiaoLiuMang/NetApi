package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.fragment.finance.adapter.FinanceTotalAdapter;
import com.ty.bwagent.fragment.finance.bean.FinanceTotal;
import com.ty.bwagent.fragment.finance.viewmodel.FinanceTotalViewModel;
import com.ty.bwagent.view.XTextView;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.SimpleObserver;

import java.util.List;

/**
 * 月度详细-总输赢
 */
public class FinanceTotalFragment extends ABRefreshFragment<FinanceTotal> {

    FinanceTotalViewModel mFinanceTotalViewModel;
    TextView tv_month;//查询月份
    XTextView win_total;//总输赢
    TextView month_text;//月度明细月份
    ConstraintLayout title_layout;//标题栏
    String startData;
    FinanceEntity financeEntity;//佣金明细对象

    public static FinanceTotalFragment getInstance(Bundle bundle) {
        FinanceTotalFragment fragment = new FinanceTotalFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_details;
    }

    @Override
    protected void createProvider() {
        mFinanceTotalViewModel = new ViewModelProvider(this).get(FinanceTotalViewModel.class);
        mFinanceTotalViewModel.totalNetLiveData.observe(this, new SimpleObserver<BaseEntity<List<FinanceTotal>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<FinanceTotal>> financeTotals) {
                if (financeTotals.getData().size() > 0) {
                    title_layout.setVisibility(View.VISIBLE);
                } else {
                    title_layout.setVisibility(View.GONE);
                }
                listAdapter.setNewData(financeTotals.getData());
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

        });
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public View getEmptyView() {
        return View.inflate(mContext, R.layout.empty_message, null);
    }


    @Override
    public View getHeaderView() {
        View header = View.inflate(mContext, R.layout.header_finance_total,null);
        title_layout = header.findViewById(R.id.title_layout);
        tv_month = header.findViewById(R.id.tv_month);
        win_total = header.findViewById(R.id.win_total);
        month_text = header.findViewById(R.id.month_text);
        return header;
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        financeEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        startData = bundle.getString(ABConfig.KEY_TAG);
        mFinanceTotalViewModel.queryProfitDetail(startData);
        win_total.setMontyText(financeEntity.getProfit());
        tv_month.setText(startData);
        month_text.setText(startData);
    }

    @Override
    public int getMode() {
        return Mode.DISABLED;
    }

    @Override
    public BaseQuickAdapter<FinanceTotal, BaseViewHolder> getListAdapter() {
        return new FinanceTotalAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//        FinanceTotal mFinanceTotal = (FinanceTotal) adapter.getItem(position);
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
    }


}
