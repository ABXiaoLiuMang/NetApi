package com.ty.bwagent.dialog;

import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import com.lxj.xpopup.impl.PartShadowPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.AddBankCardEntity;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MaterialFilterEntity;
import com.ty.net.bean.NetLiveData;
import com.ty.net.callback.NetObserver;
import com.ty.pickerview.builder.OptionsPickerBuilder;
import com.ty.pickerview.view.OptionsPickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 素材筛选对话框
 */
public class MaterialFilterPopup extends PartShadowPopupView implements View.OnClickListener {

    TextView tv_screen;
    TextView tv_reset;
    TextView tv_value_size;
    TextView tv_value_type;
    EditText tv_value_title;

    OptionsPickerView<String> sizeOptions;
    OptionsPickerView<String> typeOptions;
    MutableLiveData<MaterialFilterEntity> filterLiveData;
    String type = "";
    String title = "";
    String size = "";
    List<String> typeDatas = new ArrayList<>();
    List<String> sizeDatas = new ArrayList<>();
    List<AddBankCardEntity> imageTypeList = new ArrayList<>();
    NetLiveData<BaseEntity<List<String>>> sizeListLiveData;
    NetLiveData<BaseEntity<List<AddBankCardEntity>>> imageTypeLiveData;


    public MaterialFilterPopup(@NonNull Context context, MutableLiveData<MaterialFilterEntity> filterLiveData,NetLiveData<BaseEntity<List<String>>> sizeListLiveData,NetLiveData<BaseEntity<List<AddBankCardEntity>>> imageTypeLiveData) {
        super(context);
        this.filterLiveData = filterLiveData;
        this.sizeListLiveData = sizeListLiveData;
        this.imageTypeLiveData = imageTypeLiveData;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_material_filter;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_reset = findViewById(R.id.tv_reset);
        tv_reset.setOnClickListener(this);
        tv_reset.setTextColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        tv_reset.setBackgroundColor(ResUtils.getColor(SiteSdk.ins().btnEnableColor()));
        tv_screen = findViewById(R.id.tv_screen);
        tv_screen.setOnClickListener(this);
        tv_screen.setBackgroundColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        tv_value_title = findViewById(R.id.tv_value_title);
        tv_value_size = findViewById(R.id.tv_value_size);
        tv_value_size.setOnClickListener(this);
        tv_value_type = findViewById(R.id.tv_value_type);
        tv_value_type.setOnClickListener(this);

        buildTypeOptionsPicker();
        sizeListLiveData.observeForever(observerSize);
        imageTypeLiveData.observeForever(observerImageType);
        resetInit();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_value_size://图片尺寸
                KeyboardUtils.hideSoftInput(v);
                if(sizeOptions != null){
                    sizeOptions.show();
                }else {
                    ToastUtils.showLong(ResUtils.getString(R.string.timeout_error));
                }
                break;
            case R.id.tv_value_type://图片类型
                KeyboardUtils.hideSoftInput(v);
                typeOptions.show();
                break;
            case R.id.tv_reset://重置
                resetInit();
                filterLiveData.postValue(new MaterialFilterEntity(type, title, size));
                dismiss();
                break;
            case R.id.tv_screen://筛选
                title = tv_value_title.getText().toString().trim();
                filterLiveData.postValue(new MaterialFilterEntity(type, title, size));
                dismiss();
                break;
        }
    }

    private void resetInit() {
        type = "";
        title = "";
        size = "";
        tv_value_title.setText("");
        tv_value_size.setText("全部");
        tv_value_type.setText("全部");
    }

    @Override
    protected void onDismiss() {
        super.onDismiss();
        if(sizeOptions != null && sizeOptions.isShowing()){
            sizeOptions.dismiss();
        }
        if(typeOptions != null && typeOptions.isShowing()){
            typeOptions.dismiss();
        }
        sizeListLiveData.removeObserver(observerSize);
        imageTypeLiveData.removeObserver(observerImageType);
    }

    NetObserver<BaseEntity<List<String>>> observerSize = new NetObserver<BaseEntity<List<String>>>() {
        @Override
        protected void onSuccess(BaseEntity<List<String>> listBaseEntity) {
            sizeDatas.add("全部");
            sizeDatas.addAll(listBaseEntity.getData());
            buildSizeOptionsPicker();
        }

        @Override
        protected void onError(int code, String errMsg) {
        }
    };

    NetObserver<BaseEntity<List<AddBankCardEntity>>> observerImageType = new NetObserver<BaseEntity<List<AddBankCardEntity>>>() {
        @Override
        protected void onSuccess(BaseEntity<List<AddBankCardEntity>> listBaseEntity) {
            imageTypeList.clear();
            typeDatas.clear();
            imageTypeList.addAll(listBaseEntity.getData());
            typeDatas.add("全部");
            for(AddBankCardEntity entity : imageTypeList){
                typeDatas.add(entity.getDictValue());
            }

            buildTypeOptionsPicker();
        }

        @Override
        protected void onError(int code, String errMsg) {
        }
    };

    private void buildSizeOptionsPicker() {
        if (sizeOptions == null) {
            sizeOptions = new OptionsPickerBuilder(getContext(), (options1, options2, options3, v) -> {
                if(options1 == 0){
                    size = "";
                    tv_value_size.setText("全部");
                }else {
                    size = sizeDatas.get(options1);
                    tv_value_size.setText(size);
                }
            })
                    .setSubmitText("确定")
                    .setSubmitColor(ResUtils.getColor(R.color.site_style_color))
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(R.color.site_style_color))
                    .setTitleText("图片尺寸")
                    .setTitleColor(ResUtils.getColor(R.color.generic_heise))
                    .setLabels("", "", "")
                    .setCyclic(false, false, false)
                    .setSelectOptions(0, 0, 0)
                    .build();
        }
        sizeOptions.setPicker(sizeDatas);
    }

    private void buildTypeOptionsPicker() {
        if (typeOptions == null) {
            typeOptions = new OptionsPickerBuilder(getContext(), (options1, options2, options3, v) -> {
                if(options1 == 0){
                    type = "";
                    tv_value_type.setText("全部");
                }else {
                    type = imageTypeList.get(options1 - 1).getCode();
                    tv_value_type.setText(typeDatas.get(options1));
                }

            })
                    .setSubmitText("确定")
                    .setSubmitColor(ResUtils.getColor(R.color.site_style_color))
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(R.color.site_style_color))
                    .setTitleText("图片类型")
                    .setTitleColor(ResUtils.getColor(R.color.generic_heise))
                    .setLabels("", "", "")
                    .setCyclic(false, false, false)
                    .setSelectOptions(0, 0, 0)
                    .build();
        }
        typeOptions.setPicker(typeDatas);
    }

}
