package com.ty.bwagent.fragment.deposit.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.SchemeSetViewModle;
import com.ty.net.NetSdk;

/**
 * 代理代存，代理转账，配置
 */
public class TurnConfigViewModel extends SchemeSetViewModle {

    /**
     * 代理代存，代理转账，配置
     */
    public void getAgentDepositConfig() {
        NetSdk.create(Api.class)
                .getAgentDepositConfig()
                .send(XLiveDataManager.getInstance().memberConfigLiveData);
    }
}
