package com.ty.bwagent.view.share;

public class ColorModel {
   private String titleColor;
   private int color;

    public ColorModel(String titleColor, int color) {
        this.titleColor = titleColor;
        this.color = color;
    }

    public String getTitleColor() {
        return titleColor;
    }

    public void setTitleColor(String titleColor) {
        this.titleColor = titleColor;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }
}
