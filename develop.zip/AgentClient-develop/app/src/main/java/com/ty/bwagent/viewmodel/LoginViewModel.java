package com.ty.bwagent.viewmodel;

import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.R;
import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.Md5Util;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.net.NetCall;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.AppUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

public class LoginViewModel extends CodeViewModel {

    //登录
    public NetLiveData<BaseEntity<UserInfo>> loginLiveData = new NetLiveData<>();


    /**
     *
     * @param userName 用户名
     * @param password 密码
     * @param verifyCode 验证码
     * @param hasCode 是否需要验证码（输入验证码控件是否显示隐藏判断确定）
     */
    public void login(final String userName, final String password, String verifyCode,boolean hasCode){
        login(userName,password,verifyCode,"",hasCode);
    }


    /**
     *
     * @param userName 用户名
     * @param password 密码
     * @param verifyCode 验证码
     * @param phoneCode 风控手机验证码
     * @param hasCode 是否需要验证码（输入验证码控件是否显示隐藏判断确定）
     */
    public void login(final String userName, final String password, String verifyCode,String phoneCode,boolean hasCode){

        if(hasCode){
            if (!StringUtils.isEmpty(verifyCode) && StringUtils.length(verifyCode) < 4 ) {
                loginLiveData.setError(22006,ResUtils.getString(R.string.generic_imagecode_warn));
                return;
            }
        }

        if (!VerifyUtils.isUserName(userName)) {
            loginLiveData.setError(0, ResUtils.getString(R.string.generic_username_warn));
            return;
        }

        if (StringUtils.length(password) < 6) {
            loginLiveData.setError(0,ResUtils.getString(R.string.generic_password_warn));
            return;
        }

        NetCall<BaseEntity<UserInfo>> netCall = NetSdk.create(Api.class)
                .login()
                .params("username",userName)
                .params("password",Md5Util.md5(password))
                .params("loginDeviceNo",AppUtil.getUUID())
                .params("flag",1)
                .params("sendCodeNum",phoneCode)
                .params("imgCode",verifyCode)
                .asJSONType();
        //欧宝登录参数差异化处理
        if(StringUtils.equals("3", BuildConfig.appType)){
            netCall.params("oldPassword",Md5Util.md5(getOldPassWord(userName,password)));
        }
        netCall.send(loginLiveData);
    }

    private String getOldPassWord(String userName,String passWord){
        String salt = Md5Util.md5(userName.toLowerCase()).substring(2,17);
        return salt + passWord + salt;
    }

}
