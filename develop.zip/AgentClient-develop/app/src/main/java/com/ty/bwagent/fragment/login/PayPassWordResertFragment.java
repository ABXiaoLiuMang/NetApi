package com.ty.bwagent.fragment.login;

import android.view.View;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.fragment.finance.fragment.DrawWalletFragment;
import com.ty.bwagent.utils.Key;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XPassWordView;
import com.ty.bwagent.viewmodel.MoneyViewModel;
import com.ty.bwagent.viewmodel.PayPasswordViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.NetObserver;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;

public class PayPassWordResertFragment extends ABBaseFragment implements View.OnClickListener {

    @BindView(R.id.tv_phone)
    TextView tv_phone;
    @BindView(R.id.tv_warning)
    TextView tv_warning;
    @BindView(R.id.tv_verify_code)
    TextView tvVerifyCode;
    @BindView(R.id.et_code)
    ClearEditText et_code;
    @BindView(R.id.tv_commit)
    TextView tvCommit;

    @BindView(R.id.x_newPass)
    XPassWordView x_newPass;
    @BindView(R.id.x_confirmPass)
    XPassWordView x_confirmPass;

    private PayPasswordViewModel registerViewModel;
    boolean isTimer;
    private MoneyViewModel moneyViewModel;
    private String phone = "";

    public static PayPassWordResertFragment getInstance() {
        PayPassWordResertFragment fragment = new PayPassWordResertFragment();
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_pay_password_resert;
    }

    @Override
    protected void createProvider() {
        initeDtae();
        initListener();
    }

    @Override
    protected void initViewsAndEvents() {

    }


    private void initeDtae() {
        moneyViewModel = new ViewModelProvider(this).get(MoneyViewModel.class);

        registerViewModel = new ViewModelProvider(this).get(PayPasswordViewModel.class);
        tvVerifyCode.setOnClickListener(this);
        tvCommit.setOnClickListener(this);
        UserInfo mUserInfo = UserInfoCache.getInstance().getUserInfo();
        if (mUserInfo != null && mUserInfo.getRealPhone() != null && mUserInfo.getRealPhone().length() >= 11) {
            tv_phone.setText(Utils.getHidePhone(mUserInfo.getRealPhone()));
        }
        Utils.isClicked60S(PayPassWordResertFragment.class.getSimpleName(),getLifecycle(),registerViewModel,tvVerifyCode);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_verify_code:
                tvVerifyCode.setEnabled(false);
                if (StringUtils.isEmpty(phone)) {
                    moneyViewModel.getDrawPhone();
                } else {
                    registerViewModel.getPhoneCode(phone);
                }
                break;
            case R.id.tv_commit:
                registerViewModel.resertPassWord(x_newPass.getPassText(), x_confirmPass.getPassText(), et_code.getText().toString().trim());
                break;
        }
    }


    private void initListener() {

        registerViewModel.resertPasswordLiveData.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity o) {
                ToastUtils.showLong("重置成功");
                pop();
            }

            @Override
            protected void onError(int code, String errMsg) {
                tv_warning.setText(errMsg);
            }
        });

        new InputResultCalculator(Arrays.asList(x_newPass.getPassEditText(), x_confirmPass.getPassEditText()), ok -> {
            tvCommit.setEnabled(ok);
        });


        //验证码倒计时
        registerViewModel.timerLiveData.observe(this, aLong -> {
            if (aLong == 0) {
                isTimer = false;
                tvVerifyCode.setText(ResUtils.getString(R.string.generic_reset_code));
                tvVerifyCode.setEnabled(true);
            } else {
                isTimer = true;
                tvVerifyCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time), aLong));
                tvVerifyCode.setEnabled(false);
            }
        });

        //监听验证码
        registerViewModel.codeLivedata.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ToastUtils.showLong("验证码已发送");
                //保存获取成功验证码时间，60秒能不能重复获取
                MMKVUtil.put(PayPassWordResertFragment.class.getSimpleName(),System.currentTimeMillis());
                registerViewModel.startTimer(getLifecycle());
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
                tvVerifyCode.setEnabled(true);
                MMKVUtil.put(PayPassWordResertFragment.class.getSimpleName(),System.currentTimeMillis());
                Utils.isClickedReset60S(errMsg,getLifecycle(),registerViewModel,tvVerifyCode);
            }
        });

        //监听获取未脱敏的电话号码
        moneyViewModel.drawPhoneLiveData.observe(this, new NetObserver<BaseEntity<String>>() {
            @Override
            protected void onSuccess(BaseEntity<String> entity) {
                if (entity != null && entity.getData() != null) {
                    PayPassWordResertFragment.this.phone = entity.getData();
                    registerViewModel.getPhoneCode(phone);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                tv_warning.setText(errMsg);
                tvVerifyCode.setEnabled(true);

            }
        });

        new InputResultCalculator(Arrays.asList(et_code, x_newPass.getPassEditText(), x_confirmPass.getPassEditText()), ok -> {
            tvCommit.setEnabled(ok);
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        KeyboardUtils.hideSoftInput(tvCommit);
    }
}
