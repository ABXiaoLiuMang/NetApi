package com.ty.bwagent.utils;

import android.widget.EditText;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.view.ClearEditText;

/**
 * 处理注册登录，修改密码，找回密码一系列输入框聚焦，失焦，文案提示
 */
public class VerifyUtils {



    /**
     * 用户名验证
     * @param etUserName 用户名输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyUserName(ClearEditText etUserName, TextView tvWarn){
        etUserName.setOnFocusChangeListener((v, hasFocus) -> {
            String userName = etUserName.getText().toString().trim();

            if(hasFocus){//获的焦点
                if (StringUtils.length(userName) > 0){
                    etUserName.setClearIconVisible(true);
                }
                tvWarn.setText("");
            }else {//失去焦点

                if (StringUtils.length(userName) < 4 && StringUtils.length(userName) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_username_warn));
                }
                etUserName.setClearIconVisible(false);
            }
        });



    }
    /**
     * 密码验证
     * @param etPassWord 密码输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyPassWord(EditText etPassWord, TextView tvWarn){
        etPassWord.setOnFocusChangeListener((v, hasFocus) -> {
            String userPassWord;

            if(hasFocus){//获的焦点
               String warn = tvWarn.getText().toString();
               //提示语是自己错误提示的，就清掉
               if(StringUtils.equals(ResUtils.getString(R.string.generic_password_warn),warn)){
                   tvWarn.setText("");
               }
            }else {//失去焦点
                userPassWord = etPassWord.getText().toString().trim();
                if (StringUtils.length(userPassWord) < 6 && StringUtils.length(userPassWord) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_password_warn));
                }
            }
        });
    }

    /**
     * 电话号码验证
     * @param etPhone 密码输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyPhone(EditText etPhone, TextView tvWarn){
        etPhone.setOnFocusChangeListener((v, hasFocus) -> {
            String phone;

            if(hasFocus){//获的焦点
               String warn = tvWarn.getText().toString();
               //提示语是自己错误提示的，就清掉
               if(StringUtils.equals(ResUtils.getString(R.string.generic_phone_warn),warn)){
                   tvWarn.setText("");
               }
            }else {//失去焦点
                phone = etPhone.getText().toString().trim();
                if (!ParameterVerification.isPhoneNumber(phone) && StringUtils.length(phone) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_phone_warn));
                }
            }
        });
    }
    /**
     * 电话号码验证(忘记密码中提示语)
     * @param etPhone 密码输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyForgetPhone(EditText etPhone, TextView tvWarn){
        etPhone.setOnFocusChangeListener((v, hasFocus) -> {
            String phone;

            if(hasFocus){//获的焦点
               String warn = tvWarn.getText().toString();
               //提示语是自己错误提示的，就清掉
               if(StringUtils.equals(ResUtils.getString(R.string.generic_phone_warn1),warn)){
                   tvWarn.setText("");
               }
            }else {//失去焦点
                phone = etPhone.getText().toString().trim();
                if (!ParameterVerification.isPhoneNumber(phone) && StringUtils.length(phone) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_phone_warn1));
                }
            }
        });
    }

    /**
     * 邮箱验证
     * @param etEmail 邮箱输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyEmail(EditText etEmail, TextView tvWarn){
        etEmail.setOnFocusChangeListener((v, hasFocus) -> {
            String email;

            if(hasFocus){//获的焦点
               String warn = tvWarn.getText().toString();
               //提示语是自己错误提示的，就清掉
               if(StringUtils.equals(ResUtils.getString(R.string.generic_email_warn),warn)){
                   tvWarn.setText("");
               }
            }else {//失去焦点
                email = etEmail.getText().toString().trim();
                if (!ParameterVerification.isEmail(email) && StringUtils.length(email) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_email_warn));
                }
            }
        });

    }

    /**
     * 邮箱验证
     * @param etQQ qq输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyQQ(EditText etQQ, TextView tvWarn){
        etQQ.setOnFocusChangeListener((v, hasFocus) -> {
            String qq;

            if(hasFocus){//获的焦点
               String warn = tvWarn.getText().toString();
               //提示语是自己错误提示的，就清掉
               if(StringUtils.equals(ResUtils.getString(R.string.generic_qq_warn),warn)){
                   tvWarn.setText("");
               }
            }else {//失去焦点
                qq = etQQ.getText().toString().trim();
                if (StringUtils.length(qq) > 0 && qq.length() < 5) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_qq_warn));
                }
            }
        });

    }


    /**
     * 金额输入小于100错误提示
     * @param etMoney 金额输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyMinMoney(EditText etMoney, TextView tvWarn){
        etMoney.setOnFocusChangeListener((v, hasFocus) -> {
            String money;

            if(hasFocus){//获的焦点
                String warn = tvWarn.getText().toString();
                //提示语是自己错误提示的，就清掉
                if(StringUtils.equals(ResUtils.getString(R.string.generic_draw_monty_warn),warn)){
                    tvWarn.setText("");
                }
            }else {//失去焦点
                money = etMoney.getText().toString().trim();
                if (StringUtils.length(money) > 0 && StringUtils.parseDouble(money) < 100 ) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_draw_monty_warn));
                }
            }
        });
    }

    /**
     * 绑定银行卡验证输入用户名
     * 1.规则，小于2位错误提示
     * @param etBindCardName 姓名输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyBindCardName(EditText etBindCardName, TextView tvWarn){
        etBindCardName.setOnFocusChangeListener((v, hasFocus) -> {
            String userName;

            if(hasFocus){//获的焦点
                String warn = tvWarn.getText().toString();
                //提示语是自己错误提示的，就清掉
                if(StringUtils.equals(ResUtils.getString(R.string.generic_draw_name_warn),warn)){
                    tvWarn.setText("");
                }
            }else {//失去焦点
                userName = etBindCardName.getText().toString().trim();
                if (StringUtils.length(userName) == 1) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_draw_name_warn));
                }
            }
        });
    }

    /**
     * 验证码验证
     * @param etCode 验证码输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyCode(EditText etCode, TextView tvWarn){
        etCode.setOnFocusChangeListener((v, hasFocus) -> {
            String code;

            if(hasFocus){//获的焦点
               String warn = tvWarn.getText().toString();
               //提示语是自己错误提示的，就清掉
               if(StringUtils.equals(ResUtils.getString(R.string.generic_code_warn),warn)){
                   tvWarn.setText("");
               }
            }else {//失去焦点
                code = etCode.getText().toString().trim();
                if (StringUtils.length(code) < 6 && StringUtils.length(code) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_code_warn));
                }
            }
        });
    }

    /**
     * 验证图形码验证
     * @param etCode 验证码输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyImageCode(EditText etCode, TextView tvWarn){
        etCode.setOnFocusChangeListener((v, hasFocus) -> {
            String code;

            if(hasFocus){//获的焦点
               String warn = tvWarn.getText().toString();
               //提示语是自己错误提示的，就清掉
               if(StringUtils.equals(ResUtils.getString(R.string.generic_imagecode_warn),warn)){
                   tvWarn.setText("");
               }
            }else {//失去焦点
                code = etCode.getText().toString().trim();
                if (StringUtils.length(code) < 4 && StringUtils.length(code) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_imagecode_warn));
                }
            }
        });
    }

    /**
     * 银行卡号验证
     * @param etBankCard 银行卡号输入框
     * @param tvWarn 提示文案控件
     */
    public static void verifyBankCarde(EditText etBankCard, TextView tvWarn){
        etBankCard.setOnFocusChangeListener((v, hasFocus) -> {
            String bankCard;

            if(hasFocus){//获的焦点
               String warn = tvWarn.getText().toString();
               //提示语是自己错误提示的，就清掉
               if(StringUtils.equals(ResUtils.getString(R.string.generic_bankcard_warn),warn)){
                   tvWarn.setText("");
               }
            }else {//失去焦点
                bankCard = etBankCard.getText().toString().trim();
                if (StringUtils.length(bankCard) < 16 && StringUtils.length(bankCard) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_bankcard_warn));
                }
            }
        });
    }


    /**
     * 判断银行卡是否合法
     * @param bankCard
     * @return
     */
    public static boolean isBankCard(String bankCard){
        return StringUtils.length(bankCard) > 15;
    }

    /**
     * 判断用户名输入是否合法
     * @param userName
     * @return
     */
    public static boolean isUserName(String userName){
        return StringUtils.length(userName) >= 4;
    }

    /**
     * 判断密码输入是否合法
     * @param passWord
     * @return
     */
    public static boolean isUserPassWord(String passWord){
        return StringUtils.length(passWord) >= 6;
    }
    /**
     * 判断验证码输入是否合法
     * @param code
     * @return
     */
    public static boolean isCode(String code){
        return StringUtils.length(code) == 6;
    }
    /**
     * 图形验证码必须4位以上
     * 判断图形验证码输入是否合法
     * @param code
     * @return
     */
    public static boolean isImageCode(String code){
        return StringUtils.length(code) > 3;
    }


}
