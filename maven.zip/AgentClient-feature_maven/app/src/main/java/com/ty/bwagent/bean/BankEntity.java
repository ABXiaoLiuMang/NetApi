package com.ty.bwagent.bean;

/**
 * 添加银行卡后携带返回数据
 */
public class BankEntity {

    String bankCode;//银行代码
    String bank_card;//银行卡号
    String bank_address;//开户地址
    String real_name;//真实姓名
    String bank_Name;//银行名字

    public BankEntity(String bank_Name,String bankCode, String bank_card, String bank_address,String real_name) {
        this.bank_Name = bank_Name;
        this.bank_card = bank_card;
        this.bank_address = bank_address;
        this.real_name = real_name;
        this.bankCode = bankCode;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBank_card() {
        return bank_card;
    }

    public void setBank_card(String bank_card) {
        this.bank_card = bank_card;
    }

    public String getBank_address() {
        return bank_address;
    }

    public void setBank_address(String bank_address) {
        this.bank_address = bank_address;
    }

    public String getReal_name() {
        return real_name;
    }

    public void setReal_name(String real_name) {
        this.real_name = real_name;
    }

    public String getBank_Name() {
        return bank_Name;
    }

    public void setBank_Name(String bank_Name) {
        this.bank_Name = bank_Name;
    }
}
