package com.ty.bwagent.adapter;

import android.text.TextUtils;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.utils.ExtensionUtils;
import com.ty.bwagent.utils.Key;
import com.ty.tysite.utils.ImageResoureSiteUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;


/**
 * 描述
 * <p> 推广列表适配器
 * author:Dale
 */
public class ExtensionAdapter extends BaseQuickAdapter<ExtensionEntity, BaseViewHolder> {

    String title;
    String inviteCode;

    public ExtensionAdapter(String title) {
        super(R.layout.recycle_item_extension);
        this.title = title;
        inviteCode = MMKVUtil.getString(Key.INVITE_CODE);
    }

    @Override
    protected void convert(BaseViewHolder helper, ExtensionEntity mExtensionEntity) {

        helper.setText(R.id.extension_tv_register, StringUtils.getFormatString(ResUtils.getString(R.string.generic_register_number), mExtensionEntity.getRegisterNum()));

        if (mExtensionEntity.isExclusive()) {
            helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl());
        } else if (TextUtils.isEmpty(inviteCode)) {
            helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl());
        } else {
            if (StringUtils.equals("h5", mExtensionEntity.getClientType())) {
                helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl() + "/entry/register/?i_code=" + inviteCode);
            } else if (StringUtils.equals("pc", mExtensionEntity.getClientType())) {
                helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl() + "/register/?i_code=" + inviteCode);
            } else {
                helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl() + "/?i_code=" + inviteCode);
            }
        }

        helper.setText(R.id.extension_tv_title, mExtensionEntity.isExclusive() ? StringUtils.isEmpty(mExtensionEntity.getTitle()) ? "" : mExtensionEntity.getTitle()
                : ExtensionUtils.getName(mExtensionEntity.getClientType()));
        helper.setVisible(R.id.extension_iv_url, mExtensionEntity.isExclusive());
        helper.setBackgroundRes(R.id.extension_iv_url, ImageResoureSiteUtils.extensionHostBg());

        helper.addOnClickListener(R.id.extension_iv_share);
    }


}

