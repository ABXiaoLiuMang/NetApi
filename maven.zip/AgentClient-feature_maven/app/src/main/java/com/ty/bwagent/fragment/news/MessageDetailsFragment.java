package com.ty.bwagent.fragment.news;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MMessage;
import com.ty.bwagent.bean.MessageSys;
import com.ty.bwagent.viewmodel.MessageDetailsViewModel;
import com.ty.bwagent.viewmodel.MessageViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.CircleImageView;

import butterknife.BindView;


public class MessageDetailsFragment extends ABBaseFragment {

    MessageViewModel mMessageViewModel;
    MessageDetailsViewModel messageDetailsViewModel;
    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.message_head)
    CircleImageView messageHead;
    @BindView(R.id.message_text)
    TextView messageText;
    @BindView(R.id.message_time)
    TextView messageTime;
    @BindView(R.id.message_inf)
    TextView messageInf;
    MMessage.ListBean mMessage;
    MessageSys.ListBean mMessageSys;
    int msgType;//1 通知，2，活动  3.公告

    public static MessageDetailsFragment getInstance(Bundle bundle) {
        MessageDetailsFragment fragment = new MessageDetailsFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_message_details;
    }

    @Override
    protected void createProvider() {
        messageDetailsViewModel = new ViewModelProvider(this).get(MessageDetailsViewModel.class);
        mMessageViewModel = new ViewModelProvider(findFragment(MessageTabFragment.class)).get(MessageViewModel.class);

        //删除一条通知消息
        messageDetailsViewModel.deleteLiveData.observe(this,new SimpleObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                mMessageViewModel.delMsgLiveData.postValue(mMessage.getId());
                ToastUtils.showLong("删除成功");
                pop();
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        msgType = bundle.getInt(ABConfig.KEY_TAG);
        if(msgType == 3 ){//只有msgType=1既通知消息才显示删除按钮
            titleBar.setShowRight(View.GONE);
        }
        titleBar.setRightOnClickListener(view -> {
            messageDetailsViewModel.msgDelete(mMessage.getId());
        });
        initView();
    }
    private void initView(){
        if(msgType == 3){//公告消息
            mMessageSys = bundle.getParcelable(ABConfig.KEY_OBJECT);

            messageText.setText(mMessageSys.getTitle());
            messageTime.setText(mMessageSys.getCreatedAt());
            messageInf.setText(mMessageSys.getContent());
            String imageUrl = mMessageSys.getAppImageUrl();
            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.mipmap.icon_message_cz_bg)
                    .error(R.mipmap.icon_message_cz_bg);
            Glide.with(mContext).load(imageUrl).apply(requestOptions).into(messageHead);

        }else {
            mMessage = bundle.getParcelable(ABConfig.KEY_OBJECT);
            messageText.setText(mMessage.getTitle());
            messageTime.setText(mMessage.getSendTime());
            messageInf.setText(mMessage.getContent());

            String imageUrl = mMessage.getImgUrl();
            if (StringUtils.isEmpty(imageUrl) && mMessage.getIcon() != null) {
                MMessage.ListBean.IconBean iconBean = mMessage.getIcon();
                imageUrl = iconBean.getIcon_96_96();
            }
            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.mipmap.icon_message_cz_bg)
                    .error(R.mipmap.icon_message_cz_bg);
            Glide.with(mContext).load(imageUrl).apply(requestOptions).into(messageHead);
        }
    }

}
