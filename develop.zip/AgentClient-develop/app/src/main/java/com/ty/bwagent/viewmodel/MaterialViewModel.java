package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.AddBankCardEntity;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.bean.MaterialEntity;
import com.ty.net.NetCall;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.StringUtils;

import java.util.List;

public class MaterialViewModel extends ViewModel {

    //素材列表查询接口
    public NetLiveData<BaseEntity<MaterialEntity>> materialListLiveData = new NetLiveData<>();

    //图片尺寸下拉框
    public NetLiveData<BaseEntity<List<String>>> sizeListLiveData = new NetLiveData<>();

    //查询图片素材类型列表
    public NetLiveData<BaseEntity<List<AddBankCardEntity>>> imageTypeLiveData = new NetLiveData<>();

    /**
     * 获取推广链接地址
     */
    public NetLiveData<BaseEntity<List<ExtensionEntity>>> entityNetLiveData = new NetLiveData<>();

    /***
     * 素材列表查询接口
     * @param imageType 图片类型
     * @param imageTitle 图片标题
     * @param imageSize 图片尺寸
     * @param pageSize
     * @param pageNumber
     */
    public void selectMaterialList(String imageType,String imageTitle,String imageSize,int pageSize,int pageNumber){
        NetSdk.create(Api.class)
                .selectMaterialList()
                .params("pageSize", pageSize)
                .params("pageNumber", pageNumber)
                .params("imageSize", imageSize)
                .params("imageType", imageType)
                .params("imageTitle", imageTitle)
                .asJSONType()
                .send(materialListLiveData);
    }

    /**
     * 查询图片尺寸
     */
    public void selectMaterialSizeList(){
        NetSdk.create(Api.class)
                .selectMaterialSizeList()
                .asJSONType()
                .send(sizeListLiveData);
    }

    /**
     * 查询图片素材类型列表
     */
    public void queryImageType(){
        NetSdk.create(Api.class)
                .queryBanks()
                .params("dictCode","image_type")
                .asJSONType()
                .send(imageTypeLiveData);
    }

    public void domainByClientType() {
        NetSdk.create(Api.class)
                .domainByClientType()
                .params("clientType", "")
                .asJSONType()
                .send(entityNetLiveData);
    }
}
