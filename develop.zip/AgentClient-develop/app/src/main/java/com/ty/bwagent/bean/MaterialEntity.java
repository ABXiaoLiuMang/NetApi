package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 描述:
 * <p>
 * author:Dale
 */
public class MaterialEntity {
    /**
     * list : [{"createAt":"2020-01-14T19:59:42","deleteStatus":0,"enableStatus":1,"id":11,"imageId":"3,ofnasonoin.jpg","imageSize":"680 * 680","imageTitle":"规范化京东方图片","imageType":3,"imageTypeZh":"赞助推广图","imageUrl":"http://baidu.com/3,ofnasonoin.jpg","timesTamp":1579003181623,"updateAt":"2020-01-14T19:59:42"},{"createAt":"2020-01-14T19:59:29","deleteStatus":0,"enableStatus":1,"id":10,"imageId":"3,ofnasonoin.jpg","imageSize":"680 * 680","imageTitle":"阿尔特塔图片","imageType":3,"imageTypeZh":"赞助推广图","imageUrl":"http://baidu.com/3,ofnasonoin.jpg","timesTamp":1579003169267,"updateAt":"2020-01-14T19:59:29"},{"createAt":"2020-01-14T19:59:26","deleteStatus":0,"enableStatus":1,"id":9,"imageId":"3,rgwegsggsd.jpg","imageSize":"780 * 780","imageTitle":"大红包图片","imageType":2,"imageTypeZh":"app推广图","imageUrl":"http://adfbgd.com/3,rgwegsggsd.jpg","timesTamp":1579003165743,"updateAt":"2020-01-14T20:56:29"}]
     */

    private List<ListBean> list;


    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }


    public static class ListBean implements Parcelable {
        /**
         * createAt : 2020-01-14T19:59:42
         * deleteStatus : 0
         * enableStatus : 1
         * id : 11
         * imageId : 3,ofnasonoin.jpg
         * imageSize : 680 * 680
         * imageTitle : 规范化京东方图片
         * imageType : 3
         * imageTypeZh : 赞助推广图
         * imageUrl : http://baidu.com/3,ofnasonoin.jpg
         * timesTamp : 1579003181623
         * updateAt : 2020-01-14T19:59:42
         */

        private String createAt;
        private int deleteStatus;
        private int enableStatus;
        private int id;
        private String imageId;
        private String imageSize;
        private String imageTitle;
        private int imageType;
        private String imageTypeZh;
        private String imageUrl;
        private long timesTamp;
        private String updateAt;

        protected ListBean(Parcel in) {
            createAt = in.readString();
            deleteStatus = in.readInt();
            enableStatus = in.readInt();
            id = in.readInt();
            imageId = in.readString();
            imageSize = in.readString();
            imageTitle = in.readString();
            imageType = in.readInt();
            imageTypeZh = in.readString();
            imageUrl = in.readString();
            timesTamp = in.readLong();
            updateAt = in.readString();
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(createAt);
            dest.writeInt(deleteStatus);
            dest.writeInt(enableStatus);
            dest.writeInt(id);
            dest.writeString(imageId);
            dest.writeString(imageSize);
            dest.writeString(imageTitle);
            dest.writeInt(imageType);
            dest.writeString(imageTypeZh);
            dest.writeString(imageUrl);
            dest.writeLong(timesTamp);
            dest.writeString(updateAt);
        }

        @Override
        public int describeContents() {
            return 0;
        }

        public static final Creator<ListBean> CREATOR = new Creator<ListBean>() {
            @Override
            public ListBean createFromParcel(Parcel in) {
                return new ListBean(in);
            }

            @Override
            public ListBean[] newArray(int size) {
                return new ListBean[size];
            }
        };

        public String getCreateAt() {
            return createAt;
        }

        public void setCreateAt(String createAt) {
            this.createAt = createAt;
        }

        public int getDeleteStatus() {
            return deleteStatus;
        }

        public void setDeleteStatus(int deleteStatus) {
            this.deleteStatus = deleteStatus;
        }

        public int getEnableStatus() {
            return enableStatus;
        }

        public void setEnableStatus(int enableStatus) {
            this.enableStatus = enableStatus;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getImageId() {
            return imageId;
        }

        public void setImageId(String imageId) {
            this.imageId = imageId;
        }

        public String getImageSize() {
            return imageSize;
        }

        public void setImageSize(String imageSize) {
            this.imageSize = imageSize;
        }

        public String getImageTitle() {
            return imageTitle;
        }

        public void setImageTitle(String imageTitle) {
            this.imageTitle = imageTitle;
        }

        public int getImageType() {
            return imageType;
        }

        public void setImageType(int imageType) {
            this.imageType = imageType;
        }

        public String getImageTypeZh() {
            return imageTypeZh;
        }

        public void setImageTypeZh(String imageTypeZh) {
            this.imageTypeZh = imageTypeZh;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public long getTimesTamp() {
            return timesTamp;
        }

        public void setTimesTamp(long timesTamp) {
            this.timesTamp = timesTamp;
        }

        public String getUpdateAt() {
            return updateAt;
        }

        public void setUpdateAt(String updateAt) {
            this.updateAt = updateAt;
        }
    }
}
