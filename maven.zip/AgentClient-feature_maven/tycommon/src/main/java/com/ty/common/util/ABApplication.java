package com.ty.common.util;

import android.app.Application;

import com.ty.constant.LibApplication;
import com.ty.utils.FileUtils;

public class ABApplication extends Application {

	private static ABApplication instance;

	public static ABApplication getInstance() {
		return instance;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		instance = this;
		LibApplication.init(this, FileUtils.PREFERENCE);
	}

}
