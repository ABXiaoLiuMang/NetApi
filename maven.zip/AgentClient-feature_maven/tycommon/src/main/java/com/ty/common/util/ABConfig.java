package com.ty.common.util;

public class ABConfig {

	public static final String KEY_TAG = "tag";
	public static final String KEY_TITLE = "title";
	public static final String KEY_TEXT = "text";
	public static final String KEY_LIST = "list";
	public static final String KEY_OBJECT = "object";

}
