package com.ty.bwagent.fragment.login;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.bean.ValidateCodeEntity;
import com.ty.bwagent.bean.VerifyEntity;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.LoginViewModel;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.net.utils.JsonUtils;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 登录异常，需要短信验证
 */
public class VerifyFragment extends ABBaseFragment {

    LoginViewModel verifyModel;
    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.iv_verify_logo)
    ImageView ivVerifyLogo;
    @BindView(R.id.tv_verify_err)
    TextView tvVerifyErr;
    @BindView(R.id.verify_et_code)
    ClearEditText verifyEtCode;
    @BindView(R.id.verify_tv_code)
    TextView verifyTvCode;
    @BindView(R.id.verify_commit)
    TextView verifyCommit;
    @BindView(R.id.tv_err)
    TextView tv_err;
    @BindView(R.id.login_et_code)
    ClearEditText login_et_code;
    @BindView(R.id.login_iv_code)
    ImageView login_iv_code;
    @BindView(R.id.layout_image)
    ConstraintLayout layout_image;
    String userName;
    String passWord;


    public static VerifyFragment getInstance(Bundle bundle) {
        VerifyFragment fragment = new VerifyFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_verify;
    }

    @Override
    protected void createProvider() {
        SystemModel.loginVerify.postValue(null);
        verifyModel = new ViewModelProvider(this).get(LoginViewModel.class);
        //验证码倒计时
        verifyModel.timerLiveData.observe(this, aLong -> {
            if(aLong == 0){
                verifyTvCode.setText(ResUtils.getString(R.string.generic_reset_code));
                verifyTvCode.setEnabled(true);
            }else {
                verifyTvCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time),aLong));
                verifyTvCode.setEnabled(false);
            }
        });


        //图形验证码
        verifyModel.verifyLivedata.observe(this,new SimpleObserver<ValidateCodeEntity>(){

            @Override
            protected void onSuccess(ValidateCodeEntity validateCodeEntity) {
                if(validateCodeEntity != null && validateCodeEntity.getBitmap() != null){
                    login_iv_code.setImageBitmap(validateCodeEntity.getBitmap());
                }else {
                    ToastUtils.showLong("网络异常，请重试");
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
            }
        });

        //发送验证码
        verifyModel.sendCodeLiveData.observe(this,new SimpleObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                MMKVUtil.put(Key.VERIFYTIME,System.currentTimeMillis());
                verifyModel.startTimer(getLifecycle());
            }
        });

        //监听登录
        verifyModel.loginLiveData.observe(this,new NetObserver<BaseEntity<UserInfo>>(){
            @Override
            protected void onSuccess(BaseEntity<UserInfo> baseEntity) {
                UserInfo userInfo = baseEntity.getData();
                MMKVUtil.put(Key.LOGIN_TOKEN, userInfo.getToken());
                MMKVUtil.put(Key.AGENT_TOKEN, userInfo.getToken());
                MMKVUtil.put(Key.SYSTYPE, userInfo.getSysType());
                MMKVUtil.put(Key.LOGIN_PHONE, userInfo.getPhone());
                MMKVUtil.put(Key.INVITE_CODE, userInfo.getInviteCode());
                MMKVUtil.put(Key.IS_USER_LOGIN, true);

                MMKVUtil.put(CacheKey.USER_NAME,userName);
                MMKVUtil.put(CacheKey.USER_PASSWORD,passWord);
                MMKVUtil.put(CacheKey.USER_LOGIN_TIME, System.currentTimeMillis());//上次登录时间
                MMKVUtil.put(CacheKey.REMEMBER_PASSWORD,true);

                UserInfoCache.getInstance().saveUserInfo(userInfo);
                XLiveDataManager.getInstance().userInfo.postNext(userInfo);
//                goActivity(MainActivity.class);
                MainActivity.startMainActiviy(false);
                getActivity().finish();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }



            @Override
            protected void onError(int code, String errMsg) {
                if(22023 == code || 22006 == code){
                    tv_err.setText(errMsg);
                    /**
                     * 判断是否显示验证码
                     *
                     * 7~19次 密码输入错误以及验证码输入错误
                     *
                     * 1.重新加载验证码，删除之前验证码
                     * 2.显示验证码布局
                     */
                    login_et_code.setText("");
                    verifyModel.autoLoadVerify();//加载验证码
                    layout_image.setVisibility(View.VISIBLE);
                }else if(22022 == code){//限制一小时登录
                    tv_err.setText(errMsg);
                    layout_image.setVisibility(View.GONE);
                    verifyCommit.setEnabled(false);
                }else if(22004 == code){//系统检测到您本次登录操作异常，为保障账户安全，已向您注册手机号163****7896发送验证码，请完成验证
                    VerifyEntity verifyEntity = JsonUtils.fromJson(errMsg,VerifyEntity.class);
                    SystemModel.loginVerify.postValue(verifyEntity);
                }else {
                    layout_image.setVisibility(View.GONE);
                    tv_err.setText(errMsg);
                }

            }

        });
    }

    String phone;
    String code;
    String imaggCode;

    @Override
    protected void initViewsAndEvents() {
        tvVerifyErr.setText(bundle.getString(ABConfig.KEY_TEXT));
        phone = bundle.getString(ABConfig.KEY_OBJECT);
        userName = bundle.getString("username");
        passWord = bundle.getString("password");

        long lastTime = MMKVUtil.getLong(Key.VERIFYTIME,0);
        long intervalTime = System.currentTimeMillis() - lastTime;
        if(intervalTime > 60 * 1000){
            verifyModel.sendCode(phone,true,4);
        }else {
            verifyModel.startTimer(getLifecycle(), 60 * 1000 - intervalTime);
        }

        LogUtils.d("异常登录电话:" + phone);

        new InputResultCalculator(Arrays.asList(verifyEtCode), ok -> {
            if(layout_image.getVisibility() == View.VISIBLE){//可见
                imaggCode = login_et_code.getText().toString();
                if(!VerifyUtils.isImageCode(imaggCode)){
                    verifyCommit.setEnabled(false);
                }else {
                    verifyCommit.setEnabled(ok);
                }
            }else{
                verifyCommit.setEnabled(ok);
            }

        });


        login_et_code.addTextChangedListener(new SimpleTextWatcher(){
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                code = verifyEtCode.getText().toString().trim();
                imaggCode = login_et_code.getText().toString().trim();
                if(VerifyUtils.isImageCode(imaggCode) && VerifyUtils.isCode(code)){
                    verifyCommit.setEnabled(true);
                }else {
                    verifyCommit.setEnabled(false);
                }

            }
        });

        titleBar.setRightOnClickListener(view -> pop());
        rootView.setOnClickListener(v -> {
            verifyEtCode.clearFocus();
            titleBar.requestFocus();
            KeyboardUtils.hideSoftInput(v);
        });

    }

    @OnClick({R.id.verify_tv_code, R.id.verify_commit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.verify_tv_code:
                verifyModel.sendCode(phone,true,4);
                break;
            case R.id.verify_commit:
                code = verifyEtCode.getText().toString().trim();
                imaggCode = login_et_code.getText().toString().trim();
                verifyModel.login(userName,passWord,imaggCode,code,layout_image.getVisibility() == View.VISIBLE);
                break;
        }
    }

}
