package com.ty.bwagent.fragment.schemeset;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.adapter.ViewPagerFragmentAdapter;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.badge.BadgeAnchor;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.badge.BadgePagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.badge.BadgeRule;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.SoftKeyboardHelper;

import java.util.ArrayList;

import androidx.viewpager.widget.ViewPager;
import butterknife.BindView;

/**
 * 方案设置
 */
public class SchemeSetFragment extends ABBaseFragment implements View.OnClickListener {


    @BindView(R.id.backView)
    TextView backView;
    @BindView(R.id.bnt_sub_agent)
    Button bntSubAgent;
    @BindView(R.id.bnt_set_scheme)
    Button bntSetScheme;
    @BindView(R.id.view_pager)
    ViewPager mViewPager;
    @BindView(R.id.tv_right)
    TextView mTvRight;
    ArrayList<ABBaseFragment> fragments = new ArrayList<>();
    private SoftKeyboardHelper softKeyboardHelper;
    private int keyboardHeightInPx = 0;
    public static int keybordUp = 0;//键盘往上面滑动的高度

    public boolean[] titltRightShowArr = new boolean[]{false, false};//头部是否展示右标题按钮
    public boolean[] titltRightEditeArr = new boolean[]{true, true};//头部是显示编辑还是保存状态
    public boolean[] titltRedDotShowArr = new boolean[]{true, true};//红点是否展示
    public BadgePagerTitleView[] badgeTitleViewArr = new BadgePagerTitleView[]{null, null};//红点的显示View


    public static String ISCOMMISSIONSHOWREDDOT = "isCommissionShowRedDot";
    public static String ISREBATESHOWREDDOT = "isRebateShowRedDot";

    public static SchemeSetFragment getInstance(boolean isCommissionShowRedDot, boolean isRebateShowRedDot) {
        SchemeSetFragment fragment = new SchemeSetFragment();
        Bundle bundle = new Bundle();
        bundle.putBoolean(ISCOMMISSIONSHOWREDDOT, isCommissionShowRedDot);
        bundle.putBoolean(ISREBATESHOWREDDOT, isRebateShowRedDot);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_team_manager;
    }

    @Override
    protected void createProvider() {
    }

    @Override
    protected void initViewsAndEvents() {
        initView();
        initDate();
        initListener();
    }

    private void initView() {

        boolean isCommissionShowRedDot = getArguments().getBoolean(ISCOMMISSIONSHOWREDDOT);
        boolean isRebateShowRedDot = getArguments().getBoolean(ISREBATESHOWREDDOT);

        titltRedDotShowArr[0] = isCommissionShowRedDot;//红点展示
        titltRedDotShowArr[1] = isRebateShowRedDot;

        if (UserInfoCache.getInstance().getUserInfo().getAgentLevel() == 20) {//末级代理 显示右边标题按钮的显示
            titltRightShowArr[0] = true;
            titltRightShowArr[1] = true;
        } else {
            titltRightShowArr[0] = isCommissionShowRedDot;
            titltRightShowArr[1] = isRebateShowRedDot;
        }

        mTvRight.setOnClickListener(this);
        backView.setOnClickListener(this);
        bntSubAgent.setOnClickListener(this);
        bntSetScheme.setOnClickListener(this);
        bntSubAgent.setSelected(true);
        bntSetScheme.setSelected(false);
        mTvRight.setVisibility(View.INVISIBLE);
    }


    private void initDate() {
        fragments.clear();
        fragments.add(SchemeSetTabFragment.getInstance(0));
        fragments.add(SchemeSetTabFragment.getInstance(1));
        ViewPagerFragmentAdapter adapter = new ViewPagerFragmentAdapter(getChildFragmentManager(), fragments);
        mViewPager.setAdapter(adapter);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.backView:
                pop();
                break;
            case R.id.bnt_sub_agent://切换返佣方案
                bntSubAgent.setSelected(true);
                bntSetScheme.setSelected(false);
                mViewPager.setCurrentItem(0);
                break;
            case R.id.bnt_set_scheme://切换返水方案
                bntSubAgent.setSelected(false);
                bntSetScheme.setSelected(true);
                mViewPager.setCurrentItem(1);
                break;
            case R.id.tv_right:
                KeyboardUtils.hideSoftInput(rootView);

                if (titltRightEditeArr[mViewPager.getCurrentItem()]) {//是编辑
                    titltRightEditeArr[mViewPager.getCurrentItem()] = false;
                    mTvRight.setText("保存");
                    ((SchemeSetTabFragment) fragments.get(mViewPager.getCurrentItem())).setIsEditeState(true, false);
                } else {
                    if (UserInfoCache.getInstance().getUserInfo().getAgentLevel() != 20) {//末级代理弹窗保存一次
                        DialogUtil.commonDialogShow(getActivity(), "温馨提示",
                                "保存前请仔细检查，设置后将无法再次修改，您是否确定要保存？", "确定", true, () -> {
                                    ((SchemeSetTabFragment) fragments.get(mViewPager.getCurrentItem())).setIsEditeState(false, true);
                                });
                    } else {
                        ((SchemeSetTabFragment) fragments.get(mViewPager.getCurrentItem())).setIsEditeState(false, titltRedDotShowArr[mViewPager.getCurrentItem()]);
                    }
                }
                break;
        }
    }


    private void initListener() {

        mViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                KeyboardUtils.hideSoftInput(rootView);
                if (position == 0) {
                    bntSubAgent.setSelected(true);
                    bntSetScheme.setSelected(false);
                    showTitleRight(position, ((SchemeSetTabFragment) fragments.get(0)).mViewPager.getCurrentItem());
                } else {
                    bntSubAgent.setSelected(false);
                    bntSetScheme.setSelected(true);

                    ((SchemeSetTabFragment) fragments.get(1)).loadSchemeRebateDate();
                    showTitleRight(position, ((SchemeSetTabFragment) fragments.get(1)).mViewPager.getCurrentItem());
                }
            }
        });

        OnChildFragListener onChildFragListener = new OnChildFragListener();
        ((SchemeSetTabFragment) fragments.get(0)).setOnChildFragListener(onChildFragListener);
        ((SchemeSetTabFragment) fragments.get(1)).setOnChildFragListener(onChildFragListener);

        // 键盘弹出密码输入框需要更新位置，整体布局上移
        softKeyboardHelper = new SoftKeyboardHelper()
                .registerFragment(this)
                .setOnSoftKeyboardChangeListener(new SoftKeyboardHelper.OnSoftKeyboardChangeListener() {


                    @Override
                    public void onSoftKeyboardChanged(int keyboardHeightInPx) {
                    }

                    @Override
                    public void onSoftKeyboardOpened(int keyboardHeightInPx) {
                        if (keyboardHeightInPx != 0) {
                            SchemeSetFragment.this.keyboardHeightInPx = keyboardHeightInPx;
                        }
                        if (keybordUp < keyboardHeightInPx && keyboardHeightInPx != 0) {
                            rootView.scrollTo(0, keyboardHeightInPx - keybordUp);
                            LogUtils.d("====往上移动=" + (keyboardHeightInPx - keybordUp));
                        }
                    }

                    @Override
                    public void onSoftKeyboardClosed() {
                        rootView.scrollTo(0, 0);
                    }
                });
    }


    //子界面返回有标题的显示监听
    public class OnChildFragListener implements SchemeSetTabFragment.OnChildFragListener {

        @Override
        public void onChildViewPagerChange(int parentPager, int childPage) {
            showTitleRight(parentPager, childPage);//子ViewPager滑动监听
        }

        @Override
        public void onTitleRightShow(int parentPager, int childPage, boolean isShow) {
            titltRightShowArr[parentPager] = isShow;//请求返回判断是否显示
            showTitleRight(parentPager, childPage);
        }

        @Override
        public void onTitleEditeShow(int parentPager, int childPage, boolean isEditeShow) {
            titltRightEditeArr[parentPager] = isEditeShow;//是编辑状态还是显示保存
            showTitleRight(parentPager, childPage);
        }

        @Override
        public void onTitleRedDotShow(int parentPager, int childPage, boolean isShowRedDot) {
            titltRedDotShowArr[parentPager] = isShowRedDot;//红点是否展示
            showTitleRight(parentPager, childPage);
        }

        @Override
        public void onBagePagerViewListener(int pagePositon, BadgePagerTitleView pagerTitleView) {
            badgeTitleViewArr[pagePositon] = pagerTitleView;//红点的View
        }

        @Override
        public void onSoftKeyboardScroll(int keybordUp) {
            if (keybordUp < keyboardHeightInPx && keyboardHeightInPx != 0) {
                rootView.scrollTo(0, keyboardHeightInPx - keybordUp);
                LogUtils.d("====往上移动=" + (keyboardHeightInPx - keybordUp));
            }
        }
    }



    //标题右侧文字状态显示
    public void showTitleRight(int parentPager, int childPage) {

        if (childPage == 0) {//返佣方案我的 和返水方案 我的
            mTvRight.setVisibility(View.INVISIBLE);
        } else {
            if (titltRightShowArr[parentPager]) {//parentPager 0:返佣方案子属下级  1：返水直属下属
                mTvRight.setVisibility(View.VISIBLE);
                if (titltRightEditeArr[parentPager]) {//是显示编辑还是保存
                    mTvRight.setText("编辑");
                } else {
                    mTvRight.setText("保存");
                }
            } else {
                mTvRight.setVisibility(View.INVISIBLE);
            }
        }
        showRetDot(parentPager);
    }

    //展示红点
    private void showRetDot(int parentPager) {
        if (badgeTitleViewArr[parentPager] != null) {//红点
            if (titltRightShowArr[parentPager] && titltRedDotShowArr[parentPager]) {//红点显示
                if (badgeTitleViewArr[parentPager].getBadgeView() == null) {
                    LinearLayout badgeTextView = (LinearLayout) LayoutInflater.from(mContext).inflate(R.layout.message_dot_badge, null);
                    badgeTitleViewArr[parentPager].setXBadgeRule(new BadgeRule(BadgeAnchor.CENTER_X, SizeUtils.dp2px(30)));
                    badgeTitleViewArr[parentPager].setYBadgeRule(new BadgeRule(BadgeAnchor.CENTER_Y, SizeUtils.dp2px(-10)));
                    badgeTitleViewArr[parentPager].setBadgeView(badgeTextView);
                    badgeTitleViewArr[parentPager].setAutoCancelBadge(false);
                }
            } else {//红点隐藏
                badgeTitleViewArr[parentPager].setBadgeView(null);
            }
        }
    }


    @Override
    public void onStop() {
        super.onStop();
        KeyboardUtils.hideSoftInput(rootView);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        softKeyboardHelper.unregisterView();
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //更新首页设置方案红点展示
        XLiveDataManager.getInstance().SchemeSetRedDot.postValue(titltRedDotShowArr);
    }
}
