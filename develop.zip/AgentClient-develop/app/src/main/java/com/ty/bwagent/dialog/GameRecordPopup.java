package com.ty.bwagent.dialog;

import android.view.View;
import android.widget.TextView;

import com.lxj.xpopup.impl.PartShadowPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.GameRecordEntity;
import com.ty.bwagent.bean.GameVenueEntity;
import com.ty.bwagent.view.SelectTimeView;
import com.ty.bwagent.viewmodel.GameRecordModel;
import com.ty.net.callback.NetObserver;
import com.ty.pickerview.builder.OptionsPickerBuilder;
import com.ty.pickerview.view.OptionsPickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.fragment.app.Fragment;

/**
 * 游戏记录筛选框
 */
public class GameRecordPopup extends PartShadowPopupView implements View.OnClickListener {

    ClearEditText et_input;
    Fragment fragment;
    private TextView tv_reset;
    private SelectTimeView selectTimeView;
    private GameRecordModel gameRecordModel;
    private TextView tv_venue;
    private BaseEntity<List<GameVenueEntity>> listBaseEntity;
    private TextView tv_state;
    private OptionsPickerView<String> venueOptions;
    private OptionsPickerView<String> stateOptions;

    public GameRecordPopup(Fragment fragment, GameRecordModel gameRecordModel) {
        super(fragment.getContext());
        this.fragment = fragment;
        this.gameRecordModel = gameRecordModel;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_game_record;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        initView();
        initDate();
    }

    private void initView() {

        tv_reset = findViewById(R.id.tv_reset);
        et_input = findViewById(R.id.et_input);
        tv_venue = findViewById(R.id.tv_venue);
        tv_state = findViewById(R.id.tv_state);
        selectTimeView = findViewById(R.id.selectTimeView);
        tv_reset.setOnClickListener(this);
        tv_reset.setTextColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        tv_reset.setBackgroundColor(ResUtils.getColor(SiteSdk.ins().btnEnableColor()));

        tv_venue.setOnClickListener(this::onClick);
        findViewById(R.id.tv_sure).setOnClickListener(this::onClick);
        findViewById(R.id.tv_reset).setOnClickListener(this::onClick);
        findViewById(R.id.tv_state).setOnClickListener(this::onClick);
    }

    private void initDate() {
        gameRecordModel.allGameVenueLiveData.observeForever(allGameVenueObserver);
        selectTimeView.setInitTime(new Date());

        stateList.clear();
        stateList.add("全部");
        stateList.add("未结算");
        stateList.add("已结算");
        stateList.add("取消");
        stateList.add("无效");

        buildStateTypeOptionsPicker();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_venue:
                if (venueList.size() == 0) {
                    isFromClick = true;
                    gameRecordModel.getAllGameVenue();
                } else {
                    KeyboardUtils.hideSoftInput(fragment.getActivity());
                    venueOptions.show();
                }
                break;
            case R.id.tv_state:
                KeyboardUtils.hideSoftInput(fragment.getActivity());
                stateOptions.show();
                break;
            case R.id.tv_reset:
                et_input.clearFocus();
                selectTimeView.setInitTime(new Date());
                et_input.setText("");
                tv_venue.setText("全部");
                tv_state.setText("全部");
                gameRecordModel.filterLiveData.postValue(new GameRecordEntity("",
                        selectTimeView.start_time.getText().toString().trim(),
                        selectTimeView.end_time.getText().toString().trim(),
                        getVenueId(),
                        ""
                ));
                dismiss();
                break;
            case R.id.tv_sure:
                if (!selectTimeView.daysBetween(selectTimeView.start_time.getText().toString().trim(), selectTimeView.end_time.getText().toString().trim())) {
                    KeyboardUtils.hideSoftInput(fragment.getActivity());
                    et_input.clearFocus();
                    ToastUtils.showLong("结束时间不能早于开始时间");
                    KeyboardUtils.hideSoftInput(fragment.getActivity());
                    return;
                }
                gameRecordModel.filterLiveData.postValue(new GameRecordEntity(et_input.getText().toString().trim(),
                        selectTimeView.start_time.getText().toString().trim(),
                        selectTimeView.end_time.getText().toString().trim(),
                        getVenueId(),
                        getStateId()
                ));
                dismiss();
                break;
        }
    }

    NetObserver<BaseEntity<List<GameVenueEntity>>> allGameVenueObserver = new NetObserver<BaseEntity<List<GameVenueEntity>>>() {
        @Override
        protected void onSuccess(BaseEntity<List<GameVenueEntity>> listBaseEntity) {
            LogUtils.e("listBaseEntity=" + listBaseEntity.getData().size());
            addVenueType(listBaseEntity);
        }

        @Override
        protected void onError(int code, String errMsg) {
            ToastUtils.showToast(errMsg);
        }
    };


    List<String> venueList = new ArrayList<>();
    private boolean isFromClick = false;

    //获取所有类型
    private void addVenueType(BaseEntity<List<GameVenueEntity>> listBaseEntity) {
        this.listBaseEntity = listBaseEntity;
        venueList.clear();
        venueList.add("全部");
        if (listBaseEntity != null && listBaseEntity.getData() != null && listBaseEntity.getData().size() > 0) {
            for (GameVenueEntity gameVenueEntity : listBaseEntity.getData()) {
                venueList.add(gameVenueEntity.getZhName());
            }
        }
        buildVenueTypeOptionsPicker();
        if (isFromClick) {
            KeyboardUtils.hideSoftInput(fragment.getActivity());
            venueOptions.show();
        }
    }

    //获取场馆id
    public String getVenueId() {
        String venueId = "";
        if (listBaseEntity != null && listBaseEntity.getData() != null && listBaseEntity.getData().size() > 0) {
            for (int i = 0; i < listBaseEntity.getData().size(); i++) {
                if (tv_venue.getText().toString().trim().equals(listBaseEntity.getData().get(i).getZhName())) {
                    venueId = listBaseEntity.getData().get(i).getId() + "";
                }
            }
        }
        return venueId;
    }

    //获取状态id
    public String getStateId() {
        String stateId = "";
        switch (tv_state.getText().toString().trim()) {
            case "全部":
                stateId = "";
                break;
            case "未结算":
                stateId = "0";
                break;
            case "已结算":
                stateId = "1";
                break;
            case "取消":
                stateId = "2";
                break;
            case "无效":
                stateId = "3";
                break;
        }
        return stateId;
    }


    private void buildVenueTypeOptionsPicker() {

        if (venueOptions == null) {
            venueOptions = new OptionsPickerBuilder(getContext(), (options1, options2, options3, v) -> {
                if (options1 == 0) {
                    tv_venue.setText("全部");
                } else {
                    tv_venue.setText(venueList.get(options1));
                }
            })
                    .setSubmitText("确定")
                    .setSubmitColor(ResUtils.getColor(R.color.site_style_color))
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(R.color.site_style_color))
                    .setTitleText("场馆")
                    .setTitleColor(ResUtils.getColor(R.color.generic_heise))
                    .setLabels("", "", "")
                    .setCyclic(false, false, false)
                    .setSelectOptions(0, 0, 0)
                    .build();
        }
        venueOptions.setPicker(venueList);
    }

    List<String> stateList = new ArrayList<>();

    private void buildStateTypeOptionsPicker() {
        if (stateOptions == null) {
            stateOptions = new OptionsPickerBuilder(getContext(), (options1, options2, options3, v) -> {
                if (options1 == 0) {
                    tv_state.setText("全部");
                } else {
                    tv_state.setText(stateList.get(options1));
                }
            })
                    .setSubmitText("确定")
                    .setSubmitColor(ResUtils.getColor(R.color.site_style_color))
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(R.color.site_style_color))
                    .setTitleText("状态")
                    .setTitleColor(ResUtils.getColor(R.color.generic_heise))
                    .setLabels("", "", "")
                    .setCyclic(false, false, false)
                    .setSelectOptions(0, 0, 0)
                    .build();
        }
        stateOptions.setPicker(stateList);
    }


    @Override
    public void dismiss() {
        super.dismiss();

    }


    public void onDesoty() {
        if (gameRecordModel != null && allGameVenueObserver != null) {
            gameRecordModel.allGameVenueLiveData.removeObserver(allGameVenueObserver);
        }

    }

}