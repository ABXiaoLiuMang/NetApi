package com.ty.bwagent.bean;

public class AddBankCardEntity {

    /**
     * code : CMBC
     * dictCode : bank_code
     * dictValue : 民生银行
     * ext1 : 1
     * ext2 :
     * id : 375
     * remark : https://img.bwhou2020.com/pay/assets/icoCmbc2@3x.png
     */

    private String code;
    private String dictCode;
    private String dictValue;
    private String ext1;
    private String ext2;
    private int id;
    private String remark;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictValue() {
        return dictValue;
    }

    public void setDictValue(String dictValue) {
        this.dictValue = dictValue;
    }

    public String getExt1() {
        return ext1;
    }

    public void setExt1(String ext1) {
        this.ext1 = ext1;
    }

    public String getExt2() {
        return ext2;
    }

    public void setExt2(String ext2) {
        this.ext2 = ext2;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
