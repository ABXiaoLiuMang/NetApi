package com.ty.common.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupAnimation;
import com.ty.common.R;
import com.ty.common.util.AlphaAnimator;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.ExitUtils;
import com.ty.utils.FixInputMethodManager;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.StatusBarUtil;

import butterknife.ButterKnife;
import butterknife.Unbinder;
import me.yokeyword.fragmentation.ui.SupportActivity;

/**
 * create by Dale
 * create on 2019/5/17
 * description: 基类
 */
public abstract class ABBaseActivity extends SupportActivity {
    protected Activity mContext;
    protected Bundle bundle;
    protected BasePopupView progressDialog;
    protected Unbinder unbinder;

    protected abstract int getLayoutId();

    protected abstract void createProvider();

    protected abstract void initViewsAndEvents();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        ExitUtils.getInstance().addActivity(this);//记录打开的Act
        initSystemBar();
        setContentView(getLayoutId());
        unbinder = ButterKnife.bind(this);
        bundle = getIntent().getExtras();
        createProvider();
        initViewsAndEvents();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (unbinder != null) {
            unbinder.unbind();
        }
        dismissProgressDialog();
        ExitUtils.getInstance().removeActivity(this);//关闭的Act
        FixInputMethodManager.fixInputMethodManagerLeak(this);
    }

    protected void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(mContext);
            progressDialog = new XPopup.Builder(mContext)
                    .isRequestFocus(false)  //loading不要焦点
                    .hasShadowBg(false)
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        progressDialog.show();

    }

    protected void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShow()) {
            progressDialog.dismiss();
        }
    }

    public void goActivity(Class<? extends Activity> descClass) {
        this.goActivity(descClass,null);
    }

    public void goActivity(Class<? extends Activity> descClass, Bundle bundle) {
        try {
            Intent intent = new Intent();
            intent.setClass(mContext, descClass);
            if (bundle != null) {
                intent.putExtras(bundle);
            }
            mContext.startActivityForResult(intent, 0);
            mContext.overridePendingTransition(R.anim.x_push_left_in, R.anim.x_push_left_out);
        } catch (Exception e) {
        }
    }


    @Override
    public void finish() {
        super.finish();
        KeyboardUtils.hideSoftInput(this);
        overridePendingTransition(R.anim.x_push_right_in, R.anim.x_push_right_out);
    }

    protected void initSystemBar(){
        StatusBarUtil.setTransparentForWindow(this);
        StatusBarUtil.setLightMode(this);//状态栏图标黑色
    }

}
