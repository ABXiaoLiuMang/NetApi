package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.fragment.finance.viewmodel.FinanceTaxViewModel;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XTextView;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.bwagent.fragment.finance.adapter.FinanceTaxAdapter;
import com.ty.bwagent.fragment.finance.bean.FinanceTax;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.SimpleObserver;

import java.util.List;

/**
 * 月度详细-红利
 */
public class FinanceTaxFragment extends ABRefreshFragment<FinanceTax> {

    FinanceTaxViewModel financeTaxViewModel;

    LinearLayout title_layout;//顶部标题布局
    TextView tv_month;//查询月份
    TextView tax_total;//场馆费
    TextView month_text;//月度明细月份
    FinanceEntity financeEntity;//佣金明细对象

    public static FinanceTaxFragment getInstance(Bundle bundle) {
        FinanceTaxFragment fragment = new FinanceTaxFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_details;
    }

    @Override
    protected void createProvider() {
        financeTaxViewModel = new ViewModelProvider(this).get(FinanceTaxViewModel.class);

        //红利月度明细
        financeTaxViewModel.taxNetLiveData.observe(this,new SimpleObserver<BaseEntity<List<FinanceTax>>>(){

            @Override
            protected void onSuccess(BaseEntity<List<FinanceTax>> listBaseEntity) {
                if(listBaseEntity.getData().size() > 0){
                    title_layout.setVisibility(View.VISIBLE);
                }else {
                    title_layout.setVisibility(View.GONE);
                }
                listAdapter.setNewData(listBaseEntity.getData());
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        financeEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        String startData = bundle.getString(ABConfig.KEY_TAG);
        financeTaxViewModel.queryPromoList(startData);
        tv_month.setText(startData);
        month_text.setText(startData);
        tax_total.setText(Utils.roundDownMoney(financeEntity.getPromo()));
    }

    @Override
    public int getMode() {
        return Mode.DISABLED;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public View getHeaderView() {
        View header = View.inflate(mContext, R.layout.header_finance_tax,null);
        title_layout = header.findViewById(R.id.title_layout);
        tv_month = header.findViewById(R.id.tv_month);
        tax_total = header.findViewById(R.id.tax_total);
        month_text = header.findViewById(R.id.month_text);
        return header;
    }

    @Override
    public BaseQuickAdapter<FinanceTax, BaseViewHolder> getListAdapter() {
        return new FinanceTaxAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//        FinanceTax financeTax = (FinanceTax) adapter.getItem(position);
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
    }


}
