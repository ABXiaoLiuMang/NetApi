package com.ty.bwagent.ui;

import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

import com.star.lockpattern.util.LockPatternUtil;
import com.star.lockpattern.widget.LockPatternIndicator;
import com.star.lockpattern.widget.LockPatternView;
import com.ty.bwagent.R;
import com.ty.bwagent.exchange.ExchangeActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.GoUtils;
import com.ty.common.ui.ABBaseActivity;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.utils.ExitUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class GestureActivity extends ABBaseActivity {

    @BindView(R.id.xTitle)
    TitleBar xTitle;
    @BindView(R.id.lockPatterIndicator)
    LockPatternIndicator lockPatterIndicator;
    @BindView(R.id.lockPatternView)
    LockPatternView lockPatternView;
    @BindView(R.id.tvreset)
    TextView tvreset;
    @BindView(R.id.messageTv)
    TextView messageTv;
    Status currentStatus;


    private byte [] mLoginPattern = null;//登录之前保存密码

    boolean isGoFinish = false;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_set_gesture;
    }

    @Override
    protected void createProvider() {}

    @Override
    protected void initViewsAndEvents() {

        mLoginPattern = MMKVUtil.decodeBytes(CacheKey.GUSTURE_PASSWORD);
        if(mLoginPattern == null){//第一次绘制
            currentStatus = Status.DEFAULT;
            xTitle.setTiteTextView("绘制手势密码");
        }else{//设置过登录
            currentStatus = Status.LOGIN;
            tvreset.setVisibility(View.VISIBLE);
            xTitle.setTiteTextView("解锁图案");
        }
        setGestureText(currentStatus);
        lockPatternView.setOnPatternListener(patternListener);
        isGoFinish = getIntent().getBooleanExtra(ABConfig.KEY_TAG,false);
    }

    @OnClick(R.id.tvreset)
    public void onViewClicked() {
        tvreset.setVisibility(View.GONE);
        MMKVUtil.removeValueForKey(CacheKey.GUSTURE_PASSWORD);
        resetLockPattern();
    }

    LockPatternView.OnPatternListener patternListener = new LockPatternView.OnPatternListener() {
        @Override
        public void onPatternStart() {
            lockPatternView.removePostClearPatternRunnable();
            lockPatternView.setPattern(LockPatternView.DisplayMode.DEFAULT);
            if(mLoginPattern == null){//没有登录过（之前没有设置过密码）
                messageTv.setTextColor(ResUtils.getColor(R.color.color_414655));
                messageTv.setText(ResUtils.getString(R.string.create_gesture_default));
            }else {
                messageTv.setTextColor(ResUtils.getColor(R.color.color_414655));
                messageTv.setText(ResUtils.getString(R.string.create_gesture_login));
            }
        }

        @Override
        public void onPatternComplete(List<LockPatternView.Cell> pattern) {
            if (pattern.size() >= 4) {
                checkResult(pattern);
            } else{//绘制错误，少于4个点
                setGestureText(Status.LESSERROR);//少于4个点
                lockPatternView.setPattern(LockPatternView.DisplayMode.DEFAULT);
            }
        }
    };

    private void checkResult(List<LockPatternView.Cell> pattern) {
        /**
         * 注意一个条件，不是二次设置密码才触发
         */
        if(LockPatternUtil.checkSwitch(pattern)){
            if(isGoFinish){
                finish();
            }else {
                GoUtils.checkSwitch(this);
            }
            return;
        }
        byte[] patternByte = LockPatternUtil.patternToHash(pattern);
        switch (currentStatus) {
            case LOGIN://设置个手势密码，登录绘制
                if (LockPatternUtil.checkPattern(pattern, mLoginPattern)) {
                    setLockPatternSuccess();
                }else {
                    lockPatternView.setPattern(LockPatternView.DisplayMode.DEFAULT);
                    messageTv.setTextColor(ResUtils.getColor(R.color.color_f4333c));
                    messageTv.setText("手势错误");
                }
                break;
            case DEFAULT://第一次绘制（或重置）
                MMKVUtil.put(CacheKey.GUSTURE_PASSWORD,patternByte);
                ToastUtils.showLong("设置手势密码成功");
                setLockPatternSuccess();
                break;
        }
    }

    /**
     * 设置提示文字
     * @param status
     */
    private void setGestureText(Status status){
        messageTv.setTextColor(ResUtils.getColor(status.colorId));
        messageTv.setText(ResUtils.getString(status.strId));
    }


    /**
     * 成功设置了手势密码(跳到首页)
     */
    private void setLockPatternSuccess() {
        goActivity(ExchangeActivity.class);
        finish();
    }

    /**
     * 重新设置手势
     */
    private void resetLockPattern() {
        mLoginPattern = null;
        currentStatus = Status.DEFAULT;
        setGestureText(currentStatus);
        lockPatterIndicator.setDefaultIndicator();
        lockPatternView.setPattern(LockPatternView.DisplayMode.DEFAULT);
    }


    public enum Status {
        DEFAULT(R.string.create_gesture_default, R.color.color_414655),//没有设置过第一次设置
        LESSERROR(R.string.create_gesture_less_error, R.color.color_f4333c),//最少连接4个点，请重新绘制
        LOGIN(R.string.create_gesture_login, R.color.color_414655);//请绘制手势，至少绘制4个点
        // 成员变量
        private int strId;
        private int colorId;


        Status(int strId, int colorId) {
            this.strId = strId;
            this.colorId = colorId;
        }
    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            exit();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void exit() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if (count > 1) {
            pop();
        } else {
            ExitUtils.getInstance().finishAll();
        }
    }

}
