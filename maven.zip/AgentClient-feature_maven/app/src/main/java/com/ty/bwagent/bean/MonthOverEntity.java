package com.ty.bwagent.bean;

/**
 * 本月概览
 */
public class MonthOverEntity {

    /**
     * commission : 0
     * totalNewMembers : 0
     * totalProfit : 0.0
     */

    private double commission;//本月佣金
    private int totalNewMembers;//新增下级
    private double totalProfit;//总输赢

    public double getCommission() {
        return commission;
    }

    public void setCommission(double commission) {
        this.commission = commission;
    }

    public int getTotalNewMembers() {
        return totalNewMembers;
    }

    public void setTotalNewMembers(int totalNewMembers) {
        this.totalNewMembers = totalNewMembers;
    }

    public double getTotalProfit() {
        return totalProfit;
    }

    public void setTotalProfit(double totalProfit) {
        this.totalProfit = totalProfit;
    }
}
