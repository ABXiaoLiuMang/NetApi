package com.ty.bwagent.fragment.deposit.fragment;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.RecyclerView;

import com.lxj.xpopup.XPopup;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.RecordFilterEntity;
import com.ty.bwagent.dialog.DepositFilterPopup;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.view.TitleBar;
import com.ty.utils.TimeUtils;

import java.util.Calendar;
import java.util.Date;


/**
 * 代存转账记录 代理代存记录 基类
 */
public abstract class DepositBaseFragment<T> extends ABRefreshFragment<T>{

    private Calendar startCalendar;
    private Calendar endCalendar;
    protected TitleBar titleBar;
    protected DepositFilterPopup depositFilterPopup;
    protected int status = 0;//人才，后端要求传这两个值 状态（0全部  403 成功 99失败）
    protected int pageNum = 1;
    protected int pageSize = 10;
    protected String startDate;
    protected String endDate;

    //提款记录筛选结果
    public MutableLiveData<RecordFilterEntity> filterLiveData = new MutableLiveData<>();

    //重置
    public MutableLiveData<RecordFilterEntity> resetLiveData = new MutableLiveData<>();

    protected abstract void requestRecordData(String startDate, String endDate, int status, int pageNum, int pageSize);

    @Override
    protected void createProvider() {
        //过滤条件筛选
        filterLiveData.observe(this, recordFilterEntity -> {
            Date startTime = TimeUtils.toDate(recordFilterEntity.getStartDate(), "yyyy-MM-dd");
            if (startTime != null) {
                startCalendar = Calendar.getInstance();
                startCalendar.setTime(startTime);
            }

            Date endTime = TimeUtils.toDate(recordFilterEntity.getEndDate(), "yyyy-MM-dd");
            if (endTime != null) {
                endCalendar = Calendar.getInstance();
                endCalendar.setTime(endTime);
            }
            status = recordFilterEntity.getStatus();
            pageNum = 1;
            startDate = recordFilterEntity.getStartDate();
            endDate = recordFilterEntity.getEndDate();
            requestRecordData(startDate,endDate,status,pageNum,pageSize);
        });

        resetLiveData.observe(this, recordFilterEntity -> {
            startCalendar = null;
            endCalendar = null;

            status = recordFilterEntity.getStatus();
            pageNum = 1;
            startDate = recordFilterEntity.getStartDate();
            endDate = recordFilterEntity.getEndDate();
            requestRecordData(startDate,endDate,status,pageNum,pageSize);
        });

    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        titleBar = rootView.findViewById(R.id.titleBar);
        titleBar.setRightOnClickListener(view -> showFilterDialog());
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum++;
        requestRecordData(startDate,endDate,status,pageNum,pageSize);
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        pageNum = 1;
        requestRecordData(startDate,endDate,status,pageNum,pageSize);
    }

    boolean loadData = false;
    @Override
    public void onResume() {
        super.onResume();
        if(!loadData){
            showProgressDialog();
            requestRecordData(startDate,endDate,status,pageNum,pageSize);
            loadData = true;
        }
    }


    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    private void showFilterDialog() {
        if (depositFilterPopup == null) {
            depositFilterPopup = new DepositFilterPopup(mContext, filterLiveData, resetLiveData);
            new XPopup.Builder(getContext())
                    .atView(titleBar)
                    .asCustom(depositFilterPopup);
        }
        if (depositFilterPopup.isShow()) {
            depositFilterPopup.dismiss();
        } else {
            if (startCalendar == null && endCalendar == null) {
                depositFilterPopup.setStartDay(-1);//设置-1 默认30天，但是这里需要设置-1，因为不显示初始值
            } else {
                depositFilterPopup.setStartDay(0);//赋值，记录上次的时间
                depositFilterPopup.setStartCalendar(startCalendar);
                depositFilterPopup.setEndCalendar(endCalendar);
            }
            depositFilterPopup.show();
        }
    }




}
