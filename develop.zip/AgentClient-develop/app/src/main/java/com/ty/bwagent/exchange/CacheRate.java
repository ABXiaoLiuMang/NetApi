package com.ty.bwagent.exchange;


import com.ty.utils.MMKVUtil;

import java.util.HashMap;
import java.util.Map;

public class CacheRate {

    private static final String cacheKey = "rate_map";
    private static final String timeKey = "time_key";

    public static void saveRate(Map map) {
        MMKVUtil.putObject(cacheKey, map);
    }

    public static Map<String, String> getRate() {
        Map<String,String> map = new HashMap<>();
        map.put("USD","1");
        map.put("CNY","6.97738");
        map.put("AUD","1.53468");
        map.put("RUB","2.23396");
        map.put("PHP","50.9815");
        map.put("KRW","1199.76");
        map.put("CAD","1.33942");
        map.put("JPY","108.02");
        map.put("SEK","9.59491");
        map.put("THB","31.4647");
        map.put("SGD","1.39268");
        map.put("GBP","0.77993");
        map.put("MYR","4.21100");
        map.put("EUR","0.90625");
        return map;
//        return MMKVUtil.getObject(cacheKey, Map.class);
    }

    public static String getUpdateTime() {
        return MMKVUtil.getString(timeKey, "");
    }

    public static void setUpdateTime(String time) {
        MMKVUtil.put(timeKey, time);
    }
}
