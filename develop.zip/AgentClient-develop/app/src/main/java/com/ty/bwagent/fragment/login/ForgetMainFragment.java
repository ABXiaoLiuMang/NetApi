package com.ty.bwagent.fragment.login;


import android.content.Context;

import androidx.viewpager.widget.ViewPager;

import com.ty.bwagent.R;
import com.ty.bwagent.adapter.ViewPagerFragmentAdapter;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.magicindicator.MagicIndicator;
import com.ty.common.view.magicindicator.ViewPagerHelper;
import com.ty.common.view.magicindicator.buildins.commonnavigator.CommonNavigator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.ColorTransitionPagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.SoftKeyboardHelper;
import com.ty.utils.StatusBarUtil;

import java.util.ArrayList;

import butterknife.BindView;


/**
 * 忘记密码第一步
 */
public class ForgetMainFragment extends ABBaseFragment {

    @BindView(R.id.magicIndicator)
    MagicIndicator magicIndicator;
    @BindView(R.id.viewPager)
    ViewPager viewPager;


    public static ForgetMainFragment getInstance() {
        return new ForgetMainFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_forget_main;
    }

    @Override
    protected void createProvider() {

    }

    @Override
    protected void initViewsAndEvents() {
        initMagicIndicator();
    }

    private void initMagicIndicator(){

        ArrayList<ABBaseFragment> fragments = new ArrayList<>();
        String [] tabTitles = new String[]{"手机找回","邮箱找回"};
        ForgetPhoneFragment forgetPhoneFragment = ForgetPhoneFragment.getInstance();
        ForgetEmailFragment forgetEmailFragment = ForgetEmailFragment.getInstance();
        fragments.add(forgetPhoneFragment);
        fragments.add(forgetEmailFragment);
        ViewPagerFragmentAdapter adapter = new ViewPagerFragmentAdapter(getChildFragmentManager(),fragments);
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(fragments.size());

        CommonNavigator commonNavigator = new CommonNavigator(mContext);
        commonNavigator.setAdapter(new CommonNavigatorAdapter() {

            @Override
            public int getCount() {
                return tabTitles.length;
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                SimplePagerTitleView simplePagerTitleView = new ColorTransitionPagerTitleView(context);
                simplePagerTitleView.setNormalColor(ResUtils.getColor(R.color.generic_huise));
                simplePagerTitleView.setSelectedColor(ResUtils.getColor(R.color.black));
                simplePagerTitleView.setText(tabTitles[index]);
                simplePagerTitleView.setOnClickListener(v -> viewPager.setCurrentItem(index));
                return simplePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator linePagerIndicator = new LinePagerIndicator(context);
                linePagerIndicator.setMode(LinePagerIndicator.MODE_WRAP_CONTENT);
                linePagerIndicator.setLineHeight(SizeUtils.dp2px(2));
                linePagerIndicator.setLineWidth(SizeUtils.dp2px(44));
                linePagerIndicator.setRoundRadius(SizeUtils.dp2px(1));
                linePagerIndicator.setColors(ResUtils.getColor(SiteSdk.ins().styleColor()));
                return linePagerIndicator;
            }
        });
        commonNavigator.setAdjustMode(true);
        magicIndicator.setNavigator(commonNavigator);
        ViewPagerHelper.bind(magicIndicator, viewPager);
    }

    SoftKeyboardHelper softKeyboardHelper;
    @Override
    public void onResume() {
        super.onResume();
        // 键盘弹出密码输入框需要更新位置，整体布局上移
        softKeyboardHelper = new SoftKeyboardHelper()
                .registerFragment(this)
                .setOnSoftKeyboardChangeListener(new SoftKeyboardHelper.OnSoftKeyboardChangeListener() {
                    @Override
                    public void onSoftKeyboardChanged(int keyboardHeightInPx) {
                    }

                    @Override
                    public void onSoftKeyboardOpened(int keyboardHeightInPx) {
//                        rootView.scrollTo(0, SizeUtils.dp2px(110) + StatusBarUtil.getNavBarHeight());
                    }

                    @Override
                    public void onSoftKeyboardClosed() {
                        rootView.scrollTo(0, 0);
                    }
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        softKeyboardHelper.unregisterView();
    }
}
