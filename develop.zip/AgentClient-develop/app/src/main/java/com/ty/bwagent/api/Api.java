package com.ty.bwagent.api;

import com.ty.bwagent.bean.AboutSponsor;
import com.ty.bwagent.bean.ActiveRateEntity;
import com.ty.bwagent.bean.AddBankCardEntity;
import com.ty.bwagent.bean.AgentLowerListBean;
import com.ty.bwagent.bean.BannerListBean;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.BindInfoEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.CommissionEntity;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.bean.DictTypeEntity;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.bean.GameVenueEntity;
import com.ty.bwagent.bean.MMessage;
import com.ty.bwagent.bean.MaterialEntity;
import com.ty.bwagent.bean.MemberDetailsEntity;
import com.ty.bwagent.bean.MemberEntity;
import com.ty.bwagent.bean.MemberGameEntity;
import com.ty.bwagent.bean.MemberGameRecordEntity;
import com.ty.bwagent.bean.MemberLowerEntity;
import com.ty.bwagent.bean.ReviewListEntity;
import com.ty.bwagent.bean.SaveUserEntity;
import com.ty.bwagent.bean.OverFlowBean;
import com.ty.bwagent.bean.SchemeSetCommissionEntity;
import com.ty.bwagent.bean.SchemeSetRebateEntity;
import com.ty.bwagent.bean.TeamCommissionEntity;
import com.ty.bwagent.bean.MessageSys;
import com.ty.bwagent.bean.MonthOverEntity;
import com.ty.bwagent.bean.SpecialNoticeEntity;
import com.ty.bwagent.bean.TeamCountEntity;
import com.ty.bwagent.bean.TeamMenberInfoEntity;
import com.ty.bwagent.bean.MemberConfigEntity;
import com.ty.bwagent.bean.TurnUserEntity;
import com.ty.bwagent.bean.UnRendTypeEntity;
import com.ty.bwagent.bean.UpFileEntity;
import com.ty.bwagent.bean.UserEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.bean.ValueBean;
import com.ty.bwagent.fragment.deposit.bean.DepositRecord;
import com.ty.bwagent.fragment.finance.bean.FinanceAccount;
import com.ty.bwagent.fragment.finance.bean.FinanceDeposit;
import com.ty.bwagent.fragment.finance.bean.FinanceDetails;
import com.ty.bwagent.fragment.finance.bean.FinanceTax;
import com.ty.bwagent.fragment.finance.bean.FinanceTotal;
import com.ty.bwagent.fragment.finance.bean.Record;
import com.ty.bwagent.view.chart.ChartEntity;
import com.ty.net.NetCall;
import com.ty.net.http.POST;

import java.util.List;
import java.util.Map;

public interface Api {

    @POST("api/client/agent/app/member/v1/login")
    NetCall<BaseEntity<UserInfo>> login();

    @POST("api/client/agent/member/v1/register")
    NetCall<BaseEntity<UserInfo>> register();

    //火狐注册专用接口
    @POST("api/client/agent/member/v2/register")
    NetCall<BaseEntity<UserInfo>> registerByHuohu();

    @POST("api/client/agent/member/v1/getCode")
    NetCall<BaseEntity> getCode();

    @POST("api/client/agent/app/mine/v1/getCode")
    NetCall<BaseEntity> getEmailCode();

    // 获取图形验证码
    String VERIFICATION_CODE = "/api/site/group/member/memberRegister/v1/defaultKaptcha";

    @POST("api/site/group/site/perInfo/v1/checkRestrict")
    NetCall<String> checkRestrict();

    //修改登录密码
    @POST("api/site/group/member/memberCommon/v1/updateInfo")
    NetCall<BaseEntity> changePassWord();

    //忘记密码（手机找回 第一步）
    @POST("api/site/group/member/memberCommon/v1/forgetByPhoneOne")
    NetCall<BaseEntity> forgetByPhoneOne();

    //忘记密码（手机找回 第二步）
    @POST("api/site/group/member/memberCommon/v1/forgetByPhoneTwo")
    NetCall<BaseEntity> forgetByPhoneTwo();

    //忘记密码（手机找回 第三步）
    @POST("api/site/group/member/memberCommon/v1/forgetByPhoneThree")
    NetCall<BaseEntity> forgetByPhoneThree();

    //忘记密码（邮箱找回 第一步）
    @POST("api/site/group/member/memberCommon/v1/forgetByEmailOne")
    NetCall<BaseEntity> forgetByEmailOne();

    //忘记密码（邮箱找回 第二步）
    @POST("api/site/group/member/memberCommon/v1/forgetByEmailTwo")
    NetCall<BaseEntity> forgetByEmailTwo();

    //忘记密码（邮箱找回 第三步）
    @POST("api/site/group/member/memberCommon/v1/forgetByEmailThree")
    NetCall<BaseEntity> forgetByEmailThree();

    //忘记密码（邮箱找回 第三步）
    @POST("api/site/group/member/common/v1/sendCode")
    NetCall<BaseEntity> forgetSendCode();

    /**************/

    // 消息列表系统公告（查询系统公告信息）
    @POST("api/client/agent/notice/v1/querySystemNoticeList")
    NetCall<BaseEntity<MessageSys>> msgSystemList();

    // 消息列表系统公告（查询系统公告信息）
    @POST("api/client/agent/app/home/v1/queryNotice")
    NetCall<BaseEntity<List<SpecialNoticeEntity>>> queryNotice();

    // 轮播图
    @POST("api/site/group/operation/baseOperation/v1/queryBannerList")
    NetCall<BaseEntity<List<BannerListBean>>> queryBannerList();


    /*******成员开始*******/
    // 本月概览
    @POST("api/client/agent/app/home/v1/queryMonthOverview")
    NetCall<BaseEntity<MonthOverEntity>> queryMonthOverview();

    //  查询下级会员和新增下级会员数量
    @POST("api/client/agent/app/member/v1/queryLowerMember")
    NetCall<BaseEntity<MemberLowerEntity>> queryLowerMember();

    // 查询活跃占比（当月，当天）
    @POST("api/client/agent/app/member/v1/queryActiveRate")
    NetCall<BaseEntity<ActiveRateEntity>> queryActiveRate();

    // 下级成员列表
    @POST("api/client/agent/app/member/v1/queryLowerMemberList")
    NetCall<BaseEntity<MemberEntity>> queryLowerMemberList();

    // 下级成员列表
    @POST("api/client/agent/app/member/v1/queryGameInfo")
    NetCall<BaseEntity<MemberGameEntity>> queryGameInfo();

    // 下级成员详情
    @POST("api/client/agent/app/member/v1/queryLowerMemberDetail")
    NetCall<BaseEntity<MemberDetailsEntity>> queryLowerMemberDetail();


    /*******成员结束*******/


    // 联系我们
    @POST("api/client/agent/member/v1/contactUs")
    NetCall<BaseEntity<ContactUsEntity>> contactUs();

    // 关于我们赞助
    @POST("api/client/agent/agent/v1/sitePcBottom/querySitePcBottomList")
    NetCall<BaseEntity<List<AboutSponsor>>> getSponsor();

    // 区域限制配置接口
    @POST("api/site/group/site/perInfo/v1/get")
    NetCall<String> getPerInfo();


    /*******佣金开始*******/
    // 查询代理个人佣金信息
    @POST("api/client/agent/app/commission/v1/queryCommissionByMemberId")
    NetCall<BaseEntity<CommissionEntity>> queryCommissionByMemberId();

    // 获取矩形数据(柱状图)
    @POST("api/client/agent/app/commission/v1/queryCommissionByDate")
    NetCall<BaseEntity<List<ChartEntity>>> queryCommissionByDate();

    // 月度详细数据
    @POST("api/client/agent/app/commission/v1/queryMonthCommissionDetail")
    NetCall<BaseEntity<FinanceEntity>> queryMonthCommissionDetail();

    // 总输赢/场馆费月度明细
    @POST("api/client/agent/app/commission/v1/queryProfitDetail")
    NetCall<BaseEntity<List<FinanceTotal>>> queryProfitDetail();

    // 红利月度明细
    @POST("api/client/agent/app/commission/v1/queryPromoList")
    NetCall<BaseEntity<List<FinanceTax>>> queryPromoList();

    // 获取存款支付方式
    @POST("api/client/agent/finance/v1/deposit")
    NetCall<BaseEntity<List<FinanceDeposit>>> queryDeposit();

    // 账户调整月度明细
    @POST("api/client/agent/app/commission/v1/queryAdjustList")
    NetCall<BaseEntity<List<FinanceAccount>>> queryAdjustList();

    // 月度明细(返水)
    @POST("api/site/group/member/memberGradeConfig/v1/getGameFanshuiHighLow")
    NetCall<BaseEntity<Map<String, List<ValueBean>>>> financeWater();

    // 月度明细(佣金 ,净输赢，冲正后净输赢)
    @POST("api/client/agent/app/commission/v1/queryCommissionLevel")
    NetCall<BaseEntity<List<FinanceDetails>>> getGameFanshuiHighLow();

    /*******佣金结束*******/

    // 绑定手机号
    @POST("api/client/agent/member/v1/bindPhone")
    NetCall<BaseEntity<BindInfoEntity>> bindPhone();

    // 绑定邮箱
    @POST("api/client/agent/member/v1/bindEmail")
    NetCall<BaseEntity<BindInfoEntity>> bindEmail();

    // 绑定QQ
    @POST("api/client/agent/member/v1/bindQq")
    NetCall<BaseEntity<BindInfoEntity>> bindQq();

    // 退出登录
    @POST("api/client/agent/member/v1/logout")
    NetCall<BaseEntity> logout();

    // 获取个人用户信息
    @POST("api/client/agent/app/mine/v1/getByApp")
    NetCall<BaseEntity<UserEntity>> getUserInfo();

    // 获取提款记录
    @POST("api/client/agent/app/withdrawal/v1/withdrawalListFilter")
    NetCall<BaseEntity<Record>> withdrawalListFilter();

    // 消息列表
    @POST("api/site/group/msg/msgHandle/v1/msgList")
    NetCall<BaseEntity<MMessage>> msgList();

    // 一键阅读
    @POST("api/site/group/msg/msgHandle/v1/onekeyReaded")
    NetCall<BaseEntity> onekeyReaded();

    // 删除一条通知消息
    @POST("api/site/group/msg/msgHandle/v1/msgDelete")
    NetCall<BaseEntity> msgDelete();

    // 标记一条消息为已读状态
    @POST("api/site/group/msg/msgHandle/v1/readed")
    NetCall<BaseEntity> msgReaded();

    // 各类型消息未读量(用来标识小红点)

    @POST("api/site/group/msg/msgHandle/v1/getUnreadForType")
    NetCall<BaseEntity<UnRendTypeEntity>> getUnreadForType();

    // 推广连接
    @POST("api/client/agent/app/member/v1/domainByClientType")
    NetCall<BaseEntity<List<ExtensionEntity>>> domainByClientType();

    // 获取推广素材列表查询接口
    @POST("api/client/agent/material/v1/selectMaterialList")
    NetCall<BaseEntity<MaterialEntity>> selectMaterialList();

    // 获取推广素材图片尺寸下拉框列表查询接口
    @POST("api/client/agent/material/v1/selectMaterialSizeList")
    NetCall<BaseEntity<List<String>>> selectMaterialSizeList();

    // 代理钱包（查询我的界面余额）
    @POST("api/client/agent/withdrawal/v1/initMoney")
    NetCall<BaseEntity<Commission>> initMoney();

    // 提款获取电话号码
    @POST("api/client/agent/agent/v1/getPhone")
    NetCall<BaseEntity<String>> getDrawPhone();

    // 上传用户头像(第一步)
//    @POST("api/component/memberfile/staticSource/v1/uploadFile")
    @POST("api/component/file/staticSource/v2/uploadFile")
    NetCall<BaseEntity<UpFileEntity>> uploadFile();

    // 上传用户头像（第二步，借用第一步返回图片url修改）
    @POST("api/site/group/member/memberAvatar/v1/insertMemberAvatar")
    NetCall<BaseEntity> insertMemberAvatar();

    // 查询银行列表
    @POST("api/component/dict/dictType/v1/query")
    NetCall<BaseEntity<List<AddBankCardEntity>>> queryBanks();

    // 银行卡三要素校验(验证银行卡)
    @POST("api/client/agent/withdrawal/v1/validateBankCard")
    NetCall<BaseEntity> validateBankCard();

    // 提款至银行卡
    @POST("api/client/agent/withdrawal/v1/withdrawalToBank")
    NetCall<BaseEntity> withdrawalToBank();

    // 提款至中心钱包
    @POST("api/client/agent/withdrawal/v1/withdrawToCentralWallet")
    NetCall<BaseEntity> withdrawToCentralWallet();


    // 查询代理代存记录
    @POST("api/client/agent/proxy/v1/agentDepositRecordList")
    NetCall<BaseEntity<DepositRecord>> agentDepositRecordList();

    // 查询代理转账记录
    @POST("api/client/agent/proxy/v1/transferRecordList")
    NetCall<BaseEntity<DepositRecord>> transferRecordList();

    // 代理转账 代理代存配置接口
    @POST("api/client/agent/configInfo/v1/getAgentDepositConfig")
    NetCall<BaseEntity<MemberConfigEntity>> getAgentDepositConfig();

    // 代理代存
    @POST("api/client/agent/proxy/v1/agentDeposit")
    NetCall<BaseEntity> agentDeposit();


    // 代理转账-获取下级用户信息接口
    @POST("api/client/agent/proxy/v1/agentTransferInfo")
    NetCall<BaseEntity<TurnUserEntity>> agentTransferInfo();

    // 代理代存-获取下级用户信息接口
    @POST("api/client/agent/proxy/v1/agentDepositInfo")
    NetCall<BaseEntity<SaveUserEntity>> agentDepositInfo();

    // 代理转账接口
    @POST("api/client/agent/proxy/v1/agentTransfer")
    NetCall<BaseEntity> agentTransfer();

    // 重置支付密码
    @POST("/api/client/agent/agent/v1/rechargePassword")
    NetCall<BaseEntity> rechargePassword();

    // 设置支付密码
    @POST("/api/client/agent/agent/v1/setPayPwd")
    NetCall<BaseEntity> setPayPwd();

    // 修改支付密码
    @POST("/api/client/agent/agent/v1/updatePassword")
    NetCall<BaseEntity> updatePassword();

    // 查询代理团队信息
    @POST("/api/client/agent/team/v1/getTeamId")
    NetCall<BaseEntity<String>> getTeamId();

    // 查询团队列表接口
    @POST("/api/client/agent/team/v1/list")
    NetCall<BaseEntity<TeamMenberInfoEntity>> getTeamMenberList();

    //  团队佣金&团队财务列表
    @POST("/api/client/agent/commission/v1/list")
    NetCall<BaseEntity<TeamCommissionEntity>> commissionList();


    //  溢出列表
    @POST("/api/client/agent/agentOverflowApply/v1/applyList")
    NetCall<BaseEntity<OverFlowBean>> applyList();

    //  溢出调整查询接口
    @POST("/api/client/agent/agentOverflowApply/v1/revisionQueryList")
    NetCall<BaseEntity> revisionQueryList();

    //多张图片上传
    @POST("/api/component/file/staticSource/v2/uploadMulti")
    NetCall<BaseEntity<List<UpFileEntity>>> uploadMultiFile();

    //申请溢出
    @POST("/api/client/agent/agentOverflowApply/v1/apply")
    NetCall<BaseEntity> applyFlowOver();

    //修改溢出申请
    @POST("/api/client/agent/agentOverflowApply/v1/updateApply")
    NetCall<BaseEntity> updateApplyFlowOver();

    //获取筛选类型
    @POST("/api/component/dict/dictType/v1/query")
    NetCall<BaseEntity<List<DictTypeEntity>>> dictTypeQuery();

    //游戏记录场馆类型
    @POST("/api/client/agent/game/v1/getAllGameVenue")
    NetCall<BaseEntity<List<GameVenueEntity>>> getAllGameVenue();

    //游戏记录场馆类型
    @POST("/api/client/agent/game/v1/queryGameInfo")
    NetCall<BaseEntity<MemberGameRecordEntity>> queryGameRecodeList();

    // 更改展示qq号
    @POST("/api/client/agent/agent/v1/updateQqType")
    NetCall<BaseEntity> updateQqType();

    // 无限代web-审核-列表查询
    @POST("/api/client/agent/limitlessAgentReview/v1/reviewList")
    NetCall<BaseEntity<ReviewListEntity>> reviewList();

    // 无限代web-审核-更新接口
    @POST("/api/client/agent/limitlessAgentReview/v1/updateReview")
    NetCall<BaseEntity> updateReview();

    //无限代web-返佣-我的方案
    @POST("/api/client/agent/limitlessAgentScheme/v1/myCommission")
    NetCall<BaseEntity<List<SchemeSetCommissionEntity>>> myCommission();

    //无限代web-返佣-下级方案
    @POST("/api/client/agent/limitlessAgentScheme/v1/myLowerCommission")
    NetCall<BaseEntity<List<SchemeSetCommissionEntity>>> myLowerCommission();

    //无限代web-返佣-新增方案
    @POST("/api/client/agent/limitlessAgentScheme/v1/insertMyLowerCommission")
    NetCall<BaseEntity> insertMyLowerCommission();

    //无限代web-返佣-更新方案
    @POST("/api/client/agent/limitlessAgentScheme/v1/updateMyLowerCommission")
    NetCall<BaseEntity> updateMyLowerCommission();

    //无限代web-返水-我的方案
    @POST("/api/client/agent/limitlessAgentScheme/v1/myDiscount")
    NetCall<BaseEntity<List<SchemeSetRebateEntity>>> myDiscount();

    //无限代web-返水-下级方案
    @POST("/api/client/agent/limitlessAgentScheme/v1/myLowerDiscount")
    NetCall<BaseEntity<List<SchemeSetRebateEntity>>> myLowerDiscount();

    //无限代web-返水-新增方案
    @POST("/api/client/agent/limitlessAgentScheme/v1/insertMyLowerDiscount")
    NetCall<BaseEntity> insertMyLowerDiscount();

    //无限代web-返水-更新方案
    @POST("/api/client/agent/limitlessAgentScheme//v1/updateMyLowerDiscount")
    NetCall<BaseEntity> updateMyLowerDiscount();

    //无限代web-下级-下级代理
    @POST("/api/client/agent/limitlessAgentLower/v1/agentLowerList")
    NetCall<BaseEntity<AgentLowerListBean>> agentLowerList();

    //无限代web-下级-新增代理
    @POST("/api/client/agent/limitlessAgentLower/v1/insertLower")
    NetCall<BaseEntity> insertLower();

    //无限代web-下级-新增代理
    @POST("/api/client/agent/limitlessAgentLower/v1/getTeamCount")
    NetCall<BaseEntity<TeamCountEntity>> getTeamCount();


}
