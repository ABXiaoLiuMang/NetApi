package com.ty.bwagent.fragment.login;

import android.view.View;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.view.XPassWordView;
import com.ty.bwagent.viewmodel.PayPasswordViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ToastUtils;

import java.util.Arrays;

import butterknife.BindView;

/**
 * 重置密码
 */
public class PayPassWordSetFragment extends ABBaseFragment implements View.OnClickListener {

    @BindView(R.id.tv_warning)
    TextView tv_warning;
    @BindView(R.id.tv_commit)
    TextView tvCommit;

    @BindView(R.id.x_newPass)
    XPassWordView x_newPass;
    @BindView(R.id.x_confirmPass)
    XPassWordView x_confirmPass;
    @BindView(R.id.titleBar)
    TitleBar titleBar;

    private PayPasswordViewModel registerViewModel;

    public static PayPassWordSetFragment getInstance() {
        PayPassWordSetFragment fragment = new PayPassWordSetFragment();
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_pay_password_set;
    }

    @Override
    protected void createProvider() {
        initeDate();
        initListener();
    }

    @Override
    protected void initViewsAndEvents() {
        setFragmentResult(1001, null);
    }

    private void initeDate() {
        registerViewModel = new ViewModelProvider(this).get(PayPasswordViewModel.class);
        tvCommit.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_commit:
                registerViewModel.payPassWordResert(x_newPass.getPassEditText().getText().toString(), x_confirmPass.getPassEditText().getText().toString().trim());
                break;
        }
    }

    private void initListener() {

        registerViewModel.setPasswordLiveData.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity o) {
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                userInfo.setPaymentPassword("1");
                UserInfoCache.getInstance().saveUserInfo(userInfo);
                ToastUtils.showLong("设置成功");
                XLiveDataManager.getInstance().userInfo.postNext(userInfo);
                pop();
            }

            @Override
            protected void onError(int code, String errMsg) {
                //ToastUtils.showLong(errMsg);
                tv_warning.setText(errMsg);
            }
        });

        new InputResultCalculator(Arrays.asList(x_newPass.getPassEditText(), x_confirmPass.getPassEditText()), ok -> {
            tvCommit.setEnabled(ok);
        });

    }


    @Override
    public void onStop() {
        super.onStop();
        KeyboardUtils.hideSoftInput(tvCommit);
    }

}
