package com.ty.bwagent.fragment.login;


import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.tianyu.updater.TYUpdater;
import com.tianyu.updater.entity.UpdateEntity;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.ViewPagerFragmentAdapter;
import com.ty.bwagent.update.XUpdateManager;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.LogUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.SoftKeyboardHelper;
import com.ty.utils.StatusBarUtil;
import com.ty.utils.StringUtils;

import java.util.ArrayList;

import butterknife.BindView;


public class LoginAndRegisterFragment extends ABBaseFragment {

    @BindView(R.id.tabLayout)
    TabLayout tabLayout;
    @BindView(R.id.viewPager)
    ViewPager viewPager;


    public static LoginAndRegisterFragment getInstance() {
        return new LoginAndRegisterFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_login_register;
    }

    @Override
    protected void createProvider() {
        XLiveDataManager.getInstance().updateResult.observe(this,new SimpleObserver<UpdateEntity>(){
            @Override
            protected void onSuccess(UpdateEntity updateEntity) {
                if(!App.is_showing_update_dialog  && !StringUtils.isEmpty(updateEntity.getVersionName())){
                    App.is_showing_update_dialog = true;
                    XUpdateManager.showUpdateDialog(mContext, null, updateEntity, null);
                }
                XLiveDataManager.getInstance().updateResult.removeObservers(LoginAndRegisterFragment.this);
            }

            @Override
            protected void onError(int code, String errMsg) {
                XLiveDataManager.getInstance().updateResult.removeObservers(LoginAndRegisterFragment.this);
            }
        });
    }

    private LoginFragment loginFragment;
    private RegisterFragment registerFragment;
    @Override
    protected void initViewsAndEvents() {
        ArrayList<ABBaseFragment> fragments = new ArrayList<>();
        loginFragment = LoginFragment.getInstance();
        registerFragment = RegisterFragment.getInstance();
        fragments.add(loginFragment);
        fragments.add(registerFragment);
        ViewPagerFragmentAdapter adapter = new ViewPagerFragmentAdapter(getChildFragmentManager(),fragments);
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(fragments.size());
        tabLayout.setupWithViewPager(viewPager);
        String [] arrays = new String[]{"登录", "注册"};
        for (int index = 0; index < arrays.length; index ++){
            tabLayout.getTabAt(index).setCustomView(R.layout.login_register_tab_indicator);
            View view = tabLayout.getTabAt(index).getCustomView();
            TextView textView = view.findViewById(R.id.tvTab);
            textView.setText(arrays[index]);
            initGradientDrawable(textView);
        }
        XLiveDataManager.getInstance().checkUpdate();//检查更新

        // 键盘弹出密码输入框需要更新位置，整体布局上移
        new SoftKeyboardHelper()
                .registerActivity(getActivity())
                .setOnSoftKeyboardChangeListener(new SoftKeyboardHelper.OnSoftKeyboardChangeListener() {
                    @Override
                    public void onSoftKeyboardChanged(int keyboardHeightInPx) {
                    }

                    @Override
                    public void onSoftKeyboardOpened(int keyboardHeightInPx) {
                        rootView.scrollTo(0, SizeUtils.dp2px(110) + StatusBarUtil.getNavBarHeight());
                    }

                    @Override
                    public void onSoftKeyboardClosed() {
                        rootView.scrollTo(0, 0);
                    }
                });
    }


    @Override
    public void onStop() {
        super.onStop();
        TYUpdater.getUpdateLiveData().removeObservers(getActivity());
    }


    /**
     * 适配设置各个站点tab背景颜色
     * @param textView
     */
    private void initGradientDrawable(TextView textView){
        GradientDrawable normalDrawable = new GradientDrawable();
        normalDrawable.setCornerRadius(SizeUtils.sp2px(20));
        normalDrawable.setShape(GradientDrawable.RECTANGLE);
        normalDrawable.setColor(ResUtils.getColor(android.R.color.transparent));

        GradientDrawable enableDrawable = new GradientDrawable();
        enableDrawable.setCornerRadius(SizeUtils.sp2px(20));
        enableDrawable.setShape(GradientDrawable.RECTANGLE);
        enableDrawable.setColor(ResUtils.getColor(SiteSdk.ins().styleColor()));

        StateListDrawable stateDrawable = new StateListDrawable();
        stateDrawable.addState(new int[]{-android.R.attr.state_selected}, normalDrawable);
        stateDrawable.addState(new int[]{android.R.attr.state_selected}, enableDrawable);
        textView.setBackground(stateDrawable);
    }
}
