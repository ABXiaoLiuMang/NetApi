package com.ty.bwagent.view.share;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.utils.ResUtils;

import java.util.Arrays;


/**
 * 描述:推广素材位置切换适配器
 *
 */
public class GravityAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    int postion = 0;

    public GravityAdapter() {
        super(R.layout.recycle_share_gravity);
        setNewData(Arrays.asList("左上角","右上角","居中","左下角","右下角"));
    }

    public void setPostion(int postion) {
        this.postion = postion;
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, String item) {
        TextView tv_gravity = helper.getView(R.id.tv_gravity);
        tv_gravity.setText(item);
        if(helper.getAdapterPosition() == postion){
            tv_gravity.setBackgroundResource(R.drawable.site_bnt_stroke_bg);
            tv_gravity.setTextColor(ResUtils.getColor(R.color.site_style_color));
        }else {
            tv_gravity.setBackgroundResource(R.drawable.share_normal_gravity_bg);
            tv_gravity.setTextColor(ResUtils.getColor(R.color.generic_huise));
        }
    }


}
