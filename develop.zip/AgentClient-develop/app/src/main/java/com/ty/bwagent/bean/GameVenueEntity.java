package com.ty.bwagent.bean;

public class GameVenueEntity {

    /**
     * commissionRate : 0.05
     * enName : EBETZR
     * id : 1
     * status : null
     * zhName : EBET真人
     */

    private double commissionRate;
    private String enName;
    private int id;
    private Object status;
    private String zhName;

    public double getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Object getStatus() {
        return status;
    }

    public void setStatus(Object status) {
        this.status = status;
    }

    public String getZhName() {
        return zhName;
    }

    public void setZhName(String zhName) {
        this.zhName = zhName;
    }
}
