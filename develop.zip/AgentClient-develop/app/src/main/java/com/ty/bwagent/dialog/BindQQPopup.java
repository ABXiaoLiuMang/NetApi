package com.ty.bwagent.dialog;

import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupAnimation;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.BindInfoEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.BindViewModel;
import com.ty.common.util.AlphaAnimator;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 绑定QQ弹窗
 */
public class BindQQPopup extends ConfirmPopupView {

    ClearEditText et_input;
    String qqText;//输入框内容
    BindViewModel bindViewModel;
    Fragment fragment;
    BasePopupView progressDialog;

    public BindQQPopup(Fragment fragment) {
        super(fragment.getContext());
        this.fragment = fragment;
        this.title = "绑定QQ号码";
        bindViewModel = new BindViewModel();
    }


    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_bindqq;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        tv_content.setVisibility(VISIBLE);
        et_input = findViewById(R.id.et_input);

        et_input.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tv_content.setText("");
            }
        });
        VerifyUtils.verifyQQ(et_input, tv_content);
        setListener(() -> {
            qqText = et_input.getText().toString().trim();
            bindViewModel.bindQq(qqText);
        }, null);

        initViewsAndEvents();
    }

    /**
     * 一系列监听回调
     */
    private void initViewsAndEvents() {


        //监听绑定结果
        bindViewModel.bindLiveData.observeForever(new NetObserver<BaseEntity<BindInfoEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<BindInfoEntity> baseEntity) {
                if (baseEntity != null) {
                    ToastUtils.showLong("绑定成功");
                    UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                    userInfo.setQq(qqText);
                    UserInfoCache.getInstance().saveUserInfo(userInfo);
                    XLiveDataManager.getInstance().userInfo.postNext(userInfo);
                }
                dismiss();
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText(errMsg);
            }

        });

    }

    @Override
    public void dismiss() {
        bindViewModel.bindLiveData.removeObservers(fragment);
        super.dismiss();
    }


    private void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(fragment.getContext(),fragment);
            progressDialog = new XPopup.Builder(fragment.getContext())
                    .isRequestFocus(false)  //loading不要焦点
                    .hasShadowBg(false)
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        progressDialog.show();
    }

    private void dismissProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }


    @Override
    protected void doAfterShow() {
        super.doAfterShow();
        KeyboardUtils.showSoftInput(et_input);
    }


    @Override
    protected void doAfterDismiss() {
        super.doAfterDismiss();
        KeyboardUtils.hideSoftInput(et_input);
    }

}