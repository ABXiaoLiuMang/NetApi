package com.ty.bwagent.fragment;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.interfaces.SimpleCallback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.HomeAdapter;
import com.ty.bwagent.bean.BannerListBean;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.bean.MemberConfigEntity;
import com.ty.bwagent.bean.MonthOverEntity;
import com.ty.bwagent.bean.QuickEntity;
import com.ty.bwagent.bean.SchemeSetCommissionEntity;
import com.ty.bwagent.bean.SchemeSetRebateEntity;
import com.ty.bwagent.bean.SpecialNoticeEntity;
import com.ty.bwagent.bean.UserEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.dialog.NoticePopup;
import com.ty.bwagent.fragment.deposit.fragment.SaveMoneyFragment;
import com.ty.bwagent.fragment.deposit.fragment.TurnMoneyFragment;
import com.ty.bwagent.fragment.finance.fragment.DrawingTabFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceTotalFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceWinFragment;
import com.ty.bwagent.fragment.login.PayPassWordSetFragment;
import com.ty.bwagent.fragment.news.MessageTabFragment;
import com.ty.bwagent.fragment.schemeset.SchemeSetFragment;
import com.ty.bwagent.fragment.share.MaterialListFragment;
import com.ty.bwagent.fragment.subordinate.SubAgentFragment;
import com.ty.bwagent.fragment.subordinate.SubAuditFragment;
import com.ty.bwagent.ui.H5Activity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.KLinkSchema;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.view.XMarqueView;
import com.ty.bwagent.view.XTextView;
import com.ty.bwagent.viewmodel.HomeViewModel;
import com.ty.bwagent.viewmodel.MoneyViewModel;
import com.ty.bwagent.viewmodel.TeamViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.utils.ImageResoureSiteUtils;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ShadowDrawable;
import com.ty.view.viewpager.XBanner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import me.yokeyword.fragmentation.ISupportFragment;

import static com.ty.bwagent.adapter.HomeAdapter.DRAWING;
import static com.ty.bwagent.adapter.HomeAdapter.EXTENSIONTAB;
import static com.ty.bwagent.adapter.HomeAdapter.FINANCETAB;
import static com.ty.bwagent.adapter.HomeAdapter.GAMERECORD;
import static com.ty.bwagent.adapter.HomeAdapter.MATERIALLIST;
import static com.ty.bwagent.adapter.HomeAdapter.MEMBERTAB;
import static com.ty.bwagent.adapter.HomeAdapter.OVERFLOW;
import static com.ty.bwagent.adapter.HomeAdapter.SAVEMONEY;
import static com.ty.bwagent.adapter.HomeAdapter.SCHEMESET;
import static com.ty.bwagent.adapter.HomeAdapter.SUBORDINATEAGENT;
import static com.ty.bwagent.adapter.HomeAdapter.SUBORDINATEAUDIT;
import static com.ty.bwagent.adapter.HomeAdapter.TEAMCENTER;
import static com.ty.bwagent.adapter.HomeAdapter.TURNMONEY;

/**
 * 首页
 */
public class HomeFragment extends ABRefreshFragment<QuickEntity> implements View.OnClickListener {

    HomeViewModel mHomeViewModel;
    MoneyViewModel moneyViewModel;

    LinearLayout cardLayout;
    View headRootView;
    XBanner banner;
    XMarqueView xMarqueView;
    TextView homeTvMoney;//本月佣金
    XTextView homeTvWin;//净输赢
    TextView homeTvAgent;//新增下级
    TextView homeMontyKey2;//净输赢

    Commission commission;//佣金余额和冻结金额
    private HomeAdapter homeAdapter;
    private TeamViewModel teamViewModel;
    private List<SpecialNoticeEntity> entityList;


    public static HomeFragment getInstance() {
        return new HomeFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home;
    }

    @Override
    protected void createProvider() {
        mHomeViewModel = new ViewModelProvider(getParentFragment()).get(HomeViewModel.class);
        moneyViewModel = new ViewModelProvider(getActivity()).get(MoneyViewModel.class);
        teamViewModel = new ViewModelProvider(this).get(TeamViewModel.class);

        //监听跑马灯通知
        mHomeViewModel.noticeLiveData.observe(this, new NetObserver<BaseEntity<List<SpecialNoticeEntity>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<SpecialNoticeEntity>> listBaseEntity) {
                List<SpecialNoticeEntity> entityList = listBaseEntity.getData();
                if (entityList != null && entityList.size() > 0) {
                    initMarqueView(entityList);
                } else {
                    List<SpecialNoticeEntity> listBeans = new ArrayList<>();
                    SpecialNoticeEntity listBean = new SpecialNoticeEntity();
                    listBean.setContent(ResUtils.getString(R.string.generic_empey_notice));
                    listBean.setTitle("暂无公告");
                    listBeans.add(listBean);
                    initMarqueView(listBeans);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                List<SpecialNoticeEntity> listBeans = new ArrayList<>();
                SpecialNoticeEntity listBean = new SpecialNoticeEntity();
                listBean.setContent(ResUtils.getString(R.string.generic_empey_notice));
                listBean.setTitle("暂无公告");
                listBeans.add(listBean);
                initMarqueView(listBeans);
            }
        });


        //监听本月概览
        mHomeViewModel.monthOverLiveData.observe(this, new SimpleObserver<BaseEntity<MonthOverEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<MonthOverEntity> baseEntity) {
                refreshLayout.finishRefresh();
                MonthOverEntity monthOverEntity = baseEntity.getData();
                homeTvMoney.setText(com.ty.bwagent.utils.Utils.parseMoney(monthOverEntity.getCommission()));//本月佣金
                homeTvMoney.setTypeface(TypefaceUtils.DIN_MEDIUM);

                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                if (userInfo.getAgentModel() == 0) {//一级代理
                    homeTvWin.setMontyText(monthOverEntity.getNetWinLose());//净输赢
                    homeTvWin.setTag(monthOverEntity.getNetWinLose() + "");
                } else {//无限极 等后台处理 字段返回
                    homeTvWin.setMontyText(monthOverEntity.getTotalProfit());//总输赢
                    homeTvWin.setTag(monthOverEntity.getTotalProfit() + "");
                }

                homeTvAgent.setText(MathUtil.parsePersonNumber(monthOverEntity.getTotalNewMembers()) + "人");//新增下级
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showToast(errMsg);
                refreshLayout.finishRefresh(false);
//                homeTvMoney.setText("--");//本月佣金
//                homeTvWin.setText("--");//总输赢
//                homeTvAgent.setText("--");//新增下级
            }
        });


        //轮播图
        mHomeViewModel.bannerLiveData.observe(this, new SimpleObserver<BaseEntity<List<BannerListBean>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<BannerListBean>> baseEntity) {
                List<BannerListBean> listBeans = baseEntity.getData();
                if (listBeans != null && listBeans.size() > 0) {
                    initBanner(listBeans);
                } else {
                    initDefaultBanner();
                }
            }
        });


        //重要通告，弹窗数据
        mHomeViewModel.specialLiveData.observe(this, new NetObserver<BaseEntity<List<SpecialNoticeEntity>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<SpecialNoticeEntity>> listBaseEntity) {
                entityList = listBaseEntity.getData();
                if (entityList != null && entityList.size() > 0 && ((MainFragment) getParentFragment()).currentIndex == 0 && !isHasShowNotice) {
                    ((MainFragment) getParentFragment()).isShowNotice = true;
                    mHomeViewModel.isShowNoticeLiveData.postValue(true);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //关于数据
        mHomeViewModel.contactUsLiveData.observe(this, new SimpleObserver<BaseEntity<ContactUsEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<ContactUsEntity> entity) {

                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                if (userInfo != null && userInfo.getFirstLogin() == 1) {//第一次登录弹框
                    isFistLogin(entity);
                    userInfo.setFirstLogin(0);//更新第一次登录状态
                    UserInfoCache.getInstance().saveUserInfo(userInfo);
                }

                ContactUsEntity contactUsEntity = entity.getData();
                String serviceText = contactUsEntity.getCustomerService();
                MMKVUtil.put(CacheKey.CUSTOMER_SERVICE, serviceText);
                MMKVUtil.put(CacheKey.H5_DOMAIN, contactUsEntity.getH5DomainUrl());
                XLiveDataManager.getInstance().contactUsLiveData.postNext(contactUsEntity);
            }
        });

        //佣金余额
        moneyViewModel.commissLiveData.observe(this, new SimpleObserver<BaseEntity<Commission>>() {
            @Override
            protected void onSuccess(BaseEntity<Commission> baseEntity) {
                commission = baseEntity.getData();
            }
        });

        //代理转账 团队中心 代理代存 是否显示
        teamViewModel.teamInfoLiveData.observe(this, new SimpleObserver<BaseEntity<String>>() {
            @Override
            protected void onSuccess(BaseEntity<String> baseEntity) {
                if (baseEntity != null && StringUtils.length(baseEntity.getData()) > 0) {
                    homeAdapter.addMemBerCenterModle();//增加团队模式
                } else {
                    homeAdapter.removeMemBerCenterModle();//取消团队模式
                }
            }
        });

        mHomeViewModel.isShowNoticeLiveData.observe(this, aBoolean -> {
            if (aBoolean && ((MainFragment) getParentFragment()).currentIndex == 0) {
                showSpecialNoticeDialog();//通知弹窗
            } else {
                isHasShowNotice = true;
            }
        });

        //获取团队模式
        XLiveDataManager.getInstance().memberConfigLiveData.observe(this, new NetObserver<BaseEntity<MemberConfigEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<MemberConfigEntity> siteConfigBean) {
                //"0为站点代理业务使用团队模式；1为站点代理业务不使用团队模式",
                if (siteConfigBean != null && siteConfigBean.getData() != null && siteConfigBean.getData().getShowTeamModel() == 0) {
                    teamViewModel.getTeamInfo();//再判断是不是队长
                } else {
                    homeAdapter.removeMemBerCenterModle();//取消团队模式
                }
                // 是否展示代理代存菜单 0展示 1隐藏
                if (siteConfigBean != null && siteConfigBean.getData() != null && siteConfigBean.getData().getShowAgentDeposit() == 0) {
                    homeAdapter.addDepositModle();//显示代理代存
                } else {
                    homeAdapter.removeDepositModle();//隐藏代理代存
                }

            }

            @Override
            protected void onError(int code, String errMsg) {

            }
        });


        XLiveDataManager.getInstance().userLiveData.observe(this, new SimpleObserver<BaseEntity<UserEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<UserEntity> baseEntity) {
                UserEntity userEntity = baseEntity.getData();
                if (userEntity != null) {
                    UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                    userInfo.setPaymentPassword(userEntity.getPaymentPassword());
                    userInfo.setSysType(userEntity.getSysType());
                    userInfo.setQqType(userEntity.getQqType());
                    UserInfoCache.getInstance().saveUserInfo(userInfo);
                }
            }
        });

        //无限代web-返佣-下级方案
        mHomeViewModel.myLowerCommissionLivaData.observe(this, new SimpleObserver<BaseEntity<List<SchemeSetCommissionEntity>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<SchemeSetCommissionEntity>> listBaseEntity) {
                if (listBaseEntity != null && listBaseEntity.getData() != null
                        && listBaseEntity.getData().size() > 0 && listBaseEntity.getData().get(0).getRebateDetail() != null
                        && listBaseEntity.getData().get(0).getRebateDetail().size() > 0) {
                    homeAdapter.setSchemeRedDot(1, false, false);
                } else {
                    homeAdapter.setSchemeRedDot(1, true, false);
                }
            }
        });

        //  返水-下属方案
        mHomeViewModel.lowerDiscountLivaData.observe(this, new SimpleObserver<BaseEntity<List<SchemeSetRebateEntity>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<SchemeSetRebateEntity>> listBaseEntity) {
                if (listBaseEntity != null && listBaseEntity.getData() != null
                        && listBaseEntity.getData().size() > 0 && listBaseEntity.getData().get(0).getRebateDetail() != null
                        && listBaseEntity.getData().get(0).getRebateDetail().size() > 0) {
                    homeAdapter.setSchemeRedDot(2, false, false);
                } else {
                    homeAdapter.setSchemeRedDot(2, false, true);
                }
            }
        });

        //方案设置红点的返回监听
        XLiveDataManager.getInstance().SchemeSetRedDot.observe(this, booleans -> {
            homeAdapter.isCommissionShowRedDot = booleans[0];
            homeAdapter.isRebateShowRedDot = booleans[1];
            homeAdapter.setRedDotShow();
        });

    }


    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();

        initView();

        mHomeViewModel.queryBannerList();//轮播图
        mHomeViewModel.queryMonthOverview();//本月概览
        mHomeViewModel.queryNotice();//获取通知公告
        mHomeViewModel.getAgentDepositConfig();//获取权限配置

        mHomeViewModel.contactUs();
        moneyViewModel.initMoney();

        if (UserInfoCache.getInstance().getUserInfo().getAgentModel() != 0) {//无限极
            mHomeViewModel.myLowerCommission();//获取佣金直属下属返佣方案 判断方案设置红点显示
            mHomeViewModel.myLowerDiscount();//获取返水直属下属返佣方案 判断方案设置红点显示
        }
        setAdapterDate();

        UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
        if (userInfo.getAgentModel() != 0) {//无限极
            homeAdapter.addInfinite();
            homeMontyKey2.setText("总输赢");
        } else {
            homeAdapter.reMoveInfinite();
            homeMontyKey2.setText("净输赢");
        }
    }

    List<QuickEntity> quickEntityList = new ArrayList<>();

    public void setAdapterDate() {
        quickEntityList.add(new QuickEntity(MEMBERTAB, R.mipmap.home_item_member_bg, false));//成员管理
        quickEntityList.add(new QuickEntity(EXTENSIONTAB, R.mipmap.home_item_share_bg, false));//佣金报表
        quickEntityList.add(new QuickEntity(FINANCETAB, R.mipmap.home_item_table_bg, false));//"佣金报表"
        quickEntityList.add(new QuickEntity(SAVEMONEY, R.mipmap.home_item_save_bg, false));//代理代存
        quickEntityList.add(new QuickEntity(DRAWING, R.mipmap.home_item_money_bg, false));//佣金提款
        quickEntityList.add(new QuickEntity(MATERIALLIST, R.mipmap.home_item_materta_bg, false));//推广素材
        quickEntityList.add(new QuickEntity(GAMERECORD, R.mipmap.home_item_game_bg, false));//游戏记录
        quickEntityList.add(new QuickEntity(OVERFLOW, R.mipmap.home_item_overfrow_bg, false));//溢出申请
        homeAdapter.setNewData(quickEntityList);
    }

    @Override
    public void onResume() {
        super.onResume();
        banner.startAutoPlay();
    }


    public void initView() {
        cardLayout = rootView.findViewById(R.id.cardLayout);
        headRootView = rootView.findViewById(R.id.headRootView);
        banner = rootView.findViewById(R.id.banner);
        xMarqueView = rootView.findViewById(R.id.xMarqueView);
        homeTvMoney = rootView.findViewById(R.id.home_tv_money);
        homeTvWin = rootView.findViewById(R.id.home_tv_win);
        homeTvAgent = rootView.findViewById(R.id.home_tv_agent);
        homeMontyKey2 = rootView.findViewById(R.id.home_monty_key2);
        ImageView iv_notice = rootView.findViewById(R.id.iv_notice);
        rootView.findViewById(R.id.home_monty_key1).setOnClickListener(this);
        rootView.findViewById(R.id.home_monty_key2).setOnClickListener(this);
        rootView.findViewById(R.id.home_monty_key3).setOnClickListener(this);
        homeTvMoney.setOnClickListener(this);
        homeTvWin.setOnClickListener(this);
        homeTvAgent.setOnClickListener(this);
        homeTvAgent.setTypeface(TypefaceUtils.DIN_MEDIUM);

        iv_notice.setBackgroundResource(ImageResoureSiteUtils.iconNotice());
        ShadowDrawable.setShadowDrawable(cardLayout, Color.WHITE, DensityUtil.dp2px(8),
                Color.parseColor("#0d000000"), DensityUtil.dp2px(4), 3, 6);
        ShadowDrawable.setShadowDrawable(recyclerView, Color.WHITE, DensityUtil.dp2px(8),
                Color.parseColor("#0d000000"), DensityUtil.dp2px(4), 3, 6);

        refreshLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                refreshLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                int height = refreshLayout.getHeight();
                int top = headRootView.getHeight();
                App.height = height;
                if (((height - top) > DensityUtil.dp2px(75) * 3)) {
                    ((HomeAdapter) listAdapter).setItemHeight((height - top) / 3);
                }
            }
        });
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.home_monty_key1:
            case R.id.home_tv_money:
                ((MainFragment) getParentFragment()).selectFragment(3);
                break;
            case R.id.home_monty_key2:
            case R.id.home_tv_win:
                Bundle bundle = new Bundle();
                bundle.putString(ABConfig.KEY_TAG, TimeUtils.toString(new Date(), "yyyy-MM"));
                bundle.putString(ABConfig.KEY_TEXT, (String) homeTvWin.getTag());
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                if (userInfo.getAgentModel() == 0) {//一级代理
                    goFragment(FinanceWinFragment.getInstance(bundle));
                } else {//无限极
                    goFragment(FinanceTotalFragment.getInstance(bundle));
                }
                break;
            case R.id.home_monty_key3:
            case R.id.home_tv_agent:
                ((MainFragment) getParentFragment()).selectFragment(1);
                break;
        }
    }


    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new GridLayoutManager(mContext, 4);
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public BaseQuickAdapter<QuickEntity, BaseViewHolder> getListAdapter() {
        homeAdapter = new HomeAdapter();
        return homeAdapter;
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        if (((MainFragment) getParentFragment()).isShowNotice) {
            return;
        }
        String title = ((QuickEntity) adapter.getItem(position)).getTitle();
        UserInfo userInfo;
        switch (title) {
            case MEMBERTAB://成员管理
                ((MainFragment) getParentFragment()).selectFragment(1);
                break;
            case EXTENSIONTAB://推广工具
                ((MainFragment) getParentFragment()).selectFragment(2);
                break;
            case FINANCETAB://佣金报表
                ((MainFragment) getParentFragment()).selectFragment(3);
                break;
            case DRAWING://提款
                userInfo = UserInfoCache.getInstance().getUserInfo();
                String phone = userInfo.getPhone();
                if (StringUtils.isEmpty(phone)) {
                    ToastUtils.showLong("请绑定手机号后操作");
                    return;
                }
                if (commission == null) {
                    return;
                }
                goFragment(DrawingTabFragment.getInstance());
                break;
            case SAVEMONEY://代理代存
                userInfo = UserInfoCache.getInstance().getUserInfo();
                if (userInfo.getSysType() == 1) {
                    if (StringUtils.isEmpty(userInfo.getPaymentPassword()) || "0".equals(userInfo.getPaymentPassword())) {
                        DialogUtil.confirmPayPassWordDailog(mContext, () -> goFragment(PayPassWordSetFragment.getInstance()));
                    } else {
                        goFragment(SaveMoneyFragment.Companion.getInstance());//官代
                    }
                } else {
                    goFragment(SaveMoneyFragment.Companion.getInstance());//普代
                }
                break;
            case TURNMONEY://代理转账
                userInfo = UserInfoCache.getInstance().getUserInfo();
                if (userInfo.getSysType() == 1) {
                    if (StringUtils.isEmpty(userInfo.getPaymentPassword()) || "0".equals(userInfo.getPaymentPassword())) {
                        DialogUtil.confirmPayPassWordDailog(mContext, () -> goFragment(PayPassWordSetFragment.getInstance()));
                    } else {
                        goFragment(TurnMoneyFragment.Companion.getInstance());//官代
                    }
                } else {
                    goFragment(TurnMoneyFragment.Companion.getInstance());//普代
                }
                break;
            case TEAMCENTER://团队中心
                goFragment(TeamCenterTabFragment.getInstance());
                break;
            case MATERIALLIST://推广素材
                goFragment(MaterialListFragment.getInstance());
                break;
            case OVERFLOW://溢出申请
                goFragment(OverflowFragment.getInstance());
                break;
            case GAMERECORD://游戏记录
                goFragment(GameRecordFragment.getInstance());
                break;
            case SUBORDINATEAGENT://下级代理
                goFragment(SubAgentFragment.Companion.getInstant());
                break;
            case SCHEMESET://方案设置
                goFragment(SchemeSetFragment.getInstance(homeAdapter.isCommissionShowRedDot, homeAdapter.isRebateShowRedDot));
                break;
            case SUBORDINATEAUDIT://下级审核
                goFragment(SubAuditFragment.Companion.getInstance());
                break;
            default:
                break;
        }

    }

    @Override
    public int getMode() {
        return Mode.PULL_FROM_START;
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        XLiveDataManager.getInstance().getUserInfo();//请求个人信息
        mHomeViewModel.queryNotice();//获取通知公告
        mHomeViewModel.queryMonthOverview();//本月概览
        mHomeViewModel.queryBannerList();//轮播图
        moneyViewModel.initMoney();
        XLiveDataManager.getInstance().checkUpdate();//检查更新
        mHomeViewModel.getAgentDepositConfig();//获取权限配置

        if (UserInfoCache.getInstance().getUserInfo().getAgentModel() != 0) {
            mHomeViewModel.myLowerCommission();//获取佣金直属下属返佣方案 判断方案设置红点显示
            mHomeViewModel.myLowerDiscount();//获取返水直属下属返佣方案 判断方案设置红点显示
        }
    }

    //初始化跑马灯
    private void initMarqueView(List<SpecialNoticeEntity> list) {
        xMarqueView.setList(list);
        xMarqueView.autoScroll(this);
        xMarqueView.getMarqueAdapter().setOnItemClickListener((adapter, view, position) -> {
            SpecialNoticeEntity listBean = (SpecialNoticeEntity) adapter.getItem(position);
            if (listBean != null && !StringUtils.equals(ResUtils.getString(R.string.generic_empey_notice), listBean.getContent())) {
                showNoticeDialog(listBean);
            }
        });
    }

    //初始化轮播图
    private void initBanner(List<BannerListBean> bannerListBeans) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int) (ScreenUtils.getScreenWidth() / 2.35f));
        banner.setLayoutParams(layoutParams);
        banner.loadImage((banner, model, view, position) -> {
            BannerListBean listBean = ((BannerListBean) model);
            ImageView imageView = view.findViewById(R.id.bannerImageView);

            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            if (listBean.getId() == -1) {
                Glide.with(mContext).load(R.mipmap.home_invali_bg).into(imageView);
            } else {
                RequestOptions requestOptions = new RequestOptions().override(ScreenUtils.getScreenWidth() * 2, layoutParams.height * 2);
                Glide.with(mContext).load(listBean.getCarouselUrl())
                        .apply(requestOptions).into(imageView);
            }
        });

        banner.setOnItemClickListener((banner, homeBanner, view, position) -> {
            if (DoubleClickUtils.isLongDoubleClick()) {
                return;
            }
            BannerListBean model = (BannerListBean) homeBanner;
            if (model.getId() == -1) {//默认轮播图不可点击
                return;
            }
            bannerJump(model);

        });

        banner.setAutoPlayAble(bannerListBeans.size() > 1);
        banner.setBannerData(R.layout.header_home_banner, bannerListBeans);
    }

    /**
     * 初始化轮播图默认数据
     */
    private void initDefaultBanner() {
        List<BannerListBean> listBeans = new ArrayList<>();
        BannerListBean bannerListBean = new BannerListBean();
        bannerListBean.setId(-1);
        listBeans.add(bannerListBean);
        initBanner(listBeans);
    }


    //普通公告(点击后进入详情)
    private void showNoticeDialog(SpecialNoticeEntity listBean) {
        DialogUtil.confirmDailog(mContext, listBean, () -> goFragment(MessageTabFragment.getInstance(2)));
    }


    NoticePopup customPopup = null;
    public static boolean isHasShowNotice = false;

    //特殊公告（多个下一条）
    private synchronized void showSpecialNoticeDialog() {
        if (isHasShowNotice || (customPopup != null && customPopup.isShow())) {
            return;
        }
        if (((MainFragment) getParentFragment()).currentIndex != 0) {
            return;
        }

        int count = getActivity().getSupportFragmentManager().getBackStackEntryCount();
        if (count > 1) {
            return;
        }
        if (entityList != null) {
            if (entityList.size() == 0) {
                return;
            }
            ((MainFragment) getParentFragment()).isShowNotice = true;
            customPopup = DialogUtil.noticeDailog(mContext, entityList);
            BasePopupView basePopupView = new XPopup.Builder(mContext)
                    .dismissOnTouchOutside(false)
                    .setPopupCallback(new SimpleCallback() {
                        @Override
                        public void onDismiss() {
                            super.onDismiss();
                            isHasShowNotice = true;
                            ((MainFragment) getParentFragment()).isShowNotice = false;
                        }
                    })
                    .asCustom(customPopup);
            basePopupView.show();
        } else {
            mHomeViewModel.querySpecialNotice();//重要通告
        }


    }


    private void goFragment(ISupportFragment supportFragment) {
        ((ABBaseFragment) getParentFragment()).start(supportFragment);
    }

    /**
     * 处理banner跳转逻辑
     *
     * @param model
     */
    private void bannerJump(BannerListBean model) {
        String link_url = model.getCarouselInfoUrl();
        if (StringUtils.isEmpty(link_url)) {
            return;
        }
        KLinkSchema kLinkSchema = KLinkSchema.getFromLink(link_url).setJumpType(model.getUrlType()).setUrlType(model.getCarouselType());
        String h5Domain = MMKVUtil.getString(CacheKey.H5_DOMAIN);
        switch (kLinkSchema) {
            case Http:
            case Https:
                if (kLinkSchema.isInnerJump()) {//内部跳转
                    if (!TextUtils.isEmpty(link_url)) {
                        if (!link_url.startsWith("http")) {
                            link_url = h5Domain + link_url;
                        }
                    }
                } else {//跳转浏览器  url不需要处理
                    if (!TextUtils.isEmpty(link_url)) {
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        Uri content_url = Uri.parse(link_url);
                        intent.setData(content_url);
                        Activity activity = requireActivity();
                        if (activity != null) {
                            ComponentName componentName = intent.resolveActivity(activity.getPackageManager());
                            if (componentName != null) {
                                activity.startActivity(intent);
                                return;
                            }
                        }
                    }
                }
                break;
            case None:
                link_url = h5Domain + "/app/promo/list/" + model.getActivityName();
                break;
            case Normal:
                link_url = h5Domain + link_url;
                break;
        }

        Bundle bundle = new Bundle();
        String title = model.getCarouselTitle();
        bundle.putString(ABConfig.KEY_TITLE, title);
        bundle.putString(ABConfig.KEY_TEXT, link_url);
        goActivity(H5Activity.class, bundle);
    }


    @Override
    public void onStop() {
        super.onStop();
        banner.stopAutoPlay();
    }


    // //登录用户注册后第一次进入APP，注意如果已在代理web端弹出过了，则进入APP则不再弹出；
    private void isFistLogin(BaseEntity<ContactUsEntity> entity) {
        if (entity == null) {
            return;
        }
        if (entity.getData() == null) {
            return;
        }

        if (entity.getData().getBaseInfo() == null || (entity.getData().getBaseInfo() != null && entity.getData().getBaseInfo().size() == 0)) {
            mHomeViewModel.querySpecialNotice();
            return;
        }

        DialogUtil.fisrtLoginDailog(mContext, entity, new SimpleCallback() {
            @Override
            public void onDismiss() {
                super.onDismiss();
                mHomeViewModel.querySpecialNotice();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isHasShowNotice = false;
    }
}
