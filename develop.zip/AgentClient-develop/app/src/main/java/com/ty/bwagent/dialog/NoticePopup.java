package com.ty.bwagent.dialog;

import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.lxj.xpopup.core.CenterPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.SpecialNoticeEntity;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.DialogTextHeightChangeShow;

import java.util.List;

/**
 * 首页特殊通告弹窗
 */
public class NoticePopup extends CenterPopupView {

    TextView tv_title;
    TextView tv_next;
    TextView tv_content;
    ConstraintLayout container;
    Context mContext;
    List<SpecialNoticeEntity> mData;
    int currentItem = 0;


    public NoticePopup(@NonNull Context context, List<SpecialNoticeEntity> mData) {
        super(context);
        mContext = context;
        this.mData = mData;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_notice;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_title = findViewById(R.id.tv_title);
        tv_next = findViewById(R.id.tv_next);
        tv_content = findViewById(R.id.tv_content);
        container = findViewById(R.id.container);
        DialogTextHeightChangeShow dialogTextHeightChangeShow = new DialogTextHeightChangeShow(container, tv_content,4.5);

        tv_next.setOnClickListener(v -> {
            currentItem++;
            if (currentItem < mData.size()) {
                tv_title.setText(mData.get(currentItem).getTitle());
                tv_content.setText(mData.get(currentItem).getContent());
                tv_content.scrollTo(0, 0);
                dialogTextHeightChangeShow.setTextHeight(mData.get(currentItem).getContent());
            } else {
                dismiss();
            }
            if (currentItem == mData.size() - 1) {
                tv_next.setText("关闭");
            }
        });

        tv_title.setText(mData.get(currentItem).getTitle());
        tv_content.setText(mData.get(currentItem).getContent());
        tv_content.setMovementMethod(ScrollingMovementMethod.getInstance());
        tv_content.setScrollbarFadingEnabled(true);
        if (currentItem == mData.size() - 1) {
            tv_next.setText("关闭");
        }
        dialogTextHeightChangeShow.setTextHeight(mData.get(currentItem).getContent());
    }


    @Override
    protected void onShow() {
        super.onShow();
        MainActivity.isDialogShow = true;
    }

    @Override
    protected void onDismiss() {
        super.onDismiss();
        MainActivity.isDialogShow = false;
    }

}
