package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.view.XTextView;
import com.ty.common.util.ABConfig;
import com.ty.utils.MathUtil;

import androidx.constraintlayout.widget.ConstraintLayout;

/**
 * 净输赢界面
 */
public class FinanceWinFragment extends FinanceDetailsFragment {

    TextView tv_month;//查询月份
    XTextView account_total;//净输赢

    public static FinanceWinFragment getInstance(Bundle bundle) {
        FinanceWinFragment fragment = new FinanceWinFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_win;
    }

    @Override
    protected void createProvider() {
        super.createProvider();
        bnt_nonet = rootView.findViewById(R.id.bnt_nonet);//这个要在initViewsAndEvents()之前获取
    }


    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        tv_month = rootView.findViewById(R.id.tv_month);
        account_total = rootView.findViewById(R.id.account_total);
        ll_net = rootView.findViewById(R.id.ll_net);

        String startData = bundle.getString(ABConfig.KEY_TAG);

        tv_month.setText(startData);
        if (financeEntity != null) {
            account_total.setMontyText(financeEntity.getNetProfit());
        } else {
            account_total.setMontyText(bundle.getString(ABConfig.KEY_TEXT));
        }

    }
}
