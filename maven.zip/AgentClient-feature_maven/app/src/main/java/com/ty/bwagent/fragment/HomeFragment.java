package com.ty.bwagent.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.lzy.imagepicker.util.Utils;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.HomeAdapter;
import com.ty.bwagent.bean.BannerListBean;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.bean.MonthOverEntity;
import com.ty.bwagent.bean.QuickEntity;
import com.ty.bwagent.bean.SpecialNoticeEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.dialog.NoticePopup;
import com.ty.bwagent.dialog.NoticeSimplePopup;
import com.ty.bwagent.fragment.finance.fragment.DrawingTabFragment;
import com.ty.bwagent.fragment.news.MessageTabFragment;
import com.ty.bwagent.ui.H5Activity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.view.XMarqueView;
import com.ty.bwagent.view.XTextView;
import com.ty.bwagent.viewmodel.HomeViewModel;
import com.ty.bwagent.viewmodel.MoneyViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ShadowDrawable;
import com.ty.view.viewpager.XBanner;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import me.yokeyword.fragmentation.ISupportFragment;

/**
 * 首页
 */
public class HomeFragment extends ABRefreshFragment<QuickEntity> implements View.OnClickListener {

    HomeViewModel mHomeViewModel;
    MoneyViewModel moneyViewModel;

    LinearLayout cardLayout;
    View headRootView;
    XBanner banner;
    XMarqueView xMarqueView;
    TextView homeTvMoney;//本月佣金
    XTextView homeTvWin;//总输赢
    TextView homeTvAgent;//新增下级
    @BindView(R.id.llContent)
    LinearLayout llContent;
    Commission commission;//佣金余额和冻结金额


    public static HomeFragment getInstance() {
        return new HomeFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home;
    }

    @Override
    protected void createProvider() {
        mHomeViewModel = new ViewModelProvider(getParentFragment()).get(HomeViewModel.class);
        moneyViewModel =  new ViewModelProvider(getActivity()).get(MoneyViewModel.class);
        //监听跑马灯通知
        mHomeViewModel.noticeLiveData.observe(this,new NetObserver<BaseEntity<List<SpecialNoticeEntity>>>(){
            @Override
            protected void onSuccess(BaseEntity<List<SpecialNoticeEntity>> listBaseEntity) {
                List<SpecialNoticeEntity> entityList = listBaseEntity.getData();
                if(entityList != null && entityList.size() > 0){
                    initMarqueView(entityList);
                }else {
                    List<SpecialNoticeEntity> listBeans = new ArrayList<>();
                    SpecialNoticeEntity listBean = new SpecialNoticeEntity();
                    listBean.setContent(ResUtils.getString(R.string.generic_empey_notice));
                    listBean.setTitle("暂无公告");
                    listBeans.add(listBean);
                    initMarqueView(listBeans);
                }

            }

            @Override
            protected void onError(int code, String errMsg) {
                List<SpecialNoticeEntity> listBeans = new ArrayList<>();
                SpecialNoticeEntity listBean = new SpecialNoticeEntity();
                listBean.setContent(ResUtils.getString(R.string.generic_empey_notice));
                listBean.setTitle("暂无公告");
                listBeans.add(listBean);
                initMarqueView(listBeans);
            }
        });

        //重要通告，弹窗数据
        mHomeViewModel.specialLiveData.observe(this,new NetObserver<BaseEntity<List<SpecialNoticeEntity>>>(){
            @Override
            protected void onSuccess(BaseEntity<List<SpecialNoticeEntity>> listBaseEntity) {
                List<SpecialNoticeEntity> entityList = listBaseEntity.getData();
                if(entityList != null && entityList.size() > 0){
                    showSpecialNoticeDialog(entityList);//通知弹窗
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //监听本月概览
        mHomeViewModel.monthOverLiveData.observe(this,new SimpleObserver<BaseEntity<MonthOverEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<MonthOverEntity> baseEntity) {
                refreshLayout.finishRefresh();
                MonthOverEntity monthOverEntity = baseEntity.getData();
                homeTvMoney.setText(com.ty.bwagent.utils.Utils.parseMoney(monthOverEntity.getCommission()));//本月佣金
                homeTvWin.setMontyText(monthOverEntity.getTotalProfit());//总输赢
                homeTvAgent.setText(MathUtil.parsePersonNumber(monthOverEntity.getTotalNewMembers()) +"人");//新增下级
            }

            @Override
            protected void onError(int code, String errMsg) {
                refreshLayout.finishRefresh(false);
                homeTvMoney.setText("--");//本月佣金
                homeTvWin.setText("--");//总输赢
                homeTvAgent.setText("--");//新增下级
            }
        });

        //轮播图
        mHomeViewModel.bannerLiveData.observe(this,new SimpleObserver<BaseEntity<List<BannerListBean>>>(){
            @Override
            protected void onSuccess(BaseEntity<List<BannerListBean>> baseEntity) {
                List<BannerListBean> listBeans = baseEntity.getData();
                if(listBeans != null && listBeans.size() > 0){
                    initBanner(listBeans);
                }else {
                    initDefaultBanner();
                }
            }
        });

        //关于数据
        mHomeViewModel.contactUsLiveData.observe(this,new SimpleObserver<BaseEntity<ContactUsEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<ContactUsEntity> entity) {
                ContactUsEntity contactUsEntity = entity.getData();
                String serviceText = contactUsEntity.getCustomerService();
                MMKVUtil.put(CacheKey.CUSTOMER_SERVICE,serviceText);
                MMKVUtil.put(CacheKey.H5_DOMAIN,contactUsEntity.getH5DomainUrl());
                XLiveDataManager.getInstance().contactUsLiveData.postNext(contactUsEntity);
            }
        });

        //佣金余额
        moneyViewModel.commissLiveData.observe(this,new SimpleObserver<BaseEntity<Commission>>(){
            @Override
            protected void onSuccess(BaseEntity<Commission> baseEntity) {
                commission = baseEntity.getData();
            }
        });

    }


    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        llContent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                llContent.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                int height = llContent.getHeight();
                int top = headRootView.getHeight();
                App.height = height;
                ((HomeAdapter)listAdapter).setItemHeight((height - top) /3);
            }
        });
        mHomeViewModel.contactUs();
        moneyViewModel.initMoney();
    }


    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        //每次到首页都要刷新（需求如此）
        mHomeViewModel.queryBannerList();//轮播图
        mHomeViewModel.queryMonthOverview();//本月概览
        mHomeViewModel.queryNotice();//获取通知公告
    }


    @Override
    public void onResume() {
        super.onResume();
        banner.startAutoPlay();
    }


    @Override
    public View getHeaderView() {
        View headView = View.inflate(mContext, R.layout.header_item_home, null);
        cardLayout = headView.findViewById(R.id.cardLayout);
        headRootView = headView.findViewById(R.id.headRootView);
        banner = headView.findViewById(R.id.banner);
        xMarqueView = headView.findViewById(R.id.xMarqueView);
        homeTvMoney = headView.findViewById(R.id.home_tv_money);
        homeTvWin = headView.findViewById(R.id.home_tv_win);
        homeTvAgent = headView.findViewById(R.id.home_tv_agent);
        headView.findViewById(R.id.home_monty_key1).setOnClickListener(this);
        headView.findViewById(R.id.home_monty_key2).setOnClickListener(this);
        headView.findViewById(R.id.home_monty_key3).setOnClickListener(this);
        homeTvMoney.setOnClickListener(this);
        homeTvWin.setOnClickListener(this);
        homeTvAgent.setOnClickListener(this);
//        View view, int bgColor, int shapeRadius, int shadowColor, int shadowRadius, int offsetX, int offsetY
        ShadowDrawable.setShadowDrawable(cardLayout, Color.WHITE, Utils.dp2px(getActivity(), 8),
                Color.parseColor("#0d000000"), Utils.dp2px(getActivity(), 4), 3, 6);

        return headView;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.home_monty_key1:
            case R.id.home_tv_money:
            case R.id.home_monty_key2:
            case R.id.home_tv_win:
                ((MainFragment)getParentFragment()).selectFragment(3);
                break;
            case R.id.home_monty_key3:
            case R.id.home_tv_agent:
                ((MainFragment)getParentFragment()).selectFragment(1);
                break;
        }
    }


    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new GridLayoutManager(mContext, 2);
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public BaseQuickAdapter<QuickEntity, BaseViewHolder> getListAdapter() {
        return new HomeAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
          switch (position){
              case 0://成员管理
                  ((MainFragment)getParentFragment()).selectFragment(1);
                  break;
              case 1://推广管理
                  ((MainFragment)getParentFragment()).selectFragment(2);
                  break;
              case 2://佣金报表
                  ((MainFragment)getParentFragment()).selectFragment(3);
                  break;
              case 3://提款

                  UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                  String phone = userInfo.getPhone();
                  if(StringUtils.isEmpty(phone)){
                      ToastUtils.showLong("请绑定手机号后操作");
                      return;
                  }

                  if(commission == null){
                      return;
                  }
                  double hasMoney = MathUtil.subtract(commission.getAgentMoney(),commission.getAgentFreezedMoney());
                  if(hasMoney < 100d){
                      ToastUtils.showLong(ResUtils.getString(R.string.generic_money_small));
                  }else {
                      goFragment(DrawingTabFragment.getInstance());
                  }
                  break;
              case 4://代理代存
              case 5://vip专享
                  ToastUtils.showLong(ResUtils.getString(R.string.generic_open));
                  break;
              default:
                  break;
          }

    }

    @Override
    public int getMode() {
        return Mode.PULL_FROM_START;
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        mHomeViewModel.queryNotice();//获取通知公告
        mHomeViewModel.queryMonthOverview();//本月概览
        mHomeViewModel.queryBannerList();//轮播图
        XLiveDataManager.getInstance().checkUpdate();//检查更新
    }

    //初始化跑马灯
    private void initMarqueView(List<SpecialNoticeEntity> list) {
        xMarqueView.setList(list);
        xMarqueView.autoScroll(this);
        xMarqueView.getMarqueAdapter().setOnItemClickListener((adapter, view, position) -> {
            SpecialNoticeEntity listBean = (SpecialNoticeEntity) adapter.getItem(position);
            if(!StringUtils.equals(ResUtils.getString(R.string.generic_empey_notice),listBean.getContent())){
                showNoticeDialog(listBean);
            }
        });
    }

    //初始化轮播图
    private void initBanner(List<BannerListBean> bannerListBeans) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int) (ScreenUtils.getScreenWidth() / 2.35f));
        banner.setLayoutParams(layoutParams);
        banner.loadImage((banner, model, view, position) -> {
            BannerListBean listBean = ((BannerListBean) model);
            ImageView imageView = view.findViewById(R.id.bannerImageView);

            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            if(listBean.getId() == -1){
                Glide.with(mContext).load(R.mipmap.home_invali_bg).into(imageView);
            }else {
                RequestOptions requestOptions = new RequestOptions().override(ScreenUtils.getScreenWidth() * 2,layoutParams.height * 2);
                Glide.with(mContext).load(listBean.getCarouselUrl())
                        .apply(requestOptions).into(imageView);
            }
        });

        banner.setOnItemClickListener((banner, homeBanner, view, position) -> {
            if (DoubleClickUtils.isLongDoubleClick()) {
                return;
            }
            BannerListBean model = (BannerListBean) homeBanner;
            if(model.getId() == -1){//默认轮播图不可点击
                 return;
            }
            bannerJump(model);

        });

        banner.setAutoPlayAble(bannerListBeans.size() > 1);
        banner.setBannerData(R.layout.header_home_banner, bannerListBeans);
    }

    /**
     * 初始化轮播图默认数据
     */
    private void initDefaultBanner(){
        List<BannerListBean> listBeans = new ArrayList<>();
        BannerListBean bannerListBean = new BannerListBean();
        bannerListBean.setId(-1);
        listBeans.add(bannerListBean);
        initBanner(listBeans);
    }


    //普通公告(点击后进入详情)
    private void showNoticeDialog(SpecialNoticeEntity listBean){
        ConfirmPopupView confirmPopupView = new NoticeSimplePopup(mContext);
        confirmPopupView.setTitleContent(listBean.getTitle(),listBean.getContent(),"")
                .setConfirmText(ResUtils.getString(R.string.generic_see_all))
                .setListener(() -> goFragment(MessageTabFragment.getInstance(2)),null)
                .hideCancelBtn()
                .setConfirmTextColor(SiteSdk.ins().styleColor());
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
    }

    //特殊公告（多个下一条）
    private void showSpecialNoticeDialog(List<SpecialNoticeEntity> entityList){
        NoticePopup customPopup = new NoticePopup(mContext,entityList);
        new XPopup.Builder(mContext)
                .dismissOnBackPressed(false)
                .dismissOnTouchOutside(false)
                .asCustom(customPopup)
                .show();
    }

    private void goFragment(ISupportFragment supportFragment){
        ((ABBaseFragment)getParentFragment()).start(supportFragment);
    }

    /**
     * 处理banner跳转逻辑
     * @param model
     */
    private void bannerJump(BannerListBean model){
        String link_url = model.getCarouselInfoUrl();
//        KLinkSchema kLinkSchema = KLinkSchema.getFromLink(link_url).setJumpType(model.getUrlType()).setUrlType(model.getCarouselType());
//        String h5Domain = MMKVUtil.getString(CacheKey.H5_DOMAIN);//TYSdk.app().preInfo.getH5Url(H5Type.H5_DOMAIN)
//        String url = "";
        if(StringUtils.isEmpty(link_url)){
            return;
        }
        Bundle bundle = new Bundle();
        String title = model.getCarouselTitle();
        bundle.putString(ABConfig.KEY_TITLE, title);
        bundle.putString(ABConfig.KEY_TEXT, link_url);
        goActivity(H5Activity.class,bundle);

//        switch (kLinkSchema) {
//            case Http:
//            case Https:
//                if (kLinkSchema.isInnerJump()) {//内部跳转
//                    if (!TextUtils.isEmpty(link_url)) {
////                        if (!link_url.startsWith("http")) {
////                            String h5_domain = TYSdk.app().getPreInfo().getH5Url(H5Type.H5_DOMAIN);
////                            link_url = h5_domain + link_url;
////                        }
//                        bundle.putString(ABConfig.KEY_TEXT, link_url);
//                        goActivity(H5Activity.class,bundle);
//                    } else {
//                        LogUtils.e("跳转webView的错误地址为： %s", link_url);
//                    }
//                } else {//跳转浏览器  url不需要处理
//                    if (!TextUtils.isEmpty(link_url)) {
//                        Intent intent = new Intent();
//                        intent.setAction("android.intent.action.VIEW");
//                        Uri content_url = Uri.parse(link_url);
//                        intent.setData(content_url);
//                        ComponentName componentName = intent.resolveActivity(mContext.getPackageManager());
//                        if (componentName != null) {
//                            getActivity().startActivity(intent);
//                        } else {
//                            LogUtils.e("没有可以跳转的外部浏览器 地址为：%s", link_url);
//                        }
//                    } else {
//                        LogUtils.e("跳转外部浏览器的错误地址为： %s", link_url);
//                    }
//                }
//                break;
//            case None:
//                url = h5Domain + "/app/promo/list/" + model.getActivityName();
//                bundle.putString(ABConfig.KEY_TEXT, url);
//                goActivity(H5Activity.class,bundle);
//                break;
//            case Normal:
//                url = h5Domain + link_url;
//                bundle.putString(ABConfig.KEY_TEXT, url);
//                goActivity(H5Activity.class,bundle);
//                break;
//        }
    }


    @Override
    public void onStop() {
        super.onStop();
        banner.stopAutoPlay();
    }

}
