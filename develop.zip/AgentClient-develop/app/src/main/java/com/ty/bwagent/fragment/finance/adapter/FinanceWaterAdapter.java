package com.ty.bwagent.fragment.finance.adapter;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.ValueBean;
import com.ty.utils.LogUtils;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * 描述 返水适配器
 * <p>
 * author:Dale
 */
public class FinanceWaterAdapter extends BaseQuickAdapter<List<String>, BaseViewHolder> {

    public FinanceWaterAdapter() {
        super(R.layout.recycle_item_finance_water);
    }

    public void setDatas(Map<String, List<ValueBean>> listMap) {
        List<List<String>> lists = new ArrayList<>();
        List<List<ValueBean>> valueBeans = new ArrayList<>();
        int listSize = 0;
        for (List<ValueBean> value : listMap.values()) {
            valueBeans.add(value);
            if (listSize == 0) {
                listSize = value.size();
            }
        }

        int mapSize = listMap.size();

        for (int k = 0; k < listSize; k++) {
            int count = 0;
            ArrayList<String> rateList = new ArrayList<>();
            for (int j = 0; j < mapSize; j++) {
                if (count == 0) {
                    rateList.add(valueBeans.get(j).get(k).getLevelName());
                }
                rateList.add(valueBeans.get(j).get(k).getMaxRate());
                LogUtils.d("name:" + valueBeans.get(j).get(k).getVenueName() + "  vip:" + valueBeans.get(j).get(k).getLevelName());
                count++;
            }

            lists.add(rateList);
        }
        setNewData(lists);
    }


    @Override
    protected void convert(BaseViewHolder helper, List<String> listMap) {
        LinearLayout water_rootView = helper.getView(R.id.water_rootView);
        water_rootView.removeAllViews();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(SizeUtils.dp2px(70), SizeUtils.dp2px(50));
        lp.gravity = Gravity.CENTER;
        for (int i = 0; i < listMap.size(); i++) {
            TextView textView = new TextView(mContext);
            textView.setTextColor(ResUtils.getColor(R.color.generic_heise));
            textView.setTextSize(12);
            textView.setGravity(Gravity.CENTER);
            if (i == 0) {
                textView.setText(listMap.get(i));
            } else {
                textView.setText(MathUtil.twoNumber(listMap.get(i)) + "%");
            }
            water_rootView.addView(textView, lp);
        }
    }

}
