package com.ty.bwagent.fragment.finance.fragment;

import android.text.InputFilter;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.lxj.xpopup.XPopup;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.DrawingEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.dialog.DrawingCenterPopup;
import com.ty.bwagent.dialog.DrawingPopup;
import com.ty.bwagent.fragment.finance.viewmodel.DrawWalletViewModel;
import com.ty.bwagent.utils.MoneyValueFilter;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.view.XCodeView;
import com.ty.bwagent.viewmodel.MoneyViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.ValueView;

import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.MMKVUtil;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;


/**
 * 提款到钱包
 */
public class DrawWalletFragment extends ABBaseFragment {

    DrawWalletViewModel mDrawWalletViewModel;
    MoneyViewModel moneyViewModel;
    @BindView(R.id.drawing_tv_warning)
    TextView drawingTvWarning;
    @BindView(R.id.valueview_draw_monty)
    ValueView valueviewDrawMonty;
    @BindView(R.id.valueview_frozen_monty)
    ValueView valueviewFrozenMonty;
    @BindView(R.id.xCodeview_draw)
    ClearEditText xCodeviewDraw;
    @BindView(R.id.valueview_phone)
    ValueView valueviewPhone;
    @BindView(R.id.xCodeview_code)
    XCodeView xCodeviewCode;
    @BindView(R.id.drawing_commit)
    TextView drawingCommit;
    String money;//提款金额
    String realPhone;
    double agentMoney;//代理可取款的金额（余额）

    public static DrawWalletFragment getInstance() {
        return new DrawWalletFragment();
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_draw_wallet;
    }

    @Override
    protected void createProvider() {
        mDrawWalletViewModel = new ViewModelProvider(this).get(DrawWalletViewModel.class);
        moneyViewModel = new ViewModelProvider(getActivity()).get(MoneyViewModel.class);


        //监听获取未脱敏的电话号码
        moneyViewModel.drawPhoneLiveData.observe(this,new NetObserver<BaseEntity<String>>(){
            @Override
            protected void onSuccess(BaseEntity<String> entity) {
                realPhone= entity.getData();
                valueviewPhone.setTextValue(Utils.getHidePhone(realPhone));//电话号码
            }
            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //佣金余额
        moneyViewModel.commissLiveData.observe(this,new SimpleObserver<BaseEntity<Commission>>(){
            @Override
            protected void onSuccess(BaseEntity<Commission> baseEntity) {
                Commission commission = baseEntity.getData();
                agentMoney = MathUtil.subtract(commission.getAgentMoney(),commission.getAgentFreezedMoney());
                valueviewDrawMonty.setTextValue(Utils.roundDownMoney(agentMoney));//可提取余额
                valueviewFrozenMonty.setTextValue(Utils.roundDownMoney(commission.getAgentFreezedMoney()));//冻结余额
            }
        });

        //监听验证码
        mDrawWalletViewModel.codeLivedata.observe(this,new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if(baseEntity ==null){
                    return;
                }
                //保存获取成功验证码时间，60秒能不能重复获取
                MMKVUtil.put(Key.VERIFYTIME,System.currentTimeMillis());
                drawingTvWarning.setText("");
                mDrawWalletViewModel.startTimer(getLifecycle());
            }
            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }
            @Override
            protected void onError(int code, String errMsg) {
                drawingTvWarning.setText(errMsg);
            }
        });

        //验证码倒计时
        mDrawWalletViewModel.timerLiveData.observe(this, aLong -> {
            if(aLong == 0){
                xCodeviewCode.getCommitBtn().setText(ResUtils.getString(R.string.generic_reset_code));
                xCodeviewCode.getCommitBtn().setEnabled(true);
            }else {
                xCodeviewCode.getCommitBtn().setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time),aLong));
                xCodeviewCode.getCommitBtn().setEnabled(false);
            }
        });

        //提款至中心钱包
        mDrawWalletViewModel.withdrawNetLiveData.observe(this,new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ToastUtils.showLong("操作成功");
                ((ABBaseFragment)getParentFragment()).pop();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                drawingTvWarning.setText(errMsg);
            }
        });

    }

    @Override
    protected void initViewsAndEvents() {
        VerifyUtils.verifyCode(xCodeviewCode.getEditText(),drawingTvWarning);
        new InputResultCalculator(Arrays.asList(xCodeviewDraw,xCodeviewCode.getEditText()), ok -> drawingCommit.setEnabled(ok));

        xCodeviewCode.getCommitBtn().setEnabled(true);//获取验证码按钮
        xCodeviewCode.getCommitBtn().setOnClickListener(v -> {//获取验证码按钮
            if(Utils.isClicked60S()){
                mDrawWalletViewModel.getPhoneCode(realPhone);
            }
        });


        //处理获取验证码后，就退出界面，然后在进入界面没有倒计时问题
//        long lastTime = MMKVUtil.getLong(Key.VERIFYTIME,0);
//        long intervalTime = System.currentTimeMillis() - lastTime;
//        if(intervalTime > 60 * 1000){
////            verifyModel.sendCode(phone,true,4);
//        }else {
//            mDrawWalletViewModel.startTimer(getLifecycle(), 60 * 1000 - intervalTime);
//            xCodeviewCode.getCommitBtn().setEnabled(false);//获取验证码按钮
//        }

        //默认两位小数
        xCodeviewDraw.setFilters(new InputFilter[]{new MoneyValueFilter()});

    }

    @OnClick(R.id.drawing_commit)
    public void onViewClicked() {
        money = xCodeviewDraw.getText().toString();
        if(StringUtils.parseDouble(money) > agentMoney){
            ToastUtils.showLong("不能大于可取款余额");
            return;
        }
        DrawingEntity drawingEntity = new DrawingEntity(money,"","");
        showCommitDialog(drawingEntity);
    }


    /**
     * 提款金额确认弹窗
     * @param drawingEntity
     */
    private void showCommitDialog(DrawingEntity drawingEntity){
        DrawingCenterPopup drawingPopup = new DrawingCenterPopup(mContext,drawingEntity);
        drawingPopup.setListener(() -> {//提款确认按钮
            String code = xCodeviewCode.getInputString();
            mDrawWalletViewModel.withdrawToCentralWallet(money,code);
        },null)
                .setCancelTextColor(R.color.generic_heise)
                .setConfirmTextColor(R.color.main_style_color)
                .setTitleContent("提示","请确认以下提款信息:",null);

        new XPopup.Builder(getContext())
                .dismissOnBackPressed(false)
                .dismissOnTouchOutside(false)
                .asCustom(drawingPopup)
                .show();
    }
}
