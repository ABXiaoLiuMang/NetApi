package com.ty.bwagent.bean;

import java.util.List;

public class ContactUsEntity {

    /**
     * agentAppDomainUrl : 554.qq.com
     * agentPcDomainUrl : http://test-agent5.bwhou2020.com
     * agentQq : 1112222
     * agentSkype : http://www.sugramapp.com/
     * agentSugram : http://www.sugramapp.com/
     * customerService : [{"code":"service_web1","name":"主线客服","url":"https://chat.5b3x6.com/chat/chatClient/chatbox.jsp?companyID=5889092&configID=3"},{"code":"service_web2","name":"次线客服","url":"https://chat.5b3x6.com/chat/chatClient/chatbox.jsp?companyID=5889092&configID=3"},{"code":"service_phone1","name":"电话客服","url":"https://chat.5b3x6.com/chat/chatClient/chatbox.jsp?companyID=5889092&configID=3"}]
     * h5DomainUrl : 52451.qq.com
     * mobileService : http://bw-app-download.ironhide2021.com/kok
     * name : 测试1
     * pcDomainUrl : www.mmmmmmddd.com
     * siteDomainUrl : http://test-download-kok.bwhou2020.com
     * siteLogoUrl :
     * sportAppDomainUrl : http://tydownload-kok.bwhou2020.com
     * submitMoreUnorde : 0
     * title : 123456
     * webAppUrl :
     * webLogoTitleUrl :
     * webLogoUrl :
     */

    private String agentAppDomainUrl;
    private String agentPcDomainUrl;
    private String agentQq;
    private String agentSkype;
    private String agentSugram;
    private String customerService;
    private String h5DomainUrl;
    private String mobileService;
    private String name;
    private String pcDomainUrl;
    private String siteDomainUrl;
    private String siteLogoUrl;
    private String sportAppDomainUrl;
    private int submitMoreUnorde;
    private String title;
    private String webAppUrl;
    private String webLogoTitleUrl;
    private String webLogoUrl;
    private String categories;
    private List<BaseInfo> baseInfo;


    public List<BaseInfo> getBaseInfo() {
        return baseInfo;
    }

    public void setBaseInfo(List<BaseInfo> baseInfo) {
        this.baseInfo = baseInfo;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public String getAgentAppDomainUrl() {
        return agentAppDomainUrl;
    }

    public void setAgentAppDomainUrl(String agentAppDomainUrl) {
        this.agentAppDomainUrl = agentAppDomainUrl;
    }

    public String getAgentPcDomainUrl() {
        return agentPcDomainUrl;
    }

    public void setAgentPcDomainUrl(String agentPcDomainUrl) {
        this.agentPcDomainUrl = agentPcDomainUrl;
    }

    public String getAgentQq() {
        return agentQq;
    }

    public void setAgentQq(String agentQq) {
        this.agentQq = agentQq;
    }

    public String getAgentSkype() {
        return agentSkype;
    }

    public void setAgentSkype(String agentSkype) {
        this.agentSkype = agentSkype;
    }

    public String getAgentSugram() {
        return agentSugram;
    }

    public void setAgentSugram(String agentSugram) {
        this.agentSugram = agentSugram;
    }

    public String getCustomerService() {
        return customerService;
    }

    public void setCustomerService(String customerService) {
        this.customerService = customerService;
    }

    public String getH5DomainUrl() {
        return h5DomainUrl;
    }

    public void setH5DomainUrl(String h5DomainUrl) {
        this.h5DomainUrl = h5DomainUrl;
    }

    public String getMobileService() {
        return mobileService;
    }

    public void setMobileService(String mobileService) {
        this.mobileService = mobileService;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPcDomainUrl() {
        return pcDomainUrl;
    }

    public void setPcDomainUrl(String pcDomainUrl) {
        this.pcDomainUrl = pcDomainUrl;
    }

    public String getSiteDomainUrl() {
        return siteDomainUrl;
    }

    public void setSiteDomainUrl(String siteDomainUrl) {
        this.siteDomainUrl = siteDomainUrl;
    }

    public String getSiteLogoUrl() {
        return siteLogoUrl;
    }

    public void setSiteLogoUrl(String siteLogoUrl) {
        this.siteLogoUrl = siteLogoUrl;
    }

    public String getSportAppDomainUrl() {
        return sportAppDomainUrl;
    }

    public void setSportAppDomainUrl(String sportAppDomainUrl) {
        this.sportAppDomainUrl = sportAppDomainUrl;
    }

    public int getSubmitMoreUnorde() {
        return submitMoreUnorde;
    }

    public void setSubmitMoreUnorde(int submitMoreUnorde) {
        this.submitMoreUnorde = submitMoreUnorde;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getWebAppUrl() {
        return webAppUrl;
    }

    public void setWebAppUrl(String webAppUrl) {
        this.webAppUrl = webAppUrl;
    }

    public String getWebLogoTitleUrl() {
        return webLogoTitleUrl;
    }

    public void setWebLogoTitleUrl(String webLogoTitleUrl) {
        this.webLogoTitleUrl = webLogoTitleUrl;
    }

    public String getWebLogoUrl() {
        return webLogoUrl;
    }

    public void setWebLogoUrl(String webLogoUrl) {
        this.webLogoUrl = webLogoUrl;
    }


    public static class BaseInfo {

        /**
         * baseFlag : 0
         * deviceNum :
         * deviceType : 代理Flygram
         * imageUrl : https://devbwoss.z3x9u9.com/website/siteManage/1587019777333995.png
         * linkUrl :
         * sort : 8
         * deviceText : 合营部Flygram
         * isEnable : 1
         */

        private String baseFlag;
        private String deviceNum;
        private String deviceType;
        private String imageUrl;
        private String linkUrl;
        private String sort;
        private String deviceText;
        private String isEnable;

        public String getBaseFlag() {
            return baseFlag;
        }

        public void setBaseFlag(String baseFlag) {
            this.baseFlag = baseFlag;
        }

        public String getDeviceNum() {
            return deviceNum;
        }

        public void setDeviceNum(String deviceNum) {
            this.deviceNum = deviceNum;
        }

        public String getDeviceType() {
            return deviceType;
        }

        public void setDeviceType(String deviceType) {
            this.deviceType = deviceType;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public String getLinkUrl() {
            return linkUrl;
        }

        public void setLinkUrl(String linkUrl) {
            this.linkUrl = linkUrl;
        }

        public String getSort() {
            return sort;
        }

        public void setSort(String sort) {
            this.sort = sort;
        }

        public String getDeviceText() {
            return deviceText;
        }

        public void setDeviceText(String deviceText) {
            this.deviceText = deviceText;
        }

        public String getIsEnable() {
            return isEnable;
        }

        public void setIsEnable(String isEnable) {
            this.isEnable = isEnable;
        }
    }
}
