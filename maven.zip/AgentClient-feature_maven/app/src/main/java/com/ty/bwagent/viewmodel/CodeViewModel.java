package com.ty.bwagent.viewmodel;

import android.graphics.Bitmap;

import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.R;
import com.ty.bwagent.api.Api;
import com.ty.bwagent.api.BaseUrlManager;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ValidateCodeEntity;
import com.ty.bwagent.utils.NetServiceTask;
import com.ty.bwagent.utils.URLPostHandler;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;

public class CodeViewModel extends TimerModelView {

    //找回密码和登录异常验证手机号获取验证码
    public NetLiveData<BaseEntity> sendCodeLiveData = new NetLiveData<>();

    // 验证码是否正在加载
    public NetLiveData<Boolean> loadingVerifyCode = new NetLiveData<>();

    /**
     * 图形验证码
     */
    public NetLiveData<ValidateCodeEntity> verifyLivedata = new NetLiveData<>();

    /**
     * 验证码(数字验证码)
     */
    public NetLiveData<BaseEntity> codeLivedata = new NetLiveData<>();

    /**
     * 初始状态
     */
    private static final int NO = 0;

    /**
     * 加载验证码id
     */
    public int loadVerifyId = NO;

    /**
     * 手动刷新加载验证码
     */
    public static final int DRIVING_LOAD_VERIFY = 6;
    /**
     * 自动加载验证码
     */
    private static final int PASSIVE_LOAD_VERIFY = 7;

    /**
     * 是否已经加载过
     */
    private boolean loadedLoginVerify = false;

    public boolean neeVerify;

    protected String xCodeId;//验证码id

    /**
     * 获取验证码
     */
    public void getPhoneCode(String phone) {
        if(!ParameterVerification.isPhoneNumber(phone)){
            codeLivedata.postError(0, ResUtils.getString(R.string.phone_input_err));
            return;
        }

        NetSdk.create(Api.class)
                .getCode()
                .params("phone",phone)
                .asJSONType()
                .send(codeLivedata);
    }
    /**
     * 获取验证码
     */
    public void getEmailCode(String email) {
        if(!ParameterVerification.isEmail(email)){
            codeLivedata.postError(0,"请输入正确的邮箱");
            return;
        }

        NetSdk.create(Api.class)
                .getEmailCode()
                .params("email",email)
                .asJSONType()
                .send(codeLivedata);
    }


    /**
     * 忘记密码（获取验证码）
     * @param sendCodeNum 号码
     */
    public void sendCode(String sendCodeNum, boolean isPhone) {
        if(isPhone){
           if(!ParameterVerification.isPhoneNumber(sendCodeNum)){
               sendCodeLiveData.postError(0,ResUtils.getString(R.string.generic_phone_warn));
               return;
           }
        }else {
            if(!ParameterVerification.isEmail(sendCodeNum)){
                sendCodeLiveData.postError(0,ResUtils.getString(R.string.generic_email_warn));
                return;
            }
        }
       sendCode(sendCodeNum,isPhone,0);
    }

    /**
     * （获取验证码）
     * @param sendCodeNum 号码
     */
    public void sendCode(String sendCodeNum, boolean isPhone,int type) {
        NetSdk.create(Api.class)
                .forgetSendCode()
                .params("sendCodeNum", sendCodeNum)
                .params("type", type)//0忘记密码，1密码修改放松，3绑定银行卡手机发送,4非常用设备手机短信验证
                .params("cate", isPhone ? 0 : 1)//0手机，1邮箱
                .asJSONType()
                .send(sendCodeLiveData);

    }



    /**
     * 手动刷新加载验证码
     */
    public void drivingLoadVerify() {
        loadVerifyId = DRIVING_LOAD_VERIFY;
        loadVerify();
    }

    /**
     * 自动加载验证码
     */
    public void autoLoadVerify() {
        neeVerify = true;
        loadVerifyId = PASSIVE_LOAD_VERIFY;
        loadedLoginVerify = false;
        loadVerify();
    }

    /**
     * 加载验证码
     */
    private void loadVerify() {
        if (loadVerifyId == NO) {
            return;
        }
        //是否需要加载
        boolean isNeedLoad = false;
        switch (loadVerifyId) {
            //手动
            case DRIVING_LOAD_VERIFY:
                isNeedLoad = true;
                break;
            //自动
            case PASSIVE_LOAD_VERIFY:
                isNeedLoad = !loadedLoginVerify;
                break;
            default:
                break;
        }

        if (isNeedLoad) {
            loadingVerifyCode.setNext(true);
            String baseUrl = BaseUrlManager.ins().currentDomain().getHost();
            download(baseUrl + Api.VERIFICATION_CODE);
        }
    }

    public void download(final String url) {
        NetServiceTask netServiceTask = new NetServiceTask(url, new URLPostHandler() {
            @Override
            public void PostHandler(Bitmap bitmap) {
                if (bitmap != null) {
                    loadVerifyId = NO;
                    ValidateCodeEntity validateCodeEntity = new ValidateCodeEntity();
                    validateCodeEntity.setBitmap(bitmap);
                    verifyLivedata.setNext(validateCodeEntity);
//                    xCodeId = validateCodeEntity.getCode_id();
                    loadingVerifyCode.setNext(false);
                    loadedLoginVerify = true;
                } else {
                    loadVerifyId = NO;
                    verifyLivedata.setNext(null);
                    loadingVerifyCode.setNext(false);
                }
            }
        });

        Thread thread = new Thread(netServiceTask);
        thread.start();

    }



//    private String getBaseUrl() {
//        String siteId = BuildConfig.appType;
//        MMKVUtil.put(Key.SITEIDKEY,siteId);
//        String baseUrl = null;
//        switch (Integer.valueOf(siteId)) {
//            case 4://火狐
//                switch (BuildConfig.appEnv){
//                    case "debug":
//                        baseUrl = "http://huohu-agent.bwhou2028.com/";
//                        break;
//                    case "pre_release":
//                        baseUrl = "http://huohu-agent.bwhou2028.com/";
//                        break;
//                    case "release":
//                        baseUrl = "http://huohu-agent.bwhou2028.com/";
//                        break;
//                    case "https_release":
//                        baseUrl = "http://huohu-agent.bwhou2028.com/";
//                        break;
//                }
//                break;
//            case 6://亿博
//                switch (BuildConfig.appEnv){
//                    case "debug":
//                        baseUrl = "http://yibo-agent.bwhou2028.com/";
//                        break;
//                    case "pre_release":
//                        baseUrl = "http://yibo-agent.bwhou2028.com/";
//                        break;
//                    case "release":
//                        baseUrl = "http://yibo-agent.bwhou2028.com/";
//                        break;
//                    case "https_release":
//                        baseUrl = "http://yibo-agent.bwhou2028.com/";
//                        break;
//                }
//                break;
//            case 7://AOA
//                switch (BuildConfig.appEnv){
//                    case "debug":
//                        baseUrl = "http://aoa-agent.bwhou2028.com/";
//                        break;
//                    case "pre_release":
//                        baseUrl = "http://aoa-agent.bwhou2028.com/";
//                        break;
//                    case "release":
//                        baseUrl = "http://aoa-agent.bwhou2028.com/";
//                        break;
//                    case "https_release":
//                        baseUrl = "http://aoa-agent.bwhou2028.com/";
//                        break;
//                }
//                break;
//            case 8://环球
//                switch (BuildConfig.appEnv){
//                    case "debug":
//                        baseUrl = "http://huanqiu-agent.bwhou2028.com/";
//                        break;
//                    case "pre_release":
//                        baseUrl = "http://huanqiu-agent.bwhou2028.com/";
//                        break;
//                    case "release":
//                        baseUrl = "http://huanqiu-agent.bwhou2028.com/";
//                        break;
//                    case "https_release":
//                        baseUrl = "http://huanqiu-agent.bwhou2028.com/";
//                        break;
//                }
//                break;
//            case 5://KOK
//            default:
//                switch (BuildConfig.appEnv){
//                    case "debug":
//                        baseUrl = "http://kok-agent.bwhou2028.com/";
//                        break;
//                    case "pre_release":
//                        baseUrl = "http://kok-agent.bwhou2028.com";
//                        break;
//                    case "release":
//                        baseUrl = "http://kok-agent.bwhou2028.com/";
//                        break;
//                    case "https_release":
//                        baseUrl = "http://kok-agent.bwhou2028.com/";
//                        break;
//                }
//                break;
//        }
//        LogUtils.d("打包环境:" + BuildConfig.appEnv + " baseUrl:" + baseUrl);
//        return baseUrl;
//    }
}
