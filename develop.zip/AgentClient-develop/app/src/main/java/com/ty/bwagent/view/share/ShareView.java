package com.ty.bwagent.view.share;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.Group;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.WeakHandler;
import com.ty.view.SegmentView;
import com.zxing.qrcode.view.QRCodeEncoder;


/**
 * @Description:
 */
public class ShareView extends HorizontalScrollView implements SeekBar.OnSeekBarChangeListener, SegmentView.OnSelectedListener, DragShareView.ViewReleasedListener {

    public interface IGravity {
        int TopLeft = 0;
        int TopRight = 1;
        int Center = 2;
        int BottomLeft = 3;
        int BottomRight = 4;
    }

    public interface Segment {
        String codeSize = ResUtils.getString(R.string.share_image_size);
        String codeGravity = ResUtils.getString(R.string.share_image_gravity);
        String codeColor = ResUtils.getString(R.string.share_image_color);

        String urlSize = ResUtils.getString(R.string.share_url_size);
        String urlGravity = ResUtils.getString(R.string.share_url_gravity);
        String urlColor = ResUtils.getString(R.string.share_url_color);

        String tipsSize = ResUtils.getString(R.string.share_tips_size);
        String tipsGravity = ResUtils.getString(R.string.share_tips_gravity);
        String tipsColor = ResUtils.getString(R.string.share_tips_color);
        int code = 0;
        int url = 1;
        int tips = 2;
    }

    /**
     * 刷新控制器标题回调
     */
    public interface RefreshTabTitle {
        /**
         * @param type           类型（二维码，推广链接 提示方法）
         * @param typeGravity    位置（左上角右上角等）
         * @param typeColor      类型的颜色
         * @param gravityPostion 类型的位置角标
         * @param colorPostion   类型的颜色角标
         * @param editTitle      推广链接或提示文字
         */
        void onRefreshTitle(String type, String typeGravity, String typeColor, int gravityPostion, int colorPostion, String editTitle);

        /**
         * 切换视图滚动到顶部
         */
        void onScrollToRefresh();
    }

    ImageView codeImageView;
    ImageView contentView;
    TextView urlTextView;
    TextView tipTextView;
    DragShareView dragShareView;
    Context mContext;
    int imageGravity = 0;//二维码图片默认位置
    int urlGravity = 0;//链接默认位置
    int tipsGravity = 0;//文案默认位置

    int imageColorPostion = 7;//二维码图片原色选择角标位置
    int urlColorPostion = 7;//链接默认原色选择角标位置
    int tipsColorPostion = 7;//文案默认原色选择角标位置

    int imageMinSize = 100;//二维码图片最小尺寸
    int imageMaxSize = 300;//二维码图片最大尺寸
    int imageSize;//二维码默认尺寸
    int lastSize;//二维码默认尺寸
    int urlSize;//链接默认字体大小
    int tipsSize;//tips默认字体大小
    int percentImage = 25;//二维码图片默认尺寸百分比
    int urlMinSize = 12;//链接最小字体
    int urlMaxSize = 32;//链接最大字体
    int percentUrl = 20;//链接默认字体百分比
    int tipsMinSize = 12;//tips最小字体
    int tipsMaxSize = 32;//tips最大字体
    int percentTips = 20;//tips默认字体百分比

    int codeColor = ResUtils.getColor(R.color.black);//二维码默认颜色
    String imageTextColor = "黑色";
    String urlTextColor = "黑色";
    String tipsTextColor = "黑色";
    String url;
    String tips;
    int mSegment = Segment.code;//默认编辑类型
    RefreshTabTitle refreshTabTitle;
    SeekBar seekBar;
    TextView textInputView;//输入内容
    GravityAdapter gravityAdapter;
    Group group;
    Bitmap bitmap;


    public ShareView(Context context) {
        this(context, null);
    }

    public ShareView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ShareView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.share_view, this, true);
        dragShareView = rootView.findViewById(R.id.dragShareView);
        contentView = rootView.findViewById(R.id.contentView);
        codeImageView = rootView.findViewById(R.id.codeImageView);
        urlTextView = rootView.findViewById(R.id.urlTextView);
        tipTextView = rootView.findViewById(R.id.tipTextView);
        lastSize = imageSize = imageMinSize + (imageMaxSize - imageMinSize) * percentImage / 100;
        urlSize = urlMinSize + (urlMaxSize - urlMinSize) * percentUrl / 100;
        tipsSize = tipsMinSize + (tipsMaxSize - tipsMinSize) * percentTips / 100;
        urlTextView.setTextSize(urlSize);
        tipTextView.setTextSize(tipsSize);
        FrameLayout.LayoutParams layoutParams = (LayoutParams) codeImageView.getLayoutParams();
        layoutParams.width = imageSize;
        layoutParams.height = imageSize;
        codeImageView.setLayoutParams(layoutParams);
        dragShareView.setViewReleasedListener(this);
    }


    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        switch (mSegment) {
            case Segment.code:
                percentImage = progress;
                imageSize = imageMinSize + (imageMaxSize - imageMinSize) * percentImage / 100;
                refreshLastCodeBg();
                lastSize = imageSize;
                break;
            case Segment.url:
                percentUrl = progress;
                urlSize = urlMinSize + (urlMaxSize - urlMinSize) * percentUrl / 100;
                urlTextView.setTextSize(urlSize);
                break;
            case Segment.tips:
                percentTips = progress;
                tipsSize = tipsMinSize + (tipsMaxSize - tipsMinSize) * percentTips / 100;
                tipTextView.setTextSize(tipsSize);
                break;
        }
        onRefreshTitle();
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    @Override
    public void onSelected(int index) {
        switch (index) {
            case 0:
                this.mSegment = Segment.code;
                if (seekBar != null) {
                    seekBar.setProgress(percentImage);
                }

                if (group != null) {
                    group.setVisibility(View.GONE);
                }
                break;
            case 1:
                this.mSegment = Segment.url;
                if (seekBar != null) {
                    seekBar.setProgress(percentUrl);
                }
                if (group != null) {
                    group.setVisibility(View.VISIBLE);
                }

                textInputView.setHint(ResUtils.getString(R.string.generic_share_hint_url));
                if (TextUtils.isEmpty(url)) {
                    textInputView.setText("");
                } else {
                    textInputView.setText(url);
                }
                break;
            case 2:
                this.mSegment = Segment.tips;
                if (seekBar != null) {
                    seekBar.setProgress(percentTips);
                }

                if (group != null) {
                    group.setVisibility(View.VISIBLE);
                }

                textInputView.setHint(ResUtils.getString(R.string.generic_share_hint_tips));
                if (TextUtils.isEmpty(tips)) {
                    textInputView.setText("");
                } else {
                    textInputView.setText(tips);
                }
                break;
        }
        onRefreshTitle();

        if (refreshTabTitle != null) {
            refreshTabTitle.onScrollToRefresh();
        }
    }

    /**
     * 返回编辑输入框的默认内容
     *
     * @return
     */
    public String[] getInputInitText() {
        String[] hintText = new String[2];
        if (mSegment == Segment.url) {
            hintText[0] = ResUtils.getString(R.string.generic_share_hint_url);
            hintText[1] = url;
        } else if (mSegment == Segment.tips) {
            hintText[0] = ResUtils.getString(R.string.generic_share_hint_tips);
            hintText[1] = tips;
        }
        return hintText;
    }

    private void onRefreshTitle() {
        if (refreshTabTitle != null) {
            switch (mSegment) {
                case Segment.code:
                    refreshTabTitle.onRefreshTitle(StringUtils.getFormatString(Segment.codeSize, imageSize),
                            StringUtils.getFormatString(Segment.codeGravity, getGravity(imageGravity)),
                            StringUtils.getFormatString(Segment.codeColor, imageTextColor), imageGravity, imageColorPostion, "");
                    break;
                case Segment.url:
                    refreshTabTitle.onRefreshTitle(StringUtils.getFormatString(Segment.urlSize, urlSize),
                            StringUtils.getFormatString(Segment.urlGravity, getGravity(urlGravity)),
                            StringUtils.getFormatString(Segment.urlColor, urlTextColor), urlGravity, urlColorPostion, "推广链接：");
                    break;
                case Segment.tips:
                    refreshTabTitle.onRefreshTitle(StringUtils.getFormatString(Segment.tipsSize, tipsSize),
                            StringUtils.getFormatString(Segment.tipsGravity, getGravity(tipsGravity)),
                            StringUtils.getFormatString(Segment.tipsColor, tipsTextColor), tipsGravity, tipsColorPostion, "提示文案：");
                    break;
            }
        }
    }


    public void setSeekBar(SeekBar seekBar) {
        this.seekBar = seekBar;
    }

    public void setGravityAdapter(GravityAdapter gravityAdapter) {
        this.gravityAdapter = gravityAdapter;
    }

    /**
     * 拖拽释放的view
     *
     * @param view
     */
    @Override
    public void onReleased(View view) {
        if (view == codeImageView) {
            imageGravity = -1;
            gravityAdapter.setPostion(-1);
        } else if (view == urlTextView) {
            urlGravity = -1;
            gravityAdapter.setPostion(-1);
        } else if (view == tipTextView) {
            tipsGravity = -1;
            gravityAdapter.setPostion(-1);
        }
        onRefreshTitle();
    }


    /**
     * 设置推广链接url
     *
     * @param url
     */
    public void setUrl(String url) {
        if (StringUtils.isEmpty(url)) {
            this.url = "";
        } else {
            this.url = url;
        }
        bitmap = QRCodeEncoder.syncEncodeQRCode(url, SizeUtils.dp2px(100), codeColor);
        urlTextView.setText(url);
        refreshCodeBg();
    }

    /**
     * 设置背景图片url
     */
    public void setImageUrl(String imageUrl) {
        Glide.with(getContext()).asBitmap().load(imageUrl).into(new SimpleTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                int h = SizeUtils.dp2px(365);
                int w = bitmap.getWidth() * h / bitmap.getHeight();
                LayoutParams layoutParams;
                if (w < ScreenUtils.getScreenWidth()) {
                    layoutParams = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h);
                    layoutParams.gravity = Gravity.CENTER_HORIZONTAL;
                } else {
                    layoutParams = new LayoutParams(w, h);
                }
                dragShareView.setLayoutParams(layoutParams);//拖拽区域
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) contentView.getLayoutParams();
                params.width = w;
                params.height = h;
                params.gravity = Gravity.CENTER_HORIZONTAL;
                contentView.setLayoutParams(params);
                contentView.setImageBitmap(bitmap);//背景图片颜色不变形

            }

            @Override
            public void onLoadFailed(@Nullable Drawable errorDrawable) {
                int h = SizeUtils.dp2px(365);
                int w = ScreenUtils.getScreenWidth();
                LayoutParams layoutParams = new LayoutParams(w, h);
                dragShareView.setLayoutParams(layoutParams);//拖拽区域
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) contentView.getLayoutParams();
                params.width = w;
                params.height = h;
                params.gravity = Gravity.CENTER_HORIZONTAL;
                contentView.setLayoutParams(params);
                contentView.setBackgroundColor(Color.parseColor("#E1E1E1"));//背景图片颜色不变形
            }
        });
    }

    /**
     * 修改编辑输入推广链接调用
     */
    private void setEditUrl() {
        bitmap = QRCodeEncoder.syncEncodeQRCode(url, SizeUtils.dp2px(100), codeColor);
        refreshCodeBg();
    }

    /**
     * 设置提示文案
     *
     * @param tips
     */
    public void setTips(String tips) {
        this.tips = tips;
        tipTextView.setText(tips);
    }

    /**
     * 更改颜色
     *
     * @param color
     */
    public void setColor(int color, int position, String textColor) {
        switch (mSegment) {
            case Segment.code://二维码颜色
                this.codeColor = getResources().getColor(color);
                this.imageTextColor = textColor;
                bitmap = QRCodeEncoder.syncEncodeQRCode(url, SizeUtils.dp2px(100), codeColor);
                imageColorPostion = position;
                refreshCodeBg();
                break;
            case Segment.url://链接颜色
                urlColorPostion = position;
                this.urlTextColor = textColor;
                urlTextView.setTextColor(getResources().getColor(color));
                break;
            case Segment.tips: //提示文字颜色
                tipsColorPostion = position;
                this.tipsTextColor = textColor;
                tipTextView.setTextColor(getResources().getColor(color));
                break;
        }
        onRefreshTitle();
    }

    /**
     * 更改位置
     *
     * @param mode
     */
    public void setGravity(int mode) {
        FrameLayout.LayoutParams layoutParams;
        switch (mSegment) {
            case Segment.code:
                this.imageGravity = mode;
                layoutParams = new FrameLayout.LayoutParams(codeImageView.getWidth(), codeImageView.getHeight());
                setLayoutParamsByView(layoutParams, codeImageView, imageGravity);
                onDragShareViewScrollTo(imageGravity);
                break;
            case Segment.url:
                this.urlGravity = mode;
                layoutParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                setLayoutParamsByView(layoutParams, urlTextView, urlGravity);
                onDragShareViewScrollTo(urlGravity);
                break;
            case Segment.tips:
                this.tipsGravity = mode;
                layoutParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                setLayoutParamsByView(layoutParams, tipTextView, tipsGravity);
                onDragShareViewScrollTo(tipsGravity);
                break;
        }
        onRefreshTitle();
    }

    private void onDragShareViewScrollTo(int gravity) {
        if (gravity == 0 || gravity == 3) {
            scrollTo(0, 0);
        } else if (gravity == 1 || gravity == 4) {
            scrollTo(getWidth(), 0);
        } else {
            scrollTo(getWidth() / 2, 0);
        }

    }

    public void setRefreshTabTitle(RefreshTabTitle refreshTabTitle) {
        this.refreshTabTitle = refreshTabTitle;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public void setTextInputView(TextView textInputView) {
        this.textInputView = textInputView;
        textInputView.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                switch (mSegment) {
                    case Segment.url:
                        url = s.toString();
                        urlTextView.setText(url);
                        mHandler.removeCallbacks(mRunnable);
                        mHandler.postDelayed(mRunnable, 800);
                        break;
                    case Segment.tips:
                        setTips(s.toString());
                        break;
                }
            }
        });
    }

    private void refreshCodeBg() {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) codeImageView.getLayoutParams();
        layoutParams.width = imageSize;
        layoutParams.height = imageSize;
        codeImageView.setLayoutParams(layoutParams);
        codeImageView.setImageBitmap(bitmap);
    }

    private void refreshLastCodeBg() {
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(imageSize, imageSize);
        FrameLayout.LayoutParams lastParams = (FrameLayout.LayoutParams) codeImageView.getLayoutParams();
        int w = getWidth() / 2;
        int h = getHeight() / 2;
        if (w != 0 && h != 0 && imageGravity == -1) {
            if (w - (imageSize / 2) < lastParams.leftMargin) {
                if (h - (imageSize / 2) < lastParams.topMargin) {//右下
                    layoutParams.leftMargin = lastParams.leftMargin - (imageSize - lastSize);
                    layoutParams.topMargin = lastParams.topMargin - (imageSize - lastSize);
                } else {//右上
                    layoutParams.leftMargin = lastParams.leftMargin - (imageSize - lastSize);
                    layoutParams.topMargin = lastParams.topMargin;
                }
            } else {
                if (h - (imageSize / 2) < lastParams.topMargin) {//左下
                    layoutParams.leftMargin = lastParams.leftMargin;
                    layoutParams.topMargin = lastParams.topMargin - (imageSize - lastSize);
                } else {//左上
                    layoutParams.leftMargin = lastParams.leftMargin;
                    layoutParams.topMargin = lastParams.topMargin;
                }
            }
            codeImageView.setLayoutParams(layoutParams);
        } else {
            lastParams.width = imageSize;
            lastParams.height = imageSize;
            codeImageView.setLayoutParams(lastParams);
        }


        codeImageView.setImageBitmap(bitmap);
    }


    private void setLayoutParamsByView(FrameLayout.LayoutParams layoutParams, View view, int gravity) {
        switch (gravity) {
            case 0:
                layoutParams.topMargin = SizeUtils.dp2px(15);
                layoutParams.leftMargin = SizeUtils.dp2px(15);
                layoutParams.gravity = Gravity.LEFT | Gravity.TOP;
                break;
            case 1:
                layoutParams.topMargin = SizeUtils.dp2px(15);
                layoutParams.rightMargin = SizeUtils.dp2px(15);
                layoutParams.gravity = Gravity.RIGHT | Gravity.TOP;
                break;
            case 2:
                layoutParams.topMargin = 0;
                layoutParams.bottomMargin = 0;
                layoutParams.rightMargin = 0;
                layoutParams.leftMargin = 0;
                layoutParams.gravity = Gravity.CENTER;
                break;
            case 3:
                layoutParams.bottomMargin = SizeUtils.dp2px(15);
                layoutParams.leftMargin = SizeUtils.dp2px(15);
                layoutParams.gravity = Gravity.BOTTOM | Gravity.LEFT;
                break;
            case 4:
                layoutParams.bottomMargin = SizeUtils.dp2px(15);
                layoutParams.rightMargin = SizeUtils.dp2px(15);
                layoutParams.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                break;

        }
        view.setLayoutParams(layoutParams);
    }


        @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        int x = (int) event.getRawX();
        int y = (int) event.getRawY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                return !(isTouchPointInView(codeImageView, x, y) || isTouchPointInView(urlTextView, x, y) || isTouchPointInView(tipTextView, x, y));
            }
        }
        return super.onInterceptTouchEvent(event);
    }

    private boolean isTouchPointInView(View view, int x, int y) {
        if (view == null) {
            return false;
        }
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        int left = location[0];
        int top = location[1];
        int right = left + view.getMeasuredWidth();
        int bottom = top + view.getMeasuredHeight();
        if (y >= top && y <= bottom && x >= left
                && x <= right) {
            return true;
        }
        return false;
    }

    private String getGravity(int gravity) {
        String sGravity = "";
        switch (gravity) {
            case IGravity.TopLeft:
                sGravity = "左上角";
                break;
            case IGravity.TopRight:
                sGravity = "右上角";
                break;
            case IGravity.BottomLeft:
                sGravity = "左下角";
                break;
            case IGravity.BottomRight:
                sGravity = "右下角";
                break;
            case IGravity.Center:
                sGravity = "居中";
                break;
        }
        return sGravity;
    }


    private WeakHandler mHandler = new WeakHandler();

    private Runnable mRunnable = () -> setEditUrl();
}
