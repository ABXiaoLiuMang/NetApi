package com.ty.common.util;

import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.OnLifecycleEvent;

import com.airbnb.lottie.LottieAnimationView;
import com.ty.common.R;
import com.ty.utils.SizeUtils;

import static android.animation.ValueAnimator.INFINITE;

public class XLoadingView extends LinearLayout implements LifecycleObserver {
    private LinearLayout linearLayout;
    private LottieAnimationView lottieAnimationView;
    private ValueAnimator animator;
    private MutableLiveData<Float> updateAnim = new MutableLiveData<>();
//    private String mPlatformFlag = getPlatformFlag();
    private LinearLayout.LayoutParams layoutParams;
    public XLoadingView(Context context) {
        this(context, null);
    }

    public XLoadingView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public XLoadingView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private void init() {
        setVisibility(GONE);
        setGravity(Gravity.CENTER);
        setOrientation(LinearLayout.VERTICAL);
        linearLayout = new LinearLayout(getContext());
        lottieAnimationView = new LottieAnimationView(getContext());
        setAnimatorJson();

    }

    public void start() {
        setVisibility(VISIBLE);
        animator.start();
    }

    public void stop() {
        setVisibility(GONE);
        animator.cancel();
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void onDestroy() {
        animator.cancel();
        animator.removeAllUpdateListeners();
    }

    private void setAnimatorJson() {
        String mJsonAddress = "";
//        String mImageAddetsFolder = "";
//        if (mPlatformFlag.equals(Key.Platform.KOK) || mPlatformFlag.equals(Key.Platform.KOKSPORT)) {
            layoutParams = new LayoutParams(SizeUtils.dp2px(160), SizeUtils.dp2px(160));
            mJsonAddress = "lottie/loading/loading_kok.json";
//        }
//        if (mPlatformFlag.equals(Key.Platform.YIBO) || mPlatformFlag.equals(Key.Platform.YIBOSPORT)) {
//            layoutParams = new LayoutParams(ResUtils.dp2px(160), ResUtils.dp2px(160));
//            mImageAddetsFolder = "lottie/loading/images_yibo";
//            mJsonAddress = "lottie/loading/loading_yibo.json";
//        }
//        if (mPlatformFlag.equals(Key.Platform.GLOBAL) || mPlatformFlag.equals(Key.Platform.GLOBALSPORT)) {
//            layoutParams = new LayoutParams(ResUtils.dp2px(160), ResUtils.dp2px(160));
//            mJsonAddress = "lottie/loading/loading_global.json";
//        }
//        if (mPlatformFlag.equals(Key.Platform.HUOHU) || mPlatformFlag.equals(Key.Platform.HUOHUSPORT)) {
//            layoutParams = new LayoutParams(ResUtils.dp2px(85), ResUtils.dp2px(85));
//            mJsonAddress = "lottie/loading/loading_fox.json";
//        }
//        if (mPlatformFlag.equals(Key.Platform.AOA) || mPlatformFlag.equals(Key.Platform.AOASPORT)) {
//            layoutParams = new LayoutParams(ResUtils.dp2px(140), ResUtils.dp2px(140));
//            mJsonAddress = "lottie/loading/loading_aoa.json";
//        }

//        if (!TextUtils.isEmpty(mImageAddetsFolder)) {
//            lottieAnimationView.setImageAssetsFolder(mImageAddetsFolder);
//        }

        lottieAnimationView.setLayoutParams(layoutParams);

        linearLayout.setLayoutParams(new LayoutParams(SizeUtils.dp2px(80), SizeUtils.dp2px(80)));
        linearLayout.setBackgroundResource(R.drawable.x_shape_conner30_gray);
        linearLayout.addView(lottieAnimationView);
        linearLayout.setGravity(Gravity.CENTER);

        linearLayout.setPadding(0,0,0,0);
        addView(linearLayout);
        lottieAnimationView.setRepeatCount(INFINITE);
        lottieAnimationView.playAnimation();
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(1300);
        animator.setRepeatCount(INFINITE);

        animator.addUpdateListener(animation -> updateAnim.setValue((float) animation.getAnimatedValue()));

        if (getContext() instanceof AppCompatActivity) {
            AppCompatActivity activity = (AppCompatActivity) getContext();
            activity.getLifecycle().addObserver(this);
            updateAnim.observe(activity, aFloat -> {
                if (aFloat == null) return;
                lottieAnimationView.setProgress(aFloat);
            });
        }

        lottieAnimationView.setAnimation(mJsonAddress);
    }
}

