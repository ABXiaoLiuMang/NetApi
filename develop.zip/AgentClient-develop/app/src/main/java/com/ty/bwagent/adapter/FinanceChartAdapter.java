package com.ty.bwagent.adapter;

import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.chart.ChartEntity;
import com.ty.tysite.utils.ResourceSiteUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;

import java.util.List;


/**
 * 描述
 * <p> 柱状图适配器
 * author:Dale
 */
public class FinanceChartAdapter extends BaseQuickAdapter<ChartEntity, BaseViewHolder> {


    double maxValue;

    public FinanceChartAdapter(@Nullable List<ChartEntity> data) {
        super(R.layout.recycle_item_finance_chart, data);
    }

    public void setMaxValue(double maxValue) {
        this.maxValue = maxValue;
    }

    @Override
    protected void convert(BaseViewHolder helper, ChartEntity item) {
        String month = item.getCommissionDate();
        if(StringUtils.length(month) > 7){
            month = month.substring(0,7);
        }
        helper.setText(R.id.finance_data, month);
        helper.setText(R.id.finance_count, Utils.getChartText(item.getCommission()));
        TextView chartView = helper.getView(R.id.finance_chart);
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) chartView.getLayoutParams();
        lp.height = (int) (SizeUtils.dp2px(128) * item.getCommission() / maxValue);
        chartView.setLayoutParams(lp);
        int resId = ResourceSiteUtils.getFinanceChartBg();
        chartView.setBackgroundResource(resId);
    }


}
