package com.ty.bwagent.ui;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ty.bwagent.R;
import com.ty.bwagent.utils.XLiveDataManager;


public class SplashActivity extends AppCompatActivity{

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        XLiveDataManager.getInstance().getPerInfo();
        GestureActivity.startGestureActivity(false,true);
        finish();
    }


}
