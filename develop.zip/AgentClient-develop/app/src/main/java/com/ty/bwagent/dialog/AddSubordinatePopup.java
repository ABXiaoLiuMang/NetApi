package com.ty.bwagent.dialog;

import android.view.View;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupAnimation;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.viewmodel.SubAgentViewModle;
import com.ty.common.util.AlphaAnimator;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.view.ClearEditText;

import androidx.fragment.app.Fragment;

/**
 * 团队管理新增下级弹窗
 */
public class AddSubordinatePopup extends ConfirmPopupView {

    ClearEditText et_input;
    Fragment fragment;
    private OnAddAgentClickListener onAddAgentClickListener;
    BasePopupView progressDialog;
    private final SubAgentViewModle agentViewModle;

    public AddSubordinatePopup(Fragment fragment, OnAddAgentClickListener onAddAgentClickListener) {
        super(fragment.getContext());
        this.fragment = fragment;
        this.onAddAgentClickListener = onAddAgentClickListener;
        this.title = "新增下级";
        agentViewModle = new SubAgentViewModle();
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_suburdin_add;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();

        et_input = findViewById(R.id.et_input);
        tv_content = findViewById(R.id.tv_content);

        et_input.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tv_content.setText("");
            }
        });
        setListener(() -> {
            if (!VerifyUtils.isUserName(et_input.getText().toString().trim())) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText(ResUtils.getString(R.string.generic_username_warn));
                return;
            }
            KeyboardUtils.hideSoftInput(et_input);
            agentViewModle.insertLower(et_input.getText().toString().trim());
        }, null);

        initViewsAndEvents();
    }

    /**
     * 一系列监听回调
     */
    private void initViewsAndEvents() {

        agentViewModle.insertLowerLiveData.observeForever(new NetObserver<BaseEntity>() {

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                onAddAgentClickListener.OnAddSuccessBack();
                dismiss();
            }

            @Override
            protected void onError(int code, String errMsg) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText(errMsg);
            }

        });
    }

    @Override
    public void dismiss() {
        super.dismiss();
        agentViewModle.insertLowerLiveData.removeObservers(fragment);
    }


    @Override
    protected void doAfterShow() {
        super.doAfterShow();
        KeyboardUtils.showSoftInput(et_input);
    }


    @Override
    protected void doAfterDismiss() {
        super.doAfterDismiss();
        KeyboardUtils.hideSoftInput(et_input);
    }

    private void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(fragment.getContext(), fragment);
            progressDialog = new XPopup.Builder(fragment.getContext())
                    .isRequestFocus(false)  //loading不要焦点
                    .hasShadowBg(false)
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        progressDialog.show();
    }

    private void dismissProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    public interface OnAddAgentClickListener {
        void OnAddSuccessBack();
    }

}