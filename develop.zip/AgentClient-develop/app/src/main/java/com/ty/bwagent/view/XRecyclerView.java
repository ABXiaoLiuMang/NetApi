package com.ty.bwagent.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.GridView;

import androidx.recyclerview.widget.RecyclerView;

/**
 * 不可滚动
 */
public class XRecyclerView extends RecyclerView {
    public XRecyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public XRecyclerView(Context context) {
        super(context);
    }

    public XRecyclerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE >> 2,
                MeasureSpec.AT_MOST));
    }
}  