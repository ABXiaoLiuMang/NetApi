package com.ty.bwagent.utils;

import android.graphics.Bitmap;

public interface URLPostHandler {
    void PostHandler(Bitmap bitmap);
}
