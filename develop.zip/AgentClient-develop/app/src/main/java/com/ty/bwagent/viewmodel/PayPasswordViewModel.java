package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.utils.Md5Util;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.StringUtils;

public class PayPasswordViewModel extends CodeViewModel {


    public NetLiveData<BaseEntity> rechargePasswordLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity> setPasswordLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity> resertPasswordLiveData = new NetLiveData<>();


    //设置密码
    public void payPassWordResert(String password, String confirmPassword) {

        if (StringUtils.length(password) != 6) {
            setPasswordLiveData.setError(0, "请输入支付密码（6位字母或数字）");
            return;
        }
        if (StringUtils.length(confirmPassword) != 6) {
            setPasswordLiveData.setError(0, "请输入支付密码（6位字母或数字）");
            return;
        }

        if (!password.equals(confirmPassword)) {
            setPasswordLiveData.setError(0, "两次密码输入不一致");
            return;
        }

        NetSdk.create(Api.class)
                .setPayPwd()
                .params("password", Md5Util.md5(password))
                .params("confirmPassword", Md5Util.md5(confirmPassword))
                .asJSONType()
                .send(setPasswordLiveData);
    }

    //修改支付密码
    public void changePassWord(String oldPassWord, String passWord, String confirmPassword) {
        if (StringUtils.length(oldPassWord) != 6) {
            rechargePasswordLiveData.setError(0, "原密码输入错误，请重新输入");
            return;
        }
        if (StringUtils.length(passWord) != 6) {
            rechargePasswordLiveData.setError(0, "请输入支付密码（6位字母或数字）");
            return;
        }
        if (StringUtils.length(confirmPassword) != 6) {
            rechargePasswordLiveData.setError(0, "请输入支付密码（6位字母或数字）");
            return;
        }

        if (!StringUtils.equals(passWord, confirmPassword)) {
            rechargePasswordLiveData.setError(0, "两次密码输入不一致");
            return;
        }

        NetSdk.create(Api.class)
                .updatePassword()
                .params("oldPassword", Md5Util.md5(oldPassWord))
                .params("password", Md5Util.md5(passWord))
                .params("confirmPassword", Md5Util.md5(confirmPassword))
                .asJSONType()
                .send(rechargePasswordLiveData);
    }

    //重置支付密码
    public void resertPassWord(String password, String confirmPassword, String phoneCode) {

        if (StringUtils.isEmpty(phoneCode)) {
            resertPasswordLiveData.setError(0, "请输入验证码");
            return;
        }
        if (StringUtils.length(password) != 6) {
            resertPasswordLiveData.setError(0, "请输入支付密码（6位字母或数字）");
            return;
        }
        if (StringUtils.length(confirmPassword) != 6) {
            resertPasswordLiveData.setError(0, "请输入支付密码（6位字母或数字）");
            return;
        }

        if (!StringUtils.equals(password, confirmPassword)) {
            resertPasswordLiveData.setError(0, "两次密码输入不一致");
            return;
        }


        NetSdk.create(Api.class)
                .rechargePassword()
                .params("password", Md5Util.md5(password))
                .params("confirmPassword", Md5Util.md5(confirmPassword))
                .params("phoneCode", phoneCode)
                .asJSONType()
                .send(resertPasswordLiveData);
    }


}
