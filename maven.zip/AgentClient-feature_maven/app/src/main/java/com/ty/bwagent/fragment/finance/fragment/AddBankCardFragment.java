package com.ty.bwagent.fragment.finance.fragment;

import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.lxj.xpopup.XPopup;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.AddBankCardEntity;
import com.ty.bwagent.bean.BankEntity;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.dialog.AddBankCardPopup;
import com.ty.bwagent.fragment.finance.viewmodel.AddBankCardViewModel;
import com.ty.bwagent.fragment.finance.viewmodel.BankViewModel;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.SingleOnClickListener;
import com.ty.common.view.ValueView;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.pickerview.view.CityPickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.SpanManager;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import butterknife.BindView;
import butterknife.OnClick;


public class AddBankCardFragment extends ABBaseFragment {

    AddBankCardViewModel mAddBankCardViewModel;
    BankViewModel bankViewModel;
    @BindView(R.id.add_bankcard_warning)
    TextView addBankcardWarning;
    @BindView(R.id.et_bank_number)
    ClearEditText etBankNumber;
    @BindView(R.id.valueview_bank_name)
    ValueView valueviewBankName;
    @BindView(R.id.valueview_bank_adds)
    ValueView valueviewBankAdds;
    @BindView(R.id.btn_bind_commit)
    TextView btnBindCommit;
    @BindView(R.id.add_bankcard_custom)
    TextView addBankcardCustom;
    @BindView(R.id.et_username)
    ClearEditText etUsername;
    String userName;//持卡人姓名
    String bankCard;//银行卡号
    String bankCode;//开户银行编码
    String bankName;//开户银行名字
    String address;//开户银行地址

    AddBankCardPopup bankCardPopup;
    String userReanName;//持卡人登录用户真实姓名

    public static AddBankCardFragment getInstance() {
        return new AddBankCardFragment();
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_add_bankcard;
    }

    @Override
    protected void createProvider() {
        mAddBankCardViewModel = new ViewModelProvider(this).get(AddBankCardViewModel.class);
        bankViewModel = new ViewModelProvider((Fragment)getPreFragment()).get(BankViewModel.class);

        //银行卡数据（选择银行弹窗用）
        mAddBankCardViewModel.banksLiveData.observe(this, new NetObserver<BaseEntity<List<AddBankCardEntity>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<AddBankCardEntity>> entity) {
                List<AddBankCardEntity> cardEntityList = entity.getData();
                entityList.addAll(cardEntityList);
            }
            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //监听验证结果
        mAddBankCardViewModel.cardLiveData.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity entity) {
                BankEntity bankEntity = new BankEntity(bankName,bankCode,bankCard,address,userName);
                bankViewModel.bankNumberLiveData.postValue(bankEntity);
                pop();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                addBankcardWarning.setText(errMsg);
            }
        });


    }

    @Override
    protected void initViewsAndEvents() {

        InputFilter nameInputFilter = (source, start, end, dest, dstart, dend) -> {
            String speChat = "^[\\u4e00-\\u9fa5a-zA-Z.·• *]+$";
            Pattern pattern = Pattern.compile(speChat);
            Matcher matcher = pattern.matcher(source.toString());
            if (matcher.find()){
                return null;
            }else {
                return "";
            }
        };

        InputFilter[] filters = new InputFilter[2];
        filters[0] = new InputFilter.LengthFilter(24);
        filters[1] = nameInputFilter;
        etUsername.setFilters(filters);

        new InputResultCalculator(Arrays.asList(etUsername,etBankNumber,valueviewBankName.getTv_value(),valueviewBankAdds.getTv_value()), ok -> {
            bankCard = etBankNumber.getText().toString().trim();
            if(!VerifyUtils.isBankCard(bankCard)){
                btnBindCommit.setEnabled(false);
                return;
            }
            btnBindCommit.setEnabled(ok);
        });
        SpanManager.callServiceSpan(addBankcardCustom, ResUtils.getString(R.string.generic_addcard_alert), ResUtils.getColor(SiteSdk.ins().styleColor()), "联系客服", new SingleOnClickListener() {
            @Override
            public void onSingleClick(View view) {
                goActivity(OnlineActivity.class);
            }
        });


        VerifyUtils.verifyBindCardName(etUsername,addBankcardWarning);
        VerifyUtils.verifyBankCarde(etBankNumber,addBankcardWarning);

        etUsername.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                super.afterTextChanged(s);

                if(s!= null){
                    if (s.toString().startsWith("-") || s.toString().startsWith(" ")) {//不能连续输入
                        s.delete(0, 1);
                    }
                }

                if(s != null && s.toString().length() > 1){
                    String text = s.toString();
                    int length = text.length();
                    if (text.endsWith("--")) {//不能连续输入
                        s.delete(length - 1, length);
                    }
                    if (s.toString().endsWith("  ")) {//不能连续输入
                        s.delete(length - 1, length);
                    }

                    if (text.endsWith("-") && length > 1) {//中文后不能输入-
                        String charText = text.substring(length - 2,length -1);
                        if(charText.matches("[\u4E00-\u9FA5]+")){
                            s.delete(length - 1, length);
                        }

                    }
                }
            }
        });

        /***
         * 结尾不能输入-和空格（搞毛哦，不能输入限制尼玛太多了）
         */
        etUsername.setOnFocusChangeListener((v, hasFocus) -> {
            if(etUsername == null){
                   return;
            }
            String input = etUsername.getText().toString();
            if(!hasFocus){//失去焦点
                if (input.endsWith("-") || input.endsWith(" ")) {//不能连续输入
                    etUsername.setText(input.substring(0,input.length() -1));
                }
            }else {
                etUsername.setClearIconVisible(true);
                etUsername.setText("");
            }
        });

        mAddBankCardViewModel.queryBanks();
        initBankCardPopup();
    }

    /**
     * 选择绑定银行卡弹窗
     */
    List<AddBankCardEntity> entityList = new ArrayList<>();
    private void initBankCardPopup(){
        bankCardPopup = new AddBankCardPopup(mContext,entityList);
        bankCardPopup.selectLiveData.observe(this, addBankCardEntity -> {
            valueviewBankName.setTextValue(addBankCardEntity.getDictValue());
            bankCode = addBankCardEntity.getCode();
            bankName = addBankCardEntity.getDictValue();
        });
    }

    @OnClick({R.id.valueview_bank_name, R.id.valueview_bank_adds, R.id.btn_bind_commit})
    public void onViewClicked(View view) {
        if (DoubleClickUtils.isLongDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.valueview_bank_name:
                KeyboardUtils.hideSoftInput(getActivity());
                new XPopup.Builder(getContext())
                        .maxHeight((int) (ScreenUtils.getScreenHeight() * 0.85f))
                        .moveUpToKeyboard(false)
                        .asCustom(bankCardPopup)
                        .show();
                break;
            case R.id.valueview_bank_adds:
                KeyboardUtils.hideSoftInput(getActivity());
                showCityPickerDialog();
                break;
            case R.id.btn_bind_commit:
                userName = etUsername.getText().toString();
                if(!StringUtils.isEmpty(userReanName) && userName.equals(userReanName.substring(0,1) + "**")){
                    userName = userReanName;
                }
                bankCard = etBankNumber.getText().toString().trim();
                mAddBankCardViewModel.validateBankCard(bankCard,bankCode,userName);
                break;
        }
    }

    /**
     * 地址选择弹窗
     */
    private CityPickerView cityPickerView;
    private void showCityPickerDialog(){
        if(cityPickerView == null){
            cityPickerView =  new CityPickerView(getActivity(),"深圳", SiteSdk.ins().styleColor(),SiteSdk.ins().styleColor());
            cityPickerView.setOnCitySelectListener((prov, city, area) -> {
                address = prov + "|" + city + "|" + area;
                valueviewBankAdds.setTextValue(address);
            });
        }
        cityPickerView.show();
    }

    @Override
    public void onStop() {
        super.onStop();
        etUsername.setOnFocusChangeListener(null);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        KeyboardUtils.hideSoftInput(getActivity());
        bankCardPopup.selectLiveData.removeObservers(this);
        bankCardPopup = null;
    }
}
