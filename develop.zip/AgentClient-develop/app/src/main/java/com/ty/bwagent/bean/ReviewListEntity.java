package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

import com.ty.utils.StringUtils;

import java.util.List;

public class ReviewListEntity {


    /**
     * endRow : 3
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : true
     * isLastPage : true
     * list : [{"createdAt":"2020-07-14 22:00:26","id":3,"memberId":111221,"memberName":"test001","phone":"1234","realName":"测试1","remark":"","reviewAt":"2020-07-14 22:00:26","reviewStatus":0,"reviewerId":92019143594,"reviewerName":"mmmnnn115"},{"createdAt":"2020-07-14 22:00:39","id":4,"memberId":111222,"memberName":"test002","phone":"1234","realName":"测试2","remark":"","reviewAt":"2020-07-14 22:00:39","reviewStatus":1,"reviewerId":92019143594,"reviewerName":"mmmnnn115"},{"createdAt":"2020-07-14 22:00:45","id":5,"memberId":111223,"memberName":"test003","phone":"1234","realName":"测试3","remark":"","reviewAt":"2020-07-14 22:00:45","reviewStatus":2,"reviewerId":92019143594,"reviewerName":"mmmnnn115"}]
     * navigateFirstPage : 1
     * navigateLastPage : 1
     * navigatePages : 8
     * navigatepageNums : [1]
     * nextPage : 0
     * pageNum : 1
     * pageSize : 10
     * pages : 1
     * prePage : 0
     * size : 3
     * startRow : 1
     * total : 3
     */

    private int endRow;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private int navigateFirstPage;
    private int navigateLastPage;
    private int navigatePages;
    private int nextPage;
    private int pageNum;
    private int pageSize;
    private int pages;
    private int prePage;
    private int size;
    private int startRow;
    private int total;
    private List<ListBean> list;
    private List<Integer> navigatepageNums;

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public List<Integer> getNavigatepageNums() {
        return navigatepageNums;
    }

    public void setNavigatepageNums(List<Integer> navigatepageNums) {
        this.navigatepageNums = navigatepageNums;
    }

    public static class ListBean implements Parcelable {
        /**
         * createdAt : 2020-07-14 22:00:26
         * id : 3
         * memberId : 111221
         * memberName : test001
         * phone : 1234
         * realName : 测试1
         * remark :
         * reviewAt : 2020-07-14 22:00:26
         * reviewStatus : 0
         * reviewerId : 92019143594
         * reviewerName : mmmnnn115
         */

        private String createdAt;
        private int id;
        private int memberId;
        private String memberName;
        private String phone;
        private String realName;
        private String remark;
        private String reviewAt;
        private int reviewStatus;
        private long reviewerId;
        private String reviewerName;

        protected ListBean(Parcel in) {
            createdAt = in.readString();
            id = in.readInt();
            memberId = in.readInt();
            memberName = in.readString();
            phone = in.readString();
            realName = in.readString();
            remark = in.readString();
            reviewAt = in.readString();
            reviewStatus = in.readInt();
            reviewerId = in.readLong();
            reviewerName = in.readString();
        }

        public static final Creator<ListBean> CREATOR = new Creator<ListBean>() {
            @Override
            public ListBean createFromParcel(Parcel in) {
                return new ListBean(in);
            }

            @Override
            public ListBean[] newArray(int size) {
                return new ListBean[size];
            }
        };

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMemberId() {
            return memberId;
        }

        public void setMemberId(int memberId) {
            this.memberId = memberId;
        }

        public String getMemberName() {
            return memberName;
        }

        public void setMemberName(String memberName) {
            this.memberName = memberName;
        }

        public String getPhone() {
            if (!StringUtils.isEmpty(phone) && StringUtils.length(phone) == 11) {
                return phone.substring(0, 3) + "****" + phone.substring(7);
            }
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getRealName() {
            if (!StringUtils.isEmpty(realName)) {
                return realName.substring(0, 1) + "**";
            }
            return realName;
        }

        public void setRealName(String realName) {
            this.realName = realName;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getReviewAt() {
            return reviewAt;
        }

        public void setReviewAt(String reviewAt) {
            this.reviewAt = reviewAt;
        }

        public int getReviewStatus() {
            return reviewStatus;
        }

        public void setReviewStatus(int reviewStatus) {
            this.reviewStatus = reviewStatus;
        }

        public long getReviewerId() {
            return reviewerId;
        }

        public void setReviewerId(long reviewerId) {
            this.reviewerId = reviewerId;
        }

        public String getReviewerName() {
            return reviewerName;
        }

        public void setReviewerName(String reviewerName) {
            this.reviewerName = reviewerName;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(createdAt);
            dest.writeInt(id);
            dest.writeInt(memberId);
            dest.writeString(memberName);
            dest.writeString(phone);
            dest.writeString(realName);
            dest.writeString(remark);
            dest.writeString(reviewAt);
            dest.writeInt(reviewStatus);
            dest.writeLong(reviewerId);
            dest.writeString(reviewerName);
        }
    }
}
