package com.ty.bwagent.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.ExtensionAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.CategoriesType;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.viewmodel.ExtensionModel;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 推广item
 */
public class ExtensionFragment extends ABRefreshFragment<ExtensionEntity> implements BaseQuickAdapter.OnItemChildClickListener {

    ImageView iv_logo;
    TextView tv_tips;

    ExtensionModel mExtensionModel;
    String clientType = "";
    String title = "";
    private BaseEntity<List<ExtensionEntity>> listBaseEntity;

    public static ExtensionFragment getInstance(Bundle bundle) {
        ExtensionFragment fragment = new ExtensionFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    protected void createProvider() {
        mExtensionModel = new ViewModelProvider(this).get(ExtensionModel.class);
        //监听推广列表数据
        mExtensionModel.entityNetLiveData.observe(this, new NetObserver<BaseEntity<List<ExtensionEntity>>>() {

            @Override
            protected void onSuccess(BaseEntity<List<ExtensionEntity>> listBaseEntity) {
                dismissProgressDialog();
                ExtensionFragment.this.listBaseEntity = listBaseEntity;
                List<ExtensionEntity> entityList = listBaseEntity.getData();
                if (clientType.equals("privateDomain")) {//专属域名
                    if (listBaseEntity != null) {
                        setSearchTypeDate(searchDate);
                    }
                } else {
                    listAdapter.setNewData(entityList);
                }
                refreshLayout.setVisibility(View.VISIBLE);
                refreshLayout.finishRefresh();
                dismissProgressDialog();

                iv_logo.setImageResource(R.mipmap.message_empty_bg);
                tv_tips.setText("暂无数据");
            }

            @Override
            protected void onError(int code, String errMsg) {
                refreshLayout.setVisibility(View.VISIBLE);
                dismissProgressDialog();
                refreshLayout.finishRefresh(false);

                iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
                tv_tips.setText("网络不给力");
                ToastUtils.showLong(errMsg);
            }

        });

        mExtensionModel.typeChangeUpNetLiveData.observe(this, this::searchLoadDate);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.x_refresh;
    }

    @Override
    protected void initViewsAndEvents() {
        CategoriesType categoriesType = bundle.getParcelable(ABConfig.KEY_OBJECT);
        if (categoriesType != null) {
            clientType = categoriesType.getParames();
            title = categoriesType.getName();
        }
        super.initViewsAndEvents();
        refreshLayout.setVisibility(View.GONE);

        listAdapter.setOnItemChildClickListener(this);
    }

    boolean loadData = false;

    @Override
    public void onResume() {
        super.onResume();
        if (!loadData) {
            showProgressDialog();
            mExtensionModel.domainByClientType(clientType);
            loadData = true;
        }
    }

    //筛选专属域名
    private String searchDate = "全部";

    public void searchLoadDate(String searchDate) {
        this.searchDate = searchDate;
        if (clientType.equals("privateDomain")) {//专属域名
            showProgressDialog();
            mExtensionModel.domainByClientType(clientType);
        }
    }

    //搜索类型
    private void setSearchTypeDate(String searchDate) {
        if ("全部".equals(searchDate)) {
            listAdapter.setNewData(listBaseEntity.getData());
        } else {
            List<ExtensionEntity> extensionEntities = new ArrayList<>();
            for (int i = 0; i < listBaseEntity.getData().size(); i++) {
                if (listBaseEntity.getData().get(i) != null && listBaseEntity.getData().get(i).getTitle() != null) {
                    if (listBaseEntity.getData().get(i).getTitle().equals(searchDate)) {
                        extensionEntities.add(listBaseEntity.getData().get(i));
                    }
                }
            }
            listAdapter.setNewData(extensionEntities);
        }
    }

    @Override
    public View getEmptyView() {
        View empty = View.inflate(mContext, R.layout.empty_extension, null);
        iv_logo = empty.findViewById(R.id.iv_logo);
        tv_tips = empty.findViewById(R.id.tv_tips);
        return empty;
    }

    @Override
    public int getMode() {
        return Mode.PULL_FROM_START;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public BaseQuickAdapter<ExtensionEntity, BaseViewHolder> getListAdapter() {
        return new ExtensionAdapter(title);
    }

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        ExtensionEntity extensionEntity = (ExtensionEntity) adapter.getItem(position);
        switch (view.getId()) {
            case R.id.extension_iv_share:
                showNoticeDialog(extensionEntity);
                break;
        }
    }


    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {

    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {

    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        mExtensionModel.domainByClientType(clientType);
    }

    private void showNoticeDialog(ExtensionEntity mExtensionEntity) {
        DialogUtil.createShareDailog(mContext, mExtensionEntity);
    }




}
