package com.ty.bwagent.bean;

/**
 * 下级成员详情
 */
public class MemberDetailsEntity {

    /**
     * availableMoney : 0.0
     * avater : http://img.bwhou2020.com/1576480523173011.png
     * createdAt : 2020-03-03 21:23:58
     * dayTotalProfit : 0.0
     * id : 2019138792
     * lastLoginTime : 2020-03-03 21:23:59
     * monthTotalProfit : 0.0
     * name : ouou10
     * realName :
     * status : 1
     * totalProfit : 0.0
     * vipLevel : VIP0
     */

    private double availableMoney;
    private String avater;
    private String createdAt;
    private double dayTotalProfit;
    private int id;
    private String lastLoginTime;
    private double monthTotalProfit;
    private String name;
    private String realName;
    private int status;
    private double totalProfit;
    private String vipLevel;
    /**
     * active : 0
     * availableMoney : 0.0
     * betAmount : 0
     * changeAgent : 0
     * changeLog : 无
     * dayTotalProfit : 0.0
     * deposit : 0
     * draw : 0
     * monthTotalProfit : 0.0
     * netAmount : 0
     * profit : 0.0
     * promo : 0.0
     * rebate : 0.0
     * riskAdjust : 0.0
     * totalProfit : 0.0
     */

    private int active;
    private double availableMoneyX;
    private double betAmount;
    private int changeAgent;
    private String changeLog;
    private double dayTotalProfitX;
    private double deposit;
    private double draw;
    private double monthTotalProfitX;
    private double netAmount;
    private double profit;
    private double promo;
    private double rebate;
    private double riskAdjust;
    private double totalProfitX;


    public double getAvailableMoney() {
        return availableMoney;
    }

    public void setAvailableMoney(double availableMoney) {
        this.availableMoney = availableMoney;
    }

    public String getAvater() {
        return avater;
    }

    public void setAvater(String avater) {
        this.avater = avater;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public double getDayTotalProfit() {
        return dayTotalProfit;
    }

    public void setDayTotalProfit(double dayTotalProfit) {
        this.dayTotalProfit = dayTotalProfit;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(String lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public double getMonthTotalProfit() {
        return monthTotalProfit;
    }

    public void setMonthTotalProfit(double monthTotalProfit) {
        this.monthTotalProfit = monthTotalProfit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public double getTotalProfit() {
        return totalProfit;
    }

    public void setTotalProfit(double totalProfit) {
        this.totalProfit = totalProfit;
    }

    public String getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(String vipLevel) {
        this.vipLevel = vipLevel;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public double getAvailableMoneyX() {
        return availableMoneyX;
    }

    public void setAvailableMoneyX(double availableMoneyX) {
        this.availableMoneyX = availableMoneyX;
    }

    public double getBetAmount() {
        return betAmount;
    }

    public void setBetAmount(double betAmount) {
        this.betAmount = betAmount;
    }

    public int getChangeAgent() {
        return changeAgent;
    }

    public void setChangeAgent(int changeAgent) {
        this.changeAgent = changeAgent;
    }

    public String getChangeLog() {
        return changeLog;
    }

    public void setChangeLog(String changeLog) {
        this.changeLog = changeLog;
    }

    public double getDayTotalProfitX() {
        return dayTotalProfitX;
    }

    public void setDayTotalProfitX(double dayTotalProfitX) {
        this.dayTotalProfitX = dayTotalProfitX;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public double getDraw() {
        return draw;
    }

    public void setDraw(int draw) {
        this.draw = draw;
    }

    public double getMonthTotalProfitX() {
        return monthTotalProfitX;
    }

    public void setMonthTotalProfitX(double monthTotalProfitX) {
        this.monthTotalProfitX = monthTotalProfitX;
    }

    public double getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(double netAmount) {
        this.netAmount = netAmount;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public double getPromo() {
        return promo;
    }

    public void setPromo(double promo) {
        this.promo = promo;
    }

    public double getRebate() {
        return rebate;
    }

    public void setRebate(double rebate) {
        this.rebate = rebate;
    }

    public double getRiskAdjust() {
        return riskAdjust;
    }

    public void setRiskAdjust(double riskAdjust) {
        this.riskAdjust = riskAdjust;
    }

    public double getTotalProfitX() {
        return totalProfitX;
    }

    public void setTotalProfitX(double totalProfitX) {
        this.totalProfitX = totalProfitX;
    }
}
