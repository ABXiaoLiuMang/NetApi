package com.ty.bwagent.utils;

import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.bean.FinanceItemEntity;
import com.ty.bwagent.fragment.finance.fragment.FinanceAccountFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceComFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceRateDetailFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceReverseFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceSaveFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceTaxFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceTotalFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceVenueFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceWaterFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceWinFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * 佣金界面列表数据展示工具类
 */
public class FinanceDateUtils {

    public static String COMMISSION = "佣金";
    public static String CZPROFIT = "冲正后净输赢";
    public static String LASTBALANCE = "上月结余";
    public static String NETPROFIT = "净输赢";
    public static String PROFIT = "总输赢";
    public static String THIRDPARTYSPEND = "场馆费";
    public static String PROMO = "红利";
    public static String REBATE = "返水";
    public static String RISKADJUST = "账户调整";
    public static String CORRECTION = "佣金调整";
    public static String DEPOSIT = "存款";
    public static String DRAW = "存款";
    public static String YONGTATE = "佣金比例";
    public static String PROMORATE = "红利分摊比例";
    public static String REBATERATE = "返水分摊比例";
    public static String ACCOUNTRATE = "账户调整分摊比例";
    public static String THIRDPARTYRATE = "场馆费分摊比例";
    public static String LASTBALANCERATE = "上月结余分摊比例";


    /**
     * 获取不是无限极佣金列表
     *
     * @param financeEntity
     * @return
     */
    public static List<FinanceItemEntity> getNomalListDate(FinanceEntity financeEntity) {
        List<FinanceItemEntity> listBean = new ArrayList<>();
        listBean.add(new FinanceItemEntity(COMMISSION, financeEntity.getCommission(), true, FinanceComFragment.class.getName()));
        listBean.add(new FinanceItemEntity(CZPROFIT, financeEntity.getCzProfit(), true, FinanceReverseFragment.class.getName()));
        listBean.add(new FinanceItemEntity(LASTBALANCE, financeEntity.getLastBalance(), false, null));
        listBean.add(new FinanceItemEntity(NETPROFIT, financeEntity.getNetProfit(), true, FinanceWinFragment.class.getName()));
        listBean.add(new FinanceItemEntity(PROFIT, financeEntity.getProfit(), true, FinanceTotalFragment.class.getName()));
        listBean.add(new FinanceItemEntity(THIRDPARTYSPEND, financeEntity.getThirdPartySpend(), true, FinanceVenueFragment.class.getName()));
        listBean.add(new FinanceItemEntity(PROMO, financeEntity.getPromo(), true, FinanceTaxFragment.class.getName()));
        listBean.add(new FinanceItemEntity(REBATE, financeEntity.getRebate(), true, FinanceWaterFragment.class.getName()));
        listBean.add(new FinanceItemEntity(RISKADJUST, financeEntity.getRiskAdjust(), false, FinanceAccountFragment.class.getName()));
        listBean.add(new FinanceItemEntity(CORRECTION, financeEntity.getCorrection(), false, null));
        listBean.add(new FinanceItemEntity(DEPOSIT, financeEntity.getDeposit(), true, FinanceSaveFragment.class.getName()));
        listBean.add(new FinanceItemEntity(DRAW, financeEntity.getDraw(), false, null));
        return listBean;
    }

    /**
     * 获取无限佣金极列表
     *
     * @param financeEntity
     * @return
     */
    public static List<FinanceItemEntity> getInfiniteListDate(FinanceEntity financeEntity) {
        List<FinanceItemEntity> listBean = new ArrayList<>();
        listBean.add(new FinanceItemEntity(COMMISSION, financeEntity.getCommission(), true, FinanceComFragment.class.getName()));
        listBean.add(new FinanceItemEntity(YONGTATE, 0, true, FinanceRateDetailFragment.class.getName()));
        listBean.add(new FinanceItemEntity(LASTBALANCE, financeEntity.getLastBalance(), false, null));
        listBean.add(new FinanceItemEntity(PROFIT, financeEntity.getProfit(), true, FinanceTotalFragment.class.getName()));
        listBean.add(new FinanceItemEntity(THIRDPARTYSPEND, financeEntity.getThirdPartySpend(), true, FinanceVenueFragment.class.getName()));
        listBean.add(new FinanceItemEntity(PROMO, financeEntity.getPromo(), true, FinanceTaxFragment.class.getName()));
        listBean.add(new FinanceItemEntity(REBATE, financeEntity.getRebate(), true, FinanceWaterFragment.class.getName()));
        listBean.add(new FinanceItemEntity(RISKADJUST, financeEntity.getRiskAdjust(), false, FinanceAccountFragment.class.getName()));
        listBean.add(new FinanceItemEntity(DEPOSIT, financeEntity.getDeposit(), true, FinanceSaveFragment.class.getName()));
        listBean.add(new FinanceItemEntity(DRAW, financeEntity.getDraw(), false, null));
        listBean.add(new FinanceItemEntity(PROMORATE, financeEntity.getDraw(), false, null));
        listBean.add(new FinanceItemEntity(REBATERATE, financeEntity.getDraw(), false, null));
        listBean.add(new FinanceItemEntity(ACCOUNTRATE, financeEntity.getDraw(), false, null));
        listBean.add(new FinanceItemEntity(THIRDPARTYRATE, financeEntity.getDraw(), false, null));
        listBean.add(new FinanceItemEntity(LASTBALANCERATE, financeEntity.getDraw(), false, null));
        return listBean;
    }


}
