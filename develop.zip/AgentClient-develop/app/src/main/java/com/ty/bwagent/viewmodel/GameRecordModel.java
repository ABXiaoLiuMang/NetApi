package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.AboutSponsor;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.bean.GameRecordEntity;
import com.ty.bwagent.bean.GameVenueEntity;
import com.ty.bwagent.bean.MemberGameEntity;
import com.ty.bwagent.bean.MemberGameRecordEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GameRecordModel extends ViewModel {

    //游戏记录场馆类型
    public NetLiveData<BaseEntity<List<GameVenueEntity>>> allGameVenueLiveData = new NetLiveData<>();
    public MutableLiveData<GameRecordEntity> filterLiveData = new MutableLiveData<>();
    //游戏列表
    public NetLiveData<BaseEntity<MemberGameRecordEntity>> memberGameLiveData = new NetLiveData<>();


    /**
     * 游戏记录场馆类型
     */
    public void getAllGameVenue() {
        NetSdk.create(Api.class)
                .getAllGameVenue()
                .asJSONType()
                .send(allGameVenueLiveData);
    }

    /**
     * 游戏列表
     *
     * @param memberName
     * @param startDate
     * @param endDate
     * @param pageNum
     * @param pageSize
     */
    public void queryGameRecodeList(String memberName, String venueId,String flag, String startDate, String endDate, int pageNum, int pageSize) {
        NetSdk.create(Api.class)
                .queryGameRecodeList()
                .params("memberName", memberName)
                .params("startDate", startDate)
                .params("venueId", venueId)
                .params("flag", flag)
                .params("endDate", endDate)
                .params("pageNum", pageNum)
                .params("pageSize", pageSize)
                .asJSONType()
                .send(memberGameLiveData);
    }


}
