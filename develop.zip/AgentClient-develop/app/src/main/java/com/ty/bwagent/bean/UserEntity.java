package com.ty.bwagent.bean;

/**
 * 个人用户信息
 */
public class UserEntity {

    /**
     * avatar : http://103.41.124.222:8080/assets/img/logo/full.png
     * email : fsfs@qq.com
     * inviteCode : 8337504
     * name : test
     * phone : 79797897
     * realName : xiaoji
     * joinedDays : 3
     */

    private String avatar;
    private String email;
    private String inviteCode;
    private String name;
    private String phone;
    private String realName;
    private String joinedDays;
    private String createdAt;
    private String subMembers;
    private String vipLevel;
    private String qq;
    private int sysType;//代理类型 0 普代 1管代
    private String qqType;//qq号是否展示 0是 1否

    public String getQqType() {
        return qqType;
    }

    public void setQqType(String qqType) {
        this.qqType = qqType;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    private String paymentPassword;//是否设置密码 0未设置，1已设置

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInviteCode() {
        return inviteCode;
    }

    public void setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getJoinedDays() {
        return joinedDays;
    }

    public void setJoinedDays(String joinedDays) {
        this.joinedDays = joinedDays;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getSubMembers() {
        return subMembers;
    }

    public void setSubMembers(String subMembers) {
        this.subMembers = subMembers;
    }

    public String getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(String vipLevel) {
        this.vipLevel = vipLevel;
    }

    public String getPaymentPassword() {
        return paymentPassword;
    }

    public void setPaymentPassword(String paymentPassword) {
        this.paymentPassword = paymentPassword;
    }

    public int getSysType() {
        return sysType;
    }

    public void setSysType(int sysType) {
        this.sysType = sysType;
    }
}
