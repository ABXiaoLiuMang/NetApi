package com.ty.bwagent.adapter;

import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.MemberEntity;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XTextView;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.view.CircleImageView;


/**
 * 描述
 * <p> 成员列表适配器
 * author:Dale
 */
public class MemberAdapter extends BaseQuickAdapter<MemberEntity.ListBean, BaseViewHolder> {

    public MemberAdapter() {
        super(R.layout.recycle_item_members);
    }

    @Override
    protected void convert(BaseViewHolder helper, MemberEntity.ListBean entity) {

        CircleImageView member_iv_head = helper.getView(R.id.member_iv_head);
        RequestOptions requestOptions = new RequestOptions()
                .error(R.mipmap.userhead_boy_default)
                .placeholder(R.mipmap.userhead_boy_default);
        Glide.with(mContext)
                .applyDefaultRequestOptions(requestOptions)
                .load(entity.getAvater())
                .into(member_iv_head);

        helper.setImageResource(R.id.member_iv_vip, Utils.getVipResId(entity.getVipLevel()));
        String realName = entity.getRealName();
        if (StringUtils.isEmpty(realName)) {
            helper.setText(R.id.member_tv_name, entity.getName());
        } else {
            realName = "[" + realName.substring(0, 1) + "**]";
            helper.setText(R.id.member_tv_name, entity.getName() + realName);
        }

        helper.setText(R.id.member_tv_money, Utils.roundDownMoney(entity.getAvailableMoney()));
        TextView member_tv_money = helper.getView(R.id.member_tv_money);
        member_tv_money.setTypeface(TypefaceUtils.DIN_MEDIUM);


        XTextView member_today_win = helper.getView(R.id.member_today_win);
        XTextView member_total_win = helper.getView(R.id.member_total_win);
        member_today_win.setMontyText(entity.getDayTotalProfit());//今日输赢
        member_total_win.setMontyText(entity.getMonthTotalProfit());//本月总输赢

        helper.setText(R.id.member_login_time, StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_login_time), StringUtils.isEmpty(entity.getLastLoginTime())?"暂无":Utils.getFormatStringTime(entity.getLastLoginTime())));
        helper.setText(R.id.member_rigester_time, StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_register_time),  StringUtils.isEmpty(entity.getCreatedAt())?"暂无":Utils.getFormatStringTime(entity.getCreatedAt())));
        helper.setVisible(R.id.member_state, entity.getStatus() == 0);//会员状态(0停用，1启用)

        helper.setVisible(R.id.tv_active, entity.getActive() == 1);//0：非活跃 1：活跃
        helper.setVisible(R.id.tv_zhuan, entity.getChangeAgent() == 1);//0: 非转代  1: 转代

    }

}
