package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 描述:消息中心系统公告列表对象
 * <p>
 * author:Dale
 */
public class MessageSys {


    /**
     * endRow : 0
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : false
     * isLastPage : false
     * list : [{"appImageUrl":"http://img.bwhou2020.com/15761513757641.png","content":"我千千万","createdAt":"2020-01-23 17:58:00","title":"211"},{"appImageUrl":"http://img.bwhou2020.com/15761513757641.png","content":"21","createdAt":"2020-01-23 17:42:31","title":"21"},{"appImageUrl":"http://img.bwhou2020.com/15761512096512.png","content":"3","createdAt":"2020-01-23 17:06:28","title":"图标5"},{"appImageUrl":"http://img.bwhou2020.com/15761514177552.png","content":"121","createdAt":"2020-01-23 17:06:16","title":"图标 2"},{"appImageUrl":"http://img.bwhou2020.com/15761513303391.png","content":"32","createdAt":"2020-01-23 17:06:01","title":"图标3"},{"appImageUrl":"http://img.bwhou2020.com/15761512096512.png","content":"21","createdAt":"2020-01-23 17:05:53","title":"图标4"},{"appImageUrl":"http://img.bwhou2020.com/15761513757641.png","content":"大大","createdAt":"2020-01-23 16:55:43","title":"代理公告启停用"},{"appImageUrl":"http://img.bwhou2020.com/15761513757641.png","content":"水电费水电费","createdAt":"2020-01-23 16:17:04","title":"打发打发"},{"appImageUrl":"http://img.bwhou2020.com/15761514177552.png","content":"上到","createdAt":"2020-01-23 16:16:53","title":"测试jsoncodesdd"},{"appImageUrl":"http://img.bwhou2020.com/15761514177552.png","content":"火狐火狐火狐","createdAt":"2020-01-23 15:45:39","title":"火狐娱乐"},{"appImageUrl":"http://img.bwhou2020.com/15761513757641.png","content":"3223","createdAt":"2020-01-23 11:41:21","title":"类型测试"},{"appImageUrl":"http://img.bwhou2020.com/15761513757641.png","content":"32","createdAt":"2020-01-23 11:40:36","title":"23"},{"appImageUrl":"http://img.bwhou2020.com/15761514177552.png","content":"123456","createdAt":"2020-01-22 22:11:12","title":"火狐娱乐"},{"appImageUrl":"http://img.bwhou2020.com/15761513757641.png","content":"范德萨范德萨","createdAt":"2020-01-22 22:03:46","title":"范德萨范德萨范德萨"},{"appImageUrl":"http://img.bwhou2020.com/15761514177552.png","content":"123456789","createdAt":"2020-01-22 21:20:41","title":"火狐娱乐"}]
     * navigateFirstPage : 0
     * navigateLastPage : 0
     * navigatePages : 0
     * navigatepageNums : []
     * nextPage : 0
     * pageNum : 1
     * pageSize : 15
     * pages : 0
     * prePage : 0
     * size : 0
     * startRow : 0
     * total : 46
     */

    private int endRow;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private int navigateFirstPage;
    private int navigateLastPage;
    private int navigatePages;
    private int nextPage;
    private int pageNum;
    private int pageSize;
    private int pages;
    private int prePage;
    private int size;
    private int startRow;
    private int total;
    private List<ListBean> list;

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean implements Parcelable {
        /**
         * appImageUrl : http://img.bwhou2020.com/15761513757641.png
         * content : 我千千万
         * createdAt : 2020-01-23 17:58:00
         * title : 211
         */

        private String appImageUrl;
        private String content;
        private String createdAt;
        private String title;

        public ListBean(){}



        protected ListBean(Parcel in) {
            appImageUrl = in.readString();
            content = in.readString();
            createdAt = in.readString();
            title = in.readString();
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(appImageUrl);
            dest.writeString(content);
            dest.writeString(createdAt);
            dest.writeString(title);
        }

        @Override
        public int describeContents() {
            return 0;
        }

        public static final Creator<ListBean> CREATOR = new Creator<ListBean>() {
            @Override
            public ListBean createFromParcel(Parcel in) {
                return new ListBean(in);
            }

            @Override
            public ListBean[] newArray(int size) {
                return new ListBean[size];
            }
        };

        public String getAppImageUrl() {
            return appImageUrl;
        }

        public void setAppImageUrl(String appImageUrl) {
            this.appImageUrl = appImageUrl;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
}
