package com.ty.bwagent.fragment.login;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.view.KeyEvent;
import android.view.View;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.enums.PopupAnimation;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.bean.ValidateCodeEntity;
import com.ty.bwagent.bean.VerifyEntity;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.LoginViewModel;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.util.AlphaAnimator;
import com.ty.common.util.SingleOnClickListener;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.net.utils.JsonUtils;
import com.ty.tysite.SiteConfig;
import com.ty.tysite.SiteSdk;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

public class LoginFragment extends ABBaseFragment {

    LoginViewModel loginViewMoel;
    @BindView(R.id.login_tv_warning)
    TextView loginTvWarning;
    @BindView(R.id.login_et_username)
    ClearEditText loginEtUsername;
    @BindView(R.id.login_et_password)
    ClearEditText loginEtPassword;
    @BindView(R.id.login_eye_pass)
    ImageView loginEyePass;
    @BindView(R.id.login_et_code)
    ClearEditText loginEtCode;
    @BindView(R.id.login_iv_code)
    ImageView loginIvCode;
    @BindView(R.id.login_layout_code)
    LinearLayout loginLayoutCode;
    @BindView(R.id.login_line)
    View loginLine;
    @BindView(R.id.login_remember_pass)
    CheckedTextView loginRememberPass;
    @BindView(R.id.login_forget_pass)
    TextView loginForgetPass;
    @BindView(R.id.login_commit)
    TextView loginCommit;
    String userName;
    String passWord;
    String realPassWord;
    String verifyCode;
    boolean isRemember;
    boolean isFisterChange;

    /**
     * 记录用户名中输入框中输入的内容
     * （改变后 密码获取焦点要清空密码）
     */
    String currUserName;

    public static LoginFragment getInstance() {
        return new LoginFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_login;
    }



    @Override
    protected void createProvider() {
        loginViewMoel = new ViewModelProvider(this).get(LoginViewModel.class);

        /**
         * 登录成功，但是没有绑定手机号回调
         */
        SystemModel.loginUserInfo.observe(this, userInfo -> {
            if(userInfo != null){
                saveLoginInfo(userInfo);
                UserInfoCache.getInstance().saveUserInfo(userInfo);
                ((ABBaseFragment)getParentFragment()).start(BindPhoneFragment.getInstance());
            }
        });

        /**
         * 登录需要验证手机号
         */
        SystemModel.loginVerify.observe(this, baseEntity -> {
            if(baseEntity != null){
                Bundle bundle = new Bundle();
                bundle.putString("username",userName);
                bundle.putString("password",passWord);
                bundle.putString(ABConfig.KEY_TEXT,baseEntity.getMsg());
                bundle.putString(ABConfig.KEY_OBJECT, baseEntity.getData());
                ((ABBaseFragment)getParentFragment()).start(VerifyFragment.getInstance(bundle));
            }
        });

        //图形验证码
        loginViewMoel.verifyLivedata.observe(this,new SimpleObserver<ValidateCodeEntity>(){

            @Override
            protected void onSuccess(ValidateCodeEntity validateCodeEntity) {
                if(validateCodeEntity != null && validateCodeEntity.getBitmap() != null){
                    loginIvCode.setImageBitmap(validateCodeEntity.getBitmap());
                }else {
                    ToastUtils.showLong("网络异常，请重试");
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
            }
        });

        //限制登录倒计时
        loginViewMoel.hourLiveData.observe(this, aLong -> {
            if(aLong == 0){
                loginCommit.setEnabled(true);
                loginTvWarning.setText("");
            }else {
                String time = TimeUtils.millis2String(TimeUtils.DATE_MM_SS,aLong * 1000);
                loginTvWarning.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_downhour_time),time));
                loginTvWarning.setVisibility(View.VISIBLE);
            }
        });


        //监听登录
        loginViewMoel.loginLiveData.observe(this,new NetObserver<BaseEntity<UserInfo>>(){
            @Override
            protected void onSuccess(BaseEntity<UserInfo> baseEntity) {
                UserInfo userInfo = baseEntity.getData();
                saveLoginInfo(userInfo);
                UserInfoCache.getInstance().saveUserInfo(userInfo);
                XLiveDataManager.getInstance().userInfo.postNext(userInfo);
                MainActivity.startMainActiviy(false);
//                goActivity(MainActivity.class);
                getActivity().finish();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                if(22023 == code || 22006 == code){
                    loginTvWarning.setText(errMsg);
                    /**
                     * 判断是否显示验证码
                     *
                     * 7~19次 密码输入错误以及验证码输入错误
                     *
                     * 1.重新加载验证码，删除之前验证码
                     * 2.显示验证码布局
                     */
                    loginEtCode.setText("");
                    loginViewMoel.autoLoadVerify();//加载验证码
                    loginLayoutCode.setVisibility(View.VISIBLE);
                }else if(22022 == code){//限制一小时登录
                    loginTvWarning.setText(errMsg);
                    loginLayoutCode.setVisibility(View.GONE);
                    loginCommit.setEnabled(false);
                }else if(22004 == code){//系统检测到您本次登录操作异常，为保障账户安全，已向您注册手机号163****7896发送验证码，请完成验证
                    VerifyEntity verifyEntity = JsonUtils.fromJson(errMsg,VerifyEntity.class);
                    SystemModel.loginVerify.postValue(verifyEntity);
                }else {
                    loginLayoutCode.setVisibility(View.GONE);
                    loginTvWarning.setText(errMsg);
                }

            }
            
        });
    }

    @Override
    protected void initViewsAndEvents() {
        loginForgetPass.setOnClickListener(singleOnClickListener);
        loginCommit.setOnClickListener(singleOnClickListener);
        initVerify();
        initSiteStyle();

        initViews();
    }

    /**
     * 处理各类输入框验证逻辑
     */
    private void initVerify(){
        new InputResultCalculator(Arrays.asList(loginEtUsername,loginEtPassword), ok -> {
            String userName = loginEtUsername.getText().toString().trim();
            if(loginLayoutCode.getVisibility() == View.VISIBLE){//可见
                verifyCode = loginEtCode.getText().toString();
                if(!VerifyUtils.isImageCode(verifyCode)){
                    loginCommit.setEnabled(false);
                }else {
                    if(VerifyUtils.isUserName(userName)){
                        loginCommit.setEnabled(ok);
                    }else {
                        loginCommit.setEnabled(false);
                    }
                }
            }else{
                if(VerifyUtils.isUserName(userName)){
                    loginCommit.setEnabled(ok);
                }else {
                    loginCommit.setEnabled(false);
                }
            }
        });

        loginEtCode.addTextChangedListener(new SimpleTextWatcher(){
            public void onTextChanged(CharSequence s, int start, int before, int count) {
               String userName = loginEtUsername.getText().toString().trim();
               String password = loginEtPassword.getText().toString().trim();
               if(!StringUtils.isEmpty(userName) && !StringUtils.isEmpty(password) && !TextUtils.isEmpty(s)){
                   loginCommit.setEnabled(true);
               }else {
                   loginCommit.setEnabled(false);
               }

            }
        });
        loginEtUsername.addTextChangedListener(new SimpleTextWatcher(){
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!isFisterChange && !StringUtils.isEmpty(realPassWord)){
                    isFisterChange = true;
                    loginEtPassword.setText("");
                    realPassWord = null;
                    loginEyePass.setVisibility(View.VISIBLE);
                    currUserName = null;
                }
            }
        });
        loginEtPassword.addTextChangedListener(new SimpleTextWatcher(){
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(TextUtils.isEmpty(s)){
                    realPassWord = null;
                    loginEyePass.setVisibility(View.VISIBLE);
                }
            }
        });

        loginEtPassword.setOnFocusChangeListener((v, hasFocus) -> {
            //获得焦点，同时是记住上个账号密码，就之间清掉（12个*）
            if(loginEtPassword == null)  return;
            String userName = loginEtUsername.getText().toString().trim();
            if (hasFocus && VerifyUtils.isUserName(userName)) {
                loginTvWarning.setText("");
            }

            if(hasFocus && StringUtils.length(userName) > 0){//获的焦点
                loginEtPassword.setClearIconVisible(true);
            }
        });


        loginEtPassword.setOnKeyListener((v, keyCode, event) -> {
            if(keyCode == KeyEvent.KEYCODE_DEL) {
                String input = MMKVUtil.getString(CacheKey.USER_NAME);
                boolean isRemember = MMKVUtil.getBoolean(CacheKey.REMEMBER_PASSWORD);
                if(StringUtils.equals(currUserName,input) && isRemember){
                    currUserName = null;
                    loginEtPassword.setText("");
                }
            }
            return false;
        });


        VerifyUtils.verifyUserName(loginEtUsername,loginTvWarning);
    }


    /**
     * 初始化各类输入框的值
     */
    private void initViews(){
        userName = MMKVUtil.getString(CacheKey.USER_NAME);
        currUserName = userName;
        passWord = MMKVUtil.getString(CacheKey.USER_PASSWORD);
        isRemember = MMKVUtil.getBoolean(CacheKey.REMEMBER_PASSWORD,true);

        if(!StringUtils.isEmpty(userName)){
            loginEtUsername.setText(userName);
            loginEtUsername.setSelection(userName.length());
            loginEtUsername.setClearIconVisible(false);
        }

        if(!StringUtils.isEmpty(passWord) && isRemember){
            realPassWord = passWord;
            loginEtPassword.setText("************");
            loginEtPassword.setSelection(12);
            loginEtPassword.setClearIconVisible(false);
            loginEyePass.setVisibility(View.GONE);
        }

        if(!StringUtils.isEmpty(passWord) && !StringUtils.isEmpty(userName)){
            loginCommit.setEnabled(true);
        }

        loginRememberPass.setChecked(isRemember);

    }

    @OnClick({R.id.login_eye_pass, R.id.login_iv_code, R.id.login_remember_pass})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.login_eye_pass:
                showHidePassWord();
                break;
            case R.id.login_iv_code:
                loginViewMoel.drivingLoadVerify();
                break;
            case R.id.login_remember_pass:
                if(loginRememberPass.isChecked()){
                    loginRememberPass.setChecked(false);
                }else {
                    loginRememberPass.setChecked(true);
                }
                break;
        }
    }


    SingleOnClickListener singleOnClickListener = new SingleOnClickListener() {
        @Override
        public void onSingleClick(View view) {
            switch (view.getId()) {
                case R.id.login_commit://提交
                    loginTvWarning.setText("");
                    loginEtCode.clearFocus();
                    loginEtPassword.clearFocus();
                    loginEtUsername.clearFocus();
                    userName = loginEtUsername.getText().toString();
                    if(StringUtils.isEmpty(realPassWord)){
                        passWord = loginEtPassword.getText().toString().trim();
                    }else {
                        passWord = realPassWord;
                    }
                    verifyCode = loginEtCode.getText().toString().trim();
                    loginViewMoel.login(userName, passWord, verifyCode, loginLayoutCode.getVisibility() == View.VISIBLE);
                    KeyboardUtils.hideSoftInput(view);
                    break;
                case R.id.login_forget_pass://找回密码
                    KeyboardUtils.hideSoftInput(view);
                    ((ABBaseFragment)getParentFragment()).start(ForgetMainFragment.getInstance());
                    break;
            }
        }
    };

    protected void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(mContext);
            progressDialog = new XPopup.Builder(mContext)
                    .isRequestFocus(false)  //loading不要焦点
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        progressDialog.show();
    }


    private void showHidePassWord(){
        TransformationMethod type= loginEtPassword.getTransformationMethod();
        if (PasswordTransformationMethod.getInstance().equals(type)){
            loginEtPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            loginEyePass.setImageResource(R.mipmap.login_eye_show_bg);
        }else {
            loginEtPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            loginEyePass.setImageResource(R.mipmap.login_eye_hide_bg);
        }
        int length = loginEtPassword.getText().toString().length();
        loginEtPassword.setSelection(length);
    }

    /**
     * 登录成功，保存登录信息
     */
    private void saveLoginInfo(UserInfo userInfo){
        MMKVUtil.put(Key.LOGIN_TOKEN, userInfo.getToken());
        MMKVUtil.put(Key.AGENT_TOKEN, userInfo.getToken());
        MMKVUtil.put(Key.SYSTYPE, userInfo.getSysType());
        MMKVUtil.put(Key.LOGIN_PHONE, userInfo.getPhone());
        MMKVUtil.put(Key.INVITE_CODE, userInfo.getInviteCode());
        MMKVUtil.put(Key.IS_USER_LOGIN, true);

        MMKVUtil.put(CacheKey.USER_NAME,userName);
        MMKVUtil.put(CacheKey.USER_PASSWORD,passWord);
        MMKVUtil.put(CacheKey.USER_LOGIN_TIME, System.currentTimeMillis());//上次登录时间
        MMKVUtil.put(CacheKey.REMEMBER_PASSWORD,loginRememberPass.isChecked());
    }

    @Override
    public void onStop() {
        super.onStop();
        SystemModel.loginUserInfo.postValue(null);
    }

    /**
     * 站点差异化处理
     */
    private void initSiteStyle(){
        SiteConfig siteConfig = (SiteConfig) SiteSdk.ins();
        Drawable drawable = ResUtils.getDrawable(ResUtils.getDrawableId(siteConfig.getSiteType() +"_login_check_style"));
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        loginRememberPass.setCompoundDrawables(drawable, null, null, null);
    }
}
