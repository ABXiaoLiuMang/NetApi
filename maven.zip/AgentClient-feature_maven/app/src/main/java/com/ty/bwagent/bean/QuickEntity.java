package com.ty.bwagent.bean;

/**
 * 描述: 首页快捷入口数据模型
 * <p>
 * author:Dale
 */
public class QuickEntity {

    private String title;
    private String info;
    private int resId;

    public QuickEntity(String title, String info, int resId) {
        this.title = title;
        this.info = info;
        this.resId = resId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }
}
