package com.ty.bwagent.bean;

/**
 * 代存用户信息
 */
public class SaveUserEntity {
    /**
     * email : 11****@qq.com
     * name : boby
     * phone : 173****5679
     * qq : 118****
     * realName : 张**
     * status : 1
     */

    private String email;
    private String name;
    private String phone;
    private String qq;
    private String realName;
    private int status;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
