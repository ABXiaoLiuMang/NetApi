package com.ty.bwagent.exchange;//package com.yabo.exchange.ui;

import com.google.gson.internal.LinkedTreeMap;
import com.ty.net.Request;
import com.ty.net.exception.ErrorMessage;

import java.math.RoundingMode;
import java.util.Map;

public class ExchangePresent{

//    public void exChange(String key) {
//        if (TextUtils.isEmpty(getView().getRateMap().get(key))) {
//            connect(key);
//        } else if (getView().isOnlineRate()) {
//            connect(key);
//        } else if (getView() != null) {
//            getView().onRate(key, getView().getRateMap().get(key));
//        }
//
//    }


//
//    private void connect(String key) {
//        ExchangeSource.convert(key)
//                .showLoaddingDialog("")
//                .isSingleEnable(true)
//                .send(new OnCallBack<Map<String, Object>>() {
//                    @Override
//                    public void success(Request<Map<String, Object>> request,
//                                        Map<String, Object> stringObjectMap) {
//                        try {
//                            if (stringObjectMap != null) {
//                                LogUtils.i(stringObjectMap);
//                                for (String key : stringObjectMap.keySet()) {
//                                    LinkedTreeMap value = (LinkedTreeMap) stringObjectMap.get(key);
//                                    Rate rate = JsonUtil.fromJson(JsonUtil.toJsonTree(value), Rate.class);
//                                    LogUtils.i("key : %s ,汇率: %s", key, rate.getVal());
//                                    BigDecimal decimal = new BigDecimal(rate.getVal())
//                                            .setScale(2, RoundingMode.HALF_UP);
//                                    if (getView() != null) {
//                                        getView().onRate(key, decimal.toPlainString());
//                                    }
//                                }
//                            }
//                        } catch (Exception e) {
////                            LogUtils.e(e);
//                        }
//
//                    }
//
//                    @Override
//                    public void error(Request<Map<String, Object>> request,
//                                      ErrorMessage errorMessage, Map<String, Object> stringObjectMap) {
////                        LogUtils.e(errorMessage.getError());
//                        try {
//                            if (stringObjectMap != null) {
//                                LogUtils.i(stringObjectMap);
//                                for (String key : stringObjectMap.keySet()) {
//                                    LinkedTreeMap value = (LinkedTreeMap) stringObjectMap.get(key);
//                                    Rate rate = JsonUtil.fromJson(JsonUtil.toJsonTree(value), Rate.class);
//                                    LogUtils.i("key : %s ,汇率: %s", key, rate.getVal());
//                                    BigDecimal decimal = new BigDecimal(rate.getVal())
//                                            .setScale(2, RoundingMode.HALF_UP);
//                                    if (getView() != null) {
//                                        getView().onRate(key, decimal.toPlainString());
//                                    }
//                                }
//                            }
//                        } catch (Exception e) {
////                            LogUtils.e(e);
//                        }
//                    }
//                });
//    }
}
