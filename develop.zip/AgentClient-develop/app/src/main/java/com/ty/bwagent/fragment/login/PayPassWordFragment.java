package com.ty.bwagent.fragment.login;

import android.view.View;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.ValueView;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;

import butterknife.BindView;

public class PayPassWordFragment extends ABBaseFragment implements View.OnClickListener {


    @BindView(R.id.valueview_modify_password)
    ValueView valueviewModifyPassword;
    @BindView(R.id.valueview_resert_password)
    ValueView valueviewResertPassword;

    public static PayPassWordFragment getInstance() {
        PayPassWordFragment fragment = new PayPassWordFragment();
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_pay_password;
    }

    @Override
    protected void createProvider() {

    }

    @Override
    protected void initViewsAndEvents() {

        valueviewModifyPassword.setOnClickListener(this);
        valueviewResertPassword.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.valueview_modify_password:
                start(PayPassWordChangeFragment.getInstance());
                break;
            case R.id.valueview_resert_password:
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                if (StringUtils.isEmpty(userInfo.getPhone())) {
                    ToastUtils.showLong("请绑定手机号码后操作");
                    return;
                }
                start(PayPassWordResertFragment.getInstance());
                break;
        }
    }
}
