package com.ty.bwagent.fragment.deposit.viewmodel;

import androidx.lifecycle.MutableLiveData;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.SaveUserEntity;
import com.ty.bwagent.bean.TurnUserEntity;
import com.ty.bwagent.utils.Md5Util;
import com.ty.bwagent.viewmodel.CodeViewModel;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

/**
 * 代理代存
 */
public class SaveViewModel extends CodeViewModel {

    //代理代存提交结果
    public NetLiveData<BaseEntity> saveLiveData = new NetLiveData<>();

    //代理转账-获取下级用户信息接口
    public NetLiveData<BaseEntity<SaveUserEntity>> saveUserInfoLiveData = new NetLiveData<>();

    //管代 代存
    public void commitLimitSave(int proxyType,String account,String money,String password,String note,String flowRatio){
        NetSdk.create(Api.class)
                .agentDeposit()
                .params("proxyType",proxyType)
                .params("agentName",account)
                .params("amount", money)
                .params("payPassword",Md5Util.md5(password))
                .params("remark",note)
                .params("flowRatio",flowRatio)
                .params("validateType","2")//1 手机短信 2 支付密码
                .asJSONType()
                .send(saveLiveData);
    }

    //普代 代存
    public void commitMoneySave(int proxyType,String account,String money,String code,String note,String flowRatio){
        NetSdk.create(Api.class)
                .agentDeposit()
                .params("proxyType",proxyType)
                .params("agentName",account)
                .params("amount", money)
                .params("remark",note)
                .params("phoneCode",code)
                .params("flowRatio",flowRatio)
                .params("validateType","1")//1 手机短信 2 支付密码
                .asJSONType()
                .send(saveLiveData);
    }

    //代理转账-获取下级用户信息接口
    public void agentDepositInfo(String agentName){
        NetSdk.create(Api.class)
                .agentDepositInfo()
                .params("memberName",agentName)
                .asJSONType()
                .send(saveUserInfoLiveData);
    }
}
