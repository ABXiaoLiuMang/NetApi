package com.ty.bwagent.fragment;


import androidx.annotation.ColorRes;
import androidx.lifecycle.ViewModelProvider;

import com.tianyu.updater.entity.UpdateEntity;
import com.ty.bwagent.App;
import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.R;
import com.ty.bwagent.update.XDialogManager;
import com.ty.bwagent.update.XUpdateManager;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.HomeViewModel;
import com.ty.common.tab.ABMainTabFragment;
import com.ty.common.tab.MainTab;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteType;
import com.ty.utils.LogUtils;
import com.ty.utils.StringUtils;

public class MainFragment extends ABMainTabFragment {

    HomeViewModel mHomeViewModel;
    private XDialogManager xDialogManager = new XDialogManager();

    public static MainFragment getInstance() {
        return new MainFragment();
    }


    @Override
    protected void createProvider() {
        mHomeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);
        //监听更新
        XLiveDataManager.getInstance().updateResult.observe(this, new SimpleObserver<UpdateEntity>() {
            @Override
            protected void onSuccess(UpdateEntity updateEntity) {
                if (currentIndex == 0) {//首页
                    if (!App.is_showing_update_dialog && !StringUtils.isEmpty(updateEntity.getVersionName()) && isSupportVisible()) {
                        App.is_showing_update_dialog = true;
                        XUpdateManager.showUpdateDialog(mContext, xDialogManager, updateEntity, () -> {
                            mHomeViewModel.querySpecialNotice();//重要通告
                        });
                    } else {
                        mHomeViewModel.querySpecialNotice();//重要通告
                    }
                } else if (currentIndex == 4) {//我的
                    if (updateEntity.getUpdateInfo().getForce() == 2 && isSupportVisible()) {//我的界面是强制更新在弹窗
                        XUpdateManager.showUpdateDialog(mContext, null, updateEntity, null);
                    }
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                mHomeViewModel.querySpecialNotice();//重要通告
            }
        });
    }


    @Override
    protected MainTab[] getMainTabs() {
        MainTab[] mainTabs = new MainTab[5];

        switch (Integer.valueOf(BuildConfig.appType)) {
            case 4://火狐
                mainTabs[0] = new MainTab("首页", "", R.mipmap.main_tab_home_normal, R.mipmap.huohu_main_tab_home_hold);
                mainTabs[1] = new MainTab("成员", "", R.mipmap.main_tab_member_normal, R.mipmap.huohu_main_tab_member_hold);
                mainTabs[2] = new MainTab("推广", "", R.mipmap.main_tab_share_normal, R.mipmap.huohu_main_tab_share_hold);
                mainTabs[3] = new MainTab("佣金", "", R.mipmap.main_tab_charge_normal, R.mipmap.huohu_main_tab_charge_hold);
                mainTabs[4] = new MainTab("我的", "", R.mipmap.main_tab_my_normal, R.mipmap.huohu_main_tab_my_hold);
                break;
            case 6://亿博
                mainTabs[0] = new MainTab("首页", "", R.mipmap.main_tab_home_normal, R.mipmap.yibo_main_tab_home_hold);
                mainTabs[1] = new MainTab("成员", "", R.mipmap.main_tab_member_normal, R.mipmap.yibo_main_tab_member_hold);
                mainTabs[2] = new MainTab("推广", "", R.mipmap.main_tab_share_normal, R.mipmap.yibo_main_tab_share_hold);
                mainTabs[3] = new MainTab("佣金", "", R.mipmap.main_tab_charge_normal, R.mipmap.yibo_main_tab_charge_hold);
                mainTabs[4] = new MainTab("我的", "", R.mipmap.main_tab_my_normal, R.mipmap.yibo_main_tab_my_hold);
                break;
            case 7://AOA
                mainTabs[0] = new MainTab("首页", "", R.mipmap.main_tab_home_normal, R.mipmap.aoa_main_tab_home_hold);
                mainTabs[1] = new MainTab("成员", "", R.mipmap.main_tab_member_normal, R.mipmap.aoa_main_tab_member_hold);
                mainTabs[2] = new MainTab("推广", "", R.mipmap.main_tab_share_normal, R.mipmap.aoa_main_tab_share_hold);
                mainTabs[3] = new MainTab("佣金", "", R.mipmap.main_tab_charge_normal, R.mipmap.aoa_main_tab_charge_hold);
                mainTabs[4] = new MainTab("我的", "", R.mipmap.main_tab_my_normal, R.mipmap.aoa_main_tab_my_hold);
                break;
            case 8://环球
                mainTabs[0] = new MainTab("首页", "", R.mipmap.main_tab_home_normal, R.mipmap.hqbet_main_tab_home_hold);
                mainTabs[1] = new MainTab("成员", "", R.mipmap.main_tab_member_normal, R.mipmap.hqbet_main_tab_member_hold);
                mainTabs[2] = new MainTab("推广", "", R.mipmap.main_tab_share_normal, R.mipmap.hqbet_main_tab_share_hold);
                mainTabs[3] = new MainTab("佣金", "", R.mipmap.main_tab_charge_normal, R.mipmap.hqbet_main_tab_charge_hold);
                mainTabs[4] = new MainTab("我的", "", R.mipmap.main_tab_my_normal, R.mipmap.hqbet_main_tab_my_hold);
                break;
            case 5://KOK
            default:
                mainTabs[0] = new MainTab("首页", "", R.mipmap.main_tab_home_normal, R.mipmap.kok_main_tab_home_hold);
                mainTabs[1] = new MainTab("成员", "", R.mipmap.main_tab_member_normal, R.mipmap.kok_main_tab_member_hold);
                mainTabs[2] = new MainTab("推广", "", R.mipmap.main_tab_share_normal, R.mipmap.kok_main_tab_share_hold);
                mainTabs[3] = new MainTab("佣金", "", R.mipmap.main_tab_charge_normal, R.mipmap.kok_main_tab_charge_hold);
                mainTabs[4] = new MainTab("我的", "", R.mipmap.main_tab_my_normal, R.mipmap.kok_main_tab_my_hold);
                break;
        }


        return mainTabs;
    }

    protected @ColorRes
    int getTextColor() {
        int resId;
        switch (Integer.valueOf(BuildConfig.appType)) {
            case 4://火狐
                resId = R.color.huohu_main_tab_color;
                break;
            case 6://亿博
                resId = R.color.yibo_main_tab_color;
                break;
            case 7://AOA
                resId = R.color.aoa_main_tab_color;
                break;
            case 8://环球
                resId = R.color.hqbet_main_tab_color;
                break;
            case 5://KOK
            default:
                resId = R.color.kok_main_tab_color;
                break;
        }
        return resId;
    }

    @Override
    protected ABBaseFragment[] getFragments() {
        ABBaseFragment[] fragments = new ABBaseFragment[5];
        fragments[0] = HomeFragment.getInstance();
        fragments[1] = MemberFragment.getInstance();
        fragments[2] = ExtensionTabFragment.getInstance();
        fragments[3] = FinanceFragment.getInstance();
        fragments[4] = MyCenterFragment.getInstance();
        return fragments;
    }


    @Override
    public void onStop() {
        super.onStop();
        if (getActivity() != null && getActivity().isFinishing()) {
            //记得清空列表
            xDialogManager.clear();
            xDialogManager = null;
        }
    }

}
