package com.ty.bwagent.dialog;

import android.view.View;
import android.widget.EditText;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupAnimation;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.viewmodel.SubordinateAuditViewModle;
import com.ty.common.util.AlphaAnimator;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.StringUtils;

import androidx.fragment.app.Fragment;

/**
 * 下级审核拒绝审核通过弹框
 */
public class SubAuditRefusePopup extends ConfirmPopupView {

    EditText et_input;
    Fragment fragment;
    private String id;
    BasePopupView progressDialog;
    private final SubordinateAuditViewModle subordinateAuditViewModle;

    public SubAuditRefusePopup(Fragment fragment, String id) {
        super(fragment.getContext());
        this.fragment = fragment;
        this.id = id;
        this.title = "审核拒绝";
        subordinateAuditViewModle = new SubordinateAuditViewModle();
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_sub_audit;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();

        et_input = findViewById(R.id.et_input);
        tv_content = findViewById(R.id.tv_content);

        et_input.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tv_content.setText("");
                tv_content.setVisibility(GONE);
            }
        });
        setListener(() -> {
            if (StringUtils.isEmpty(et_input.getText().toString().trim())) {
                tv_content.setVisibility(VISIBLE);
                tv_content.setText("请输入备注！");
                return;
            }
            KeyboardUtils.hideSoftInput(et_input);
            subordinateAuditViewModle.updateReview("1", this.id, et_input.getText().toString().trim());
        }, null);
        initViewsAndEvents();
    }

    /**
     * 一系列监听回调
     */
    private void initViewsAndEvents() {

        subordinateAuditViewModle.updateReviewLiveData.observeForever(new NetObserver<BaseEntity>() {

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                dismiss();
            }

            @Override
            protected void onError(int code, String errMsg) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText(errMsg);
            }

        });
    }

    @Override
    public void dismiss() {
        super.dismiss();
        subordinateAuditViewModle.updateReviewLiveData.removeObservers(fragment);
    }


    @Override
    protected void doAfterShow() {
        super.doAfterShow();
        KeyboardUtils.showSoftInput(et_input);
    }


    @Override
    protected void doAfterDismiss() {
        super.doAfterDismiss();
        KeyboardUtils.hideSoftInput(et_input);
    }

    private void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(fragment.getContext(), fragment);
            progressDialog = new XPopup.Builder(fragment.getContext())
                    .isRequestFocus(false)  //loading不要焦点
                    .hasShadowBg(false)
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        progressDialog.show();
    }

    private void dismissProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }


}