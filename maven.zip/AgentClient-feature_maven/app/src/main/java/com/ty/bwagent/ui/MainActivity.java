package com.ty.bwagent.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;
import android.view.KeyEvent;

import androidx.annotation.Nullable;

import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.MainFragment;
import com.ty.bwagent.update.XUpdateManager;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.common.ui.ABBaseActivity;
import com.ty.common.util.ABConfig;
import com.ty.utils.ExitUtils;
import com.ty.utils.ToastUtils;
import com.ty.utils.TopActivityManager;
import com.yabo.tymonitor.TYTingyunMonitor;

public class MainActivity extends ABBaseActivity {


    /**
     * 启动主activity
     * @param requetUpadae 是否请求更新（登录过来不用请求更新）
     */
    public static void startMainActiviy(boolean requetUpadae){
        Activity activity = TopActivityManager.getInstance().getCurActivity();
        Bundle bundle = new Bundle();
        bundle.putBoolean(ABConfig.KEY_TAG,requetUpadae);
        Intent intent = new Intent();
        intent.setClass(activity, MainActivity.class);
        intent.putExtras(bundle);
        activity.startActivity(intent);
        activity.overridePendingTransition(com.ty.common.R.anim.x_push_left_in, com.ty.common.R.anim.x_push_left_out);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_root;
    }

    @Override
    protected void createProvider() {
        TYTingyunMonitor.traceUserWithID("");
    }

    @Override
    protected void initViewsAndEvents() {
        if (findFragment(MainFragment.class) == null) {
            loadRootFragment(R.id.fl_container, MainFragment.getInstance());
        }
        XLiveDataManager.getInstance().getUserInfo();
        if(bundle.getBoolean(ABConfig.KEY_TAG,false)){
            XLiveDataManager.getInstance().checkUpdate();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        App.goPhoto = false;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            exit();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void exit() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if (count > 1) {
            pop();
        } else {
            exitApp(2000);
        }
    }

    private long mExitTime;
    public void exitApp(long doubleClickTime) {
        try {
            if (doubleClickTime <= 0){
                Process.killProcess(android.os.Process.myPid());
                System.gc();
                System.exit(0);
            }else if ((System.currentTimeMillis() - mExitTime) > doubleClickTime) {
                ToastUtils.showLong("再按一次退出程序");
                mExitTime = System.currentTimeMillis();
            } else {
                ExitUtils.getInstance().finishAll();
                Process.killProcess(android.os.Process.myPid());
                System.gc();
                System.exit(0);
            }
        } catch (Exception e) {
        }
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        UMShareAPI.get(this).onActivityResult(requestCode,resultCode,data);
//    }


}
