package com.ty.bwagent.fragment.login;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.view.View;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.Key;
import com.ty.bwagent.utils.SimpleFocusChangeListener;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.RegisterViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.NetObserver;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

public class RegisterFragment extends ABBaseFragment {

    private static final String REGISTER_CODE_KEY = "register_code_key";
    @BindView(R.id.register_tv_warning)
    TextView registerTvWarning;
    @BindView(R.id.register_et_username)
    ClearEditText registerEtUsername;
    @BindView(R.id.register_et_password)
    ClearEditText registerEtPassword;
    @BindView(R.id.register_eye_pass)
    ImageView registerEyePass;
    @BindView(R.id.register_et_phone)
    ClearEditText registerEtPhone;
    @BindView(R.id.register_et_code)
    ClearEditText registerEtCode;
    @BindView(R.id.register_tv_code)
    TextView registerTvCode;
    @BindView(R.id.register_remember_pass)
    CheckedTextView registerRememberPass;
    @BindView(R.id.register_commit)
    TextView registerCommit;
    boolean isTimer;

    RegisterViewModel registerViewMoel;
    String phone;
    String userName;
    String passWord;


    public static RegisterFragment getInstance() {
        return new RegisterFragment();
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_register;
    }

    @Override
    protected void createProvider() {
        registerViewMoel =  new ViewModelProvider(this).get(RegisterViewModel.class);

        //验证码倒计时
        registerViewMoel.timerLiveData.observe(this, aLong -> {
            if(aLong == 0){
                isTimer = false;
                registerTvCode.setText(ResUtils.getString(R.string.generic_reset_code));
                phone = registerEtPhone.getText().toString().trim();
                if(ParameterVerification.isPhoneNumber(phone)){
                    registerTvCode.setEnabled(true);
                }else {
                    registerTvCode.setEnabled(false);
                }
            }else {
                isTimer = true;
                registerTvCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time),aLong));
                registerTvCode.setEnabled(false);
            }
        });

        //监听注册结果
        registerViewMoel.registerLiveData.observe(this, new NetObserver<BaseEntity<UserInfo>>() {
            @Override
            protected void onSuccess(BaseEntity<UserInfo> baseEntity) {
                UserInfo userInfo = baseEntity.getData();
                MMKVUtil.put(Key.LOGIN_TOKEN, userInfo.getToken());
                MMKVUtil.put(Key.AGENT_TOKEN, userInfo.getToken());
                MMKVUtil.put(Key.SYSTYPE, userInfo.getSysType());
                MMKVUtil.put(Key.LOGIN_PHONE, userInfo.getPhone());
                MMKVUtil.put(Key.INVITE_CODE, userInfo.getInviteCode());
                MMKVUtil.put(CacheKey.USER_LOGIN_TIME, System.currentTimeMillis());//上次登录时间
                MMKVUtil.put(Key.IS_USER_LOGIN, true);
                MMKVUtil.put(CacheKey.USER_NAME,userName);
                MMKVUtil.put(CacheKey.USER_PASSWORD,passWord);
                MMKVUtil.put(CacheKey.REMEMBER_PASSWORD,true);
                UserInfoCache.getInstance().saveUserInfo(userInfo);
                XLiveDataManager.getInstance().userInfo.postNext(baseEntity.getData());
                MainActivity.startMainActiviy(false);
                getActivity().finish();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                registerTvWarning.setText(errMsg);
            }
        });

        //监听验证码
        registerViewMoel.codeLivedata.observe(this,new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ToastUtils.showLong("验证码已发送");
                MMKVUtil.put(REGISTER_CODE_KEY, System.currentTimeMillis());
                registerViewMoel.startTimer(getLifecycle());
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
                registerTvCode.setEnabled(true);
                MMKVUtil.put(REGISTER_CODE_KEY, System.currentTimeMillis());
                Utils.isClickedReset60S(errMsg,getLifecycle(),registerViewMoel,registerTvCode);
            }
        });

    }

    @Override
    protected void initViewsAndEvents() {
        initVerify();//处理输入框失去焦点的提示逻辑
        registerViewMoel.autoLoadVerify();//自动加载验证码
        Utils.isClicked60S(REGISTER_CODE_KEY,getLifecycle(),registerViewMoel,registerTvCode);
    }


    @OnClick({R.id.register_eye_pass, R.id.register_tv_code, R.id.register_remember_pass, R.id.register_commit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.register_eye_pass:
                showHidePassWord();
                break;
            case R.id.register_tv_code://获取验证码
                registerTvCode.setEnabled(false);
                phone = registerEtPhone.getText().toString().trim();
                registerViewMoel.getPhoneCode(phone);
                break;
            case R.id.register_remember_pass:// 同意条款
                if(registerRememberPass.isChecked()){
                    registerRememberPass.setChecked(false);
                }else {
                    registerRememberPass.setChecked(true);
                }
                break;
            case R.id.register_commit:
                registerCommit();
                break;
        }
    }

    /**
     * 注册提交
     * (抽离出来，火狐重写此方法即可)
     */
    protected void registerCommit(){
        userName = registerEtUsername.getText().toString().trim();
        passWord = registerEtPassword.getText().toString().trim();
        phone = registerEtPhone.getText().toString().trim();
        String code = registerEtCode.getText().toString().trim();
        registerTvWarning.setText("");
        registerViewMoel.register(userName,passWord,phone,code);
    }


    /**
     * 处理各类输入框验证逻辑
     */
    private void initVerify(){
        new InputResultCalculator(Arrays.asList(registerEtPhone), ok -> {
            phone = registerEtPhone.getText().toString();
            if(ParameterVerification.isPhoneNumber(phone) && !isTimer){
                registerTvCode.setEnabled(ok);
            }else {
                registerTvCode.setEnabled(false);
            }
        });

        initCommitEnabled();

        new SimpleFocusChangeListener(registerTvWarning,registerEtUsername,registerEtPassword);
        new SimpleFocusChangeListener(registerTvWarning,registerEtUsername,registerEtPhone);
        new SimpleFocusChangeListener(registerTvWarning,registerEtUsername,registerEtCode);
        verifyUserName(registerEtUsername,registerTvWarning);
    }


    /**
     *
     * 提交按钮可点击状态监听
     * (抽离出来，火狐重写此方法即可)
     */
    protected void initCommitEnabled(){
        new InputResultCalculator(Arrays.asList(registerEtUsername, registerEtPassword, registerEtPhone, registerEtCode), ok -> {
            String userName = registerEtUsername.getText().toString().trim();
            if (VerifyUtils.isUserName(userName)) {
                registerCommit.setEnabled(ok);
            }else {
                registerCommit.setEnabled(false);
            }
        });
    }

    private void showHidePassWord() {
        TransformationMethod type = registerEtPassword.getTransformationMethod();
        if (PasswordTransformationMethod.getInstance().equals(type)) {
            registerEtPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            registerEyePass.setImageResource(R.mipmap.login_eye_show_bg);
        } else {
            registerEtPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            registerEyePass.setImageResource(R.mipmap.login_eye_hide_bg);
        }
        registerEtPassword.setSelection(registerEtPassword.getText().toString().length());
    }

    private void verifyUserName(ClearEditText etUserName, TextView tvWarn){
        etUserName.setOnFocusChangeListener((v, hasFocus) -> {
            String userName = etUserName.getText().toString().trim();

            if(hasFocus){//获的焦点
                if (StringUtils.length(userName) > 0){
                    etUserName.setClearIconVisible(true);
                }
                tvWarn.setText("");
            }else {//失去焦点

                if (StringUtils.length(userName) < 4 && StringUtils.length(userName) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_register_warn));
                }
            }
        });
    }
}
