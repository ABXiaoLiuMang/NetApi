package com.ty.bwagent.dialog;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.DrawingEntity;
import com.ty.bwagent.utils.Utils;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

/**
 * 提款中心钱包确认对话框
 */
public class DrawingCenterPopup extends ConfirmPopupView {


    TextView draw_money;
    DrawingEntity drawingEntity;

    public DrawingCenterPopup(@NonNull Context context, DrawingEntity drawingEntity) {
        super(context);
        this.drawingEntity = drawingEntity;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_drawing_center;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        draw_money = findViewById(R.id.draw_money);
        draw_money.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_draw_money), Utils.roundDownMoney(StringUtils.parseDouble(drawingEntity.getMoney()))));
    }
}
