package com.ty.bwagent.utils;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupPosition;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.lxj.xpopup.interfaces.OnConfirmListener;
import com.lxj.xpopup.interfaces.SimpleCallback;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.bean.DepositEntity;
import com.ty.bwagent.bean.DrawingEntity;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.bean.RecordFilterEntity;
import com.ty.bwagent.bean.SpecialNoticeEntity;
import com.ty.bwagent.dialog.AddSubordinatePopup;
import com.ty.bwagent.dialog.BindEmailPopup;
import com.ty.bwagent.dialog.BindPhonePopup;
import com.ty.bwagent.dialog.BindQQPopup;
import com.ty.bwagent.dialog.CommonDialogPopView;
import com.ty.bwagent.dialog.CreatePicPopup;
import com.ty.bwagent.dialog.DepositPopup;
import com.ty.bwagent.dialog.DepositTipsPopup;
import com.ty.bwagent.dialog.DrawingCenterPopup;
import com.ty.bwagent.dialog.DrawingPopup;
import com.ty.bwagent.dialog.ExtensionFilterPopup;
import com.ty.bwagent.dialog.FisrtLoginPopup;
import com.ty.bwagent.dialog.MaterialTipsPopup;
import com.ty.bwagent.dialog.MemberSortPopup;
import com.ty.bwagent.dialog.MemberTipPopup;
import com.ty.bwagent.dialog.NoticePopup;
import com.ty.bwagent.dialog.NoticeSimplePopup;
import com.ty.bwagent.dialog.OverFlowFindPopup;
import com.ty.bwagent.dialog.OverFlowPopup;
import com.ty.bwagent.dialog.RecordFilterPopup;
import com.ty.bwagent.dialog.SelectDialogItemPopup;
import com.ty.bwagent.dialog.SharePopup;
import com.ty.bwagent.dialog.SubAuditRefusePopup;
import com.ty.bwagent.dialog.TurnTipsPopup;
import com.ty.bwagent.dialog.UpHeadPopup;
import com.ty.common.view.TitleBar;
import com.ty.tysite.SiteSdk;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;

import java.util.List;

public class DialogUtil {


    /**
     * 代理代存提示弹窗
     *
     * @param mContext
     */
    public static void showDepositTipsDialog(Context mContext) {
        DepositTipsPopup confirmPopupView = new DepositTipsPopup(mContext);
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
    }

    /**
     * 代理转账提示弹窗
     *
     * @param mContext
     */
    public static void showTurnTipsDialog(Context mContext) {
        TurnTipsPopup confirmPopupView = new TurnTipsPopup(mContext);
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
    }

    /**
     * 分享素材提示弹窗
     *
     * @param mContext
     */
    public static void showMaterialTipsDialog(Context mContext) {
        MaterialTipsPopup confirmPopupView = new MaterialTipsPopup(mContext);
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
    }

    /**
     * 成员中右上角提示弹窗
     *
     * @param mContext
     */
    public static void showMemberTipsDialog(Context mContext) {
        MemberTipPopup confirmPopupView = new MemberTipPopup(mContext);
        confirmPopupView.setTitleContent("温馨提示", ResUtils.getString(R.string.generic_member_tips), "")
                .setConfirmText("我知道了")
                .hideCancelBtn()
                .setConfirmTextColor(SiteSdk.ins().styleColor());
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
    }

    /**
     * 佣金中右上角提示弹窗
     *
     * @param mContext
     */
    public static void showFinanceTipsDialog(Context mContext) {
        MemberTipPopup confirmPopupView = new MemberTipPopup(mContext);
        confirmPopupView.bindLayout(R.layout.custom_dialog_member_center)
                .setTitleContent("温馨提示", ResUtils.getString(R.string.generic_finance_tips), "")
                .setConfirmText("我知道了")
                .hideCancelBtn()
                .setConfirmTextColor(SiteSdk.ins().styleColor());
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
    }

    /**
     * 绑定电话弹窗
     */
    public static void showBindPhoneDailog(Fragment fragment) {
        BindPhonePopup centerBindPopup = new BindPhonePopup(fragment);
        centerBindPopup.setConfirmTextColor(SiteSdk.ins().styleColor());
        BasePopupView show = new XPopup.Builder(fragment.getContext())
                .autoDismiss(false)
                .dismissOnTouchOutside(false)
                .dismissOnBackPressed(false)
                .asCustom(centerBindPopup)
                .show();
        //点击外部键盘收起来
        show.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        KeyboardUtils.hideSoftInput(fragment.getActivity());
                        break;
                }
                return false;
            }
        });
    }

    /**
     * 邮箱弹窗弹窗
     */
    public static void showBindEmailDailog(Fragment fragment) {
        BindEmailPopup centerBindPopup = new BindEmailPopup(fragment);
        centerBindPopup.setConfirmTextColor(SiteSdk.ins().styleColor());
        BasePopupView show = new XPopup.Builder(fragment.getContext())
                .moveUpToKeyboard(true)
                .autoDismiss(false)
                .dismissOnTouchOutside(false)
                .dismissOnBackPressed(false)
                .asCustom(centerBindPopup).show();

        //点击外部键盘收起来
        show.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        KeyboardUtils.hideSoftInput(fragment.getActivity());
                        break;
                }
                return false;
            }
        });
    }

    /**
     * 邮箱弹窗弹窗
     */
    public static void showBindQQDailog(Fragment fragment) {
        BindQQPopup centerBindPopup = new BindQQPopup(fragment);
        centerBindPopup.setConfirmTextColor(SiteSdk.ins().styleColor());
        BasePopupView show = new XPopup.Builder(fragment.getContext())
                .moveUpToKeyboard(true)
                .autoDismiss(false)
                .dismissOnTouchOutside(false)
                .dismissOnBackPressed(false)
                .asCustom(centerBindPopup).show();

        //点击外部键盘收起来
        show.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        KeyboardUtils.hideSoftInput(fragment.getActivity());
                        break;
                }
                return false;
            }
        });
    }

    /**
     * 分享生成图片弹窗
     */
    public static void createPicDailog(Context context, String shareUrl) {
        CreatePicPopup createPicPopup = new CreatePicPopup(context, shareUrl);
        new XPopup.Builder(context)
                .dismissOnBackPressed(false)
                .asCustom(createPicPopup)
                .show();
    }

    /**
     * 推广分享弹窗
     */
    public static void createShareDailog(Context mContext, ExtensionEntity mExtensionEntity) {
        SharePopup sharePopup = new SharePopup(mContext, mExtensionEntity);
        new XPopup.Builder(mContext)
                .asCustom(sharePopup)
                .show();
    }

    /**
     * 提款金额确认弹窗
     */
    public static DrawingPopup drawingDailog(Context mContext, DrawingEntity drawingEntity) {
        DrawingPopup drawingPopup = new DrawingPopup(mContext, drawingEntity);
        new XPopup.Builder(mContext)
                .dismissOnBackPressed(false)
                .dismissOnTouchOutside(false)
                .asCustom(drawingPopup)
                .show();
        return drawingPopup;
    }

    /**
     * 代转金额确认弹窗
     */
    public static DepositPopup depositPopupDailog(Context mContext, DepositEntity drawingEntity) {
        DepositPopup depositPopup = new DepositPopup(mContext, drawingEntity);
        new XPopup.Builder(mContext)
                .dismissOnBackPressed(false)
                .dismissOnTouchOutside(false)
                .asCustom(depositPopup)
                .show();
        return depositPopup;
    }

    /**
     * 提款到钱包 提款金额确认弹窗
     */
    public static DrawingCenterPopup drawingPopupDailog(Context mContext, DrawingEntity drawingEntity) {
        DrawingCenterPopup drawingPopup = new DrawingCenterPopup(mContext, drawingEntity);
        new XPopup.Builder(mContext)
                .dismissOnBackPressed(false)
                .dismissOnTouchOutside(false)
                .asCustom(drawingPopup)
                .show();
        return drawingPopup;
    }

    /**
     * 推广域名的筛选弹窗
     */
    public static ExtensionFilterPopup extensionFilterPopupDailog(Context mContext, TitleBar titleBar) {
        ExtensionFilterPopup extensionFilterPopup = new ExtensionFilterPopup(mContext);
        new XPopup.Builder(mContext)
                .atView(titleBar)
                .asCustom(extensionFilterPopup).show();
        return extensionFilterPopup;
    }

    /**
     * 第一次登录弹框
     */
    public static void fisrtLoginDailog(Context mContext, BaseEntity<ContactUsEntity> entity, SimpleCallback simpleCallback) {
        FisrtLoginPopup customPopup = new FisrtLoginPopup(mContext, entity.getData());
        new XPopup.Builder(mContext)
                .dismissOnBackPressed(true)
                .setPopupCallback(simpleCallback)
                .dismissOnTouchOutside(true)
                .asCustom(customPopup)
                .show();
    }

    /**
     * 成员下级列表排序弹框
     */
    public static MemberSortPopup memberSortDailog(Context mContext, TextView memberSort) {
        MemberSortPopup memberSortPopup = new MemberSortPopup(mContext);
        new XPopup.Builder(mContext)
                .atView(memberSort)
                .popupPosition(PopupPosition.Bottom)
                .asCustom(memberSortPopup)
                .show();
        return memberSortPopup;
    }

    /**
     * 首页通知栏弹框
     */
    public static NoticePopup noticeDailog(Context mContext, List<SpecialNoticeEntity> entityList) {
        NoticePopup customPopup = new NoticePopup(mContext, entityList);
        new XPopup.Builder(mContext)
                .dismissOnBackPressed(false)
                .dismissOnTouchOutside(false)
                .asCustom(customPopup)
                .show();
        return customPopup;
    }

    /**
     * 普通公告(点击后进入详情)
     */
    public static ConfirmPopupView confirmDailog(Context mContext, SpecialNoticeEntity listBean, OnConfirmListener confirmListener) {
        ConfirmPopupView confirmPopupView = new NoticeSimplePopup(mContext);
        confirmPopupView.setTitleContent(listBean.getTitle(), listBean.getContent(), "")
                .setConfirmText(ResUtils.getString(R.string.generic_see_all))
                .setListener(confirmListener, null)
                .hideCancelBtn()
                .setConfirmTextColor(SiteSdk.ins().styleColor());
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
        return confirmPopupView;
    }

    /**
     * 提款记录tab界面
     */
    public static RecordFilterPopup recordFilterDailog(Context mContext, TitleBar titleBar, MutableLiveData<RecordFilterEntity> filterLiveData, MutableLiveData<RecordFilterEntity> resetLiveData) {
        RecordFilterPopup recordFilterPopup = new RecordFilterPopup(mContext, filterLiveData, resetLiveData);
        new XPopup.Builder(mContext)
                .atView(titleBar)
                .asCustom(recordFilterPopup);
        return recordFilterPopup;
    }

    /**
     * 上传头像
     */
    public static UpHeadPopup upHeadPopupDailog(Fragment fragment, UpHeadPopup.Builder builder) {
        UpHeadPopup upHeadPopup = new UpHeadPopup(fragment, builder);
        new XPopup.Builder(fragment.getContext())
                .asCustom(upHeadPopup)
                .show();
        return upHeadPopup;
    }


    /**
     * 代理转账弹框
     */
    public static ConfirmPopupView confirmPayPassWordDailog(Context mContext, OnConfirmListener confirmListener) {
        ConfirmPopupView confirmPopupView = new ConfirmPopupView(mContext);
        confirmPopupView.bindLayout(R.layout.custom_dialog_center_black);
        confirmPopupView.setTitleContent("提示", "为了您的资金安全，请先设置支付密码", "")
                .setConfirmText(ResUtils.getString(R.string.generic_setting_pay))
                .setCancelText("取消")
                .setListener(confirmListener, null)
                .setConfirmTextColor(SiteSdk.ins().styleColor());
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
        return confirmPopupView;
    }

    /**
     * 统一确定弹框的处理
     */
    public static CommonDialogPopView commonDialogShow(Context mContext, String title, String titleContent, String bntRight, boolean onTouchOutside, OnConfirmListener confirmListener) {
        CommonDialogPopView confirmPopupView = new CommonDialogPopView(mContext);
        confirmPopupView.bindLayout(R.layout.custom_dialog_center);
        confirmPopupView.setTitleContent(title, titleContent, "")
                .setConfirmText(bntRight)
                .setCancelText("取消")
                .setListener(confirmListener, null)
                .setConfirmTextColor(SiteSdk.ins().styleColor());
        new XPopup.Builder(mContext)
                .dismissOnTouchOutside(onTouchOutside)
                .dismissOnBackPressed(onTouchOutside)
                .asCustom(confirmPopupView)
                .show();
        return confirmPopupView;
    }


    /**
     * 底部弹框
     */
    public static void createSelectItemDailog(Context mContext, SelectDialogItemPopup.Builder builder) {
        SelectDialogItemPopup sharePopup = new SelectDialogItemPopup(mContext, builder);
        new XPopup.Builder(mContext)
                .hasShadowBg(builder.getHasShadowBg())
                .setPopupCallback(builder.getxPopupCallback() != null ? builder.getxPopupCallback() : null)
                .asCustom(sharePopup)
                .show();
    }

    /**
     * 溢出申请提示弹窗
     *
     * @param mContext
     */
    public static void showOverFlowTipsDialog(Context mContext) {
        OverFlowPopup confirmPopupView = new OverFlowPopup(mContext);
        new XPopup.Builder(mContext)
                .dismissOnBackPressed(true)
                .dismissOnTouchOutside(true)
                .asCustom(confirmPopupView)
                .show();
    }


    /**
     * 溢出查询
     */
    public static void showOverFlowFindDailog(Fragment fragment, OverFlowFindPopup.OnFindClickListener onFindClickListener) {
        OverFlowFindPopup centerBindPopup = new OverFlowFindPopup(fragment, onFindClickListener);
        centerBindPopup.setConfirmTextColor(SiteSdk.ins().styleColor());
        BasePopupView show = new XPopup.Builder(fragment.getContext())
                .moveUpToKeyboard(true)
                .autoDismiss(false)
                .dismissOnTouchOutside(false)
                .dismissOnBackPressed(false)
                .asCustom(centerBindPopup)
                .show();
        //点击外部键盘收起来
        show.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        KeyboardUtils.hideSoftInput(fragment.getActivity());
                        break;
                }
                return false;
            }
        });
    }

    /**
     * 团队管理新增下级弹窗
     */
    public static void addSubordinatePopup(Fragment fragment, AddSubordinatePopup.OnAddAgentClickListener onAddAgentClickListener) {
        AddSubordinatePopup centerBindPopup = new AddSubordinatePopup(fragment, onAddAgentClickListener);
        centerBindPopup.setConfirmTextColor(SiteSdk.ins().styleColor());
        BasePopupView show = new XPopup.Builder(fragment.getContext())
                .moveUpToKeyboard(true)
                .autoDismiss(false)
                .maxWidth((int) (ScreenUtils.getScreenWidth() * 0.75f))
                .dismissOnTouchOutside(false)
                .dismissOnBackPressed(false)
                .asCustom(centerBindPopup)
                .show();
        //点击外部键盘收起来
        show.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        KeyboardUtils.hideSoftInput(fragment.getActivity());
                        break;
                }
                return false;
            }
        });
    }

 /**
     * 团队管理新增下级弹窗
     */
    public static void subAuditRefuse(Fragment fragment,String id) {
        SubAuditRefusePopup centerBindPopup = new SubAuditRefusePopup(fragment,id);
        centerBindPopup.setConfirmTextColor(SiteSdk.ins().styleColor());
        BasePopupView show = new XPopup.Builder(fragment.getContext())
                .moveUpToKeyboard(true)
                .autoDismiss(false)
                .maxWidth((int) (ScreenUtils.getScreenWidth() * 0.75f))
                .dismissOnTouchOutside(false)
                .dismissOnBackPressed(false)
                .asCustom(centerBindPopup)
                .show();
        //点击外部键盘收起来
        show.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        KeyboardUtils.hideSoftInput(fragment.getActivity());
                        break;
                }
                return false;
            }
        });
    }



}
