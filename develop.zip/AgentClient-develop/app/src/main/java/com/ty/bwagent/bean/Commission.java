package com.ty.bwagent.bean;

/**
 * 佣金余额
 */
public class Commission {

    /**
     * agentFreezedMoney : 300.0
     * agentMoney : 998.0
     */

    private double agentFreezedMoney;
    private double agentMoney;
    private double valetMoney;//额度金额

    public double getAgentFreezedMoney() {
        return agentFreezedMoney;
    }

    public void setAgentFreezedMoney(double agentFreezedMoney) {
        this.agentFreezedMoney = agentFreezedMoney;
    }

    public double getAgentMoney() {
        return agentMoney;
    }

    public void setAgentMoney(double agentMoney) {
        this.agentMoney = agentMoney;
    }

    public double getValetMoney() {
        return valetMoney;
    }

    public void setValetMoney(double valetMoney) {
        this.valetMoney = valetMoney;
    }
}
