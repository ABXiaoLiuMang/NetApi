package com.ty.bwagent.utils;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.view.chart.ChartEntity;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class Utils {

    /**
     * 返回成员vip等级图片
     * @return
     */
    public static int getVipResId(String vip){
        int resId = R.mipmap.icon_vip_0;
        switch (vip){
            case "VIP0":
                resId = R.mipmap.icon_vip_0;
                break;
            case "VIP1":
                resId = R.mipmap.icon_vip_1;
                break;
            case "VIP2":
                resId = R.mipmap.icon_vip_2;
                break;
            case "VIP3":
                resId = R.mipmap.icon_vip_3;
                break;
            case "VIP4":
                resId = R.mipmap.icon_vip_4;
                break;
            case "VIP5":
                resId = R.mipmap.icon_vip_5;
                break;
            case "VIP6":
                resId = R.mipmap.icon_vip_6;
                break;
            case "VIP7":
                resId = R.mipmap.icon_vip_7;
                break;
            case "VIP8":
                resId = R.mipmap.icon_vip_8;
                break;
            case "VIP9":
                resId = R.mipmap.icon_vip_9;
                break;
            case "VIP10":
                resId = R.mipmap.icon_vip_10;
                break;
        }
        return resId;
    }

    /***
     * 我的 中处理金额*号显示
     * @param money
     * @return
     */
    public static String getHideMoney(String money){
        StringBuilder stringBuilder = new StringBuilder();
        for(int i = 0 ; i < money.length(); i ++){
            stringBuilder.append("*");
        }
        return stringBuilder.toString();
    }


    /**
     * 保留一位小数，向下取整
     * 柱状图Y坐标数据处理
     * @param maxValue 最大值
     * @param setp 级别
     * @return 返回Y刻度显示字符
     */
    public static String getChartText(double maxValue,int setp){
        String text;
        double count  = maxValue * setp / 4;
        if(count >= 10000){
            double scale = MathUtil.divide(count , 10000,2);
            BigDecimal bigDecimal = new BigDecimal(scale);
            text = bigDecimal.setScale(0,BigDecimal.ROUND_DOWN).toString();
          return text +"万" ;
        }else {
            BigDecimal bigDecimal = new BigDecimal(count);
            text = bigDecimal.setScale(0,BigDecimal.ROUND_DOWN).toString();
        }
        return text;
    }


    /**
     * 短信验证码60秒能不能重复点击记录
     * @return
     */
    public static boolean isClicked60S() {
        long lastTime = MMKVUtil.getLong(Key.VERIFYTIME, 0);
        long intervalTime = System.currentTimeMillis() - lastTime;
        if (intervalTime > 60 * 1000) {
            return true;
        } else {
            int time = (int) (((60 * 1000) - intervalTime)/1000);
            ToastUtils.showLong(StringUtils.getFormatString("访问太频繁，请%1$d秒后重试",time));
            return false;
        }
    }

    /**
     *
     * 保留一位小数，向下取整
     * * 柱状图上面数据
     * @param count
     * @return
     */
    public static String getChartText(double count){
        String text;
        if(count >= 10000){
            double scale = MathUtil.divide(count , 10000,2);
            text = chatDownMoney(scale);
            return text +"万" ;
        }else {
            text = chatDownMoney(count);
        }
        return text;
    }

    /**
     * 柱状图上面的金额处理
     * * @param inMoney
     * @return
     */
    public static String chatDownMoney(double inMoney) {
        DecimalFormat formater = new DecimalFormat();
        formater.setMaximumFractionDigits(1);
        formater.setGroupingSize(0);
        formater.setRoundingMode(RoundingMode.FLOOR);
        BigDecimal bigDecimal = new BigDecimal(formater.format(inMoney));

        BigDecimal bd = new BigDecimal(bigDecimal.setScale(2, 4).toString());
        String pattern = "###.0";
        DecimalFormat df = new DecimalFormat(pattern);
        String result = df.format(bd);
        if (inMoney < 1D) {
            result = "0" + result;
        }
        return result;
    }

    /**
     * 获取柱状图的最大值
     * @param mDatas
     * @return
     */
    public static double getMax(List<ChartEntity> mDatas) {
        //最大值
        double maxValue;

        double tmp = 0;
        for (ChartEntity yData : mDatas) {
            if (yData.getCommission() > tmp) {
                tmp = yData.getCommission();
            }
        }
        if (tmp > 20) {
            maxValue = Math.round(tmp / 20d) * 20;
        } else {
            maxValue = 20;
        }
        LogUtils.d("maxValue:" + maxValue);
        return maxValue;
    }

    public static String getHideEmail(String email){
        if(!StringUtils.isEmpty(email)){
            int index = email.indexOf("@");
            if(index == 1){
                return "****" + email.substring(email.indexOf("@"));
            }else if(index == 2){
                return email.substring(0, 1) + "****" + email.substring(email.indexOf("@"));
            }else {
                return email.substring(0, 2) + "****" + email.substring(email.indexOf("@"));
            }
        }
        return "";
    }
    public static String getHidePhone(String phone){
        if(!StringUtils.isEmpty(phone) && StringUtils.length(phone) > 7){
            return phone.substring(0, 3) + "****" + phone.substring(7);
        }
        return "";
    }


    /**
     * 为textview设置下划线
     * @param textView
     * @param text
     */
    public static void setTextViewLine(TextView textView,String text){
        SpannableString content = new SpannableString(text); content.setSpan(new UnderlineSpan(), 0, text.length(), 0);
        textView.setText(content);
    }


    /**
     * 金额数据处理
     * @param money
     * @return
     */
    public static SpannableString parseMoney(double money) {
        String text;
        if(money <= -99999999999.99D ){//小于100亿
            text = "-999,999.00万";
        }else if(money <= -10000000D ){//小于1千万
            double m = MathUtil.divide(money,10000D);
            text = roundDownMoney(m) + "万";
        }else if(- 10000000D < money && money < 10000000D){ //大于负的1千万 小于正的一千万
            text = roundDownMoney(money);
        }else if(10000000D <= money && money < 99999999999.99D){//大于1千万 小于100亿
            double m = MathUtil.divide(money,10000D);
            text = roundDownMoney(m) + "万";
        }else {//大于一亿
            text = "999,999.00万";
        }
        SpannableString spannableString = new SpannableString(text);
        if(text.endsWith("万")){
            ForegroundColorSpan colorSpan = new ForegroundColorSpan(ResUtils.getColor(R.color.generic_heise));
            spannableString.setSpan(colorSpan, spannableString.length() - 1, spannableString.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        }
        return spannableString;
    }


    /**
     * 佣金界面佣金金额显示判断(数值≥10000000.00时，以万的形式表现,
     * 以万的形式表现，保留两位小数，向下取整（即10000099.00 -> 1000.00万）)
     * @param money 金额，返回显示内容
     */
    public static String financeCalculate(double money) {
        if (money >= 10000000) {
            double m = MathUtil.divide(money,10000D);
            BigDecimal bigDecimal = new BigDecimal(m);
            double dm = bigDecimal.setScale(2,BigDecimal.ROUND_DOWN).doubleValue();
            return MathUtil.parseNumber(dm) +"万";
        } else {
            return MathUtil.parseNumber(money);
        }
    }


    public static String getMoney(double value) {
        DecimalFormat dFormat = new DecimalFormat(",###,##0.00000000000000000");
        dFormat.setGroupingSize(3);
        String money = dFormat.format(value);
        String frist = money.substring(0, 1);
        if (".".equals(frist)) {
            return "0" + money.substring(0, 3);
        }
        int index = getIndex(money, '.');
        if (index == -1) {
            return "0.00";
        }
        return money.substring(0, index + 3);
    }

    public static int getIndex(String str, char ch) {
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == '.') {
                return i;
            }
        }
        return -1;
    }



    /**
     * 向下取整，保留两位小数
     * @param inMoney
     * @return
     */
    public static String roundDownMoney(double inMoney) {
       return  getMoney(inMoney);
    }



    /**********************加签的三个方法*********************/

    /**
     * 获取指定长度随机字符串
     *
     * @param length
     * @return
     */
    public static String getRandomString(int length) {
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(3);
            long result = 0;
            switch (number) {
                case 0:
                    result = Math.round(Math.random() * 25 + 65);
                    sb.append(String.valueOf((char) result));
                    break;
                case 1:
                    result = Math.round(Math.random() * 25 + 97);
                    sb.append(String.valueOf((char) result));
                    break;
                case 2:
                    sb.append(String.valueOf(new Random().nextInt(10)));
                    break;
            }
        }
        return sb.toString();
    }

    public static String sign(String data, String secret, String nonce, long timestamp) {
        String str = data + "|" + nonce + "|" + timestamp + "|" + secret;
        char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'a', 'b', 'c', 'd', 'e', 'f'};
        try {
            MessageDigest mdTemp = MessageDigest.getInstance("SHA1");
            mdTemp.update(str.getBytes("UTF-8"));
            byte[] md = mdTemp.digest();
            int j = md.length;
            char buf[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                buf[k++] = hexDigits[byte0 >>> 4 & 0xf];
                buf[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(buf);
        } catch (Exception e) {
            return null;
        }
    }

    public static int getSecondTimestamp(Date date){
        if (null == date) {
            return 0;
        }
        String timestamp = String.valueOf(date.getTime());
        int length = timestamp.length();
        if (length > 3) {
            return Integer.valueOf(timestamp.substring(0,length-3));
        } else {
            return 0;
        }
    }

}
