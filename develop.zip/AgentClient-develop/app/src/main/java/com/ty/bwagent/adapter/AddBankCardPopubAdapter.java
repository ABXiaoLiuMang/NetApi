package com.ty.bwagent.adapter;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.AddBankCardEntity;

import java.util.ArrayList;
import java.util.List;


/**
 * 描述
 * <p> 绑定银行卡Popup（弹窗适配器）
 * author:Dale
 */
public class AddBankCardPopubAdapter extends BaseQuickAdapter<AddBankCardEntity, BaseViewHolder> {

    public AddBankCardPopubAdapter(List<AddBankCardEntity> entityList) {
        super(R.layout.recycle_item_addbankcard_popub,entityList);
    }

    private int selectPosition = 0;

    public void setSelectPosition(int selectPosition) {
        this.selectPosition = selectPosition;
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, AddBankCardEntity item) {
        ImageView iv_bank_logo = helper.getView(R.id.iv_bank_logo);
        Glide.with(mContext).load(item.getRemark()).into(iv_bank_logo);
        TextView tvBankCard = helper.getView(R.id.add_bankcard_type);
        tvBankCard.setText(item.getDictValue());
        Drawable drawableRight = mContext.getResources().getDrawable(R.mipmap.generic_ic_bank_select);
        drawableRight.setBounds(0, 0, drawableRight.getMinimumWidth(), drawableRight.getMinimumHeight());
        if (selectPosition == helper.getLayoutPosition()) {
            tvBankCard.setCompoundDrawables(null, null, drawableRight, null);
        } else {
            tvBankCard.setCompoundDrawables(null, null, null, null);
        }
    }

}
