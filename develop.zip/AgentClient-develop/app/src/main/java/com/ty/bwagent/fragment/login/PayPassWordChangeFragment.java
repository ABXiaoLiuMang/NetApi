package com.ty.bwagent.fragment.login;

import android.text.InputFilter;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.ui.LoginActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.view.XPassWordView;
import com.ty.bwagent.viewmodel.ChangePassWordViewModel;
import com.ty.bwagent.viewmodel.PayPasswordViewModel;
import com.ty.bwagent.viewmodel.RegisterViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.SimpleObserver;
import com.ty.net.http.POST;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;

import java.util.Arrays;

import androidx.lifecycle.ViewModelProvider;
import butterknife.BindView;
import butterknife.OnClick;


public class PayPassWordChangeFragment extends ABBaseFragment {

    PayPasswordViewModel mChangePassWordViewModel;
    @BindView(R.id.change_tv_warning)
    TextView changeTvWarning;
    @BindView(R.id.x_oldPass)
    XPassWordView xOldPass;
    @BindView(R.id.x_newPass)
    XPassWordView xNewPass;
    @BindView(R.id.x_confirmPass)
    XPassWordView xConfirmPass;
    @BindView(R.id.changer_commit)
    TextView changerCommit;
    String oldPassWord;
    String passWord;
    String confirmPassword;


    public static PayPassWordChangeFragment getInstance() {
        return new PayPassWordChangeFragment();
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_change_pay_password;
    }

    @Override
    protected void createProvider() {
        mChangePassWordViewModel = new ViewModelProvider(this).get(PayPasswordViewModel.class);
        mChangePassWordViewModel.rechargePasswordLiveData.observe(this, new SimpleObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ToastUtils.showLong("修改成功");
                pop();
            }

            @Override
            protected void onError(int code, String errMsg) {
                changeTvWarning.setText(errMsg);
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        new InputResultCalculator(Arrays.asList(xOldPass.getPassEditText(), xNewPass.getPassEditText(), xConfirmPass.getPassEditText()), ok -> {
            changerCommit.setEnabled(ok);
        });

    }


    @OnClick(R.id.changer_commit)
    public void onViewClicked() {
        oldPassWord = xOldPass.getPassText();
        passWord = xNewPass.getPassText();
        confirmPassword = xConfirmPass.getPassText();
        mChangePassWordViewModel.changePassWord(oldPassWord, passWord, confirmPassword);
        KeyboardUtils.hideSoftInput(changerCommit);
    }

    @Override
    public void onStop() {
        super.onStop();
        KeyboardUtils.hideSoftInput(changerCommit);
    }
}
