package com.ty.bwagent.api;

import com.ty.bwagent.bean.ActiveRateEntity;
import com.ty.bwagent.bean.AddBankCardEntity;
import com.ty.bwagent.bean.BannerListBean;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.CommissionEntity;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.bean.DayLowerEntity;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.bean.MMessage;
import com.ty.bwagent.bean.MemberDetailsEntity;
import com.ty.bwagent.bean.MemberEntity;
import com.ty.bwagent.bean.MemberGameEntity;
import com.ty.bwagent.bean.MemberLowerEntity;
import com.ty.bwagent.bean.MessageSys;
import com.ty.bwagent.bean.MonthOverEntity;
import com.ty.bwagent.bean.RestrictEntity;
import com.ty.bwagent.bean.SpecialNoticeEntity;
import com.ty.bwagent.bean.UnRendTypeEntity;
import com.ty.bwagent.bean.UpFileEntity;
import com.ty.bwagent.bean.UserEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.bean.ValueBean;
import com.ty.bwagent.fragment.finance.bean.FinanceAccount;
import com.ty.bwagent.fragment.finance.bean.FinanceDetails;
import com.ty.bwagent.fragment.finance.bean.FinanceTax;
import com.ty.bwagent.fragment.finance.bean.FinanceTotal;
import com.ty.bwagent.fragment.finance.bean.Record;
import com.ty.bwagent.view.chart.ChartEntity;
import com.ty.net.NetCall;
import com.ty.net.http.GET;
import com.ty.net.http.POST;

import java.util.List;
import java.util.Map;

public interface Api {

    @POST("api/client/agent/app/member/v1/login")
    NetCall<BaseEntity<UserInfo>> login();

    @POST("api/client/agent/member/v1/register")
    NetCall<BaseEntity<UserInfo>> register();

    @POST("api/client/agent/member/v1/getCode")
    NetCall<BaseEntity> getCode();

    @POST("api/client/agent/app/mine/v1/getCode")
    NetCall<BaseEntity> getEmailCode();

    // 获取图形验证码
    String VERIFICATION_CODE = "/api/site/group/member/memberRegister/v1/defaultKaptcha";

    @POST("api/site/group/site/perInfo/v1/get")
    NetCall<BaseEntity<String>> getPreInfo();

    @POST("api/site/group/site/perInfo/v1/checkRestrict")
    NetCall<BaseEntity<RestrictEntity>> checkRestrict();

    //修改登录密码
    @POST("api/site/group/member/memberCommon/v1/updateInfo")
    NetCall<BaseEntity> changePassWord();

    //忘记密码（手机找回 第一步）
    @POST("api/site/group/member/memberCommon/v1/forgetByPhoneOne")
    NetCall<BaseEntity> forgetByPhoneOne();

    //忘记密码（手机找回 第二步）
    @POST("api/site/group/member/memberCommon/v1/forgetByPhoneTwo")
    NetCall<BaseEntity> forgetByPhoneTwo();

    //忘记密码（手机找回 第三步）
    @POST("api/site/group/member/memberCommon/v1/forgetByPhoneThree")
    NetCall<BaseEntity> forgetByPhoneThree();

    //忘记密码（邮箱找回 第一步）
    @POST("api/site/group/member/memberCommon/v1/forgetByEmailOne")
    NetCall<BaseEntity> forgetByEmailOne();

    //忘记密码（邮箱找回 第二步）
    @POST("api/site/group/member/memberCommon/v1/forgetByEmailTwo")
    NetCall<BaseEntity> forgetByEmailTwo();

    //忘记密码（邮箱找回 第三步）
    @POST("api/site/group/member/memberCommon/v1/forgetByEmailThree")
    NetCall<BaseEntity> forgetByEmailThree();

    //忘记密码（邮箱找回 第三步）
    @POST("api/site/group/member/common/v1/sendCode")
    NetCall<BaseEntity> forgetSendCode();

    /**************/

    // 消息列表系统公告（查询系统公告信息）
    @POST("api/client/agent/notice/v1/querySystemNoticeList")
    NetCall<BaseEntity<MessageSys>> msgSystemList();

    // 消息列表系统公告（查询系统公告信息）
    @POST("api/client/agent/app/home/v1/queryNotice")
    NetCall<BaseEntity<List<SpecialNoticeEntity>>> queryNotice();

    // 轮播图
    @POST("api/site/group/operation/baseOperation/v1/queryBannerList")
    NetCall<BaseEntity<List<BannerListBean>>> queryBannerList();


    /*******成员开始*******/
    // 本月概览
    @POST("api/client/agent/app/home/v1/queryMonthOverview")
    NetCall<BaseEntity<MonthOverEntity>> queryMonthOverview();

    //  查询下级会员和新增下级会员数量
    @POST("api/client/agent/app/member/v1/queryLowerMember")
    NetCall<BaseEntity<MemberLowerEntity>> queryLowerMember();

    // 查询活跃占比（当月，当天）
    @POST("api/client/agent/app/member/v1/queryActiveRate")
    NetCall<BaseEntity<ActiveRateEntity>> queryActiveRate();

    // 查询日增长曲线数据
    @POST("api/client/agent/app/member/v1/queryDayLowerMember")
    NetCall<BaseEntity<List<DayLowerEntity>>> queryDayLowerMember();

    // 下级成员列表
    @POST("api/client/agent/app/member/v1/queryLowerMemberList")
    NetCall<BaseEntity<MemberEntity>> queryLowerMemberList();

    // 下级成员列表
    @POST("api/client/agent/app/member/v1/queryGameInfo")
    NetCall<BaseEntity<MemberGameEntity>> queryGameInfo();

    // 下级成员详情
    @POST("api/client/agent/app/member/v1/queryLowerMemberDetail")
    NetCall<BaseEntity<MemberDetailsEntity>> queryLowerMemberDetail();


    /*******成员结束*******/


    // 联系我们
    @POST("api/client/agent/member/v1/contactUs")
    NetCall<BaseEntity<ContactUsEntity>> contactUs();

    // 汇率获取
    @GET("api/v5/convert")
    NetCall<String> getExchange();


    /*******佣金开始*******/
    // 查询代理个人佣金信息
    @POST("api/client/agent/app/commission/v1/queryCommissionByMemberId")
    NetCall<BaseEntity<CommissionEntity>> queryCommissionByMemberId();

    // 获取矩形数据(柱状图)
    @POST("api/client/agent/app/commission/v1/queryCommissionByDate")
    NetCall<BaseEntity<List<ChartEntity>>> queryCommissionByDate();

    // 月度详细数据
    @POST("api/client/agent/app/commission/v1/queryMonthCommissionDetail")
    NetCall<BaseEntity<FinanceEntity>> queryMonthCommissionDetail();

    // 总输赢/场馆费月度明细
    @POST("api/client/agent/app/commission/v1/queryProfitDetail")
    NetCall<BaseEntity<List<FinanceTotal>>> queryProfitDetail();

    // 红利月度明细
    @POST("api/client/agent/app/commission/v1/queryPromoList")
    NetCall<BaseEntity<List<FinanceTax>>> queryPromoList();

    // 账户调整月度明细
    @POST("api/client/agent/app/commission/v1/queryAdjustList")
    NetCall<BaseEntity<List<FinanceAccount>>> queryAdjustList();

    // 月度明细(返水)
    @POST("api/site/group/member/memberGradeConfig/v1/getGameFanshuiHighLow")
    NetCall<BaseEntity<Map<String, List<ValueBean>>>> financeWater();

    // 月度明细(佣金 ,净输赢，冲正后净输赢)
    @POST("api/client/agent/app/commission/v1/queryCommissionLevel")
    NetCall<BaseEntity<List<FinanceDetails>>> getGameFanshuiHighLow();

    /*******佣金结束*******/

    // 绑定手机号
    @POST("api/client/agent/member/v1/bindPhone")
    NetCall<BaseEntity> bindPhone();

    // 绑定邮箱
    @POST("api/client/agent/member/v1/bindEmail")
    NetCall<BaseEntity> bindEmail();

    // 退出登录
    @POST("api/client/agent/member/v1/logout")
    NetCall<BaseEntity> logout();

    // 获取个人用户信息
    @POST("api/client/agent/app/mine/v1/getByApp")
    NetCall<BaseEntity<UserEntity>> getUserInfo();

    // 获取提款记录
    @POST("api/client/agent/app/withdrawal/v1/withdrawalListFilter")
    NetCall<BaseEntity<Record>> withdrawalListFilter();

    // 消息列表
    @POST("api/site/group/msg/msgHandle/v1/msgList")
    NetCall<BaseEntity<MMessage>> msgList();

    // 一键阅读
    @POST("api/site/group/msg/msgHandle/v1/onekeyReaded")
    NetCall<BaseEntity> onekeyReaded();

    // 删除一条通知消息
    @POST("api/site/group/msg/msgHandle/v1/msgDelete")
    NetCall<BaseEntity> msgDelete();

    // 标记一条消息为已读状态
    @POST("api/site/group/msg/msgHandle/v1/readed")
    NetCall<BaseEntity> msgReaded();

    // 各类型消息未读量(用来标识小红点)

    @POST("api/site/group/msg/msgHandle/v1/getUnreadForType")
    NetCall<BaseEntity<UnRendTypeEntity>> getUnreadForType();

    // 推广连接
    @POST("api/client/agent/app/member/v1/domainByClientType")
    NetCall<BaseEntity<List<ExtensionEntity>>> domainByClientType();

    // 代理钱包（查询我的界面余额）
    @POST("api/client/agent/withdrawal/v1/initMoney")
    NetCall<BaseEntity<Commission>> initMoney();

    // 提款获取电话号码
    @POST("api/client/agent/agent/v1/getPhone")
    NetCall<BaseEntity<String>> getDrawPhone();

    // 上传用户头像(第一步)
    @POST("api/component/memberfile/staticSource/v1/uploadFile")
    NetCall<BaseEntity<UpFileEntity>> uploadFile();

    // 上传用户头像（第二步，借用第一步返回图片url修改）
    @POST("api/site/group/member/memberAvatar/v1/insertMemberAvatar")
    NetCall<BaseEntity> insertMemberAvatar();

    // 查询银行列表
    @POST("api/component/dict/dictType/v1/query")
    NetCall<BaseEntity<List<AddBankCardEntity> >> queryBanks();

    // 银行卡三要素校验(验证银行卡)
    @POST("api/client/agent/withdrawal/v1/validateBankCard")
    NetCall<BaseEntity> validateBankCard();

    // 提款至银行卡
    @POST("api/client/agent/withdrawal/v1/withdrawalToBank")
    NetCall<BaseEntity> withdrawalToBank();

    // 提款至中心钱包
    @POST("api/client/agent/withdrawal/v1/withdrawToCentralWallet")
    NetCall<BaseEntity> withdrawToCentralWallet();
}
