package com.ty.bwagent;


import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Process;

import androidx.lifecycle.Observer;
import androidx.multidex.MultiDex;

import com.bw.tmapmanager.domains.TmapDomainsManager;
import com.bw.tmapmanager.network.inter.TmapStrategy;
import com.bw.tmapmanager.network.sign.TmapChuangYuStrategy;
import com.bw.tmapmanager.network.sign.TmapSCDNStrategy;
import com.bw.tmapmanager.network.sign.TmapYunDunStrategy;
import com.lzy.imagepicker.ImagePicker;
import com.lzy.imagepicker.util.GlideImageLoader;
import com.lzy.imagepicker.view.CropImageView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.tencent.bugly.Bugly;
import com.tencent.bugly.beta.Beta;
import com.tianyu.tyinstall.TYInstall;
import com.tianyu.updater.TYUpdater;
import com.ty.bwagent.api.BaseRetryInterceptor;
import com.ty.bwagent.api.BaseUrlManager;
import com.ty.bwagent.api.HttpSignUtils;
import com.ty.bwagent.api.NetSignInterceptor;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.header.MyClassicsRefreshFooter;
import com.ty.bwagent.header.MyClassicsRefreshHeader;
import com.ty.bwagent.ui.GestureActivity;
import com.ty.bwagent.ui.LoginActivity;
import com.ty.bwagent.ui.SystemMaintainActivity;
import com.ty.bwagent.ui.TyInstallMidActivity;
import com.ty.bwagent.update.XUpdateManager;
import com.ty.bwagent.utils.AppEnv;
import com.ty.bwagent.utils.ParameIntercept;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.util.ABApplication;
import com.ty.common.util.ABConfig;
import com.ty.net.NetSdk;
import com.ty.net.callback.OnAddCommonHeadCallBack;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.AppConfig;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.NetworkUtils;
import com.ty.utils.TopActivityManager;
import com.yabo.tymonitor.TYTingyunMonitor;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


public class App extends ABApplication {

    public static int height;

    private static final String OFFICIAL_CODE = "00000";//官方默认渠道号

    /**
     * 上传头像拍照设置为ture,回来不回调锁屏
     */
    public static boolean goPhoto = false;

    /**
     * 是否显示过更新对话框 false 没有
     */
    public static boolean is_showing_update_dialog = false;

    static {
        //设置全局的Header构建器
        SmartRefreshLayout.setDefaultRefreshHeaderCreator((context, layout) -> new MyClassicsRefreshHeader(context));
        //设置全局的Footer构建器
        SmartRefreshLayout.setDefaultRefreshFooterCreator((context, layout) -> new MyClassicsRefreshFooter(context));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MMKVUtil.put(Key.SITEIDKEY, BuildConfig.appType);
        LogUtils.isDebug(BuildConfig.DEBUG);

//        if (LeakCanary.isInAnalyzerProcess(this)) {
//            return;
//        }
//        LeakCanary.install(this);


        if (isMainProcess()) {
            SiteSdk.ins().initSDK(this).setSiteId(BuildConfig.appType);
            initNetSdk();
            updateCDNmainHost();
            initXUpdate();
//        initUmeng();
            initTyInstall();
//            initBugly();
            initTingYun();
            systemMaintain();
        }
        initImagePicker();

//        Fragmentation.builder()
//                // 设置 栈视图 模式为 （默认）悬浮球模式   SHAKE: 摇一摇唤出  NONE：隐藏， 仅在Debug环境生效
//                .stackViewMode(Fragmentation.BUBBLE)
//                .debug(BuildConfig.DEBUG) // 实际场景建议.debug(BuildConfig.DEBUG)
//                /**
//                 * 可以获取到{@link me.yokeyword.fragmentation.exception.AfterSaveStateTransactionWarning}
//                 * 在遇到After onSaveInstanceState时，不会抛出异常，会回调到下面的ExceptionHandler
//                 */
//                .handleException(new ExceptionHandler() {
//                    @Override
//                    public void onException(Exception e) {
//                        // 以Bugtags为例子: 把捕获到的 Exception 传到 Bugtags 后台。
//                        // Bugtags.sendException(e);
//                    }
//                })
//                .install();


        addForegroundListener();
    }


    private void initNetSdk() {
        String baseUrl = BaseUrlManager.ins().currentDomain().getHost();
        //必须先初始化
        NetSdk.config(this)
                .baseUrl(baseUrl)
                .addHeaders(new OnAddCommonHeadCallBack() {
                    @Override
                    public HashMap<String, String> OnCommonHeadCallBack() {
                        return HttpSignUtils.getBaseHeader();
                    }
                })
                .addInterceptor(new ParameIntercept())
                .addInterceptor(new NetSignInterceptor())
                .addInterceptor(new BaseRetryInterceptor())
                .needLog(BuildConfig.DEBUG);
    }


    /**
     * 接入文档
     * http://jira.hnxmny.com:8090/pages/viewpage.action?pageId=25692954
     */
    private void initTyInstall() {
        TYInstall.getInstance()
                .initTyInstall(this, BuildConfig.appKey)
                .setDebug(true)
                .setChannel("", OFFICIAL_CODE)
                .setClientType("android-game")
                .setParserClass(TyInstallMidActivity.class)
                .reportInstall()
                .checkParams();
    }

    /**
     * 初始化更新
     * http://jira.hnxmny.com:8090/pages/viewpage.action?pageId=26692106 集成文档
     */
    private void initXUpdate() {
        XUpdateManager.getInstance();
        Set<String> setActivities = new HashSet<>();
        setActivities.add("LoginActivity");
        setActivities.add("MainActivity");
        try {
            TYUpdater tyUpdater = TYUpdater.get().setDebug(BuildConfig.DEBUG)
                    .setAppEnv(AppEnv.RELEASE)
                    .setIsRetry(true)
                    .addShowActivities(setActivities)
                    .initUpdate(this, BuildConfig.appKey);
            if (NetworkUtils.isAvailable()) {
                tyUpdater.checkVersion();
            }
        } catch (Exception e) {
        }
    }

    /**
     * 初始化加签
     */
    private void updateCDNmainHost() {
        TmapSCDNStrategy alscdn = new TmapSCDNStrategy();
        TmapYunDunStrategy yundun = new TmapYunDunStrategy();
        TmapChuangYuStrategy chuangyu = new TmapChuangYuStrategy();
        TmapStrategy[] tmapStrategies = new TmapStrategy[]{alscdn, yundun, chuangyu};
        long currentTime = System.currentTimeMillis() / 1000;
        TmapDomainsManager.getInstance().init(tmapStrategies, currentTime, 1800).initLogInfo(true);
    }


    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
        Beta.installTinker();
    }

    //是否是主进程
    private boolean isMainProcess() {
        int pid = Process.myPid();
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningAppProcessInfo appProcess : activityManager.getRunningAppProcesses()) {
            if (appProcess.pid == pid) {
                LogUtils.d(String.format("当前进程：%s", appProcess.processName));
                return getApplicationInfo().packageName.equals(appProcess.processName);
            }
        }
        return false;
    }


    /**
     * 初始化Bugly
     */
    private void initBugly() {
        Bugly.setIsDevelopmentDevice(this, true);
        //context 一定要传入this(当前项目的Application)，否则不能进行上报tinkerid
        if ((BuildConfig.appEnv == AppEnv.HTTPS_RELEASE || BuildConfig.appEnv == AppEnv.RELEASE) && !BuildConfig.DEBUG) {
            Bugly.init(this, Key.BUGLY_ID_PRODUCT, BuildConfig.DEBUG);
        } else {
            Bugly.init(this, Key.BUGLY_ID_DEBUG, BuildConfig.DEBUG);
        }
    }

    private void initTingYun() {
        TYTingyunMonitor.init(this);
        if ((BuildConfig.appEnv == AppEnv.HTTPS_RELEASE || BuildConfig.appEnv == AppEnv.RELEASE) && !BuildConfig.DEBUG) {
            TYTingyunMonitor.startAppMonitorEnv(Key.TING_YUN_KEY_PRODUCT, BuildConfig.iCode, true);
        } else {
            TYTingyunMonitor.startAppMonitorEnv(Key.TING_YUN_KEY_DEBUG, BuildConfig.iCode, true);
        }
    }

    /**
     * 全局系统级别回调监听
     */
    private void systemMaintain() {
        SystemModel.sMaintainInfo.observeForever(sysObserver);
        SystemModel.areaWarnResult.observeForever(sysObserver);
        SystemModel.loginOut.observeForever(loginOut);
    }

    SimpleObserver<BaseEntity> sysObserver = new SimpleObserver<BaseEntity>() {
        @Override
        protected void onSuccess(BaseEntity baseEntity) {
            Activity activity = com.ty.utils.TopActivityManager.getInstance().getCurActivity();
            if (activity != null && !activity.isFinishing()) {
                activity.startActivity(new Intent(activity, SystemMaintainActivity.class));
                activity.finish();
            }
        }
    };

    Observer<Boolean> loginOut = aBoolean -> {
        Activity activity = com.ty.utils.TopActivityManager.getInstance().getCurActivity();
        if (activity != null && !activity.isFinishing()) {
            if (!(activity instanceof LoginActivity)) {
                XLiveDataManager.getInstance().loginOut();
                activity.startActivity(new Intent(activity, LoginActivity.class));
                activity.finish();
            }
        }
    };


    //    /**
//     * 友盟分享
//     */
//    private void initUmeng(){
//        UMConfigure.setLogEnabled(true);
//        UMConfigure.init(this, UMConfigure.DEVICE_TYPE_PHONE, "1fe6a20054bcef865eeb0991ee84525b");
//    }


    private void initImagePicker() {
        ImagePicker imagePicker = ImagePicker.getInstance();
        imagePicker.setImageLoader(new GlideImageLoader());   //设置图片加载器
        imagePicker.setShowCamera(true);                      //显示拍照按钮
        imagePicker.setCrop(true);                            //允许裁剪（单选才有效）
        imagePicker.setSaveRectangle(true);                   //是否按矩形 区域保存
        imagePicker.setSelectLimit(1);              //选中数量限制
        imagePicker.setMultiMode(false);                      //多选
        imagePicker.setStyle(CropImageView.Style.RECTANGLE);  //裁剪框的形状
        imagePicker.setFocusWidth(1000);                       //裁剪框的宽度。单位像素（圆形自动取宽高最小值）
        imagePicker.setFocusHeight(1000);                      //裁剪框的高度。单位像素（圆形自动取宽高最小值）
        imagePicker.setOutPutX(1000);                         //保存文件的宽度。单位像素
        imagePicker.setOutPutY(1000);                         //保存文件的高度。单位像素
    }

    /**
     * app启动，第一次不跳转锁屏
     */
    boolean isStartAlive = false;

    private void addForegroundListener() {
        TopActivityManager.getInstance().addListener(new TopActivityManager.OnAppStatusChangedListener() {
            @Override
            public void onForeground() {
                if (App.goPhoto) {
                    return;
                }
                Activity activity = TopActivityManager.getInstance().getCurActivity();
                if (isStartAlive) {
                    Intent intent = new Intent(activity, GestureActivity.class);
                    if (AppConfig.isStartActivity(activity)) {
                        intent.putExtra(ABConfig.KEY_TAG, false);
                    } else {
                        intent.putExtra(ABConfig.KEY_TAG, true);
                    }
                    activity.startActivity(intent);
                }
                isStartAlive = true;

                LogUtils.d("app 前台 activity:" + activity.getClass().getSimpleName());
            }

            @Override
            public void onBackground() {
                Activity activity = TopActivityManager.getInstance().getCurActivity();
                if (activity != null && !activity.isFinishing()) {
                    if (AppConfig.isBackgroundActivity(activity)) {//照相选择满足条件销毁
                        activity.finish();
                    }
                }
            }
        });
    }
}


