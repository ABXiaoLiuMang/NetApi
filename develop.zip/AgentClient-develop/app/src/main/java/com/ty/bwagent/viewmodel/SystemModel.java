package com.ty.bwagent.viewmodel;

import androidx.lifecycle.MutableLiveData;

import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.bean.VerifyEntity;
import com.ty.net.bean.NetLiveData;

public class SystemModel {
    public static MutableLiveData<Integer> areaWarnResult = new MutableLiveData<>();//地区限制(维护)
    public static MutableLiveData<Boolean> loginOut = new MutableLiveData<>();//退出登录，登录失效
    public static MutableLiveData<UserInfo> loginUserInfo = new MutableLiveData<>();//登录时候，没有绑定手机号，走错误err，但是有返回登录信息
    public static MutableLiveData<VerifyEntity> loginVerify = new MutableLiveData<>();//登录时候，走错误err，需要验证手机号



}
