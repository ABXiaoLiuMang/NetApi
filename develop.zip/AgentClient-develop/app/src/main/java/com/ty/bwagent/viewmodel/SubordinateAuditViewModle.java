package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ReviewListEntity;
import com.ty.net.NetCall;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.StringUtils;

import androidx.lifecycle.ViewModel;

public class SubordinateAuditViewModle extends ViewModel {


    //列表查询
    public NetLiveData<BaseEntity<ReviewListEntity>> reviewListLiveData = new NetLiveData<>();
    //更新接口
    public NetLiveData<BaseEntity> updateReviewLiveData = new NetLiveData<>();


    /**
     * //审核-列表查询
     *
     * @param memberName
     * @param reviewStatus 审核状态0待审核1审核拒绝2审批通过
     * @param createdAt
     * @param pageNum
     * @param pageSize
     */
    public void reviewList(String memberName, String reviewStatus, String createdAt, String endAt, int pageNum, int pageSize) {
        NetCall<BaseEntity<ReviewListEntity>> netCall = NetSdk.create(Api.class)
                .reviewList()
                .params("memberName", memberName)
                .params("createdAt", createdAt)
                .params("endAt", endAt)
                .params("pageNum", pageNum)
                .params("pageSize", pageSize);
        if (!StringUtils.isEmpty(reviewStatus)) {
            netCall.params("reviewStatus", reviewStatus);
        }
        netCall.asJSONType()
                .send(reviewListLiveData);
    }


    /**
     * //无限极-代理web-代理审核-更新接口
     *
     * @param reviewStatus 审核状态审核状态0待审核1审核拒绝2审批通过
     */
    public void updateReview(String reviewStatus, String id, String remark) {
        NetSdk.create(Api.class)
                .updateReview()
                .params("reviewStatus", reviewStatus)
                .params("id", id)
                .params("remark", remark)
                .asJSONType()
                .send(updateReviewLiveData);
    }

}
