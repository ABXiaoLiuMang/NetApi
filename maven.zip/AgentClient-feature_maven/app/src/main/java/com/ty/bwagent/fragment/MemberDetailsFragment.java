package com.ty.bwagent.fragment;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.MemberDetailsAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MemberDetailsEntity;
import com.ty.bwagent.bean.MemberEntity;
import com.ty.bwagent.bean.MemberGameEntity;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.ExpandableLayout;
import com.ty.bwagent.view.XSelectTimeView;
import com.ty.bwagent.view.XTextView;
import com.ty.bwagent.viewmodel.MemberDetailsViewModel;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.view.CircleImageView;

import java.util.List;

import butterknife.BindView;

/**
 * 成员详情页面
 */
public class MemberDetailsFragment extends ABRefreshFragment<MemberGameEntity.ListBean> {

    MemberDetailsViewModel mMemberDetailsViewModel;
    @BindView(R.id.member_iv_head)
    CircleImageView memberIvHead;
    @BindView(R.id.member_account)
    TextView memberAccount;
    @BindView(R.id.member_iv_vip)
    ImageView memberIvVip;
    @BindView(R.id.member_name)
    TextView memberName;
    @BindView(R.id.member_tv_money)
    TextView memberTvMoney;
    @BindView(R.id.member_today_win)
    XTextView memberTotalWin;
    @BindView(R.id.member_total_win)
    XTextView memberMonthWin;
    @BindView(R.id.mScrollView)
    LinearLayout mScrollView;
    @BindView(R.id.member_login_time)
    TextView memberLoginTime;
    @BindView(R.id.member_rigester_time)
    TextView memberRigesterTime;
    @BindView(R.id.topExpandableLayout)
    ExpandableLayout topExpandableLayout;
    @BindView(R.id.xSelectTimeView)
    XSelectTimeView xSelectTimeView;
    @BindView(R.id.buttomExpandableLayout)
    ExpandableLayout buttomExpandableLayout;
    @BindView(R.id.member_state)
    TextView memberState;

    String startDate;//开始时间
    String endDate;//结束时间
    int pageNum = 1;
    int pageSize = 10;

    MemberEntity.ListBean listBean;


    public static MemberDetailsFragment getInstance(MemberEntity.ListBean listBean) {
        MemberDetailsFragment detailsFragment = new MemberDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ABConfig.KEY_OBJECT, listBean);
        detailsFragment.setArguments(bundle);
        return detailsFragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_member_details;
    }

    @Override
    protected void createProvider() {
        mMemberDetailsViewModel = new ViewModelProvider(this).get(MemberDetailsViewModel.class);

        /**
         * （外面传入了的，还鸡巴更新）
         * 详情数据更新
         */
        mMemberDetailsViewModel.memberDetailsLiveData.observe(this,new NetObserver<BaseEntity<MemberDetailsEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<MemberDetailsEntity> baseEntity) {
                MemberDetailsEntity detailsEntity = baseEntity.getData();
                memberIvVip.setImageResource(Utils.getVipResId(detailsEntity.getVipLevel()));

                memberAccount.setText(detailsEntity.getName());

                if (!StringUtils.isEmpty(detailsEntity.getRealName())) {
                    memberName.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_realname), detailsEntity.getRealName()));
                }
                memberTvMoney.setText(Utils.roundDownMoney(detailsEntity.getAvailableMoney()));//钱包余额
                memberTotalWin.setMontyText(Utils.roundDownMoney(detailsEntity.getDayTotalProfit()));//今日输赢
                memberMonthWin.setMontyText(Utils.roundDownMoney(detailsEntity.getMonthTotalProfit()));//本月输赢
                memberLoginTime.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_login_time), detailsEntity.getLastLoginTime()));
                memberRigesterTime.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_register_time), detailsEntity.getCreatedAt()));
                memberState.setVisibility(detailsEntity.getStatus() == 0 ?  View.VISIBLE: View.GONE);// 已禁用是否显示
            }

            @Override
            protected void onError(int code, String errMsg) {

            }
        });


        //游戏列表
        mMemberDetailsViewModel.memberGameLiveData.observe(this, new NetObserver<BaseEntity<MemberGameEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<MemberGameEntity> listBaseEntity) {
                List<MemberGameEntity.ListBean> entityList = listBaseEntity.getData().getList();
                if (pageNum == 1) {
                    listAdapter.setNewData(entityList);
                    refreshLayout.finishRefresh();
                } else {
                    listAdapter.addData(entityList);
                    refreshLayout.finishLoadMore();
                }
                if (entityList.size() < pageSize) {
                    refreshLayout.finishLoadMoreWithNoMoreData();
                }
            }

            @Override
            protected void onLoading(boolean show) {
                super.onLoading(show);
                if (!show) {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                if (pageNum == 1) {
                    refreshLayout.finishRefresh(false);
                } else {
                    refreshLayout.finishLoadMore(false);
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        listBean = bundle.getParcelable(ABConfig.KEY_OBJECT);
        xSelectTimeView.setOnSearchListener((sTime, eTime) -> {
            showProgressDialog();
            //选择时间后搜索
            startDate = sTime;
            endDate = eTime;
            pageNum = 1;
            mMemberDetailsViewModel.queryLowerMember(listBean.getId(), startDate, endDate, pageNum, pageSize);//查询游戏动态
        });
        startDate = TimeUtils.getDiffDate(-6);
        endDate = TimeUtils.getDiffDate(0);
        mMemberDetailsViewModel.queryLowerMember(listBean.getId(), startDate, endDate, pageNum, pageSize);//查询游戏动态
        mMemberDetailsViewModel.queryLowerMemberDetail(listBean.getId());//查询游戏详情
        initExpandable();
        initViews();
    }

    /**
     * 处理折叠布局,展开,收缩，滚动等逻辑
     */
    private void initExpandable() {
//        topExpandableLayout.setConsTraintLayout(buttomExpandableLayout);
//        buttomExpandableLayout.setConsTraintLayout(topExpandableLayout);
//        topExpandableLayout.setScrollView(mScrollView);
//        buttomExpandableLayout.setScrollView(mScrollView);
    }

    private void initViews() {
        RequestOptions requestOptions = new RequestOptions()
                .error(R.mipmap.userhead_boy_default)
                .placeholder(R.mipmap.userhead_boy_default);
        Glide.with(mContext)
                .applyDefaultRequestOptions(requestOptions)
                .load(listBean.getAvater())
                .into(memberIvHead);

        memberIvVip.setImageResource(Utils.getVipResId(listBean.getVipLevel()));

        memberAccount.setText(listBean.getName());

        if (!StringUtils.isEmpty(listBean.getRealName())) {
            memberName.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_realname), listBean.getRealName()));
        }
        memberTvMoney.setText(Utils.roundDownMoney(listBean.getAvailableMoney()));//钱包余额
        memberTotalWin.setMontyText(listBean.getTotalProfit());//今日输赢
        memberMonthWin.setMontyText(listBean.getMonthTotalProfit());//本月输赢
        memberLoginTime.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_login_time), listBean.getLastLoginTime()));
        memberRigesterTime.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_register_time), listBean.getCreatedAt()));
        memberState.setVisibility(listBean.getStatus() == 0 ?  View.VISIBLE: View.GONE);// 已禁用是否显示
    }


    @Override
    public View getEmptyView() {
        View emptyView = View.inflate(mContext, R.layout.empty_member, null);
        emptyView.setOnClickListener(v -> KeyboardUtils.hideSoftInput(emptyView));
        TextView tv_empty = emptyView.findViewById(R.id.tv_empty);
        tv_empty.setText("暂无数据");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, App.height - SizeUtils.dp2px(380));
        emptyView.setLayoutParams(lp);
        return emptyView;
    }

    @Override
    public BaseQuickAdapter<MemberGameEntity.ListBean, BaseViewHolder> getListAdapter() {
        return new MemberDetailsAdapter();
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//        MemberGameEntity mMemberDetails = (MemberGameEntity) adapter.getItem(position);
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum++;
        mMemberDetailsViewModel.queryLowerMember(listBean.getId(), startDate, endDate, pageNum, pageSize);//查询游戏动态
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        pageNum = 1;
        mMemberDetailsViewModel.queryLowerMember(listBean.getId(), startDate, endDate, pageNum, pageSize);//查询游戏动态
        mMemberDetailsViewModel.queryLowerMemberDetail(listBean.getId());//查询游戏详情
    }

}
