package com.ty.bwagent.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.LifecycleObserver;
import com.ty.bwagent.R;

import butterknife.BindView;


public class ExpandableLayout extends LinearLayout implements LifecycleObserver {


    public ExpandableLayout(Context context) {
        this(context, null);
    }

    public ExpandableLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    View showView;
    ExpandableView hideView;
    ExpandableLayout consTraintLayout;
    View mScrollView;
    ImageView arrowView;
    boolean isExpanded = false;//默认是否是展开的

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setOrientation(LinearLayout.VERTICAL);
        showView = findViewById(R.id.showView);
        hideView = findViewById(R.id.hideView);
        arrowView = findViewById(R.id.arrowView);
        if (showView == null) {
            throw new RuntimeException("显示的View布局ID必须为showView");
        }
        if (hideView == null) {
            throw new RuntimeException("隐藏的ExpandableView布局ID必须为hideView");
        }
        if (arrowView == null) {
            throw new RuntimeException("箭头指示器的ViewID必须为arrowView");
        }
        showView.setOnClickListener(v -> {
            if(hideView.isExpanded()){//展开的
                rotateArrow(true);
            }else {
                rotateArrow(false);
                if(consTraintLayout != null && consTraintLayout.getHideView().isExpanded()){
                    consTraintLayout.showView.performClick();
                }
            }
            if(mScrollView != null){
                mScrollView.scrollTo(0,0);
            }
            hideView.toggle();
        });


        isExpanded = hideView.isExpanded();
    }

    private void rotateArrow(boolean flag) {
        float pivotX = arrowView.getWidth() / 2f;
        float pivotY = arrowView.getHeight() / 2f;
        float fromDegrees;
        float toDegrees;
        // flag为true则向上
        if(isExpanded){
            if (flag) {
                fromDegrees = 0f;
                toDegrees = -90f;
            } else {
                fromDegrees = -90f;
                toDegrees = 0f;
            }
        }else {
            if (flag) {
                fromDegrees = 90f;
                toDegrees = 0f;
            } else {
                fromDegrees = 0f;
                toDegrees = 90f;
            }
        }

        RotateAnimation animation = new RotateAnimation(fromDegrees, toDegrees,pivotX, pivotY);
        animation.setDuration(400);
        animation.setFillAfter(true);
        arrowView.startAnimation(animation);
    }
//    private void rotateArrow(boolean flag) {
//        float pivotX = arrowView.getWidth() / 2f;
//        float pivotY = arrowView.getHeight() / 2f;
//        float fromDegrees;
//        float toDegrees;
//        // flag为true则向上
//        if (flag) {
//            fromDegrees = 90f;
//            toDegrees = 0f;
//        } else {
//            fromDegrees = 0f;
//            toDegrees = 90f;
//        }
//        RotateAnimation animation = new RotateAnimation(fromDegrees, toDegrees,pivotX, pivotY);
//        animation.setDuration(400);
//        animation.setFillAfter(true);
//        arrowView.startAnimation(animation);
//    }



    public ExpandableView getHideView() {
        return hideView;
    }

    public void setConsTraintLayout(ExpandableLayout consTraintLayout) {
        this.consTraintLayout = consTraintLayout;
    }

    public void setScrollView(View mScrollView) {
        this.mScrollView = mScrollView;
    }

    public void setOnExpansionUpdateListener(ExpandableView.OnExpansionUpdateListener listener) {
        if(hideView != null){
            hideView.setOnExpansionUpdateListener(listener);
        }
    }

    /**
     *
     * @return ture 展开
     */
    public boolean isExpanded() {
        return hideView.isExpanded();
    }
}
