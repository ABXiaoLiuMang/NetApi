package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.ActiveRateEntity;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.DayLowerEntity;
import com.ty.bwagent.bean.MemberEntity;
import com.ty.bwagent.bean.MemberLowerEntity;
import com.ty.net.NetCall;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.LogUtils;
import com.ty.utils.StringUtils;

import java.util.List;

public class MemberModel extends ViewModel {

    //查询下级会员和新增下级会员数量
    public NetLiveData<BaseEntity<MemberLowerEntity>> monthOverLiveData = new NetLiveData<>();

    //查询活跃占比（当月，当天）
    public NetLiveData<BaseEntity<ActiveRateEntity>> activeRateLiveData = new NetLiveData<>();

    //查询日增长曲线数据
    public NetLiveData<BaseEntity<List<DayLowerEntity>>> dayLowerLiveData = new NetLiveData<>();

    //下级成员列表
    public NetLiveData<BaseEntity<MemberEntity>> memberListLiveData = new NetLiveData<>();


    //查询下级会员和新增下级会员数量
    public void queryLowerMember(){
        NetSdk.create(Api.class)
                .queryLowerMember()
                .asJSONType()
                .send(monthOverLiveData);
    }

    //查询活跃占比（当月，当天）
    public void queryActiveRate(){
        NetSdk.create(Api.class)
                .queryActiveRate()
                .asJSONType()
                .send(activeRateLiveData);
    }

    //查询日增长曲线数据
//    public void queryDayLowerMember(String startDate,String endDate){
//        NetSdk.create(Api.class)
//                .queryDayLowerMember()
//                .params("startDate",startDate)
//                .params("endDate",endDate)
//                .asJSONType()
//                .send(dayLowerLiveData);
//    }

    //下级成员列表

    /**
     *
     * @param sortLastLoginTime 最后登录时间排序字段(1:desc,2:asc)
     * @param sortAvailableMoney 钱包余额排序字段（1:desc,2:asc）
     * @param sortCreateTime 注册时间排序字段(1:desc,2:asc)
     * @param name 用户名精准搜索     * @param pageNum
     * @param pageSize
     */
    public void queryLowerMemberList(int sortLastLoginTime, int sortAvailableMoney,int sortCreateTime,String name,int pageNum,int pageSize){
        NetCall<BaseEntity<MemberEntity>> netCall = NetSdk.create(Api.class)
                .queryLowerMemberList()
                .params("pageNum", pageNum)
                .params("pageSize", pageSize);
        if (!StringUtils.isEmpty(name)) {
            netCall.params("name", name);
        }

        if (sortLastLoginTime > 0) {
            netCall.params("sortLastLoginTime", sortLastLoginTime);
        }
        if (sortAvailableMoney > 0) {
            netCall.params("sortAvailableMoney", sortAvailableMoney);
        }
        if (sortCreateTime > 0) {
            netCall.params("sortCreateTime", sortCreateTime);
        }
        netCall.asJSONType()
                .send(memberListLiveData);
    }
}
