package com.ty.bwagent.fragment.share;

import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.App;
import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.bean.MaterialEntity;
import com.ty.bwagent.utils.Key;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.share.ShareLayout;
import com.ty.bwagent.viewmodel.MaterialViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.constant.PermissionConstants;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;

import java.util.List;

import butterknife.BindView;


public class ShareEditFragment extends ABBaseFragment {

    MaterialViewModel mMaterialViewModel;
    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.stateLayout)
    ShareLayout stateLayout;
    MaterialEntity.ListBean listBean;
    String webUrl;
    String appUrl;
    String specialUrl;
    String inviteCode;

    public static ShareEditFragment getInstance(Bundle bundle) {
        ShareEditFragment fragment = new ShareEditFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_share_edit;
    }


    @Override
    protected void createProvider() {
        listBean = bundle.getParcelable(ABConfig.KEY_OBJECT);
        inviteCode = MMKVUtil.getString(Key.INVITE_CODE);
        mMaterialViewModel = new ViewModelProvider((ABBaseFragment) getPreFragment()).get(MaterialViewModel.class);
        mMaterialViewModel.entityNetLiveData.observe(this, new NetObserver<BaseEntity<List<ExtensionEntity>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<ExtensionEntity>> listBaseEntity) {
                List<ExtensionEntity> entityList = listBaseEntity.getData();
                if (entityList != null) {
                    initStateLayout(entityList);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {

            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        titleBar.setRightOnClickListener(view -> {
            App.goPhoto = true;
            PermissionUtils.permission(PermissionConstants.STORAGE)
                    .callback(new PermissionUtils.SimpleCallback() {
                        @Override
                        public void onGranted() {
                            View view = ((ViewGroup) stateLayout.getShareView()).getChildAt(0);
                            Bitmap bitmap = Utils.getViewBitmp(view);
                            if(bitmap != null){
                                ScreenUtils.saveCaptureView(bitmap);
                            }
                            pop();
                        }

                        @Override
                        public void onDenied() {
                            ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn));
                        }
                    })
                    .request();
        });
        stateLayout.setImageUrl(listBean.getImageUrl());
        stateLayout.setPicTitle(listBean.getImageTitle());
//        stateLayout.setTips(listBean.getImageTitle());
    }


    /**
     * 初始化二维码链接
     * a. 10和11站点没有区分全站和体育app ，是一起的
     * b. h5(主站h5),pc(主站pc),site(全站APP),sportApp(体育App)
     * @param entityList
     */
    private void initStateLayout(List<ExtensionEntity> entityList){
        for (ExtensionEntity entity : entityList) {

            if (StringUtils.equals("siteSportApp", entity.getClientType())) {
                specialUrl = appUrl = entity.getUrl() + "/?i_code=" + inviteCode;
            }

            if (StringUtils.equals("pc", entity.getClientType())) {
                webUrl = entity.getUrl() + "/register/?i_code=" + inviteCode;
            }
            if (StringUtils.equals("site", entity.getClientType())) {
                appUrl = entity.getUrl() + "/?i_code=" + inviteCode;
            }
        }


       if (listBean.getImageType() == 2) {//app 推广链接
           if (StringUtils.equals("11", BuildConfig.appType) || StringUtils.equals("10", BuildConfig.appType)) {
               stateLayout.setUrl(specialUrl);
           }else {
               stateLayout.setUrl(appUrl);
           }
        } else {//(赠送推广图/综合推广图/赞助推广图)
            stateLayout.setUrl(webUrl);
        }
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        KeyboardUtils.hideSoftInput(requireActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        App.goPhoto = false;
    }

}
