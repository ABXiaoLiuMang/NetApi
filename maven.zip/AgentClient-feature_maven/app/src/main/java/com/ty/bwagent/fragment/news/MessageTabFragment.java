package com.ty.bwagent.fragment.news;

import android.content.Context;
import android.os.Bundle;
import android.util.ArrayMap;
import android.view.LayoutInflater;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UnRendTypeEntity;
import com.ty.bwagent.fragment.BaseViewPagerFragment;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.MessageViewModel;
import com.ty.bwagent.viewmodel.ReadMsgViewModel;
import com.ty.common.util.ABConfig;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.badge.BadgeAnchor;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.badge.BadgePagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.badge.BadgeRule;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.ToastUtils;


public class MessageTabFragment extends BaseViewPagerFragment {

    MessageViewModel mMessageViewModel;
    ReadMsgViewModel readMsgViewModel;
    View noticeDot;//通知小红点
    View activeDot;//活动小红点
    int msgType;//消息类型
    int index;//默认选中第几个tab
    int readType = -1;//记录点击一键阅读的类型（标记成功后，知道取消那个类型的小红点）

    /**
     * 在首页滚动通知过来选中通过
     *
     * @param index 默认选中第几个tab
     * @return
     */
    public static MessageTabFragment getInstance(int index) {
        Bundle bundle = new Bundle();
        bundle.putInt(ABConfig.KEY_TAG, index);
        MessageTabFragment tabFragment = new MessageTabFragment();
        tabFragment.setArguments(bundle);
        return tabFragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_message_tab;
    }

    @Override
    protected void createProvider() {
        mMessageViewModel = new ViewModelProvider(this).get(MessageViewModel.class);
        readMsgViewModel = new ViewModelProvider(this).get(ReadMsgViewModel.class);

        //具体消息类型未读量
        XLiveDataManager.getInstance().unreadTypeLiveData.observe(this, new SimpleObserver<BaseEntity<UnRendTypeEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<UnRendTypeEntity> baseEntity) {
                UnRendTypeEntity entity = baseEntity.getData();
                if (entity.getActivityCount() > 0) {
                    activeDot.setVisibility(View.VISIBLE);
                } else {
                    activeDot.setVisibility(View.INVISIBLE);
                }

                if (entity.getNoticeCount() > 0) {
                    noticeDot.setVisibility(View.VISIBLE);
                } else {
                    noticeDot.setVisibility(View.INVISIBLE);
                    if (viewPager.getCurrentItem() == 0) {
                        titleBar.setShowRight(View.GONE);
                    }
                }

            }
        });

        //一键标记为已读
        readMsgViewModel.aLLReadedLiveData.observe(this, new SimpleObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if (readType == 1) {//通知消息
                    noticeDot.setVisibility(View.INVISIBLE);
                } else if (readType == 2) {//活动
                    activeDot.setVisibility(View.INVISIBLE);
                }
                titleBar.setShowRight(View.GONE);
                ToastUtils.showLong("标记成功");
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        viewPager.setOffscreenPageLimit(3);
        index = bundle.getInt(ABConfig.KEY_TAG);
        viewPager.setCurrentItem(index, false);
        if (index == 2) {//只有通告才不显示右边按钮
            titleBar.setShowRight(View.GONE);
        }
        noticeDot.setVisibility(View.INVISIBLE);
        activeDot.setVisibility(View.INVISIBLE);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                if (position == 2) {//只有通告才不显示右边按钮
                    titleBar.setShowRight(View.GONE);
                }
                index = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        titleBar.setRightOnClickListener(view -> {
            //一键标记通知为已读
            readType = viewPager.getCurrentItem() + 1;
            readMsgViewModel.onekeyReaded(readType);
        });
    }

    /**
     * 没有未读消息隐藏小红点
     * type: 1 通知  2 活动
     */
    public void hideDotView(int type) {
        if (type == 1) {
            noticeDot.setVisibility(View.GONE);
        } else if (type == 2) {
            activeDot.setVisibility(View.GONE);
        }
    }

    @Override
    public Fragment getCurrentItem(int position) {
        //position 消息类型1.通知 2.活动 3.公告
        msgType = position + 1;
        if (msgType == 3) {//系统公告类型，界面样式不一样
            return MessageSysFragment.getInstance(msgType);
        }
        return MessageFragment.getInstance(msgType);
    }

    @Override
    public String[] getTabTitles() {
        return new String[]{"通知", "活动", "公告"};
    }

    @Override
    public CommonNavigatorAdapter getNavigatorAdapter() {
        CommonNavigatorAdapter mAdapter = new CommonNavigatorAdapter() {
            @Override
            public int getCount() {
                return tabTitles.length;
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int position) {
                BadgePagerTitleView badgePagerTitleView = new BadgePagerTitleView(context);
                SimplePagerTitleView tabView = new SimplePagerTitleView(context);
                tabView.setPadding(SizeUtils.dp2px(15), 0, SizeUtils.dp2px(15), 0);
                tabView.setNormalColor(ResUtils.getColor(R.color.generic_huise));
                tabView.setSelectedColor(ResUtils.getColor(R.color.black));
                tabView.setText(tabTitles[position]);
                tabView.setOnClickListener(v -> viewPager.setCurrentItem(position));
                badgePagerTitleView.setInnerPagerTitleView(tabView);
                if (position == 0) {
                    noticeDot = LayoutInflater.from(context).inflate(R.layout.message_dot_badge, null);
                    badgePagerTitleView.setBadgeView(noticeDot);
                    badgePagerTitleView.setXBadgeRule(new BadgeRule(BadgeAnchor.CENTER_X, SizeUtils.dp2px(15)));
                    badgePagerTitleView.setYBadgeRule(new BadgeRule(BadgeAnchor.CENTER_Y, SizeUtils.dp2px(-12)));
                }

                if (position == 1) {
                    activeDot = LayoutInflater.from(context).inflate(R.layout.message_dot_badge, null);
                    badgePagerTitleView.setBadgeView(activeDot);
                    badgePagerTitleView.setXBadgeRule(new BadgeRule(BadgeAnchor.CENTER_X, SizeUtils.dp2px(15)));
                    badgePagerTitleView.setYBadgeRule(new BadgeRule(BadgeAnchor.CENTER_Y, SizeUtils.dp2px(-12)));
                }

                badgePagerTitleView.setAutoCancelBadge(false);
                return badgePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator linePagerIndicator = new LinePagerIndicator(context);
                linePagerIndicator.setMode(LinePagerIndicator.MODE_EXACTLY);
                linePagerIndicator.setLineHeight(SizeUtils.dp2px(2));
                linePagerIndicator.setLineWidth(SizeUtils.dp2px(44));
                linePagerIndicator.setRoundRadius(SizeUtils.dp2px(1));
                linePagerIndicator.setColors(ResUtils.getColor(SiteSdk.ins().styleColor()));
                return linePagerIndicator;
            }
        };
        return mAdapter;
    }


    public void showRightTitle(boolean show, int position) {
        if (index != position) {
            return;
        }
        if (show) {
            titleBar.setShowRight(View.VISIBLE);
        } else {
            titleBar.setShowRight(View.GONE);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        mMessageViewModel.getUnreadForType();
    }
}
