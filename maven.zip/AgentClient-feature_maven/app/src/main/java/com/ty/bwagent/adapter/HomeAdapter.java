package com.ty.bwagent.adapter;

import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.QuickEntity;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 描述 首页快捷入口是适配器
 * <p>
 * author:Dale
 */
public class HomeAdapter extends BaseQuickAdapter<QuickEntity, BaseViewHolder> {

    int itemHeight = 0;

    public HomeAdapter() {
        super(R.layout.recycle_item_quick_home);
        List<QuickEntity> quickEntityList = new ArrayList<>();
        quickEntityList.add(new QuickEntity("成员管理", "管理下级成员", R.mipmap.home_item_member_bg));
        quickEntityList.add(new QuickEntity("推广管理", "招募下级成员", R.mipmap.home_item_share_bg));
        quickEntityList.add(new QuickEntity("佣金报表", "查看佣金明细", R.mipmap.home_item_table_bg));
        quickEntityList.add(new QuickEntity("佣金提款", "佣金余额提现", R.mipmap.home_item_money_bg));
        quickEntityList.add(new QuickEntity("代理代存", "即将上线", R.mipmap.home_item_daili_bg));
        quickEntityList.add(new QuickEntity("VIP专享", "即将上线", R.mipmap.home_item_vip_bg));
        setNewData(quickEntityList);
    }

    public void setItemHeight(int itemHeight) {
        this.itemHeight = itemHeight;
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, QuickEntity mQuickEntity) {
        LinearLayout item_rootView = helper.getView(R.id.item_rootView);
        ViewGroup.LayoutParams lp = item_rootView.getLayoutParams();
        lp.height = itemHeight;
        item_rootView.setLayoutParams(lp);
        helper.setText(R.id.home_tv_title, mQuickEntity.getTitle());
        helper.setText(R.id.home_tv_info, mQuickEntity.getInfo());
        helper.setImageResource(R.id.home_iv_icon, mQuickEntity.getResId());
        if(StringUtils.equals("代理代存",mQuickEntity.getTitle()) || StringUtils.equals("VIP专享",mQuickEntity.getTitle())){
            item_rootView.setBackgroundColor(ResUtils.getColor(R.color.x_window_color));
        }else {
            item_rootView.setBackgroundColor(ResUtils.getColor(R.color.white));
        }
    }

}
