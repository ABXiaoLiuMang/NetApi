package com.ty.bwagent.view.table;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ty.bwagent.R;

import java.util.HashSet;

/**
 * 表格
 */
public class TableView extends LinearLayout  {

    private RecyclerView recyclerView;
    private TableRowView column_header;
    private RowAdapter rowAdapter;

    public TableView(@NonNull Context context) {
        super(context);
        init();
    }

    public TableView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public TableView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(VERTICAL);
        LayoutInflater.from(getContext()).inflate(R.layout.table_layout, this, true);
        recyclerView = findViewById(R.id.column_recyclerView);
        column_header = findViewById(R.id.column_header);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
    }



    public void setAdapter(TableAdapter adapter) {
        if (rowAdapter != null) {
            rowAdapter.destroy();
            rowAdapter = null;
        }
        if (adapter == null) {
            return;
        }
        rowAdapter = new RowAdapter(adapter);
        recyclerView.setAdapter(rowAdapter);
        adapter.setRecyclerAdapter(rowAdapter);
        column_header.setAdapter(new TableRowView.TableColumnAdapter(adapter, 0));
        rowAdapter.initRow(column_header);
    }


    static class RowVH extends RecyclerView.ViewHolder {
        TableRowView v;

        public RowVH(TableRowView itemView) {
            super(itemView);
            v = itemView;
        }
    }

    static class RowAdapter extends RecyclerView.Adapter<RowVH> {
        TableAdapter delegate;
        int firstPos = -1;
        int firstOffset = -1;
        HashSet<RecyclerView> observerList;
        private RecyclerView.OnScrollListener onScrollListener = new RecyclerView.OnScrollListener() {

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                firstPos = linearLayoutManager.findFirstVisibleItemPosition();
                View firstVisibleItem = linearLayoutManager.getChildAt(0);
                if (firstVisibleItem != null) {
                    firstOffset = linearLayoutManager.getDecoratedRight(firstVisibleItem);
                    for (RecyclerView rv : observerList) {
                        if (recyclerView != rv) {
                            LinearLayoutManager layoutManager = (LinearLayoutManager) rv.getLayoutManager();
                            if (layoutManager != null) {
                                layoutManager.scrollToPositionWithOffset(firstPos + 1, firstOffset);
                            }
                        }
                    }
                }
            }

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }
        };
        private OnTouchListener onTouchListener = new OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                    case MotionEvent.ACTION_POINTER_DOWN:
                        for (RecyclerView rv : observerList) {
                            if (rv != null) {
                                rv.stopScroll();
                            }
                        }
                }
                return false;
            }
        };

        RowAdapter(TableAdapter delegate) {
            this.delegate = delegate;
            observerList = new HashSet<>();
        }

        @Override
        public RowVH onCreateViewHolder(ViewGroup parent, int viewType) {
            TableRowView v = new TableRowView(parent.getContext());
            initRow(v);
            return new RowVH(v);
        }



        private void initRow(RecyclerView recyclerView) {
            recyclerView.setHasFixedSize(true);
            LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
            if (layoutManager != null && firstPos > 0 && firstOffset > 0) {
                layoutManager.scrollToPositionWithOffset(firstPos + 1, firstOffset);
            }
            observerList.add(recyclerView);
            recyclerView.setOnTouchListener(onTouchListener);
            recyclerView.addOnScrollListener(onScrollListener);
        }

        public void destroy() {
            for (RecyclerView rv : observerList) {
                if (rv != null) {
                    rv.removeOnScrollListener(onScrollListener);
                    rv.setOnTouchListener(null);
                }
            }
            observerList.clear();
        }

        @Override
        public void onBindViewHolder(RowVH holder, int position) {
            int p = position + 1;
            if (holder.v.getAdpater() == null) {
                holder.v.setAdapter(new TableRowView.TableColumnAdapter(delegate, p));
            } else {
                holder.v.getAdpater().setRow(p);
            }
        }

        @Override
        public int getItemCount() {
            return delegate.getRowCount() -1;
        }
    }

}
