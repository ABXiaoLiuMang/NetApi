package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.exchange.StringUtil;
import com.ty.bwagent.fragment.finance.adapter.FinanceSaveAdapter;
import com.ty.bwagent.fragment.finance.adapter.FinanceTaxAdapter;
import com.ty.bwagent.fragment.finance.bean.FinanceDeposit;
import com.ty.bwagent.fragment.finance.bean.FinanceTax;
import com.ty.bwagent.fragment.finance.viewmodel.FinanceDetailsViewModel;
import com.ty.bwagent.fragment.finance.viewmodel.FinanceTaxViewModel;
import com.ty.bwagent.utils.Utils;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.TimeUtils;

import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 月度详细-存款
 */
public class FinanceSaveFragment extends ABRefreshFragment<FinanceDeposit> {

    FinanceDetailsViewModel financeTaxViewModel;

    LinearLayout title_layout;//顶部标题布局
    TextView tv_month;//查询月份
    TextView tax_total;//场馆费
    TextView month_text;//月度明细月份
    FinanceEntity financeEntity;//佣金明细对象

    private LinearLayout ll_net;
    private TextView bnt_nonet;

    public static FinanceSaveFragment getInstance(Bundle bundle) {
        FinanceSaveFragment fragment = new FinanceSaveFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_details;
    }

    @Override
    protected void createProvider() {
        financeTaxViewModel = new ViewModelProvider(this).get(FinanceDetailsViewModel.class);

        //存款月度明细
        financeTaxViewModel.financeDepositNetLiveData.observe(this, new SimpleObserver<BaseEntity<List<FinanceDeposit>>>() {

            @Override
            protected void onSuccess(BaseEntity<List<FinanceDeposit>> listBaseEntity) {
                ll_net.setVisibility(View.GONE);

                if (listBaseEntity.getData().size() > 0) {
                    title_layout.setVisibility(View.VISIBLE);
                } else {
                    title_layout.setVisibility(View.GONE);
                }
                listAdapter.setNewData(listBaseEntity.getData());
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                ll_net.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        ll_net = rootView.findViewById(R.id.ll_net);
        bnt_nonet = rootView.findViewById(R.id.bnt_nonet);

        financeEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        String startData = bundle.getString(ABConfig.KEY_TAG);
        financeTaxViewModel.queryDeposit(startData + "-01", StringUtil.getLastDayOfMonth(startData));
        tv_month.setText(startData);
        month_text.setText(startData);
        tax_total.setText(Utils.roundDownMoney(financeEntity.getDeposit()));

        bnt_nonet.setOnClickListener(v -> financeTaxViewModel.queryDeposit(startData + "-01", StringUtil.getLastDayOfMonth(startData)));

    }

    @Override
    public int getMode() {
        return Mode.DISABLED;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public View getHeaderView() {
        View header = View.inflate(mContext, R.layout.header_finance_save, null);
        title_layout = header.findViewById(R.id.title_layout);
        tv_month = header.findViewById(R.id.tv_month);
        tax_total = header.findViewById(R.id.tax_total);
        month_text = header.findViewById(R.id.month_text);
        return header;
    }

    @Override
    public BaseQuickAdapter<FinanceDeposit, BaseViewHolder> getListAdapter() {
        return new FinanceSaveAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//        FinanceTax financeTax = (FinanceTax) adapter.getItem(position);
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
    }


}
