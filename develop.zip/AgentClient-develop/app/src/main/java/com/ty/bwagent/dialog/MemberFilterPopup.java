package com.ty.bwagent.dialog;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lxj.xpopup.animator.PopupAnimator;
import com.lxj.xpopup.animator.TranslateAnimator;
import com.lxj.xpopup.enums.PopupAnimation;
import com.lxj.xpopup.impl.PartShadowPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.exchange.StringUtil;
import com.ty.bwagent.view.SelectSingleTimeView;
import com.ty.bwagent.view.SelectTimeView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Date;

import androidx.fragment.app.Fragment;

/**
 * 成员记录筛选框
 */
public class MemberFilterPopup extends PartShadowPopupView implements View.OnClickListener {

    ClearEditText et_input;
    private TextView tv_reset;
    private SelectSingleTimeView selectTimeView;
    private OnFilterCallBackListener onFilterCallBackListener;

    public String accoutName = "";//团队管理

    public String accoutName1 = "";//财务自由
    public String month1 = "";

    public String accoutName2 = "";//团队佣金
    public String month2 = "";
    private int fragPositon;
    private LinearLayout ll_month;
    private LinearLayout ll_main;
    private View view_line;


    public MemberFilterPopup(Fragment fragment, int fragPositon, OnFilterCallBackListener onFilterCallBackListener) {
        super(fragment.getContext());
        this.fragPositon = fragPositon;
        this.onFilterCallBackListener = onFilterCallBackListener;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_filter_manager;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_reset = findViewById(R.id.tv_reset);
        et_input = findViewById(R.id.et_input);
        ll_month = findViewById(R.id.ll_month);
        view_line = findViewById(R.id.view_line);
        ll_main = findViewById(R.id.ll_main);

        selectTimeView = findViewById(R.id.selectTimeView);
        tv_reset.setOnClickListener(this);
        tv_reset.setTextColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        tv_reset.setBackgroundColor(ResUtils.getColor(SiteSdk.ins().btnEnableColor()));

        findViewById(R.id.tv_sure).setOnClickListener(this::onClick);
        findViewById(R.id.tv_reset).setOnClickListener(this::onClick);

        setFragPositon(fragPositon);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_reset:
                dismiss();
                selectTimeView.onReset();
                et_input.setText("");
                setDate();
                break;
            case R.id.tv_sure:
                dismiss();
                setDate();
                break;
        }
    }

    public void setDate() {
        switch (fragPositon) {
            case 0:
                accoutName = et_input.getText().toString().trim();
                if (onFilterCallBackListener != null) {
                    onFilterCallBackListener.OnDateBack("", accoutName);
                }
                break;
            case 1:
                accoutName1 = et_input.getText().toString().trim();
                month1 = selectTimeView.getTime();
                if (onFilterCallBackListener != null) {
                    onFilterCallBackListener.OnDateBack(month1, accoutName1);
                }
                break;
            case 2:
                accoutName2 = et_input.getText().toString().trim();
                month2 = selectTimeView.getTime();
                if (onFilterCallBackListener != null) {
                    onFilterCallBackListener.OnDateBack(month2, accoutName2);
                }
                break;
        }
    }


    public void setFragPositon(int fragPositon) {

        this.fragPositon = fragPositon;
        if (ll_month == null) {
            return;
        }
        if (fragPositon == 0) {//团队管理
            if (ll_month.getVisibility() == VISIBLE) {
                ll_month.setVisibility(GONE);
                view_line.setVisibility(INVISIBLE);
            }
            et_input.setText(accoutName);
        } else if (fragPositon == 1) {//团队财务
                ll_month.setVisibility(VISIBLE);
                view_line.setVisibility(VISIBLE);
            et_input.setText(accoutName1);
            if (StringUtils.isEmpty(month1)) {
                month1 = TimeUtils.getDiffMonth(-1);
                selectTimeView.setInitTime(StringUtil.getYMToDate(month1));
            } else {
                selectTimeView.setInitTime(StringUtil.getYMToDate(month1));
            }
        } else {//团队佣金
            if (ll_month.getVisibility() != VISIBLE) {
                ll_month.setVisibility(VISIBLE);
                view_line.setVisibility(VISIBLE);
            }
            et_input.setText(accoutName2);
            if (StringUtils.isEmpty(month2)) {
                month2 = TimeUtils.getDiffMonth(-1);
            }
            selectTimeView.setInitTime(StringUtil.getYMToDate(month2));
        }

    }

    public interface OnFilterCallBackListener {
        void OnDateBack(String time, String name);
    }

}