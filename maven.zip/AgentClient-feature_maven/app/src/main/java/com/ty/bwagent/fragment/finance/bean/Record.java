package com.ty.bwagent.fragment.finance.bean;

import java.util.List;

/**
 * 描述:
 * <p>
 * author:Dale
 */
public class Record {


    /**
     * endRow : 9
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : true
     * isLastPage : true
     * list : [{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394755358789632","createdAt":"2020-01-07T11:52:07","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394753437798400","createdAt":"2020-01-07T11:52:07","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394756768075776","createdAt":"2020-01-07T11:52:07","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394755694333952","createdAt":"2020-01-07T11:52:07","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394754717061120","createdAt":"2020-01-07T11:52:07","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394753760759808","createdAt":"2020-01-07T11:52:07","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394751000907776","createdAt":"2020-01-07T11:52:06","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394751718133760","createdAt":"2020-01-07T11:52:06","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394748866007040","createdAt":"2020-01-07T11:52:06","status":"审核中"},{"amount":111,"bankCard":"****1234","bankCode":"ABC","bankRealname":"小**","billNo":"WT1214394752749932544","createdAt":"2020-01-07T11:52:06","status":"审核中"}]
     * navigateFirstPage : 1
     * navigateLastPage : 1
     * navigatePages : 8
     * navigatepageNums : [1]
     * nextPage : 0
     * pageNum : 2
     * pageSize : 10
     * pages : 1
     * prePage : 0
     * size : 10
     * startRow : 0
     * total : 330
     */

    private int endRow;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private int navigateFirstPage;
    private int navigateLastPage;
    private int navigatePages;
    private int nextPage;
    private int pageNum;
    private int pageSize;
    private int pages;
    private int prePage;
    private int size;
    private int startRow;
    private int total;
    private List<ListBean> list;

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * amount : 111.0
         * bankCard : ****1234
         * bankCode : ABC
         * bankRealname : 小**
         * billNo : WT1214394755358789632
         * createdAt : 2020-01-07T11:52:07
         * status : 审核中
         */

        private double amount;
        private String bankCard;
        private String bankCode;
        private String bankName;
        private String bankRealname;
        private String billNo;
        private String createdAt;
        private String status;

        public double getAmount() {
            return amount;
        }

        public void setAmount(double amount) {
            this.amount = amount;
        }

        public String getBankCard() {
            return bankCard;
        }

        public void setBankCard(String bankCard) {
            this.bankCard = bankCard;
        }

        public String getBankCode() {
            return bankCode;
        }

        public void setBankCode(String bankCode) {
            this.bankCode = bankCode;
        }

        public String getBankRealname() {
            return bankRealname;
        }

        public void setBankRealname(String bankRealname) {
            this.bankRealname = bankRealname;
        }

        public String getBillNo() {
            return billNo;
        }

        public void setBillNo(String billNo) {
            this.billNo = billNo;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getBankName() {
            return bankName;
        }

        public void setBankName(String bankName) {
            this.bankName = bankName;
        }
    }
}
