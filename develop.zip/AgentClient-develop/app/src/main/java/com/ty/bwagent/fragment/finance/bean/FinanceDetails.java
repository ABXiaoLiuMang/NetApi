package com.ty.bwagent.fragment.finance.bean;

/**
 * 描述: 佣金 -冲正后输赢 - 净输赢
 * <p> 三个模块数据一样
 * author:Dale
 */
public class FinanceDetails {

    /**
     * level : 1
     * maxAmount : 40000.0
     * minAmount : 1.0
     * name : 一星代理
     * num : 4
     * rate : 0.3
     */

    private int level;//级别
    private double maxAmount;//最大金额（公司本月总输赢最大值）
    private double minAmount;//最小金额（公司本月总输赢最小值）
    private String name;//名称
    private int num;//活跃人数（活跃玩家最低要求）
    private double rate;//佣金比例

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public double getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(double maxAmount) {
        this.maxAmount = maxAmount;
    }

    public double getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(double minAmount) {
        this.minAmount = minAmount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
}
