package com.ty.bwagent.dialog;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.core.CenterPopupView;
import com.ty.bwagent.R;

/**
 * 代理代存温馨提示弹窗
 */
public class DepositTipsPopup extends CenterPopupView {

    TextView tv_confirm;
    Context mContext;

    public DepositTipsPopup(@NonNull Context context) {
        super(context);
        mContext = context;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_deposit_tips;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_confirm = findViewById(R.id.tv_confirm);
        tv_confirm.setOnClickListener(v -> {
            dismiss();
        });
    }


}
