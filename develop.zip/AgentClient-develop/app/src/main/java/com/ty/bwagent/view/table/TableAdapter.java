package com.ty.bwagent.view.table;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public abstract class TableAdapter<T> {


    public abstract int getRowCount();

    public abstract void setRecyclerAdapter(RecyclerView.Adapter adapter);

    public abstract void addDatas(List<T> datas);

    public abstract void setNewDatas(List<T> datas);

    public abstract int getColumnCount();


    public int getItemViewType(int row, int column) {
        return 0;
    }


    public abstract void onBindViewHolder(RecyclerView.ViewHolder holder, int row, int column);


    public abstract RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType);

}
