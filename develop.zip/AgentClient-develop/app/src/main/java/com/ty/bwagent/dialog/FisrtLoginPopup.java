package com.ty.bwagent.dialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lxj.xpopup.core.CenterPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.tysite.SiteConfig;
import com.ty.tysite.SiteSdk;
import com.ty.utils.TextCopyUtils;

import androidx.annotation.NonNull;

/**
 * //登录用户注册后第一次进入APP，注意如果已在代理web端弹出过了，则进入APP则不再弹出；
 */
public class FisrtLoginPopup extends CenterPopupView implements View.OnClickListener {

    Context mContext;
    ContactUsEntity mData;
    private TextView tv_title;
    private TextView tv_ok;
    private LinearLayout ll_content;

    public FisrtLoginPopup(@NonNull Context context, ContactUsEntity mData) {
        super(context);
        mContext = context;
        this.mData = mData;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_first_login;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        initView();
        setDate();
    }

    private void initView() {
        tv_title = findViewById(R.id.tv_title);
        tv_ok = findViewById(R.id.tv_ok);
        ll_content = findViewById(R.id.ll_content);
        tv_ok.setOnClickListener(this);
    }

    private void setDate() {

        if (mData != null && mData.getBaseInfo() != null) {
            for (ContactUsEntity.BaseInfo baseInfo : mData.getBaseInfo()) {
                if ("0".equals(baseInfo.getIsEnable())) {
                    View rootView = LayoutInflater.from(mContext).inflate(R.layout.item_first_login, null);
                    ll_content.addView(rootView);
                    TextView tv_copy = rootView.findViewById(R.id.tv_copy);
                    TextView tv_name = rootView.findViewById(R.id.tv_name);
                    TextView tv_content = rootView.findViewById(R.id.tv_content);
                    tv_content.setText(baseInfo.getDeviceNum());
                    tv_name.setText(baseInfo.getDeviceText());
                    tv_copy.setOnClickListener(v -> TextCopyUtils.getSelectText(tv_content, TextCopyUtils.SelectMode.COPY));
                }
            }
            SiteConfig siteConfig = (SiteConfig) SiteSdk.ins();
            tv_title.setText("恭喜成为" + siteConfig.getSiteName() + "合营伙伴!");
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_ok:
                dismiss();
                break;
        }

    }
}
