package com.ty.bwagent.common;

import com.google.gson.reflect.TypeToken;
import com.ty.net.utils.JsonUtils;
import com.ty.utils.MMKVUtil;

/**
 * Desc:
 * Created by Jeff on 2019/6/28
 **/
public class CacheUtil {

    /**
     * 获取缓存实体类
     *
     * @param key    缓存的key
     * @param tClass 需要转换的实体类class
     * @return 返回实体类
     */
    public static  <T> T getObject(String key, Class<T> tClass){
        return JsonUtils.fromJson(MMKVUtil.getString(key), tClass);
    }

    /**
     * 获取缓存实体类
     *
     * @param key 缓存的key
     * @return 返回实体类
     */
    public static  <T> T getObject(String key, TypeToken<T> type) {
        return JsonUtils.fromJson(MMKVUtil.getString(key), type.getType());
    }

    public static void putObject(String key, Object value) {
        MMKVUtil.put(key, JsonUtils.toJson(value));
    }

}
