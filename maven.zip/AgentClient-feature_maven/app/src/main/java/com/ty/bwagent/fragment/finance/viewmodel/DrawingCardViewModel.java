package com.ty.bwagent.fragment.finance.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.viewmodel.CodeViewModel;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.ArrayList;

import okhttp3.MediaType;

/**
 * 提款到银行卡
 */
public class DrawingCardViewModel extends CodeViewModel {

    //提款到银行卡
    public NetLiveData<BaseEntity> drawaCardLiveData = new NetLiveData<>();

    /**
     * 提款到银行卡
     * @param code 短信验证码
     * @param bankCode 银行代码
     * @param bank_card 银行卡号
     * @param amount 金额
     * @param bankRealname 真实姓名
     * @param bank_address 开户地址
     */
    public void withdrawalToBank(String code,String bankCode,String bank_card,String amount,String bankRealname,String bank_address){

        DrawalBanKReq banKReq = new DrawalBanKReq()
                .setBankCode(bankCode)
                .setBank_card(bank_card)
                .setAmount(amount)
                .setBankRealname(bankRealname)
                .setBank_address(bank_address);
        ArrayList<DrawalBanKReq> arrayList = new ArrayList<>();
        arrayList.add(banKReq);
        BanKReqBean banKReqBean = new BanKReqBean()
                .setCode(code)
                .setReqArrayList(arrayList);

        NetSdk.create(Api.class)
                .withdrawalToBank()
                .params(banKReqBean)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .send(drawaCardLiveData);
    }

    class BanKReqBean{
        String code;
        ArrayList<DrawalBanKReq> list;

        public String getCode() {
            return code;
        }

        public BanKReqBean setCode(String code) {
            this.code = code;
            return this;
        }

        public ArrayList<DrawalBanKReq> getReqArrayList() {
            return list;
        }

        public BanKReqBean setReqArrayList(ArrayList<DrawalBanKReq> list) {
            this.list = list;
            return this;
        }
    }

    class DrawalBanKReq{
        String bankCode;
        String bank_card;
        String amount;
        String bankRealname;
        String bank_address;

        public String getBankCode() {
            return bankCode;
        }

        public DrawalBanKReq setBankCode(String bankCode) {
            this.bankCode = bankCode;
            return this;
        }

        public String getBank_card() {
            return bank_card;
        }

        public DrawalBanKReq setBank_card(String bank_card) {
            this.bank_card = bank_card;
            return this;
        }

        public String getAmount() {
            return amount;
        }

        public DrawalBanKReq setAmount(String amount) {
            this.amount = amount;
            return this;
        }

        public String getBankRealname() {
            return bankRealname;
        }

        public DrawalBanKReq setBankRealname(String bankRealname) {
            this.bankRealname = bankRealname;
            return this;
        }

        public String getBank_address() {
            return bank_address;
        }

        public DrawalBanKReq setBank_address(String bank_address) {
            this.bank_address = bank_address;
            return this;
        }
    }

}
