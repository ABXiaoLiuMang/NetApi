package com.ty.bwagent.bean;

import android.graphics.Bitmap;

import java.io.File;

/**
 * 图形验证码
 */
public class ValidateCodeEntity {
    private Bitmap bitmap;
    public File file;
    private String code_id;
    private int type;
    private String message;

    public ValidateCodeEntity() {

    }

    public ValidateCodeEntity(int type) {
        this.type = type;
    }

    public ValidateCodeEntity(Bitmap code, String code_id) {
        this.bitmap = code;
        this.code_id = code_id;
    }

    public ValidateCodeEntity(Bitmap code, String code_id, int type) {
        this.bitmap = code;
        this.code_id = code_id;
        this.type = type;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap code) {
        this.bitmap = code;
    }

    public String getCode_id() {
        return code_id;
    }

    public void setCode_id(String code_id) {
        this.code_id = code_id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
