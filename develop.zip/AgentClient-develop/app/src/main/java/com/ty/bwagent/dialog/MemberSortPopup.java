package com.ty.bwagent.dialog;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lxj.xpopup.impl.PartShadowPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.MemberSortAdapter;

/**
 * 成员中时间排序筛选对话框
 */
public class MemberSortPopup extends PartShadowPopupView {

    RecyclerView recyclerView;
    MemberSortAdapter memberSortAdapter;
    OnSortListener onSortListener;

    public MemberSortPopup(@NonNull Context context) {
        super(context);
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_member_sorttime;
    }

    public MemberSortPopup setOnSortListener(OnSortListener onSortListener) {
        this.onSortListener = onSortListener;
        return this;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        recyclerView = findViewById(R.id.column_recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        memberSortAdapter = new MemberSortAdapter();
        memberSortAdapter.setOnItemClickListener((adapter, view, postion) -> {
            memberSortAdapter.setPostion(postion);
            if(onSortListener != null){
                onSortListener.onSort(postion);
            }
            dismiss();
        });
        recyclerView.setAdapter(memberSortAdapter);

    }

    public interface OnSortListener{
        void onSort(int postion);
    }

}
