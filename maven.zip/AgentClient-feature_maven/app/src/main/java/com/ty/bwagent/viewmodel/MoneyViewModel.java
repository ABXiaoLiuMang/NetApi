package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

/**
 * 佣金钱包（多界面共用，独立出来）
 */
public class MoneyViewModel extends ViewModel {

    //佣金钱包
    public NetLiveData<BaseEntity<Commission>> commissLiveData = new NetLiveData<>();

    public NetLiveData<BaseEntity<String>> drawPhoneLiveData = new NetLiveData<>();

    //代理钱包,查询余额
    public void initMoney(){
        NetSdk.create(Api.class)
                .initMoney()
                .send(commissLiveData);
    }

    //提款获取电话号码
    public void getDrawPhone(){
        NetSdk.create(Api.class)
                .getDrawPhone()
                .send(drawPhoneLiveData);
    }
}
