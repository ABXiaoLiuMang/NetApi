package com.ty.bwagent.dialog;

import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.lxj.xpopup.core.CenterPopupView;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.DialogTextHeightChangeShow;
import com.ty.utils.LogUtils;

import androidx.annotation.NonNull;

public class OverFlowPopup extends CenterPopupView {

    public OverFlowPopup(@NonNull Context context) {
        super(context);

    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_over_flow;
    }


    @Override
    protected void initPopupContent() {
        super.initPopupContent();

        findViewById(R.id.tv_confirm).setOnClickListener(v -> dismiss());

    }


}
