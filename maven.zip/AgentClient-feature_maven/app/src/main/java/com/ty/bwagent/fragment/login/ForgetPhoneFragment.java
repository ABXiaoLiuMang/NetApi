package com.ty.bwagent.fragment.login;

import android.view.View;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ForgetPassEntity;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.viewmodel.ForgetPassWordViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.SingleOnClickListener;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.SpanManager;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

public class ForgetPhoneFragment extends ABBaseFragment {

    @BindView(R.id.forget_phone_warning)
    TextView forgetPhoneWarning;
    @BindView(R.id.forget_tv_phone)
    ClearEditText forgetTvPhone;
    @BindView(R.id.forget_tv_username)
    ClearEditText forgetTvUsername;
    @BindView(R.id.forget_commit)
    TextView forgetCommit;
    @BindView(R.id.forget_custom)
    TextView forgetCustom;

    ForgetPassWordViewModel forgetPassWordViewModel;
    String userName;
    String phone;

    public static ForgetPhoneFragment getInstance() {
        return new ForgetPhoneFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_forgetpass_phone;
    }

    @Override
    protected void createProvider() {
        forgetPassWordViewModel =  new ViewModelProvider(this).get(ForgetPassWordViewModel.class);

        //电话号码找回密码第一步
        forgetPassWordViewModel.findOneLiveData.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ForgetPassEntity forgetPassEntity = new ForgetPassEntity();
                forgetPassEntity.setFromPhone(true)
                        .setName(userName)
                        .setPhone(phone);
                ((ABBaseFragment)getParentFragment()).start(ForgetSetp1Fragment.getInstance(forgetPassEntity));
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
//                forgetPhoneWarning.setText(errMsg);
                ToastUtils.showLong(errMsg);
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        SpanManager.callServiceSpan(forgetCustom, ResUtils.getString(R.string.generic_forgetpass_alert), ResUtils.getColor(SiteSdk.ins().styleColor()), "联系客服", new SingleOnClickListener() {
            @Override
            public void onSingleClick(View view) {
                goActivity(OnlineActivity.class);
            }
        });
        initVerify();
    }

    @OnClick({R.id.forget_commit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.forget_commit:
                showProgressDialog();
                userName = forgetTvUsername.getText().toString().trim();
                phone = forgetTvPhone.getText().toString().trim();
                forgetPassWordViewModel.forgetByPhoneOne(userName,phone);
                break;
        }
    }

    /**
     * 处理各类输入框验证逻辑
     */
    private void initVerify(){
        new InputResultCalculator(Arrays.asList(forgetTvPhone, forgetTvUsername), ok -> {
            userName = forgetTvUsername.getText().toString();
            phone = forgetTvPhone.getText().toString();
            if(VerifyUtils.isUserName(userName) && ParameterVerification.isPhoneNumber(phone)){
                forgetCommit.setEnabled(ok);
            }else {
                forgetCommit.setEnabled(false);
            }
        });

        VerifyUtils.verifyUserName(forgetTvUsername,forgetPhoneWarning);
        VerifyUtils.verifyForgetPhone(forgetTvPhone,forgetPhoneWarning);
        forgetTvPhone.setWarnTv(forgetPhoneWarning);
    }
}
