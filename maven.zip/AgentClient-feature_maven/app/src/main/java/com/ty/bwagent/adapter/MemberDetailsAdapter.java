package com.ty.bwagent.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.MemberGameEntity;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XTextView;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;


/**
 * 描述 成员游戏详情列表
 * <p>
 * author:Dale
 */
public class MemberDetailsAdapter extends BaseQuickAdapter<MemberGameEntity.ListBean, BaseViewHolder> {

    public MemberDetailsAdapter() {
        super(R.layout.item_member_details);
    }


    @Override
    protected void convert(BaseViewHolder helper, MemberGameEntity.ListBean mMemberDetails) {
      helper.setText(R.id.member_game_type,mMemberDetails.getVenueName());
      helper.setText(R.id.member_game_name, StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_game_name),mMemberDetails.getGameName()));
      helper.setText(R.id.member_game_money, Utils.roundDownMoney(mMemberDetails.getBetAmount()));//投注金额
      helper.setText(R.id.member_game_time, mMemberDetails.getBetTime());
      XTextView member_game_win = helper.getView(R.id.member_game_win);//输赢
      member_game_win.setMontyText(mMemberDetails.getNetAmount());
    }

}
