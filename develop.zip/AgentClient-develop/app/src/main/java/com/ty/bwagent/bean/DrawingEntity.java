package com.ty.bwagent.bean;

import com.ty.utils.StringUtils;

/**
 * 确认提款弹窗数据对象
 */
public class DrawingEntity {

    String money;
    String bank_card;//卡号
    String real_name;//真实姓名

    public DrawingEntity(String money, String bank_card, String real_name) {
        this.money = money;
        this.bank_card = bank_card;
        this.real_name = real_name;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getBank_card() {
        if(!StringUtils.isEmpty(bank_card) && StringUtils.length(bank_card) > 4){
            return  "****" + bank_card.substring(bank_card.length() - 4);
        }
        return "";
    }

    public void setBank_card(String bank_card) {
        this.bank_card = bank_card;
    }

    public String getReal_name() {
        if(!StringUtils.isEmpty(real_name)){
            return real_name.substring(0, 1) + "**";
        }
        return "";
    }

    public void setReal_name(String real_name) {
        this.real_name = real_name;
    }
}
