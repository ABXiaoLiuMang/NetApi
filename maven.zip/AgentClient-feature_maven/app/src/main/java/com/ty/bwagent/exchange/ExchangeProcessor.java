package com.ty.bwagent.exchange;

import android.annotation.SuppressLint;
import android.text.TextUtils;
import android.widget.EditText;

import com.ty.utils.LogUtils;

import java.math.BigDecimal;
import java.util.Stack;
import java.util.regex.Pattern;

public class ExchangeProcessor {


    @SuppressLint("SetTextI18n")
    public static void dotDown(EditText edExpression, EditText edResult) {
        if (edResult != null && !edExpression.getTag().equals(ExchangeFragment.TOP_RATE)
                && !edExpression.getTag().equals(ExchangeFragment.BOTTOM_RATE)) {
            String strEdit = edResult.getText().toString();
            if (strEdit.contains(".")) return;
            if (Pattern.matches("^=[0-9].*", strEdit))
                strEdit = "0";
            edResult.setText((strEdit.length() == 0 ? "0" : strEdit) + ".");
            edResult.setSelection(edResult.getText().toString().length());
        } else if (edExpression.getTag() != null && (edExpression.getTag()
                .equals(ExchangeFragment.TOP_RATE) || edExpression.getTag()
                .equals(ExchangeFragment.BOTTOM_RATE))) {
            String strEdit = edExpression.getText().toString();
            if (strEdit.contains(".")) return;
            if (Pattern.matches("^=[0-9].*", strEdit))
                strEdit = "0";
            edExpression.setText((strEdit.length() == 0 ? "0" : strEdit) + ".");
            edExpression.setSelection(edExpression.getText().toString().length());
        }
    }

    //按下数字函数
    public static void numDown(String num, EditText edExpression,
                               EditText edResult, CalculateState calculateState,
                               ExchangeFragment fragment) {
        if (edResult != null && !edExpression.getTag()
                .equals(ExchangeFragment.TOP_RATE) && !edExpression.getTag()
                .equals(ExchangeFragment.BOTTOM_RATE)) {
            if (calculateState.isEqual()) {
                fragment.clearResultAndExp();
                fragment.setEdEnable(true);
            }
            String strEdit = edResult.getText().toString();
            if (calculateState.isOperateDown()) {
                edResult.setText("");
                edResult.setText(num);
                edResult.setSelection(edResult.getText().toString().length());
            } else {
                if (strEdit.contains(".")) {
                    int i = strEdit.indexOf(".");
                    int length = strEdit.substring(i, strEdit.length()).length();
                    if (length > 2) return;
                }
                if (strEdit.equals("0") || Pattern.matches("^=[0-9].*", strEdit)) {
                    edResult.setText(num);
                } else {
                    if (calculateState.isEqual()) {
                        edResult.setText("");
                        edResult.setText(num);
                        calculateState.setEqual(false);
                    } else {
                        edResult.setText(strEdit + num);
                    }
                    edResult.setSelection(edResult.getText().toString().length());
                }
            }
            calculateState.setOperateDown(false);
        }
        if (edExpression != null && edExpression.getTag() != null
                && (edExpression.getTag().equals(ExchangeFragment.TOP_RATE)
                || edExpression.getTag().equals(ExchangeFragment.BOTTOM_RATE))) {
            String strEdit = edExpression.getText().toString();
            calculateState.setOperateDown(false);
            if (strEdit.equals("0") || Pattern.matches("^=[0-9].*", strEdit)) {
                edExpression.setText(num);
                edExpression.setSelection(edExpression.getText().toString().length());
            } else {
                edExpression.setText(strEdit + num);
                edExpression.setSelection(edExpression.getText().toString().length());
            }
        }

    }

    // 按下运算符函数
    public static void operatorDown(String operator, EditText edExpression
            , EditText edResult, CalculateState calculateState) {
        if (edExpression == null) return;
        if (!calculateState.isOperateDown()) {
            String strEdit = edExpression.getText().toString();
            calculateState.setOperateDown(true);
            calculateState.setDotDown(false);
            if (Pattern.matches("^=[0-9].*", strEdit))
                strEdit = strEdit.substring(1, strEdit.length());
            if (calculateState.isEqual()) {
                calculateState.setEqual(false);
                edExpression.setText(strEdit + operator);
            } else if (edResult.getText().toString().length() != 0) {
                edExpression.setText(strEdit + edResult.getText().toString() + operator);
            }
        } else {
            String strEdit = edExpression.getText().toString();
            if (strEdit.length() > 0) {
                calculateState.setOperateDown(true);
                String substring = strEdit.substring(0, strEdit.length() - 1);
                edExpression.setText(substring + operator);
            }
        }
    }


    public static void backSpace(EditText edExpression, EditText edResult,
                                 CalculateState calculateState, ExchangeFragment fragment) {
        if (edExpression == null) return;
        if (edExpression.getTag() instanceof String) {
            if (edExpression.getTag().equals(ExchangeFragment.TOP_RATE) ||
                    edExpression.getTag().equals(ExchangeFragment.BOTTOM_RATE)) {
                String s = edExpression.getText().toString();
                int length = s.length();
                if (Pattern.matches("^=[0-9].*", s)) {
                    edExpression.setText("0");
                } else {
                    int resultLength = edExpression.getText().toString().length();
                    if (resultLength > 0) {
                        edExpression.setText(edExpression.getText().toString().substring(0, resultLength - 1));
                        edExpression.setSelection(edExpression.getText().toString().length());
                    } else if (length > 0) {
                        String word = s.substring(length - 1, length);
                        if (word.equals(".")) calculateState.setDotDown(false);
                        if (word.equals("+") || word.equals("-") || word.equals("×") || word.equals("÷"))
                            calculateState.setOperateDown(false);
                        edExpression.setText(s.substring(0, length - 1));
                        edExpression.setSelection(edExpression.getText().toString().length());
                    }
                }
                return;
            }
        }
        String strEdit1 = edExpression.getText().toString();
        int length = strEdit1.length();
        if (Pattern.matches("^=[0-9].*", strEdit1)) {
            edExpression.setText("0");
            edResult.setText("");
        } else {
            int resultLength = edResult.getText().toString().length();
            if (resultLength > 0) {
                edResult.setText(edResult.getText().toString().substring(0, resultLength - 1));
                edResult.setSelection(edResult.getText().toString().length());
            } else if (length > 0 && edResult != fragment.mEdTopInputRate
                    && edResult != fragment.mEdBottomInputRate) {
                String word = strEdit1.substring(length - 1, length);
                if (word.equals(".")) calculateState.setDotDown(false);
                if (word.equals("+") || word.equals("-") || word.equals("×") || word.equals("÷"))
                    calculateState.setOperateDown(false);
                edExpression.setText(strEdit1.substring(0, length - 1));
                edExpression.setSelection(edExpression.getText().toString().length());
            }
        }
    }


    public static void equal(EditText edExpression, EditText edResult,
                             CalculateState calculateState) {
        if (edExpression == null) return;
        if (edResult == null) return;
        if (calculateState.isEqual()) return;
        calculateState.setEqual(true);
        String strEdit = edExpression.getText().toString() +
                edResult.getText().toString();
        edExpression.setText(strEdit);
        strEdit = strEdit.replace(",", "");
        int length = strEdit.length();
        if (!Pattern.matches("^=[0-9].*", strEdit)) {
            // edResult.setText(strEdit);
            if (Pattern.matches(".*[\\+\\-\\×\\÷\\.]$", strEdit)) {
                strEdit = strEdit.substring(0, length - 1);
            }
            String postfixExp = getPostfixExp(strEdit);
            BigDecimal decimal = calPostfix(postfixExp);

           /* if (s.le > 12) {
                s = new BigDecimal(s).toPlainString();
            }*/
            String s1 = decimal.toPlainString();
            String s2 = subStringDotRight(s1);
            String s = subStringDotLeft(s2);
            String subString = subStringCE(s, ".", "E");
            edResult.setText(StringUtils.addComa(subString));
            edResult.setSelection(edResult.getText().toString().length());
        }
    }

    public static String equal(String strEdit) {
        int length = strEdit.length();
        if (!Pattern.matches("^=[0-9].*", strEdit)) {
            // edResult.setText(strEdit);
            if (Pattern.matches(".*[\\+\\-\\×\\÷\\.]$", strEdit)) {
                strEdit = strEdit.substring(0, length - 1);
            }
            String postfixExp = getPostfixExp(strEdit);
            BigDecimal decimal = calPostfix(postfixExp);

           /* if (s.le > 12) {
                s = new BigDecimal(s).toPlainString();
            }*/
            String s1 = decimal.toPlainString();
            String s2 = subStringDotRight(s1);
            String s = subStringDotLeft(s2);
            String subString = subStringCE(s, ".", "E");
            return subString;
        }
        return "";
    }


    //将中缀表达式转换为后缀表达式
    private static String getPostfixExp(String str) {
        String postfix = "";
        String numString = "";   //因数字 不止一位需要String存储
        Stack numStack = new Stack();
        Stack opStack = new Stack();
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (Character.isDigit(ch) || ch == '.') {    //判定ch 是否是数字 或者是 .
                numString += String.valueOf(ch);        //将数字和 .放入numString，等待下一个运算符
            } else {    //ch为运算符时
                if (numString.length() > 0) {
                    numStack.push(numString);//将此运算符前数字压入数字栈
                    numString = "";         //压入栈后，初始化 numString
                }
                opPush(opStack, numStack, ch);
            }
        }

        //最后判定numString是否为空，因为最后一个可能是数字，没有运算符进行判定
        if (numString.length() > 0)
            numStack.push(numString);

        //检测完后，将运算符栈中转入到数字栈中
        while (!opStack.empty()) {
            numStack.push(opStack.pop());
        }
        //将数字栈打印出来得到后缀表达式
        //此处需要将字符串逆序，才得到后缀表达式，但是有小数点的存在，不能直接用 reverse 的逆序函数
        //通过两个栈的先进后出特点，得到栈的逆序
        while (!numStack.empty()) {
            opStack.push(numStack.pop());
        }
        while (!opStack.empty()) {
            postfix = postfix + String.valueOf(opStack.pop()) + " ";
        }
        return postfix;
    }

    //计算后缀表达式
    private static BigDecimal calPostfix(String str) {
        try {
            String result = "";
            Stack numStack = new Stack();
            for (int i = 0; i < str.length(); i++) {
                char ch = str.charAt(i);
                if (ch == ' ') {
                    //运算符时
                    if (result.length() > 0 && (result.equals("+") || result.equals("-")
                            || result.equals("×") || result.equals("÷"))) {
                        double num = 0;
                        double secondNum = Double.parseDouble(String.valueOf(numStack.pop()));
                        double firstNum = Double.parseDouble(String.valueOf(numStack.pop()));
                        switch (result) {
                            case "+":
                                num = firstNum + secondNum;
                                break;
                            case "-":
                                num = firstNum - secondNum;
                                break;
                            case "×":
                                num = firstNum * secondNum;
                                break;
                            case "÷":
                                num = firstNum / secondNum;
                                break;
                                default:break;
                        }
                        numStack.push(num);
                    } else if (result.length() > 0) {
                        numStack.push(result);
                    }
                    result = "";
                } else {
                    result += String.valueOf(ch);
                }
            }
            return BigDecimal.valueOf(Double.valueOf(String.valueOf(numStack.pop()))).stripTrailingZeros();
        } catch (Exception e) {
        }

        return new BigDecimal(0);
    }

    //获取运算符权重
    private static int getOpWeight(char ch) {
        // + - 权重为1
        if (ch == '+' || ch == '-') return 1;
        //× ÷ 权重为2
        if (ch == '×' || ch == '÷') return 4;
        return -1;
    }

    //将运算符压入栈
    private static void opPush(Stack opStack, Stack numStack, char ch) {
        if (canOpPush(opStack, ch)) {    //判定能否将运算符压入栈内
            opStack.push(ch);           //true则压入栈内
        } else {                        //false（即 待压入运算符优先级 <= 栈顶运算符优先级）
            //将栈顶运算符取出压入数字栈
            numStack.push(String.valueOf(opStack.pop()));
            //此处需要递归判定，弹出所有优先级 >= 该运算符的栈顶元素
            opPush(opStack, numStack, ch);
        }
    }

    //判定运算符能否压入运算符栈
    private static Boolean canOpPush(Stack opStack, char ch) {
        //当运算符栈为空时，返回true；或当待压入运算符权重大于栈顶权重，返回true
        if (opStack.empty() || (getOpWeight(ch) > getOpWeight(String.valueOf(opStack.peek()).charAt(0))))
            return true;
        return false;           //其他情况返回false
    }

    private static String subStringCE(String str, String strStart, String strEnd) {

        /* 找出指定的2个字符在 该字符串里面的 位置 */
        int strStartIndex = str.indexOf(strStart);
        int strEndIndex = str.indexOf(strEnd);

        /* index 为负数 即表示该字符串中 没有该字符 */
        if (strStartIndex < 0) {
            return str;
        }
        if (strEndIndex < 0) {
            return str;
        }
        /* 开始截取 */
        String result = str.substring(strStartIndex, strEndIndex).substring(strStart.length());
        if (result.length() > 6) {
            String substring = result.substring(0, 6);
            result = str.replace(result, substring);
        }
        return result;
    }

    private static String subStringDotLeft(String src) {
        if (src.contains(".") && !src.contains("E")) {
            int i = src.indexOf(".");
            String substring = src.substring(0, i);
            if (substring.length() > 10) {
                StringBuffer stringBuffer = new StringBuffer(src.replace(".", ""));
                String s = stringBuffer.insert(1, ".").toString();
                return s + "E+" + (substring.length() - 1);
            }
        } else if (!src.contains(".") && !src.contains("E")) {
            if (src.length() > 11) {
                StringBuffer stringBuffer = new StringBuffer(src);
                String s = stringBuffer.insert(1, ".").toString();
                return s + "E+" + (src.length() - 1);
            }
        }
        return src;
    }

    private static String subStringDotRight(String src) {
        if (src.contains(".") && !src.contains("E")) {
            int i = src.indexOf(".");
            String substring = src.substring(i, src.length());
            if (substring.length() > 2) {
                return src.substring(0, i + 3);
            }
        }
        return src;
    }

    public static String calculateRate(String rate, String input, boolean isMultiply) {
        input = input.replace(",", "");
        BigDecimal decimal = new BigDecimal(input);
        if (!TextUtils.isEmpty(rate)) {
            if (isMultiply) {
                String exp = rate + "×" + decimal.toPlainString();
                return equal(exp);
            } else {
                String exp = decimal.toPlainString() + "÷" + rate;
                return equal(exp);
            }

        }
        return "";
    }
}
