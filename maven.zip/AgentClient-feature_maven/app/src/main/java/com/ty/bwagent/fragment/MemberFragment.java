package com.ty.bwagent.fragment;

import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.enums.PopupPosition;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.MemberAdapter;
import com.ty.bwagent.bean.ActiveRateEntity;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MemberEntity;
import com.ty.bwagent.bean.MemberLowerEntity;
import com.ty.bwagent.dialog.MemberSortPopup;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.view.ExpandableLayout;
import com.ty.bwagent.view.XPieView;
import com.ty.bwagent.viewmodel.MemberModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 成员
 */
public class MemberFragment extends ABRefreshFragment<MemberEntity.ListBean> {

    MemberModel mMemberModel;
    @BindView(R.id.member_total_count)
    TextView memberTotalCount;
    @BindView(R.id.member_month_add)
    TextView memberMonthAdd;
    @BindView(R.id.member_sort)
    TextView memberSort;
    @BindView(R.id.search_editText)
    ClearEditText searchEditText;
    @BindView(R.id.topExpandableLayout)
    ExpandableLayout topExpandableLayout;
    @BindView(R.id.buttomExpandableLayout)
    ExpandableLayout buttomExpandableLayout;
    @BindView(R.id.mScrollView)
    LinearLayout mScrollView;
    @BindView(R.id.xPieView)
    XPieView xPieView;
    @BindView(R.id.titleBar)
    TitleBar titleBar;


    MemberSortPopup memberSortPopup;//成员中时间排序筛选对话框

    /**
     * 下级成员列表请求参数
     */
    int pageNum = 1;
    int pageSize = 10;

    public static MemberFragment getInstance() {
        MemberFragment fragment = new MemberFragment();
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_member;
    }

    @Override
    protected void createProvider() {
        mMemberModel = new ViewModelProvider(this).get(MemberModel.class);

        //查询下级会员和新增下级会员数量
        mMemberModel.monthOverLiveData.observe(this,new SimpleObserver<BaseEntity<MemberLowerEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<MemberLowerEntity> baseEntity) {
                MemberLowerEntity entity = baseEntity.getData();
                memberTotalCount.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_total), entity.getLowerMemberTotal()));//下级成员累计
                memberMonthAdd.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_member_month), entity.getAddNewLowerMember()));//本月新增
                refreshLayout.finishRefresh();
            }
            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code,errMsg);
                refreshLayout.finishRefresh(false);
            }
        });

        //查询活跃占比,饼状图（当月，当天）
        mMemberModel.activeRateLiveData.observe(this,new NetObserver<BaseEntity<ActiveRateEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<ActiveRateEntity> rateEntityBaseEntity) {
                xPieView.initPieView(rateEntityBaseEntity.getData());
            }
            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //下级成员列表
        mMemberModel.memberListLiveData.observe(this,new NetObserver<BaseEntity<MemberEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<MemberEntity> listBaseEntity) {
                dismissProgressDialog();
                List<MemberEntity.ListBean> entityList = listBaseEntity.getData().getList();
                if(pageNum == 1){
                    listAdapter.setNewData(entityList);
                    refreshLayout.finishRefresh();
                    recyclerView.scrollToPosition(0);
                }else {
                    listAdapter.addData(entityList);
                    refreshLayout.finishLoadMore();
                }
                if(entityList.size() < pageSize){
                    refreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                if(pageNum == 1){
                    ToastUtils.showLong("网络异常，请重试");
                    refreshLayout.finishRefresh(false);
                }else {
                    refreshLayout.finishLoadMore(false);
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        initExpandable();
        titleBar.setRightOnClickListener(view -> DialogUtil.showMemberTipsDialog(mContext));//右上角按钮弹窗
        searchEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if(!hasFocus){//失去焦点
                KeyboardUtils.hideSoftInput(v);
            }
        });

        searchEditText.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(StringUtils.isEmpty(s.toString())){
                    name = "";
                    pageNum = 1;
                    mMemberModel.queryLowerMemberList(sortLastLoginTime,sortAvailableMoney,sortCreateTime,name,pageNum,pageSize);//获取下级成员列表
                }
            }
        });

    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        //每次到这里都要刷新（需求如此）
        initTopView();
    }

    private void initTopView(){
        mMemberModel.queryLowerMember();//查询下级会员和新增下级会员数量
        mMemberModel.queryActiveRate();//获取饼状图数据（当月，当天）
    }


    String name ="";//精准搜索下级用户名
    @OnClick({R.id.member_sort,R.id.searchMember})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.member_sort:
                showTimeSortDialog();
                break;
            case R.id.searchMember://下级成员中搜索按钮事件
                name = searchEditText.getText().toString().trim();
                if(StringUtils.isEmpty(name)){
                    ToastUtils.showLong("请输入账号进行搜索");
                    return;
                }
                KeyboardUtils.hideSoftInput(view);
                showProgressDialog();
                pageNum = 1;
                mMemberModel.queryLowerMemberList(sortLastLoginTime,sortAvailableMoney,sortCreateTime,name,pageNum,pageSize);//获取下级成员列表
                break;

        }
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }


    @Override
    public View getEmptyView() {
        View emptyView = View.inflate(mContext,R.layout.empty_member,null);
        emptyView.setOnClickListener(v -> KeyboardUtils.hideSoftInput(emptyView));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, App.height - SizeUtils.dp2px(280));
        emptyView.setLayoutParams(lp);
        return emptyView;
    }

    @Override
    public BaseQuickAdapter<MemberEntity.ListBean, BaseViewHolder> getListAdapter() {
        return new MemberAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        MemberEntity.ListBean listBean = (MemberEntity.ListBean) adapter.getItem(position);
        ((ABBaseFragment)getParentFragment()).start(MemberDetailsFragment.getInstance(listBean));
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum ++;
        mMemberModel.queryLowerMemberList(sortLastLoginTime,sortAvailableMoney,sortCreateTime,name,pageNum,pageSize);//获取下级成员列表
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        if(topExpandableLayout.isExpanded()){//刷新上面展开视图
            initTopView();
        }else if(buttomExpandableLayout.isExpanded()){//刷新下面展开视图
            pageNum = 1;
            mMemberModel.queryLowerMemberList(sortLastLoginTime,sortAvailableMoney,sortCreateTime,name,pageNum,pageSize);//获取下级成员列表
        }else {//都收缩全部刷新
            initTopView();
            pageNum = 1;
            mMemberModel.queryLowerMemberList(sortLastLoginTime,sortAvailableMoney,sortCreateTime,name,pageNum,pageSize);//获取下级成员列表
        }

    }

    /**
     * 处理折叠布局,展开,收缩，滚动等逻辑
     */
    private void initExpandable(){
        refreshLayout.setEnableLoadMore(false);
        topExpandableLayout.setConsTraintLayout(buttomExpandableLayout);
        buttomExpandableLayout.setConsTraintLayout(topExpandableLayout);
        topExpandableLayout.setScrollView(mScrollView);
        buttomExpandableLayout.setScrollView(mScrollView);
        buttomExpandableLayout.setOnExpansionUpdateListener((expansionFraction, state) -> {
            if(state ==0){//收缩
                refreshLayout.setEnableLoadMore(false);
            }else if(state == 3) {//展开
                pageNum = 1;
                mMemberModel.queryLowerMemberList(sortLastLoginTime,sortAvailableMoney,sortCreateTime,name,pageNum,pageSize);//获取下级成员列表
                refreshLayout.setEnableLoadMore(true);
            }
        });
    }



    /**
     *
     * 下级成员列表排序弹窗
     * 以及搜索逻辑处理
     *
     */
    int sortLastLoginTime = 1;//最后登录时间排序字段(1:desc,2:asc)
    int sortAvailableMoney = -1;//钱包余额排序字段（1:desc,2:asc）;
    int sortCreateTime = -1;//注册时间排序字段(1:desc,2:asc)
    private void showTimeSortDialog() {
        if (memberSortPopup == null) {
            memberSortPopup = new MemberSortPopup(getContext());
            memberSortPopup.setOnSortListener(postion ->{
                switch (postion){//最后登录时间
                   case 0:
                       sortLastLoginTime = 1;
                       sortAvailableMoney = -1;
                       sortCreateTime = -1;
                       memberSort.setText("按最后登录时间排序");
                       break;
                   case 1://钱包余额
                       sortLastLoginTime = -1;
                       sortAvailableMoney = 1;
                       sortCreateTime = -1;
                       memberSort.setText("按钱包余额排序");
                       break;
                   case 2://注册时间
                       sortLastLoginTime = -1;
                       sortAvailableMoney = -1;
                       sortCreateTime = 1;
                       memberSort.setText("按注册时间排序");
                       break;
                }
                showProgressDialog();
                pageNum = 1;
                mMemberModel.queryLowerMemberList(sortLastLoginTime,sortAvailableMoney,sortCreateTime,name,pageNum,pageSize);//获取下级成员列表
            });
            new XPopup.Builder(getContext())
                    .atView(memberSort)
                    .popupPosition(PopupPosition.Bottom)
                    .asCustom(memberSortPopup)
                    .show();
        }
        memberSortPopup.show();
    }
}
