package com.ty.bwagent.bean;

/**
 * 查询下级会员和新增下级会员数量
 */
public class MemberLowerEntity {

    /**
     * addNewLowerMember : 0
     * lowerMemberTotal : 0
     */

    private int addNewLowerMember;//新增下级会员
    private int lowerMemberTotal;//下级会员总数
    private int effectiveActive;//有效活跃会员
    private int nativeMember;//活跃会员


    public int getEffectiveActive() {
        return effectiveActive;
    }

    public void setEffectiveActive(int effectiveActive) {
        this.effectiveActive = effectiveActive;
    }

    public int getNativeMember() {
        return nativeMember;
    }

    public void setNativeMember(int nativeMember) {
        this.nativeMember = nativeMember;
    }

    public int getAddNewLowerMember() {
        return addNewLowerMember;
    }

    public void setAddNewLowerMember(int addNewLowerMember) {
        this.addNewLowerMember = addNewLowerMember;
    }

    public int getLowerMemberTotal() {
        return lowerMemberTotal;
    }

    public void setLowerMemberTotal(int lowerMemberTotal) {
        this.lowerMemberTotal = lowerMemberTotal;
    }
}
