package com.ty.bwagent.view.share;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.constraintlayout.widget.Group;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.SimpleCallback;
import com.ty.bwagent.R;
import com.ty.bwagent.dialog.ShareEditPopup;
import com.ty.utils.ResUtils;
import com.ty.view.SegmentView;

/**
 * 推广素材view
 */
public class ShareLayout extends LinearLayout implements ShareView.RefreshTabTitle {

    Context mContext;
    ShareView shareView;
    SegmentView segmentView;
    TextView progress_title;//编辑类型标题(二维码，url tips)
    TextView gravity_title;//位置标题
    TextView color_title;//颜色标题
    TextView edit_title;//边距类型（推广链接，提示文字等）
    TextView textInputView;//边距类型（推广链接，提示文字等）
    TextView pic_title;//图片标题
    NestedScrollView mScrollView;//滚动视图
    Group group;
    SeekBar seekBar;
    RecyclerView recy_gravity;//位置选择
    RecyclerView recy_color;//颜色选择
    GravityAdapter gravityAdapter;
    ColorAdapter colorAdapter;

    public ShareLayout(Context context) {
        this(context, null);
    }

    public ShareLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ShareLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setOrientation(LinearLayout.VERTICAL);
        mContext = context;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        LayoutInflater.from(mContext).inflate(R.layout.share_layout, this, true);
        mScrollView = findViewById(R.id.mScrollView);
        shareView = findViewById(R.id.shareView);
        segmentView = findViewById(R.id.segmentView);
        progress_title = findViewById(R.id.progress_title);
        gravity_title = findViewById(R.id.gravity_title);
        color_title = findViewById(R.id.color_title);
        edit_title = findViewById(R.id.edit_title);
        seekBar = findViewById(R.id.seekBar);
        pic_title = findViewById(R.id.pic_title);
        recy_gravity = findViewById(R.id.recy_gravity);
        textInputView = findViewById(R.id.text_inputView);
        recy_color = findViewById(R.id.recy_color);
        group = findViewById(R.id.group);
        initView();
    }

    private void initView() {
        //位置
        recy_gravity.setLayoutManager(new GridLayoutManager(getContext(),5));
        gravityAdapter = new GravityAdapter();
        gravityAdapter.setOnItemClickListener((adapter, view, position) -> {
            gravityAdapter.setPostion(position);//更改位置
            shareView.setGravity(position);
        });
        recy_gravity.setAdapter(gravityAdapter);

        //颜色
        recy_color.setLayoutManager(new GridLayoutManager(getContext(),10));
        colorAdapter = new ColorAdapter();
        colorAdapter.setOnItemClickListener((adapter, view, position) -> {
            ColorModel colorModel = (ColorModel) adapter.getItem(position);
            colorAdapter.setPostion(position);//更改位置
            shareView.setColor(colorModel.getColor(),position,colorModel.getTitleColor());
        });
        recy_color.setAdapter(colorAdapter);

        shareView.setRefreshTabTitle(this);
        shareView.setSeekBar(seekBar);
        shareView.setGroup(group);
        shareView.setTextInputView(textInputView);
        shareView.setGravityAdapter(gravityAdapter);
        seekBar.setOnSeekBarChangeListener(shareView);
        seekBar.setProgress(25);
        segmentView.setOnSelectedListener(shareView);
        textInputView.setOnClickListener(v -> showEditDialog());
    }


    /**
     * 设置推广链接url
     * @param url
     */
    public void setUrl(String url) {
        shareView.setUrl(url);
    }

    /**
     * 设置背景图片url
     * @param imageUrl
     */
    public void setImageUrl(String imageUrl) {
        shareView.setImageUrl(imageUrl);
    }

    public void setTips(String tips) {
        shareView.setTips(tips);
    }

    /**
     * 设置图片标题
     * @param picTitle
     */
    public void setPicTitle(String picTitle) {
        pic_title.setText(ResUtils.getString(R.string.generic_share_title,picTitle));
    }

    @Override
    public void onRefreshTitle(String type, String typeGravity, String typeColor, int gravityPostion, int colorPostion,String editTitle) {
        progress_title.setText(type);
        gravity_title.setText(typeGravity);
        color_title.setText(typeColor);
        edit_title.setText(editTitle);
        if(gravityAdapter!= null){
            gravityAdapter.setPostion(gravityPostion);
        }
        if(colorAdapter!= null){
            colorAdapter.setPostion(colorPostion);
        }
    }

    @Override
    public void onScrollToRefresh() {
        mScrollView.scrollTo(0,0);
    }

    public View getShareView() {
        return shareView;
    }


    private void showEditDialog(){
        final ShareEditPopup shareEditPopup = new ShareEditPopup(getContext(),shareView.getInputInitText());
        new XPopup.Builder(getContext())
                .autoOpenSoftInput(true)
                .setPopupCallback(new SimpleCallback() {
                    @Override
                    public void onShow() {
                    }

                    @Override
                    public void onDismiss() {
                        String comment = shareEditPopup.getInputText();
                        textInputView.setText((TextUtils.isEmpty(comment)) ? "" : comment);
                    }
                })
                .asCustom(shareEditPopup)
                .show();
    }
}
