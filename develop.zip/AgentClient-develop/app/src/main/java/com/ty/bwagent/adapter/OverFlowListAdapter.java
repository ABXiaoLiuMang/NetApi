package com.ty.bwagent.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.OverFlowBean;
import com.ty.utils.StringUtils;


/**
 * 溢出列表
 */
public class OverFlowListAdapter extends BaseQuickAdapter<OverFlowBean.ListBean, BaseViewHolder> {

    public final static String STATE_SEE = "see";//查看
    public final static String STATE_APPLY = "apply";//申请
    public final static String STATE_EDITE = "edite";//编辑

    public OverFlowListAdapter() {
        super(R.layout.recycle_item_overflow);
    }

    @Override
    protected void convert(BaseViewHolder helper, OverFlowBean.ListBean entity) {
        helper.setText(R.id.tv_time, entity.getCreateAt());
        helper.setText(R.id.tv_name, "会员账号：" + entity.getMemberName());
        helper.setText(R.id.tv_remark, "备        注：" + entity.getRemark());

        if (StringUtils.isEmpty(entity.getRemark())) {
            helper.setGone(R.id.tv_remark, false);
        } else {
            helper.setGone(R.id.tv_remark, true);
        }

        switch (entity.getApplyStatus()) {//颜色区分：可以申请/待审核-黑色，无法申请/系统驳回/审核拒绝-红色，审核通过-绿色

            case 0://无法申请
                helper.setText(R.id.tv_state, "无法申请");
                helper.setTextColor(R.id.tv_state, mContext.getResources().getColor(R.color.generic_warning));

                helper.setGone(R.id.tv_apply_time, false);
                helper.setGone(R.id.bnt_top, false);
                helper.setGone(R.id.bnt_bottom, false);
                break;
            case 1://可以申请
                helper.setText(R.id.tv_state, "可以申请");
                helper.setText(R.id.bnt_top, "申请");
                helper.setTag(R.id.bnt_top, STATE_APPLY);
                helper.setTextColor(R.id.tv_state, mContext.getResources().getColor(R.color.common_anhei));

                helper.setGone(R.id.tv_apply_time, false);
                helper.setGone(R.id.bnt_top, true);
                helper.setGone(R.id.bnt_bottom, false);

                break;
            case 2://待审核
                helper.setText(R.id.tv_state, "待审核");
                helper.setText(R.id.bnt_top, "查看");
                helper.setTag(R.id.bnt_top, STATE_SEE);
                helper.setText(R.id.bnt_bottom, "编辑");
                helper.setTag(R.id.bnt_bottom, STATE_EDITE);
                helper.setTextColor(R.id.tv_state, mContext.getResources().getColor(R.color.common_anhei));

                helper.setGone(R.id.tv_apply_time, false);
                helper.setGone(R.id.bnt_top, true);
                helper.setGone(R.id.bnt_bottom, true);
                break;
            case 3://审核通过
                helper.setText(R.id.tv_state, "审核通过");
                helper.setText(R.id.tv_apply_time, "审核时间：" + entity.getApplyTime());
                helper.setText(R.id.bnt_top, "查看");
                helper.setTag(R.id.bnt_top, STATE_SEE);
                helper.setTextColor(R.id.tv_state, mContext.getResources().getColor(R.color.generic_lvse_a));

                helper.setGone(R.id.tv_apply_time, true);
                helper.setGone(R.id.bnt_top, true);
                helper.setGone(R.id.bnt_bottom, false);

                break;
            case 4://审核拒绝
                helper.setText(R.id.tv_state, "审核拒绝");
                helper.setText(R.id.bnt_top, "查看");
                helper.setTag(R.id.bnt_top, STATE_SEE);
                helper.setText(R.id.bnt_bottom, "申请");
                helper.setTag(R.id.bnt_bottom, STATE_EDITE);
                helper.setTextColor(R.id.tv_state, mContext.getResources().getColor(R.color.generic_warning));
                helper.setText(R.id.tv_apply_time, "审核时间：" + entity.getApplyTime());

                helper.setGone(R.id.tv_apply_time, true);
                helper.setGone(R.id.bnt_top, true);
                helper.setGone(R.id.bnt_bottom, true);

                break;
            case 5://审核驳回
                helper.setText(R.id.tv_state, "系统驳回");
                helper.setText(R.id.bnt_top, "查看");
                helper.setTag(R.id.bnt_top, STATE_SEE);
                helper.setTextColor(R.id.tv_state, mContext.getResources().getColor(R.color.generic_warning));
                helper.setText(R.id.tv_apply_time, "审核时间：" + entity.getApplyTime());

                helper.setGone(R.id.tv_apply_time, true);
                helper.setGone(R.id.bnt_top, true);
                helper.setGone(R.id.bnt_bottom, false);
                break;
        }
        helper.addOnClickListener(R.id.bnt_top, R.id.bnt_bottom);

    }

}
