package com.ty.bwagent.dialog;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BottomPopupView;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.Key;
import com.ty.constant.PermissionConstants;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TextCopyUtils;
import com.ty.utils.ToastUtils;

/**
 * 分享对话框
 */
public class SharePopup extends BottomPopupView implements View.OnClickListener {

    TextView shareLink;
    TextView sharePic;
    TextView tv_cancel;
    ExtensionEntity extensionEntity;
    Context context;
    String shareUrl;

    public SharePopup(@NonNull Context context, ExtensionEntity extensionEntity) {
        super(context);
        this.context = context;
        this.extensionEntity = extensionEntity;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_share;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        shareLink = findViewById(R.id.share_link);
        sharePic = findViewById(R.id.share_pic);
        tv_cancel = findViewById(R.id.tv_cancel);
        shareLink.setOnClickListener(this);
        tv_cancel.setOnClickListener(this);
        sharePic.setOnClickListener(this);
        if (extensionEntity.isExclusive()) {
            shareUrl = extensionEntity.getUrl();
        } else {
            String inviteCode = MMKVUtil.getString(Key.INVITE_CODE);

            if (StringUtils.equals("h5", extensionEntity.getClientType())) {
                shareUrl = StringUtils.getFormatString("%1$s/entry/register/?i_code=%2$s", extensionEntity.getUrl(), inviteCode);
            } else if (StringUtils.equals("pc", extensionEntity.getClientType())) {
                shareUrl = StringUtils.getFormatString("%1$s/register/?i_code=%2$s", extensionEntity.getUrl(), inviteCode);
            } else {
                shareUrl = StringUtils.getFormatString("%1$s?i_code=%2$s", extensionEntity.getUrl(), inviteCode);
            }

        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_cancel:
                dismiss();
                break;
            case R.id.share_link:
                TextCopyUtils.getSelectText(shareUrl, TextCopyUtils.SelectMode.COPY);
                dismiss();
                break;
            case R.id.share_pic:
                DialogUtil.createPicDailog(context,shareUrl);
                dismiss();
                break;
        }
    }

    @Override
    protected void onDismiss() {
        App.goPhoto = false;
        MainActivity.isDialogShow = false;
        super.onDismiss();
    }

    @Override
    protected void onShow() {
        super.onShow();
        MainActivity.isDialogShow = true;
    }

}
