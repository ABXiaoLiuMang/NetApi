package com.ty.bwagent.header;

import android.animation.ValueAnimator;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;

import com.airbnb.lottie.LottieAnimationView;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshKernel;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.RefreshState;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.ty.bwagent.BuildConfig;
import com.ty.utils.LogUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;

import static com.airbnb.lottie.LottieDrawable.INFINITE;

/**
 * 自定义SmartRefreshLayout的headerView
 * 功能为实现Lottie 自定义json动画
 */
public class MyClassicsRefreshHeader extends LinearLayout implements RefreshHeader, LifecycleObserver {

    private LottieAnimationView mLottieAnimationView;
//    private String mPlatformFlag = getPlatformWithOutSportFlag();
    String mJsonAddress_PullDownToRefresh = "";
    String mJsonAddress_Refreshing = "";
    public MyClassicsRefreshHeader(Context context) {
        super(context);
        initView(context);
    }

    public MyClassicsRefreshHeader(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.initView(context);
    }

    public MyClassicsRefreshHeader(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.initView(context);
    }

    private void initView(Context context) {
        setGravity(Gravity.CENTER);
        setOrientation(VERTICAL);

        int mLoadingVidewHeight;
        String mImageAddetsFolder = "";

        switch (StringUtils.parseInt(BuildConfig.appType)){
            case 6://亿博
                mImageAddetsFolder = "lottie/loading/images_yibo";
                mJsonAddress_PullDownToRefresh = "lottie/loading/loading_yibo2.json";
                mLoadingVidewHeight = 110;
                break;
            case 8://环球
                mJsonAddress_PullDownToRefresh = "lottie/loading/loading_global.json";
                mJsonAddress_Refreshing="lottie/loading/loading_global_circle.json";
                mLoadingVidewHeight = 110;
                break;
            case 4://火狐
                mJsonAddress_PullDownToRefresh = "lottie/loading/loading_fox.json";
                mJsonAddress_Refreshing="lottie/loading/loading_fox_circle.json";
                mLoadingVidewHeight = 80;
                break;
            case 7://AOA
                mJsonAddress_PullDownToRefresh = "lottie/loading/loading_aoa.json";
                mLoadingVidewHeight = 110;
                break;
            case 1://旗舰站
            case 5://KOK
            default:
                mJsonAddress_PullDownToRefresh = "lottie/loading/loading_kok_new.json";
                mLoadingVidewHeight = 110;
                break;
        }

        mLottieAnimationView = new LottieAnimationView(getContext());
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, SizeUtils.dp2px(mLoadingVidewHeight));
        mLottieAnimationView.setLayoutParams(layoutParams);
        addView(mLottieAnimationView);
        mLottieAnimationView.setRepeatCount(INFINITE);
        if (!TextUtils.isEmpty(mImageAddetsFolder)) {
            mLottieAnimationView.setImageAssetsFolder(mImageAddetsFolder);
        }
    }

    /**
     * 获取真实视图（必须返回，不能为null）
     *
     * @return
     */
    @NonNull
    @Override
    public View getView() {
        return this;//真实的视图就是自己，不能返回null
    }

    /**
     * 获取变换方式（必须指定一个：平移、拉伸、固定、全屏）
     *
     * @return
     */
    @NonNull
    @Override
    public SpinnerStyle getSpinnerStyle() {
        return SpinnerStyle.Translate;//指定为平移，不能null
    }


    /**
     * 开始动画（开始刷新或者开始加载动画）
     *
     * @param refreshLayout RefreshLayout
     * @param height        HeaderHeight or FooterHeight
     * @param maxDragHeight 最大拖动高度
     */
    @Override
    public void onStartAnimator(@NonNull RefreshLayout refreshLayout, int height, int maxDragHeight) {
    }

    /**
     * 动画结束
     *
     * @param refreshLayout RefreshLayout
     * @param success       数据是否成功刷新或加载
     * @return 完成动画所需时间 如果返回 Integer.MAX_VALUE 将取消本次完成事件，继续保持原有状态
     */
    @Override
    public int onFinish(@NonNull RefreshLayout refreshLayout, boolean success) {
        //mProgressDrawable.stop();//停止动画
        if (success) {
            //mHeaderText.setText("刷新完成");
        } else {
            //mHeaderText.setText("刷新失败");
        }
        return 500;//延迟500毫秒之后再弹回
    }


    @Override
    public void onStateChanged(@NonNull RefreshLayout refreshLayout, @NonNull RefreshState oldState, @NonNull RefreshState newState) {
        switch (newState) {
            case None:
            case PullDownToRefresh:
                //mHeaderText.setText("下拉开始刷新");
                //mArrowView.setVisibility(VISIBLE);//显示下拉箭头
                //mProgressView.setVisibility(GONE);//隐藏动画
                //mArrowView.animate().rotation(0);//还原箭头方向

                mLottieAnimationView.setRepeatCount(ValueAnimator.INFINITE);
                if(!TextUtils.isEmpty(mJsonAddress_Refreshing)){
                    mLottieAnimationView.loop(false);
                }
                mLottieAnimationView.setAnimation(mJsonAddress_PullDownToRefresh);
                mLottieAnimationView.playAnimation();
                break;
            case Refreshing:
                //mHeaderText.setText("正在刷新");
                //mProgressView.setVisibility(VISIBLE);//显示加载动画
                //mArrowView.setVisibility(GONE);//隐藏箭头
//                Log.i("info", "==============Refreshing");
//                startAnim();
                if(!TextUtils.isEmpty(mJsonAddress_Refreshing)){
                    mLottieAnimationView.setRepeatCount(ValueAnimator.INFINITE);
                    mLottieAnimationView.setAnimation(mJsonAddress_Refreshing);
                    mLottieAnimationView.playAnimation();
                }
                break;
            case ReleaseToRefresh:
                //mHeaderText.setText("释放立即刷新");
                //mArrowView.animate().rotation(180);//显示箭头改为朝上
                break;
            case RefreshFinish:
                mLottieAnimationView.cancelAnimation();
//                isShow = false;
//                closeAnim();
                break;
        }
    }

    @Override
    public boolean isSupportHorizontalDrag() {
        return false;
    }

    /**
     * 尺寸定义初始化完成 （如果高度不改变（代码修改：setHeader），只调用一次, 在RefreshLayout#onMeasure中调用）
     *
     * @param kernel        RefreshKernel 核心接口（用于完成高级Header功能）
     * @param height        HeaderHeight or FooterHeight
     * @param maxDragHeight 最大拖动高度
     */
    @Override
    public void onInitialized(@NonNull RefreshKernel kernel, int height, int maxDragHeight) {
    }

    /**
     * 设置主题颜色 （如果自定义的Header没有主题颜色，本方法可以什么都不处理）
     *
     * @param colors 对应Xml中配置的 srlPrimaryColor srlAccentColor
     */
    @Override
    public void setPrimaryColors(int... colors) {
    }

    @Override
    public void onMoving(boolean isDragging, float percent, int offset, int height, int maxDragHeight) {
    }

    @Override
    public void onReleased(@NonNull RefreshLayout refreshLayout, int height, int maxDragHeight) {

    }

    @Override
    public void onHorizontalDrag(float percentX, int offsetX, int offsetMax) {

    }

    public void bindLifecycle(LifecycleOwner lifecycleOwner) {
        lifecycleOwner.getLifecycle().addObserver(this);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void onDestroy() {
        LogUtils.d("销毁了");
        mLottieAnimationView.removeAllAnimatorListeners();
        mLottieAnimationView.cancelAnimation();
    }
}
