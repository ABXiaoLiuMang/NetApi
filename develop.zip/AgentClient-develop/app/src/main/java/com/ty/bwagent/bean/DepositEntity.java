package com.ty.bwagent.bean;

public class DepositEntity {
    String money;
    String nick;
    String realName;
    int status;//是否禁止
    boolean isTurn;//ture:代理代转 false 代理代存

    public DepositEntity(String money, String nick, String realName,boolean isTurn) {
        this.money = money;
        this.nick = nick;
        this.realName = realName;
        this.isTurn = isTurn;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public boolean isTurn() {
        return isTurn;
    }

    public void setTurn(boolean turn) {
        isTurn = turn;
    }
}
