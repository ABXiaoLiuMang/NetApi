package com.ty.bwagent.bean;

/**
 * 下级成员详情
 */
public class MemberDetailsEntity {

    /**
     * availableMoney : 0.0
     * avater : http://img.bwhou2020.com/1576480523173011.png
     * createdAt : 2020-03-03 21:23:58
     * dayTotalProfit : 0.0
     * id : 2019138792
     * lastLoginTime : 2020-03-03 21:23:59
     * monthTotalProfit : 0.0
     * name : ouou10
     * realName :
     * status : 1
     * totalProfit : 0.0
     * vipLevel : VIP0
     */

    private double availableMoney;
    private String avater;
    private String createdAt;
    private double dayTotalProfit;
    private int id;
    private String lastLoginTime;
    private double monthTotalProfit;
    private String name;
    private String realName;
    private int status;
    private double totalProfit;
    private String vipLevel;

    public double getAvailableMoney() {
        return availableMoney;
    }

    public void setAvailableMoney(double availableMoney) {
        this.availableMoney = availableMoney;
    }

    public String getAvater() {
        return avater;
    }

    public void setAvater(String avater) {
        this.avater = avater;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public double getDayTotalProfit() {
        return dayTotalProfit;
    }

    public void setDayTotalProfit(double dayTotalProfit) {
        this.dayTotalProfit = dayTotalProfit;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(String lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public double getMonthTotalProfit() {
        return monthTotalProfit;
    }

    public void setMonthTotalProfit(double monthTotalProfit) {
        this.monthTotalProfit = monthTotalProfit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public double getTotalProfit() {
        return totalProfit;
    }

    public void setTotalProfit(double totalProfit) {
        this.totalProfit = totalProfit;
    }

    public String getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(String vipLevel) {
        this.vipLevel = vipLevel;
    }
}
