package com.ty.bwagent.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.FinanceAdapter;
import com.ty.bwagent.adapter.FinanceChartAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.CommissionEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.bean.FinanceItemEntity;
import com.ty.bwagent.fragment.finance.fragment.FinanceAccountFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceComFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceReverseFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceTaxFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceTotalFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceVenueFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceWaterFragment;
import com.ty.bwagent.fragment.finance.fragment.FinanceWinFragment;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.ExpandableLayout;
import com.ty.bwagent.view.XSeleSingleTimeView;
import com.ty.bwagent.view.XSelectYMTimeView;
import com.ty.bwagent.view.chart.ChartEntity;
import com.ty.bwagent.viewmodel.FinanceViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.TimeUtils;

import java.util.List;

import butterknife.BindView;
import me.yokeyword.fragmentation.ISupportFragment;

/**
 * 佣金
 */
public class FinanceFragment extends ABRefreshFragment<FinanceItemEntity> {

    FinanceViewModel financeViewModel;

    @BindView(R.id.mScrollView)
    LinearLayout mScrollView;
    @BindView(R.id.topExpandableLayout)
    ExpandableLayout topExpandableLayout;
    @BindView(R.id.buttomExpandableLayout)
    ExpandableLayout buttomExpandableLayout;
    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.finance_money)
    TextView financeMoney;
    @BindView(R.id.finance_money_state)
    TextView financeMoneyState;
    @BindView(R.id.finance_total_money)
    TextView financeTotalMoney;
    @BindView(R.id.finance_total_state)
    TextView financeTotalState;
    @BindView(R.id.finance_ratio)
    TextView financeRatio;
    @BindView(R.id.x_SelectTimeView_top)
    XSelectYMTimeView xSelectTimeViewTop;
    @BindView(R.id.x_SelectTimeView_buttom)
    XSeleSingleTimeView xSelectTimeViewButtom;
    @BindView(R.id.chartRecyclerView)
    RecyclerView chartRecyclerView;//柱状图
    @BindView(R.id.count_4)
    TextView count4;
    @BindView(R.id.count_3)
    TextView count3;
    @BindView(R.id.count_2)
    TextView count2;
    @BindView(R.id.count_1)
    TextView count1;
    @BindView(R.id.count_0)
    TextView count0;

    FinanceChartAdapter financeChartAdapter;//柱状图适配器
    FinanceEntity financeEntity;//佣金明细对象
    String currDate;//当前月份概览查询
    String startDate;//柱状图开始时间
    String endDate;//柱状图结束时间
    String monthDate;//月底详细记录月份


    public static FinanceFragment getInstance() {
        return new FinanceFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance;
    }

    @Override
    protected void createProvider() {
        financeViewModel =  new ViewModelProvider(this).get(FinanceViewModel.class);

        //查询个人佣金信息
        financeViewModel.commissionLiveData.observe(this,new SimpleObserver<BaseEntity<CommissionEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<CommissionEntity> commissionEntityBaseEntity) {
                refreshLayout.finishRefresh();
                CommissionEntity entity = commissionEntityBaseEntity.getData();

                financeMoneyState.setText(entity.getCommissionStatus() == 1 ?"已发放" : "未发放");//发放状态
                financeMoneyState.setTextColor(entity.getCommissionStatus() == 1 ? ResUtils.getColor(R.color.generic_lvse) : ResUtils.getColor(R.color.main_style_color));

                financeTotalMoney.setText(Utils.financeCalculate(entity.getTotalCommission()));//累计可赚佣金
                financeMoney.setText(Utils.financeCalculate(entity.getMonthCommission()));//预计可赚佣金
                financeTotalState.setText(Utils.financeCalculate(entity.getAgentMoney()));//佣金余额
                financeRatio.setText(MathUtil.twoNumber(entity.getRate() * 100) +"%");//佣金比例
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                refreshLayout.finishRefresh(false);
                financeTotalMoney.setText("--");//累计可赚佣金
                financeMoney.setText("--");//预计可赚佣金
                financeTotalState.setText("--");//佣金余额
            }
        });

        //柱状图数据
        financeViewModel.chartsLiveData.observe(this,new SimpleObserver<BaseEntity<List<ChartEntity>>>(){

            @Override
            protected void onSuccess(BaseEntity<List<ChartEntity>> chartEntitys) {
                initChartRecyclerView(chartEntitys.getData());//柱状图
            }
            @Override
            protected void onLoading(boolean show) {
                if(!show){
                    dismissProgressDialog();
                }
            }
        });

        //月度详细数据
        financeViewModel.financeLiveData.observe(this,new NetObserver<BaseEntity<FinanceEntity>>(){

            @Override
            protected void onSuccess(BaseEntity<FinanceEntity> chartEntitys) {
                financeEntity = chartEntitys.getData();
                ((FinanceAdapter)listAdapter).bindFinanceEntity(financeEntity);
            }

            @Override
            protected void onLoading(boolean show) {
                if(!show){
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        startDate = TimeUtils.getDiffMonth(-6);//需求默认7个月(这里传6)
        monthDate = currDate = endDate = TimeUtils.getDiffMonth(0);

        initExpandable();
        titleBar.setRightOnClickListener(view -> {
            DialogUtil.showFinanceTipsDialog(mContext);
        });
        xSelectTimeViewTop.setOnSearchListener((startTime, endTime) -> {
            showProgressDialog();
            this.startDate = startTime;
            this.endDate = endTime;
            financeViewModel.queryCommissionByDate(startTime,endTime);//获取矩形数据(柱状图)
        });
        xSelectTimeViewButtom.setOnSearchListener((month) -> {
            showProgressDialog();
            this.monthDate = month;
            financeViewModel.queryMonthCommissionDetail(month);//月度详细记录
        });
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        //每次到这里都要刷新（需求如此）
        initRequest();
    }

    @Override
    public int getMode() {
        return Mode.PULL_FROM_START;
    }

    @Override
    public BaseQuickAdapter<FinanceItemEntity, BaseViewHolder> getListAdapter() {
        return new FinanceAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        Bundle bundle = new Bundle();
        bundle.putString(ABConfig.KEY_TAG,monthDate);
        switch (position){
            case 0://佣金
                bundle.putParcelable(ABConfig.KEY_OBJECT,financeEntity);
                goFragment(FinanceComFragment.getInstance(bundle));
                break;
            case 1://冲正后输赢
                bundle.putParcelable(ABConfig.KEY_OBJECT,financeEntity);
                goFragment(FinanceReverseFragment.getInstance(bundle));
            case 2://上月结余(无)
                break;
            case 3://净输赢
                bundle.putParcelable(ABConfig.KEY_OBJECT,financeEntity);
                goFragment(FinanceWinFragment.getInstance(bundle));
                break;
            case 4://总输赢
                bundle.putParcelable(ABConfig.KEY_OBJECT,financeEntity);
                goFragment(FinanceTotalFragment.getInstance(bundle));
                break;
            case 5://场馆费
                bundle.putParcelable(ABConfig.KEY_OBJECT,financeEntity);
                goFragment(FinanceVenueFragment.getInstance(bundle));
                break;
            case 6://红利
                bundle.putParcelable(ABConfig.KEY_OBJECT,financeEntity);
                goFragment(FinanceTaxFragment.getInstance(bundle));
                break;
            case 7://返水
                bundle.putParcelable(ABConfig.KEY_OBJECT,financeEntity);
                goFragment(FinanceWaterFragment.getInstance(bundle));
                break;
            case 8://账户调整(按需求，不跳转详情界面了)
//                bundle.putParcelable(ABConfig.KEY_OBJECT,financeEntity);
//                goFragment(FinanceAccountFragment.getInstance(bundle));
                break;
            case 9://佣金调整（无）
                break;
        }
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        startDate = TimeUtils.getDiffMonth(-6);//需求默认7个月(这里传6)
        monthDate = endDate = TimeUtils.getDiffMonth(0);
        xSelectTimeViewTop.onReset();
        xSelectTimeViewButtom.onReset();
        initRequest();
    }

    private void initRequest(){
        financeViewModel.queryCommissionByMemberId(currDate);//查询代理个人佣金信息
        financeViewModel.queryCommissionByDate(startDate,endDate);//获取矩形数据(柱状图)
        financeViewModel.queryMonthCommissionDetail(monthDate);//月度详细记录
    }

    /**
     * 处理折叠布局,展开,收缩，滚动等逻辑
     */
    private void initExpandable(){
        topExpandableLayout.setConsTraintLayout(buttomExpandableLayout);
        buttomExpandableLayout.setConsTraintLayout(topExpandableLayout);
        topExpandableLayout.setScrollView(mScrollView);
        buttomExpandableLayout.setScrollView(mScrollView);
    }

    /**
     * 初始化柱状图
     * @param mDatas
     */
    private void initChartRecyclerView(List<ChartEntity> mDatas) {
        double maxValue = Utils.getMax(mDatas);
        count0.setText(Utils.getChartText(maxValue,0));
        count1.setText(Utils.getChartText(maxValue,1));
        count2.setText(Utils.getChartText(maxValue,2));
        count3.setText(Utils.getChartText(maxValue,3));
        count4.setText(Utils.getChartText(maxValue,4));
        financeChartAdapter = new FinanceChartAdapter(mDatas);
        financeChartAdapter.setMaxValue(maxValue);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        chartRecyclerView.setLayoutManager(linearLayoutManager);
        chartRecyclerView.setAdapter(financeChartAdapter);
    }




    private void goFragment(ISupportFragment supportFragment){
        ((ABBaseFragment)getParentFragment()).start(supportFragment);
    }

}
