package com.ty.bwagent.update;

import android.content.Context;
import android.os.Process;
import android.text.TextUtils;

import androidx.fragment.app.FragmentActivity;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.XPopupCallback;
import com.tianyu.updater.TYUpdater;
import com.tianyu.updater.entity.NotificationEntity;
import com.tianyu.updater.entity.UpdateEntity;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.utils.ExitUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ScreenUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.ToastUtils;

public class XUpdateManager {

    private static XUpdateManager ourInstance = null;

    public static XUpdateManager getInstance() {
        if(ourInstance == null){
            ourInstance = new XUpdateManager();
        }
        return ourInstance;
    }

    private XUpdateManager() {
    }




    public interface UpdateCallBack{
       void onUpdateonDismiss();
    }

    /**
     * 直接调用 show方法
     *
     * @param activity
     * @param xDialogManager
     * @param updateInfo
     */
    public static void showUpdateDialog(Context context, XDialogManager xDialogManager, UpdateEntity updateInfo, UpdateCallBack updateCallBack) {
        if (context == null) {
            return;
        }
        if (xDialogManager == null) {
        }
        if (updateInfo == null) {
            return;
        }
        if (TextUtils.isEmpty(updateInfo.getDownloadUrl())) {
            return;
        }

        if (!TextUtils.isEmpty(updateInfo.getVersionName())) {
            XUpdatePopupViewNew dialog = createUpdateView(context, xDialogManager, updateInfo, updateCallBack);
            if (!dialog.isShowing()) {
                TYUpdater.get()
                        .setNotificationInfo(new NotificationEntity().setShowNotification(true))
                        .setDialogView(dialog)
                        .setUpdateInfo(updateInfo);
//                        .start();

                if (xDialogManager != null) {
                    xDialogManager.showUpdate(dialog);
                } else {
                    dialog.show();
                }
            }
        }

    }


    /**
     * 直接调用 show方法
     *
     * @param activity
     * @param xDialogManager
     * @param updateInfo
     */
    public static void showUpdateDialog(FragmentActivity activity, XDialogManager xDialogManager, UpdateEntity updateInfo) {
        if (activity == null) {
            return;
        }
        if (xDialogManager == null) {
        }
        if (updateInfo == null) {
            return;
        }
        if (TextUtils.isEmpty(updateInfo.getDownloadUrl())) {
            return;
        }

        if (!TextUtils.isEmpty(updateInfo.getVersionName())) {
            XUpdatePopupViewNew dialog = createUpdateView(activity, xDialogManager, updateInfo,null);
            if (!dialog.isShowing()) {
                TYUpdater.get()
                        .setNotificationInfo(new NotificationEntity().setShowNotification(true))
                        .setDialogView(dialog)
                        .setUpdateInfo(updateInfo);
//                        .start();

                if (xDialogManager != null) {
                    xDialogManager.showUpdate(dialog);
                } else {
                    dialog.show();
                }
            }
        }

    }

    /**
     * 创建升级 view
     * @param xDialogManager
     * @param updateInfo
     * @return
     */
    private static XUpdatePopupViewNew createUpdateView(Context context, XDialogManager xDialogManager, UpdateEntity updateInfo,UpdateCallBack updateCallBack) {
        if (context == null) {
            LogUtils.e("UpdaterManager", " XUpdatePopupViewNew Activity == null");
            return null;
        }
        if (updateInfo == null) {
            LogUtils.e("UpdaterManager", "update data == null");
            return null;
        }

        if (TextUtils.isEmpty(updateInfo.getDownloadUrl())) {
            LogUtils.e("UpdaterManager", " XUpdatePopupViewNew download URL == null");
            return null;
        }

        XUpdatePopupViewNew dialog = new XUpdatePopupViewNew(context, xDialogManager);
        dialog.setUpdateInfo(updateInfo);
        final boolean force = updateInfo.isForce();
        new XPopup.Builder(context)
                .dismissOnTouchOutside(!force)
                .dismissOnBackPressed(true)
                .maxWidth(SizeUtils.dp2px(270))
                .setPopupCallback(new XPopupCallback() {
                    @Override
                    public void onCreated() {}

                    @Override
                    public void beforeShow() {}

                    @Override
                    public void onShow() {
                    }

                    @Override
                    public void onDismiss() {
                       if(updateCallBack != null){
                           updateCallBack.onUpdateonDismiss();
                       }
                    }

                    @Override
                    public boolean onBackPressed() {
                        exitApp();
                        return true;
                    }
                })
                .asCustom(dialog);

        return dialog;
    }

    private static long mExitTime = 0;

    private static void exitApp() {
        if ((System.currentTimeMillis() - mExitTime) > 2000) {
            ToastUtils.showLong("再按一次退出游戏");
            mExitTime = System.currentTimeMillis();
        } else {
            ExitUtils.getInstance().finishAll();
            Process.killProcess(android.os.Process.myPid());
            System.gc();
            System.exit(0);
        }
    }

    public void clean(){
        ourInstance = null;
    }


//    /**
//     * 是否有升级
//     *
//     * @param context
//     */
//    public void getUpdateData(FragmentActivity context) {
//        TYUpdater.getUpdateLiveData().observe(context, tyUpdateBean -> {
//            if (tyUpdateBean != null) {
//                if (!TextUtils.isEmpty(tyUpdateBean.getVersion())) {
//                    UpdateEntity updateEntity = new UpdateEntity();
//                    updateEntity.setUpdateInfo(tyUpdateBean);
//                    XLiveDataManager.getInstance().updateResult.postNext(updateEntity);
//                }
//            }
//        });
//
//    }
}
