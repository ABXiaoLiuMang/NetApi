package com.ty.bwagent.adapter

import android.widget.TextView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.ty.bwagent.R
import com.ty.bwagent.bean.AgentLowerListBean
import com.ty.bwagent.utils.TypefaceUtils
import com.ty.bwagent.utils.Utils
import com.ty.bwagent.view.XTextView
import java.lang.Exception


/**
 * 下级代理列表显示
 */
class SubordinateAgentAdapter : BaseQuickAdapter<AgentLowerListBean.ListBean, BaseViewHolder>(R.layout.recycle_item_sub_agent) {

    override fun convert(helper: BaseViewHolder, item: AgentLowerListBean.ListBean) {


        item?.let {

            try {
                val tvName = helper.getView<TextView>(R.id.tv_name)//名字
                tvName.text = item.agentName
                tvName.typeface = TypefaceUtils.DIN_MEDIUM

                val tvSubordinateAgentCount = helper.getView<TextView>(R.id.tv_subordinateAgent_count)//直属代理
                tvSubordinateAgentCount.text = Utils.fmtMicrometer(item.subordinateUserCount.toString() + "")
                tvSubordinateAgentCount.typeface = TypefaceUtils.DIN_MEDIUM

                val tvSubordinateUserCount = helper.getView<TextView>(R.id.tv_subordinateUserCount)//直属玩家
                tvSubordinateUserCount.text = Utils.fmtMicrometer(item.memberCount.toString() + "")
                tvSubordinateUserCount.typeface = TypefaceUtils.DIN_MEDIUM

                val tvLastBalance = helper.getView<TextView>(R.id.tv_lastBalance)//上月结余
                tvLastBalance.text = Utils.parsListMoney(item.lastBalance)
                tvLastBalance.typeface = TypefaceUtils.DIN_MEDIUM

                val tvCzProfit = helper.getView<XTextView>(R.id.tv_czProfit)//总输赢
                tvCzProfit.setMontyText(item.czProfit)

                val tvCommission = helper.getView<TextView>(R.id.tv_commission)//佣金
                tvCommission.text = Utils.parsListMoney(item.commission)
                tvCommission.typeface = TypefaceUtils.DIN_MEDIUM

            } catch (e: Exception) {

            }

        }

    }


}
