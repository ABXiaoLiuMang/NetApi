package com.ty.bwagent.ui;


import android.content.Intent;
import android.view.KeyEvent;
import android.view.View;

import com.ty.bwagent.R;
import com.ty.bwagent.fragment.login.LoginAndRegisterFragment;
import com.ty.common.ui.ABBaseActivity;
import com.ty.utils.ExitUtils;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.LogUtils;

import butterknife.BindView;


public class LoginActivity extends ABBaseActivity {
    @BindView(R.id.fl_container)
    View rootView;


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        LogUtils.d("LoginActivity onNewIntent");
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_root;
    }

    @Override
    protected void createProvider() {
        findViewById(android.R.id.content).setOnClickListener(v -> KeyboardUtils.hideSoftInput(LoginActivity.this));
    }

    @Override
    protected void initViewsAndEvents() {
        if (findFragment(LoginAndRegisterFragment.class) == null) {
            loadRootFragment(R.id.fl_container, LoginAndRegisterFragment.getInstance());
        }

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            exit();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void exit() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if (count > 1) {
            pop();
        } else {
            ExitUtils.getInstance().finishAll();
        }
    }
}
