package com.ty.bwagent.bean;

import java.util.List;

/**
 * 描述: 成员游戏记录列表
 * <p>
 * author:Dale
 */
public class MemberGameRecordEntity {
    /**
     * endRow : 0
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : true
     * isLastPage : true
     * navigateFirstPage : 1
     * navigateLastPage : 1
     * navigatePages : 8
     * navigatepageNums : [1]
     * nextPage : 0
     * pageNum : 1
     * pageSize : 1
     * pages : 1
     * prePage : 0
     * size : 1
     * startRow : 0
     * total : 3
     */

    private int endRow;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private int navigateFirstPage;
    private int navigateLastPage;
    private int navigatePages;
    private int nextPage;
    private int pageNum;
    private int pageSize;
    private int pages;
    private int prePage;
    private int size;
    private int startRow;
    private int total;
    private List<ListBean> list;

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {


        /**
         * agentName : eady1
         * betAmount : 0.0
         * betTime : 2020-04-19 15:40:56
         * billNo : k04eady2_YBW::PG::TRANSFERIN::5615643-5615643-101-0-1587282056237
         * createdAt : null
         * earlySettleFlag : null
         * flag : 1
         * gameName : 象财神
         * gamePlayInfo :
         * gameTpe : null
         * gameUserIp :
         * id : 1
         * memberId : null
         * memberName :
         * name : eady2
         * netAmount : 0.0
         * odds : null
         * oddsType : null
         * settleTime : 2020-04-19 15:40:56
         * sourceUrl :
         * startTime : null
         * topId : 2019139727
         * updatedAt : null
         * validBetAmount : 0.0
         * venueBillNo :
         * venueId : 13
         * venueName : PG电子
         * venueUsername :
         */

        private String agentName;
        private double betAmount;
        private String betTime;
        private String billNo;
        private Object createdAt;
        private Object earlySettleFlag;
        private int flag;
        private String gameName;
        private String gamePlayInfo;
        private Object gameTpe;
        private String gameUserIp;
        private int id;
        private Object memberId;
        private String memberName;
        private String name;
        private double netAmount;
        private Object odds;
        private Object oddsType;
        private String settleTime;
        private String sourceUrl;
        private Object startTime;
        private int topId;
        private Object updatedAt;
        private double validBetAmount;
        private String venueBillNo;
        private int venueId;
        private String venueName;
        private String venueUsername;

        public String getAgentName() {
            return agentName;
        }

        public void setAgentName(String agentName) {
            this.agentName = agentName;
        }

        public double getBetAmount() {
            return betAmount;
        }

        public void setBetAmount(double betAmount) {
            this.betAmount = betAmount;
        }

        public String getBetTime() {
            return betTime;
        }

        public void setBetTime(String betTime) {
            this.betTime = betTime;
        }

        public String getBillNo() {
            return billNo;
        }

        public void setBillNo(String billNo) {
            this.billNo = billNo;
        }

        public Object getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(Object createdAt) {
            this.createdAt = createdAt;
        }

        public Object getEarlySettleFlag() {
            return earlySettleFlag;
        }

        public void setEarlySettleFlag(Object earlySettleFlag) {
            this.earlySettleFlag = earlySettleFlag;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getGameName() {
            return gameName;
        }

        public void setGameName(String gameName) {
            this.gameName = gameName;
        }

        public String getGamePlayInfo() {
            return gamePlayInfo;
        }

        public void setGamePlayInfo(String gamePlayInfo) {
            this.gamePlayInfo = gamePlayInfo;
        }

        public Object getGameTpe() {
            return gameTpe;
        }

        public void setGameTpe(Object gameTpe) {
            this.gameTpe = gameTpe;
        }

        public String getGameUserIp() {
            return gameUserIp;
        }

        public void setGameUserIp(String gameUserIp) {
            this.gameUserIp = gameUserIp;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public Object getMemberId() {
            return memberId;
        }

        public void setMemberId(Object memberId) {
            this.memberId = memberId;
        }

        public String getMemberName() {
            return memberName;
        }

        public void setMemberName(String memberName) {
            this.memberName = memberName;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public double getNetAmount() {
            return netAmount;
        }

        public void setNetAmount(double netAmount) {
            this.netAmount = netAmount;
        }

        public Object getOdds() {
            return odds;
        }

        public void setOdds(Object odds) {
            this.odds = odds;
        }

        public Object getOddsType() {
            return oddsType;
        }

        public void setOddsType(Object oddsType) {
            this.oddsType = oddsType;
        }

        public String getSettleTime() {
            return settleTime;
        }

        public void setSettleTime(String settleTime) {
            this.settleTime = settleTime;
        }

        public String getSourceUrl() {
            return sourceUrl;
        }

        public void setSourceUrl(String sourceUrl) {
            this.sourceUrl = sourceUrl;
        }

        public Object getStartTime() {
            return startTime;
        }

        public void setStartTime(Object startTime) {
            this.startTime = startTime;
        }

        public int getTopId() {
            return topId;
        }

        public void setTopId(int topId) {
            this.topId = topId;
        }

        public Object getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(Object updatedAt) {
            this.updatedAt = updatedAt;
        }

        public double getValidBetAmount() {
            return validBetAmount;
        }

        public void setValidBetAmount(double validBetAmount) {
            this.validBetAmount = validBetAmount;
        }

        public String getVenueBillNo() {
            return venueBillNo;
        }

        public void setVenueBillNo(String venueBillNo) {
            this.venueBillNo = venueBillNo;
        }

        public int getVenueId() {
            return venueId;
        }

        public void setVenueId(int venueId) {
            this.venueId = venueId;
        }

        public String getVenueName() {
            return venueName;
        }

        public void setVenueName(String venueName) {
            this.venueName = venueName;
        }

        public String getVenueUsername() {
            return venueUsername;
        }

        public void setVenueUsername(String venueUsername) {
            this.venueUsername = venueUsername;
        }
    }

}
