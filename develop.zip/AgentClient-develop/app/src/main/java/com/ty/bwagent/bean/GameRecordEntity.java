package com.ty.bwagent.bean;

/**
 * 游戏记录筛选条件
 */
public class GameRecordEntity {

    private String memberName = "";
    private String endDate;
    private String startDate;
    private String venueId = "";
    private String flag = "";


    public GameRecordEntity(String memberName, String startDate, String endDate, String venueId, String flag) {
        this.memberName = memberName;
        this.endDate = endDate;
        this.startDate = startDate;
        this.venueId = venueId;
        this.flag = flag;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getVenueId() {
        return venueId;
    }

    public void setVenueId(String venueId) {
        this.venueId = venueId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
}
