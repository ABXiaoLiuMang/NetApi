package com.ty.bwagent.utils;

import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.CategoriesType;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.utils.StringUtils;

import java.util.ArrayList;

public class ExtensionUtils {


    //  h5(主站h5),pc(主站pc),site(全站APP),sportApp(体育App),privateDomain(专属域名), person(真人), chess(棋牌),
    //  lottery(彩票) 根据终端类型获取推广链接地址,不传值得话默认查询全部
    //1-全站、2-体育、3-棋牌、4-彩票、5-真人、6-全站体育 多个以,分开
    public static ArrayList<CategoriesType> getCategoriesType(BaseEntity<ContactUsEntity> entity) {

        ArrayList<CategoriesType> categoriesTypes = new ArrayList<>();
        categoriesTypes.add(new CategoriesType(-4, "全部", ""));
        categoriesTypes.add(new CategoriesType(-3, "专属域名", "privateDomain"));
        categoriesTypes.add(new CategoriesType(-2, "主站H5", "h5"));
        categoriesTypes.add(new CategoriesType(-1, "主站PC", "pc"));

        if (entity != null && entity.getData() != null && !StringUtils.isEmpty(entity.getData().getCategories())) {
            String[] split = entity.getData().getCategories().split(",");
            for (int i = 0; i < split.length; i++) {
                CategoriesType categoriesType = null;
                switch (split[i]) {
                    case "1":
                        categoriesType = new CategoriesType(1, "全站APP", "site");
                        break;
                    case "2":
                        categoriesType = new CategoriesType(2, "体育APP", "sportApp");
                        break;
                    case "3":
                        categoriesType = new CategoriesType(3, "棋牌APP", "chess");
                        break;
                    case "4":
                        categoriesType = new CategoriesType(4, "彩票APP", "lottery");
                        break;
                    case "5":
                        categoriesType = new CategoriesType(5, "真人APP", "person");
                        break;
                    case "6":
                        categoriesType = new CategoriesType(6, "全站体育APP", "siteSportApp");
                        break;
                }
                if (categoriesType != null) {
                    categoriesTypes.add(categoriesType);
                }
            }
        }
        return categoriesTypes;
    }


    public static ArrayList<CategoriesType> initCatoriseType() {
        ArrayList<CategoriesType> categoriesTypes = new ArrayList<>();
        categoriesTypes.add(new CategoriesType(-4, "全部", ""));
        categoriesTypes.add(new CategoriesType(-3, "专属域名", "privateDomain"));
        categoriesTypes.add(new CategoriesType(-2, "主站H5", "h5"));
        categoriesTypes.add(new CategoriesType(-1, "主站PC", "pc"));
        return categoriesTypes;
    }


    public static String[] getTitle(ArrayList<CategoriesType> categoriesTypes) {
        String[] titles = null;
        if (categoriesTypes != null && categoriesTypes.size() > 0) {
            titles = new String[categoriesTypes.size()];
            for (int i = 0; i < categoriesTypes.size(); i++) {
                titles[i] = categoriesTypes.get(i).getName();
            }
        }
        return titles;
    }


    public static String getName(String clientType) {
        String name = "";
        switch (clientType) {
            default:
                name = "";
                break;
            case "h5":
                name = "主站H5";
                break;
            case "pc":
                name = "主站pc";
                break;
            case "site":
                name = "全站APP";
                break;
            case "sportApp":
                name = "体育APP";
                break;
            case "chess":
                name = "棋牌APP";
                break;
            case "lottery":
                name = "彩票APP";
                break;
            case "person":
                name = "真人APP";
                break;
            case "siteSportApp":
                name = "全站体育APP";
                break;
        }
        return name;

    }


}
