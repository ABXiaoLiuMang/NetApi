package com.ty.bwagent.fragment.deposit.fragment

import android.os.Bundle
import android.text.InputFilter
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import androidx.lifecycle.ViewModelProvider
import com.ty.bwagent.R
import com.ty.bwagent.bean.*
import com.ty.bwagent.fragment.deposit.viewmodel.TurnConfigViewModel
import com.ty.bwagent.fragment.deposit.viewmodel.TurnViewModel
import com.ty.bwagent.fragment.login.PayPassWordSetFragment
import com.ty.bwagent.utils.*
import com.ty.bwagent.utils.Utils.getMoney
import com.ty.bwagent.viewmodel.MoneyViewModel
import com.ty.common.ui.ABBaseFragment
import com.ty.common.util.ABConfig
import com.ty.net.callback.NetObserver
import com.ty.net.callback.SimpleObserver
import com.ty.utils.*
import kotlinx.android.synthetic.main.fragment_team_manager.view.*
import kotlinx.android.synthetic.main.fragment_turn_layout.*
import kotlinx.android.synthetic.main.include_turn_msg.*
import kotlinx.android.synthetic.main.include_turn_password.*

/**
 * 代理代转
 */
class TurnMoneyFragment : ABBaseFragment(), View.OnClickListener {

    private lateinit var softKeyboardHelper: SoftKeyboardHelper

    lateinit var moneyViewModel: MoneyViewModel
    lateinit var turnViewModel: TurnViewModel
    private lateinit var turnConfigViewModel: TurnConfigViewModel
    var commission: Commission? = null

    var account: String? = null//代存账号
    var money: String? = null//代存金额
    var note: String? = null//备注
    var password: String? = null//代存支付密码
    var code: String? = null//验证码
    var phone: String? = null
    var teamModelSettingBean: MemberConfigEntity.TeamModelSettingBean? = null
    var proxyType = 1
    var limitType = true//ture: 额度代转 false 佣金代转
    var turnType = true//ture: 验证码支付 false 密码支付
    var msgEnabled = false
    var passEnabled = false


    companion object {

        fun getInstance(): TurnMoneyFragment {
            return TurnMoneyFragment()
        }

        fun getInstance(bundle: Bundle): TurnMoneyFragment {
            var turnMoneyFragment = TurnMoneyFragment();
            turnMoneyFragment.arguments = bundle
            return turnMoneyFragment
        }

    }


    override fun getLayoutId(): Int {
        return R.layout.fragment_turn_layout
    }

    override fun createProvider() {
        moneyViewModel = ViewModelProvider(requireActivity()).get(MoneyViewModel::class.java)
        turnViewModel = ViewModelProvider(this).get(TurnViewModel::class.java)
        turnConfigViewModel = ViewModelProvider(this).get(TurnConfigViewModel::class.java)

        //佣金余额
        moneyViewModel.commissLiveData.observe(this, object : NetObserver<BaseEntity<Commission>>() {
            override fun onSuccess(baseEntity: BaseEntity<Commission>) {
                commission = baseEntity.data?.apply {
                    val money = this.valetMoney
                    if (money >= 10000000000.0) {
                        tv_limit_money.text = "9,999,999,999.99"
                    } else {
                        tv_limit_money.text = Utils.roundDownMoney(money)
                    }
                }
            }

            override fun onError(code: Int, errMsg: String) {}
        })

        //转账结果监听
        turnViewModel.depositTurnLiveData.observe(this, object : NetObserver<BaseEntity<*>>() {
            override fun onSuccess(baseEntity: BaseEntity<*>) {
                ToastUtils.showLong("转账成功")
                pop()
            }

            override fun onLoading(show: Boolean) {
                if (show) showProgressDialog() else dismissProgressDialog()
            }

            override fun onError(code: Int, errMsg: String) {
                ToastUtils.showLong(errMsg)
                moneyViewModel.initMoney()//刷新一下可转账金额
                turnConfigViewModel.getAgentDepositConfig()//刷新一下配置
            }
        })

        //代理转账-获取下级用户信息接口
        turnViewModel.turnUserInfoLiveData.observe(this, object : SimpleObserver<BaseEntity<TurnUserEntity>>() {
            override fun onSuccess(baseEntity: BaseEntity<TurnUserEntity>) {
                var userName = baseEntity.data.realName
                if (StringUtils.length(userName) > 0) {
                    userName = userName.substring(0, 1) + "**"
                }
                account = baseEntity.data.name
                val depositEntity = DepositEntity(money, account, userName, true)
                depositEntity.status = baseEntity.data.status//用户状态(0停用，1启用)
                showCommitDialog(depositEntity)
            }

            override fun onLoading(show: Boolean) {
                if (show) {
                    commit_limit.isEnabled = false
                    showProgressDialog()
                } else {
                    commit_limit.isEnabled = true
                    dismissProgressDialog()
                }
            }
        })

        //代理代存，代理转账，配置
        XLiveDataManager.getInstance().memberConfigLiveData.observe(this, object : NetObserver<BaseEntity<MemberConfigEntity>>() {
            override fun onSuccess(memberConfigEntityBaseEntity: BaseEntity<MemberConfigEntity>?) {
                if (memberConfigEntityBaseEntity != null) {
                    teamModelSettingBean = memberConfigEntityBaseEntity.data?.teamModelSetting?.apply {
                        tv_limit_tips.text = StringUtils.getFormatString(ResUtils.getString(R.string.generic_deposit_turn),
                                getMoney(this.min),
                                getMoney(this.max),
                                getMoney(this.stint))
                    }
                }
            }

            override fun onError(code: Int, errMsg: String) {}
        })


        //监听验证码
        turnViewModel.codeLivedata.observe(this, object : NetObserver<BaseEntity<*>>() {
            override fun onSuccess(baseEntity: BaseEntity<*>?) {
                if (baseEntity == null) {
                    return
                }
                //保存获取成功验证码时间，60秒能不能重复获取
                MMKVUtil.put(TurnMoneyFragment::class.java.simpleName, System.currentTimeMillis())
                ToastUtils.showLong("验证码已发送")
                turnViewModel.startTimer(lifecycle)
            }

            override fun onLoading(show: Boolean) {
                if (show) {
                    showProgressDialog()
                } else {
                    dismissProgressDialog()
                }
            }

            override fun onError(code: Int, errMsg: String) {
                ToastUtils.showLong(errMsg)
                tv_save_code.isEnabled = true
                MMKVUtil.put(TurnMoneyFragment::class.java.simpleName, System.currentTimeMillis())
                Utils.isClickedReset60S(errMsg, lifecycle, turnViewModel, tv_save_code)
            }
        })

        //验证码倒计时
        turnViewModel.timerLiveData.observe(this, androidx.lifecycle.Observer {
            if (it.toLong() == 0L) {
                tv_save_code.text = ResUtils.getString(R.string.generic_reset_code)
                tv_save_code.isEnabled = true
            } else {
                tv_save_code.text = StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time), it)
                tv_save_code.isEnabled = false
            }
        })
    }


    override fun initViewsAndEvents() {

        var agentName = arguments?.getString(ABConfig.KEY_TAG);

        if (!StringUtils.isEmpty(agentName)) {//来自SubAgentDetailFragment
            titleBar.tv_right.visibility = INVISIBLE
            et_input_account.setText(agentName)
            et_input_account.setClearIconVisible(false)
            et_input_account.isEnabled = false
        } else {
            titleBar.tv_right.visibility = VISIBLE
            et_input_account.isEnabled = true
            titleBar.setRightOnClickListener {
                KeyboardUtils.hideSoftInput(requireActivity())
                start(DepositRecordFragment.getInstance())
            }
            titleBar.setTitleRightDrawable(R.mipmap.member_ask_bg)
        }

        //顶部提示弹窗
        titleBar.setTitleOnClickListener { DialogUtil.showTurnTipsDialog(mContext) }

        InputResultCalculator(listOf(et_input_account, et_input_money, et_input_code)) { ok ->
            commit_limit.isEnabled = ok
            msgEnabled = ok
        }

        commit_limit.setOnClickListener(this)
        tv_save_code.setOnClickListener(this)
        iv_eye_pass.setOnClickListener(this)

        val userInfo = UserInfoCache.getInstance().userInfo

        rg_turnType.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rb_trun_limit -> {
                    proxyType = 1
                    limitType = true
                    initSaveMoney()
                }
                R.id.rb_turn_money -> {
                    proxyType = 0
                    limitType = false
                    initSaveMoney()
                }
            }
            checkRefreshWarning()
        }

        rg_payType.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rb_type_phone -> {
                    group_pass.visibility = View.GONE
                    group_msg.visibility = View.VISIBLE
                    commit_limit.isEnabled = msgEnabled
                    InputResultCalculator(listOf(et_input_account, et_input_money, et_input_code)) { ok ->
                        commit_limit.isEnabled = ok
                        msgEnabled = ok
                    }
                    turnType = true
                }
                R.id.rb_type_pass -> {

                    if (StringUtils.isEmpty(userInfo.paymentPassword) || "0" == userInfo.paymentPassword) {
                        DialogUtil.confirmPayPassWordDailog(mContext) {
                            start(PayPassWordSetFragment.getInstance())
                        }
                        rb_type_phone.isChecked = true
                        return@setOnCheckedChangeListener
                    }

                    group_pass.visibility = View.VISIBLE
                    group_msg.visibility = View.GONE
                    commit_limit.isEnabled = passEnabled
                    InputResultCalculator(listOf(et_input_account, et_input_money, et_input_password)) { ok ->
                        commit_limit.isEnabled = ok
                        passEnabled = ok
                    }
                    turnType = false
                }
            }
        }
        if (userInfo.sysType == 1) {//管代
            rb_type_pass.isChecked = true
            rb_type_phone.isChecked = false
            group_type.visibility = View.GONE
        }


        phone = UserInfoCache.getInstance().userInfo?.phone
        tv_phone.text = Utils.getHidePhone(phone)

        et_input_money.filters = arrayOf(MoneyValueFilter(), InputFilter.LengthFilter(12))


        et_input_money.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {//获的焦点
                drawing_tv_warning.text = ""
            } else {//失去焦点
                if (et_input_money == null) {
                    return@setOnFocusChangeListener
                }
                checkRefreshWarning()
            }
        }

        moneyViewModel.initMoney()//获取可转账金额
        turnConfigViewModel.getAgentDepositConfig()
        registerKeyboardListener()
        Utils.isClicked60S(TurnMoneyFragment::class.java.simpleName, lifecycle, turnViewModel, tv_save_code)
    }


    override fun onClick(v: View?) {
        if (DoubleClickUtils.isLongDoubleClick()) {
            return
        }
        when (v?.id) {
            R.id.commit_limit -> {//提交
                commitClick()
            }
            R.id.iv_eye_pass -> {
                showHidePassWord()
            }
            R.id.tv_save_code -> {
                tv_save_code.isEnabled = false
                turnViewModel.getPhoneCode(phone)
            }
        }
    }


    /**
     * 提交按钮事件
     */
    private fun commitClick() {
        account = et_input_account.text?.toString()
        money = et_input_money.text?.toString()
        password = et_input_password.text?.toString()
        note = et_input_note.text?.toString()
        code = et_input_code.text?.toString()

        if (StringUtils.length(account) < 4) {
            ToastUtils.showLong(ResUtils.getString(R.string.generic_username_warn))
            return
        }

        if (turnType) {
            if (!VerifyUtils.isCode(code)) {
                ToastUtils.showLong(ResUtils.getString(R.string.generic_code_warn))
                return
            }
        } else {
            if (StringUtils.length(password) < 6) {
                ToastUtils.showLong("请输入支付密码（6位字母或数字）")
                return
            }
        }

        teamModelSettingBean?.let {
            if (StringUtils.parseDouble(money) < it.min || StringUtils.parseDouble(money) > it.max) {
                ToastUtils.showLong(StringUtils.getFormatString(ResUtils.getString(R.string.generic_turn_tips), getMoney(it.min), getMoney(it.max)))
                return
            }
        }
        turnViewModel.agentTransferInfo(account)
    }


    /**
     * 更新提示语
     */
    private fun checkRefreshWarning() {
        val money = StringUtils.parseDouble(et_input_money.text.toString().trim { it <= ' ' })
        if (money == 0.00) return
        teamModelSettingBean?.let {
            if (money > it.max || money < it.min) {
                drawing_tv_warning.text = StringUtils.getFormatString(ResUtils.getString(R.string.generic_deposit_turn_tips), getMoney(it.min), getMoney(it.max))
                return@checkRefreshWarning
            }
        }
        commission?.let {
            val availableMoney = if (limitType) it.valetMoney else it.agentMoney - it.agentFreezedMoney
            if (money > availableMoney) drawing_tv_warning.text = "不能超过可转账金额" else drawing_tv_warning.text = ""
        }
    }

    /**
     * 初始化金额
     */
    private fun initSaveMoney() {
        //佣金余额
        commission?.let {
            val money = if (limitType) it.valetMoney else it.agentMoney - it.agentFreezedMoney
            if (money >= 10000000000.0) {
                tv_limit_money.text = "9,999,999,999.99"
            } else {
                tv_limit_money.text = Utils.roundDownMoney(money)
            }
        }
    }

    /**
     * 代转金额确认弹窗
     *
     * @param depositEntity
     */
    private fun showCommitDialog(depositEntity: DepositEntity) {
        KeyboardUtils.hideSoftInput(requireActivity())
        DialogUtil.depositPopupDailog(mContext, depositEntity)
                .setListener({
                    //提款确认按钮
                    if (turnType) {
                        turnViewModel.commitLowerTurn(proxyType, account, money, code, note)
                    } else {
                        turnViewModel.commitMainTurn(proxyType, account, money, password, note)
                    }
                    KeyboardUtils.hideSoftInput(requireActivity())
                }, null)
                .setCancelTextColor(R.color.generic_heise)
                .setConfirmTextColor(R.color.site_style_color)
                .setTitleContent("提示", "是否确定为下列账号进行转账：", null)
    }

    /**
     * 软键盘输入框管理
     */
    private fun registerKeyboardListener() {
        softKeyboardHelper = SoftKeyboardHelper()
                .registerFragment(this)
                .setOnSoftKeyboardChangeListener(object : SoftKeyboardHelper.OnSoftKeyboardChangeListener {
                    override fun onSoftKeyboardChanged(keyboardHeightInPx: Int) {}

                    override fun onSoftKeyboardOpened(keyboardHeightInPx: Int) {
                        rootView.scrollTo(0, SizeUtils.dp2px(50f) + StatusBarUtil.getNavBarHeight())
                    }

                    override fun onSoftKeyboardClosed() {
                        rootView.scrollTo(0, 0)
                    }
                })

    }

    private fun showHidePassWord() {
        val type = et_input_password.transformationMethod
        if (PasswordTransformationMethod.getInstance() == type) {
            et_input_password.transformationMethod = HideReturnsTransformationMethod.getInstance()
            iv_eye_pass.setImageResource(R.mipmap.login_eye_show_bg)
        } else {
            et_input_password.transformationMethod = PasswordTransformationMethod.getInstance()
            iv_eye_pass.setImageResource(R.mipmap.login_eye_hide_bg)
        }
        et_input_password.setSelection(et_input_password.text.toString().length)
    }

    override fun onDestroy() {
        super.onDestroy()
        XLiveDataManager.getInstance().getUserInfo()//请求个人信息
        turnConfigViewModel.getAgentDepositConfig()
        KeyboardUtils.hideSoftInput(requireActivity())
        softKeyboardHelper?.unregisterView()
    }
}
