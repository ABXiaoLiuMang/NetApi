package com.ty.bwagent.bean;

public class RestrictEntity {
    /**
     * code : 10403
     * data : {"address":"马来西亚|马来西亚","ip":"202.186.238.170"}
     * errorSn :
     * msg : 操作成功
     */

    private int code;
    private DataBean data;
    private String errorSn;
    private String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getErrorSn() {
        return errorSn;
    }

    public void setErrorSn(String errorSn) {
        this.errorSn = errorSn;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public static class DataBean {
        /**
         * address : 马来西亚|马来西亚
         * ip : 202.186.238.170
         */

        private String address;
        private String ip;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getIp() {
            return ip;
        }

        public void setIp(String ip) {
            this.ip = ip;
        }
    }
}
