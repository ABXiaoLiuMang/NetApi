package com.ty.bwagent.ui;


import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ty.bwagent.R;
import com.ty.common.util.ABConfig;


public class SplashActivity extends AppCompatActivity{

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Intent intent = new Intent(this,GestureActivity.class);
        intent.putExtra(ABConfig.KEY_TAG,false);
        startActivity(intent);
        finish();
    }


}
