package com.ty.bwagent.bean;

public class TeamCountEntity {


    /**
     * addSubAuthority : 0
     * memberCount : 50
     * totalCount : 100
     */

    private int addSubAuthority;
    private long memberCount;
    private long totalCount;

    public int getAddSubAuthority() {
        return addSubAuthority;
    }

    public void setAddSubAuthority(int addSubAuthority) {
        this.addSubAuthority = addSubAuthority;
    }

    public long getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(long memberCount) {
        this.memberCount = memberCount;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }
}
