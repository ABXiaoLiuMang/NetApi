package com.ty.bwagent.fragment;

import android.graphics.Bitmap;
import android.os.Build;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.RestrictEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.viewmodel.DevicesViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.TitleBar;
import com.ty.common.view.ValueView;
import com.ty.constant.PermissionConstants;
import com.ty.net.callback.NetObserver;
import com.ty.net.utils.JsonUtils;
import com.ty.utils.AppUtil;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;

import butterknife.BindView;


public class DevicesFragment extends ABBaseFragment {

    DevicesViewModel mDevicesViewModel;
    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.valueview_member)
    ValueView valueviewMember;
    @BindView(R.id.valueview_phone_model)
    ValueView valueviewPhoneModel;
    @BindView(R.id.valueview_ip)
    ValueView valueviewIp;
    @BindView(R.id.valueview_phone_version)
    ValueView valueviewPhoneVersion;
    @BindView(R.id.valueview_app_version)
    ValueView valueviewAppVersion;
    @BindView(R.id.valueview_time)
    ValueView valueviewTime;
    @BindView(R.id.valueview_package)
    ValueView valueviewPackage;
    UserInfo userInfo;

    public static DevicesFragment getInstance() {
        DevicesFragment fragment = new DevicesFragment();
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_devices;
    }

    @Override
    protected void createProvider() {
        mDevicesViewModel = new ViewModelProvider(this).get(DevicesViewModel.class);
        mDevicesViewModel.areaWarnResult.observe(this, new NetObserver<String>() {
            @Override
            protected void onSuccess(String result) {
                RestrictEntity restrictEntity = JsonUtils.fromJson(result,RestrictEntity.class);
                if(restrictEntity != null){
                    String address = restrictEntity.getData().getAddress();
                    address = address.replace("|", "/");
                    valueviewIp.setTextValue(restrictEntity.getData().getIp() + " [" + address + "]");
                }
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {

            }

        });

    }

    @Override
    protected void initViewsAndEvents() {
        userInfo = UserInfoCache.getInstance().getUserInfo();
        valueviewMember.setTextValue(userInfo.getName());
        valueviewPhoneModel.setTextValue(Build.BRAND + "  " + Build.MODEL);
        valueviewPhoneVersion.setTextValue(Build.VERSION.RELEASE);
        valueviewAppVersion.setTextValue("v" + AppUtil.getVersionName());
        valueviewTime.setTextValue(TimeUtils.millis2String(TimeUtils.DATE_FORMAT_DATETIME, System.currentTimeMillis()));
        valueviewPackage.setTextValue(AppUtil.getPackgeName());
        titleBar.setRightOnClickListener(view -> {
            if (!DoubleClickUtils.isDoubleClick3S()) {
                saveScreen();
            }
        });

        mDevicesViewModel.checkRestrict();
    }

    private void saveScreen() {
        App.goPhoto = true;
        PermissionUtils.permission(PermissionConstants.STORAGE)
                .callback(new PermissionUtils.SimpleCallback() {
                    @Override
                    public void onGranted() {
                        Bitmap bitmap = ScreenUtils.screenShot(getActivity());
                        ScreenUtils.saveCaptureView(bitmap);
                    }

                    @Override
                    public void onDenied() {
                        ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn1));
                    }
                })
                .request();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        App.goPhoto = false;
    }
}
