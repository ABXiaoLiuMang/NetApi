package com.ty.bwagent.fragment.finance.fragment;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.RecordFilterEntity;
import com.ty.bwagent.dialog.RecordFilterPopup;
import com.ty.bwagent.fragment.BaseViewPagerFragment;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.TimeUtils;

import java.util.Calendar;
import java.util.Date;


/**
 * 提款记录tab界面
 */
public class RecordTabFragment extends BaseViewPagerFragment {

    RecordFilterPopup recordFilterPopup;
    private Calendar startCalendar;
    private Calendar endCalendar;

    //提款记录筛选结果
    public MutableLiveData<RecordFilterEntity> filterLiveData = new MutableLiveData<>();

    //重置
    public MutableLiveData<RecordFilterEntity> resetLiveData = new MutableLiveData<>();

    public static RecordTabFragment getInstance() {
        return new RecordTabFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_record_tab;
    }


    @Override
    protected void createProvider() {
        filterLiveData.observe(this, recordFilterEntity -> {
            Date startTime = TimeUtils.toDate(recordFilterEntity.getStartDate(), "yyyy-MM-dd");
            if (startTime != null) {
                startCalendar = Calendar.getInstance();
                startCalendar.setTime(startTime);
            }

            Date endTime = TimeUtils.toDate(recordFilterEntity.getEndDate(), "yyyy-MM-dd");
            if (endTime != null) {
                endCalendar = Calendar.getInstance();
                endCalendar.setTime(endTime);
            }
            viewPager.setCurrentItem(0, false);
        });

        resetLiveData.observe(this, recordFilterEntity -> {
            startCalendar = null;
            endCalendar = null;
            viewPager.setCurrentItem(0, false);
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        titleBar.setRightOnClickListener(view -> showFilterDialog());
    }

    private void showFilterDialog() {
        if (recordFilterPopup == null) {
            this.recordFilterPopup = DialogUtil.recordFilterDailog(mContext, titleBar, filterLiveData, resetLiveData);
        }
        if (recordFilterPopup.isShow()) {
            recordFilterPopup.dismiss();
        } else {
            switch (viewPager.getCurrentItem()) {
                case 0:
                    if (startCalendar == null && endCalendar == null) {
                        recordFilterPopup.setStartDay(-1);//设置-1 默认30天，但是这里需要设置-1，因为不显示初始值
                    } else {
                        recordFilterPopup.setStartDay(0);//赋值，记录上次的时间
                        recordFilterPopup.setStartCalendar(startCalendar);
                        recordFilterPopup.setEndCalendar(endCalendar);
                    }
                    break;
                case 3:
                    recordFilterPopup.setStartDay(29);
                    break;
                case 1:
                    recordFilterPopup.setStartDay(6);
                    break;
                case 2:
                    recordFilterPopup.setStartDay(14);
                    break;
            }
            recordFilterPopup.setPosition(viewPager.getCurrentItem());
            recordFilterPopup.show();
        }
    }


    @Override
    public Fragment getCurrentItem(int position) {
        if (position == 0) {
            return RecordAllFragment.getInstance(position);
        } else {
            return RecordFragment.getInstance(position);
        }
    }

    @Override
    public String[] getTabTitles() {
        return new String[]{"全部", "7日", "15日", "30日"};
    }

    @Override
    public CommonNavigatorAdapter getNavigatorAdapter() {
        CommonNavigatorAdapter adapter = new CommonNavigatorAdapter() {

            @Override
            public int getCount() {
                return tabTitles.length;
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                SimplePagerTitleView tabView = new SimplePagerTitleView(context);
                tabView.setPadding(SizeUtils.dp2px(15), 0, SizeUtils.dp2px(15), 0);
                tabView.setNormalColor(ResUtils.getColor(R.color.generic_huise));
                tabView.setSelectedColor(ResUtils.getColor(R.color.black));
                tabView.setText(tabTitles[index]);
                tabView.setOnClickListener(v -> viewPager.setCurrentItem(index));
                return tabView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator linePagerIndicator = new LinePagerIndicator(context);
                linePagerIndicator.setMode(LinePagerIndicator.MODE_EXACTLY);
                linePagerIndicator.setLineHeight(SizeUtils.dp2px(2));
                linePagerIndicator.setLineWidth(SizeUtils.dp2px(60));
                linePagerIndicator.setRoundRadius(SizeUtils.dp2px(1));
                linePagerIndicator.setColors(ResUtils.getColor(SiteSdk.ins().styleColor()));
                return linePagerIndicator;
            }
        };
        return adapter;
    }
}
