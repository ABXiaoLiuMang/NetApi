package com.ty.bwagent.header;

import android.animation.ValueAnimator;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;

import com.airbnb.lottie.LottieAnimationView;
import com.scwang.smartrefresh.layout.api.RefreshFooter;
import com.scwang.smartrefresh.layout.api.RefreshKernel;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.RefreshState;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.ty.bwagent.BuildConfig;
import com.ty.tysite.utils.SmartRefreshSiteUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;

import static com.airbnb.lottie.LottieDrawable.INFINITE;

/**
 * 自定义上拉刷新控件 alfred
 */
public class MyClassicsRefreshFooter extends LinearLayout implements RefreshFooter, LifecycleObserver {

    private TextView mFootText;//沒有更多數據
    private LottieAnimationView mLottieAnimationView;
    String mJsonAddress_PullDownToRefresh = "";
    String mJsonAddress_Refreshing = "";
    protected boolean mNoMoreData = false;

    public MyClassicsRefreshFooter(Context context) {
        super(context);
        initView(context);
    }

    public MyClassicsRefreshFooter(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public MyClassicsRefreshFooter(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        setGravity(Gravity.CENTER);
        setOrientation(VERTICAL);
        int mLoadingVidewHeight = 0;
        String mImageAddetsFolder = "";


        String mImageAddetsFolderSite = SmartRefreshSiteUtils.getRefreshFootSiteDate(BuildConfig.appType)[0];
        if (!StringUtils.isEmpty(mImageAddetsFolderSite)) {
            mImageAddetsFolder = mImageAddetsFolderSite;
        }

        String mJsonAddress_PullDownToRefreshSite = SmartRefreshSiteUtils.getRefreshFootSiteDate(BuildConfig.appType)[1];
        if (!StringUtils.isEmpty(mJsonAddress_PullDownToRefreshSite)) {
            mJsonAddress_PullDownToRefresh = mJsonAddress_PullDownToRefreshSite;
        }

        String mLoadingVidewHeightSite = SmartRefreshSiteUtils.getRefreshFootSiteDate(BuildConfig.appType)[2];
        if (!StringUtils.isEmpty(mLoadingVidewHeightSite)) {
            mLoadingVidewHeight = Integer.parseInt(mLoadingVidewHeightSite);
        }
        String mJsonAddress_RefreshingSite = SmartRefreshSiteUtils.getRefreshFootSiteDate(BuildConfig.appType)[3];
        if (!StringUtils.isEmpty(mJsonAddress_RefreshingSite)) {
            mJsonAddress_Refreshing = mJsonAddress_RefreshingSite;
        }
        
        mFootText = new TextView(getContext());
        mFootText.setText("我是有底线的，已经到最底部啦!");
        mFootText.setGravity(Gravity.CENTER);
        mLottieAnimationView = new LottieAnimationView(getContext());
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, SizeUtils.dp2px(mLoadingVidewHeight));
        mLottieAnimationView.setLayoutParams(layoutParams);
        layoutParams = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, SizeUtils.dp2px(60));
        layoutParams.gravity = Gravity.CENTER;
        addView(mFootText, layoutParams);
        addView(mLottieAnimationView);
        mLottieAnimationView.setRepeatCount(INFINITE);
        if (!TextUtils.isEmpty(mImageAddetsFolder)) {
            mLottieAnimationView.setImageAssetsFolder(mImageAddetsFolder);
        }
        mLottieAnimationView.setVisibility(View.VISIBLE);
        mFootText.setVisibility(View.GONE);
    }

    public void setFootText(String text) {
        mFootText.setText(text);
    }

    @Override
    public boolean setNoMoreData(boolean noMoreData) {
        if (mNoMoreData != noMoreData) {
            mNoMoreData = noMoreData;
            if (noMoreData) {
                //没有更多数据喽...
                mLottieAnimationView.setVisibility(View.GONE);
                mFootText.setVisibility(View.VISIBLE);
            } else {
                //上拉加载更多
                if (mFootText.getVisibility() == View.VISIBLE) {
                    mFootText.setVisibility(View.GONE);
                }
                if (mLottieAnimationView.getVisibility() == View.GONE) {
                    mLottieAnimationView.setVisibility(View.VISIBLE);
                }
            }
        }
        return true;
    }

    @NonNull
    @Override
    public View getView() {
        return this;//真实的视图就是自己，不能返回null
    }

    @NonNull
    @Override
    public SpinnerStyle getSpinnerStyle() {
        return SpinnerStyle.Translate;//指定为平移，不能null
    }

    @Override
    public void setPrimaryColors(int... colors) {

    }

    @Override
    public void onInitialized(@NonNull RefreshKernel kernel, int height, int maxDragHeight) {

    }

    @Override
    public void onMoving(boolean isDragging, float percent, int offset, int height, int maxDragHeight) {

    }

    @Override
    public void onReleased(@NonNull RefreshLayout refreshLayout, int height, int maxDragHeight) {

    }

    @Override
    public void onStartAnimator(@NonNull RefreshLayout refreshLayout, int height, int maxDragHeight) {

    }

    @Override
    public int onFinish(@NonNull RefreshLayout refreshLayout, boolean success) {
        if (!mNoMoreData) {
            if (success) {
                //加载完成
            } else {
                //加载失败
            }
        }
        return 0;
    }

    @Override
    public void onHorizontalDrag(float percentX, int offsetX, int offsetMax) {

    }

    @Override
    public boolean isSupportHorizontalDrag() {
        return false;
    }

    @Override
    public void onStateChanged(@NonNull RefreshLayout refreshLayout, @NonNull RefreshState oldState, @NonNull RefreshState newState) {
        if (!mNoMoreData) {
            switch (newState) {
                case None:
                case PullUpToLoad:
                    //上拉加载更多
                    mLottieAnimationView.setRepeatCount(ValueAnimator.INFINITE);
                    if (!TextUtils.isEmpty(mJsonAddress_Refreshing)) {
                        mLottieAnimationView.loop(false);
                    }
                    mLottieAnimationView.setAnimation(mJsonAddress_PullDownToRefresh);
                    mLottieAnimationView.playAnimation();
                    break;
                case Loading:
                case LoadReleased:
                    //正在加载...
                    if (!TextUtils.isEmpty(mJsonAddress_Refreshing)) {
                        mLottieAnimationView.setRepeatCount(ValueAnimator.INFINITE);
                        mLottieAnimationView.setAnimation(mJsonAddress_Refreshing);
                        mLottieAnimationView.playAnimation();
                    }
                    break;
                case ReleaseToLoad:
                    //释放立即加载

                    break;
                case Refreshing:
                    //正在刷新...
                    break;
                case RefreshFinish:
                    LogUtils.d("RefreshFinish");
                    mLottieAnimationView.cancelAnimation();
                    break;
            }
        }
    }

    public void bindLifecycle(LifecycleOwner lifecycleOwner) {
        lifecycleOwner.getLifecycle().addObserver(this);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void onDestroy() {
        mLottieAnimationView.removeAllAnimatorListeners();
        mLottieAnimationView.cancelAnimation();
    }
}
