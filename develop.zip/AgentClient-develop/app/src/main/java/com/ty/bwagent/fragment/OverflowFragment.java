package com.ty.bwagent.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.OverFlowListAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.OverFlowBean;
import com.ty.bwagent.dialog.SelectDialogItemPopup;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.view.ExpandableView;
import com.ty.bwagent.view.SelectTimeView;
import com.ty.bwagent.viewmodel.OverFlowViewModle;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

//溢出申请
public class OverflowFragment extends ABRefreshFragment implements BaseQuickAdapter.OnItemChildClickListener {

    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.ll_more)
    ExpandableView ll_more;
    @BindView(R.id.tv_more)
    LinearLayout tv_more;
    @BindView(R.id.tv_state)
    TextView tv_state;
    @BindView(R.id.arrowView)
    ImageView arrowView;
    @BindView(R.id.tv_sec_state)
    TextView tv_sec_state;
    @BindView(R.id.et_name)
    EditText et_name;
    @BindView(R.id.selectTimeView_add)
    SelectTimeView selectTimeViewAdd;//新增时间
    @BindView(R.id.selectTimeView_apply)
    SelectTimeView selectTimeViewApply;//审核时间
    @BindView(R.id.ll_nodate)
    LinearLayout ll_nodate;//
    @BindView(R.id.iv_image)
    ImageView iv_logo;//
    @BindView(R.id.tv_message)
    TextView tv_tips;//

    private OverFlowViewModle overFlowViewModle;
    private List<String> stateList = new ArrayList<>();

    int pageNum = 1;
    int pageSize = 10;
    private Handler handler;

    public static OverflowFragment getInstance() {
        OverflowFragment fragment = new OverflowFragment();
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.layout_frag_overflow;
    }

    @Override
    protected void createProvider() {
        overFlowViewModle = new ViewModelProvider(this).get(OverFlowViewModle.class);

        overFlowViewModle.overFlowListNetLiveData.observe(this, new NetObserver<BaseEntity<OverFlowBean>>() {
            @Override
            protected void onSuccess(BaseEntity<OverFlowBean> overFlowBeanBaseEntity) {
                dismissProgressDialog();

                if (pageNum == 1) {
                    listAdapter.setNewData(overFlowBeanBaseEntity.getData().getList());
                    refreshLayout.finishRefresh();
                } else {
                    listAdapter.addData(overFlowBeanBaseEntity.getData().getList());
                    refreshLayout.finishLoadMore();
                }
                if (overFlowBeanBaseEntity != null && overFlowBeanBaseEntity.getData() != null) {
                    pageNum = overFlowBeanBaseEntity.getData().getPageNum();
                    if (pageNum == overFlowBeanBaseEntity.getData().getPages()) {
                        refreshLayout.finishLoadMoreWithNoMoreData();
                    }
                }

                if (listAdapter.getItemCount() == 0) {
                    ll_nodate.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    iv_logo.setImageResource(R.mipmap.message_empty_bg);
                    tv_tips.setText("暂无数据");
                } else {
                    ll_nodate.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                ToastUtils.showLong(errMsg);
                if (pageNum == 1) {
                    refreshLayout.finishRefresh(false);
                } else {
                    refreshLayout.finishLoadMore(false);
                }

                if (listAdapter.getItemCount() == 0) {
                    ll_nodate.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
                    tv_tips.setText("网络不给力");
                } else {
                    ll_nodate.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }
            }
        });


        overFlowViewModle.applyFlowOverNetLiveData.observe(this, new SimpleObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if (baseEntity == null) {
                    return;
                }
                resert();
            }
        });

    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        titleBar.setTitleRightDrawable(R.mipmap.member_ask_bg);
        titleBar.setTitleOnClickListener(view -> DialogUtil.showOverFlowTipsDialog(getActivity()));
        titleBar.setRightOnClickListener(view -> {
            DialogUtil.showOverFlowFindDailog(this, () -> resert());
        });

        handler = new Handler();
        handler.postDelayed(this::resert, 300);//延迟300ms进入时 不卡顿
        addStates();

        listAdapter.setOnItemChildClickListener(this);

    }

    //点击按钮事件
    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        OverFlowBean.ListBean entity = (OverFlowBean.ListBean) adapter.getItem(position);
        Bundle bundle = new Bundle();
        bundle.putString(ABConfig.KEY_TAG, view.getTag().toString());
        bundle.putParcelable(ABConfig.KEY_OBJECT, entity);
        start(OverFlowEditDetailFragment.getInstance(bundle));
    }


    //重置 或者重新查询
    private void resert() {
        if (selectTimeViewAdd == null) {
            return;
        }

        pageNum = 1;
        showProgressDialog();
        selectTimeViewAdd.onReset();
        selectTimeViewApply.onReset();
        et_name.setText("");
        tv_sec_state.setText("全部");
        searchDate();
    }


    //筛选
    private void searchDate() {
        overFlowViewModle.getOverFlowList(et_name.getText().toString().trim(),
                getApplyStatus(tv_sec_state.getText().toString().trim()),
                selectTimeViewAdd.getStartTime(), selectTimeViewAdd.getEndTime(),
                selectTimeViewApply.getStartTime(),
                selectTimeViewApply.getEndTime(), pageSize, pageNum);
    }

    @OnClick({R.id.tv_more, R.id.tv_sec_state, R.id.tv_cancel, R.id.ll_nodate, R.id.tv_sure, R.id.ll_main})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_more:
                if (ll_more.isExpanded()) {//展开的
                    rotateArrow(true);
                    tv_state.setText("展开");
                } else {
                    rotateArrow(false);
                    tv_state.setText("收起");
                }
                ll_more.toggle();
                break;
            case R.id.tv_sec_state:
                KeyboardUtils.hideSoftInput(getActivity());
                DialogUtil.createSelectItemDailog(getActivity(), new SelectDialogItemPopup.Builder().setTitle("状态")
                        .setDateList(stateList).setSelectName(tv_sec_state.getText().toString().trim()).setOnClickListener(currentItem -> {
                            tv_sec_state.setText(stateList.get(currentItem));
                        })
                );
                break;
            case R.id.tv_cancel:
                KeyboardUtils.hideSoftInput(getActivity());
                resert();
                break;
            case R.id.tv_sure:
                KeyboardUtils.hideSoftInput(getActivity());
                if (checkDate()) {
                    showProgressDialog();
                    pageNum = 1;
                    searchDate();
                }
                break;
            case R.id.ll_main:
            case R.id.ll_nodate:
                KeyboardUtils.hideSoftInput(getActivity());
                break;
        }

    }

    private boolean checkDate() {

        if (!StringUtils.isEmpty(selectTimeViewAdd.getStartTime()) && StringUtils.isEmpty(selectTimeViewAdd.getEndTime())) {
            ToastUtils.showLong("请选择新增时间");
            return false;
        }
        if (StringUtils.isEmpty(selectTimeViewAdd.getStartTime()) && !StringUtils.isEmpty(selectTimeViewAdd.getEndTime())) {
            ToastUtils.showLong("请选择新增时间");
            return false;
        }

        if (!StringUtils.isEmpty(selectTimeViewApply.getStartTime()) && StringUtils.isEmpty(selectTimeViewApply.getEndTime())) {
            ToastUtils.showLong("请选择审核时间");
            return false;
        }
        if (StringUtils.isEmpty(selectTimeViewApply.getStartTime()) && !StringUtils.isEmpty(selectTimeViewApply.getEndTime())) {
            ToastUtils.showLong("请选择审核时间");
            return false;
        }

        if (!selectTimeViewAdd.daysBetween(selectTimeViewAdd.getStartTime(), selectTimeViewAdd.getEndTime())) {
            ToastUtils.showLong("结束时间不能早于开始时间");
            return false;
        }

        if (!selectTimeViewApply.daysBetween(selectTimeViewApply.getStartTime(), selectTimeViewApply.getEndTime())) {
            ToastUtils.showLong("结束时间不能早于开始时间");
            return false;
        }
        return true;
    }

    private void rotateArrow(boolean flag) {
        float pivotX = arrowView.getWidth() / 2f;
        float pivotY = arrowView.getHeight() / 2f;
        float fromDegrees;
        float toDegrees;
        if (flag) {
            fromDegrees = 180f;
            toDegrees = 0f;
        } else {
            fromDegrees = 0f;
            toDegrees = 180f;
        }

        RotateAnimation animation = new RotateAnimation(fromDegrees, toDegrees, pivotX, pivotY);
        animation.setDuration(250);
        animation.setFillAfter(true);
        arrowView.startAnimation(animation);
    }

    @Override
    public BaseQuickAdapter getListAdapter() {
        return new OverFlowListAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        KeyboardUtils.hideSoftInput(getActivity());
    }


    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }


    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum = pageNum + 1;
        searchDate();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        if (checkDate()) {
            pageNum = 1;
            searchDate();
        } else {
            refreshLayout.finishRefresh();
        }
        KeyboardUtils.hideSoftInput(getActivity());
    }

    private void addStates() {
        stateList.add("全部");
        stateList.add("无法申请");
        stateList.add("可以申请");
        stateList.add("待审核");
        stateList.add("审核通过");
        stateList.add("审核拒绝");
        stateList.add("系统驳回");
    }

    public String getApplyStatus(String status) {
        String applyStatus = "";
        switch (status) {
            case "无法申请":
                applyStatus = "0";
                break;
            case "可以申请":
                applyStatus = "1";
                break;
            case "待审核"://
                applyStatus = "2";
                break;
            case "审核通过"://
                applyStatus = "3";
                break;
            case "审核拒绝"://
                applyStatus = "4";
                break;
            case "系统驳回"://
                applyStatus = "5";
                break;
            case "全部":
                applyStatus = "";
                break;
        }
        return applyStatus;
    }

    @Override
    public void onStop() {
        super.onStop();
        KeyboardUtils.hideSoftInput(getActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
    }
}
