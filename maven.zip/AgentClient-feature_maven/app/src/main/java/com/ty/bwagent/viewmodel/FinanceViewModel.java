package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.CommissionEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.view.chart.ChartEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class FinanceViewModel extends ViewModel {

    //查询代理个人佣金信息
    public NetLiveData<BaseEntity<CommissionEntity>> commissionLiveData = new NetLiveData<>();

    //查询柱状图
    public NetLiveData<BaseEntity<List<ChartEntity>>> chartsLiveData = new NetLiveData<>();

    //月度详细记录
    public NetLiveData<BaseEntity<FinanceEntity>> financeLiveData = new NetLiveData<>();


    /**
     * 查询代理个人佣金信息
     * @param commissionDate 查询月份（yyyy-mm）
     */
    public void queryCommissionByMemberId(String commissionDate){
        NetSdk.create(Api.class)
                .queryCommissionByMemberId()
                .params("commissionDate",commissionDate)
                .asJSONType()
                .send(commissionLiveData);
    }

    /**
     * 获取矩形数据(柱状图)
     * @param startDate 查询月份（yyyy-mm）
     * @param endDate 查询月份（yyyy-mm）
     */
    public void queryCommissionByDate(String startDate,String endDate){
        NetSdk.create(Api.class)
                .queryCommissionByDate()
                .params("startDate",startDate)
                .params("endDate",endDate)
                .asJSONType()
                .send(chartsLiveData);
    }

    /**
     * 月度详细记录
     * @param commissionDate
     */
    public void queryMonthCommissionDetail(String commissionDate){
        NetSdk.create(Api.class)
                .queryMonthCommissionDetail()
                .params("commissionDate",commissionDate)
                .asJSONType()
                .send(financeLiveData);
    }
}
