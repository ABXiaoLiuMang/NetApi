package com.ty.bwagent.dialog;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;

import com.lxj.xpopup.core.CenterPopupView;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.constant.PermissionConstants;
import com.ty.tysite.utils.ImageResoureSiteUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.ToastUtils;
import com.zxing.qrcode.core.BGAQRCodeUtil;
import com.zxing.qrcode.view.QRCodeEncoder;


/**
 * 生成图片对话框
 */
public class CreatePicPopup extends CenterPopupView {

    ImageView create_pic;
    TextView create_save;
    Context context;
    View rootView;
    String shareUrl;
    private ImageView iv_share_bg;

    public CreatePicPopup(@NonNull Context context, String shareUrl) {
        super(context);
        this.context = context;
        this.shareUrl = shareUrl;
    }


    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_create_pic;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        create_pic = findViewById(R.id.create_pic);
        iv_share_bg = findViewById(R.id.iv_share_bg);
        create_save = findViewById(R.id.create_save);
        rootView = findViewById(R.id.rootView);

        iv_share_bg.setBackgroundResource(ImageResoureSiteUtils.ivShareBg());

        create_save.setOnClickListener(v -> {
            App.goPhoto = true;
            PermissionUtils.permission(PermissionConstants.STORAGE)
                    .callback(new PermissionUtils.SimpleCallback() {
                        @Override
                        public void onGranted() {
                            Bitmap bitmap = ScreenUtils.getViewBitmp(rootView);
                            ScreenUtils.saveCaptureView(bitmap);
                            dismiss();
                        }

                        @Override
                        public void onDenied() {
                            ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn));
                        }
                    })
                    .request();
        });
        createChineseQRCode();

    }

    Observer<Boolean> observer = new Observer<Boolean>() {
        @Override
        public void onChanged(Boolean aBoolean) {
            if(aBoolean){
                dismiss();
            }
        }
    };

    private void createChineseQRCode() {
        Bitmap bitmap = QRCodeEncoder.syncEncodeQRCode(shareUrl, BGAQRCodeUtil.dp2px(context, 84));
        create_pic.setImageBitmap(bitmap);
    }

    @Override
    protected void onDismiss() {
        App.goPhoto = false;
        MainActivity.isDialogShow = false;
        XLiveDataManager.getInstance().keyBackClick.postValue(false);
        XLiveDataManager.getInstance().keyBackClick.removeObserver(observer);
        super.onDismiss();
    }

    @Override
    protected void onShow() {
        super.onShow();
        XLiveDataManager.getInstance().keyBackClick.observeForever(observer);
        MainActivity.isDialogShow = true;
    }


}
