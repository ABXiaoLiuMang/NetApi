package com.ty.bwagent.dialog;

import android.content.Context;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

import androidx.annotation.NonNull;

import com.lxj.xpopup.core.BottomPopupView;
import com.ty.bwagent.R;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.SoftKeyboardHelper;
import com.ty.utils.StringUtils;

public class ShareEditPopup extends BottomPopupView {

    EditText edit_input;
    String [] hintText;
    SoftKeyboardHelper softKeyboardHelper;

    public ShareEditPopup(@NonNull Context context,String[] hintText) {
        super(context);
        this.hintText = hintText;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_share_edit;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        edit_input = findViewById(R.id.text_inputView);
        edit_input.setHint(hintText[0]);
        String text = hintText[1];
        edit_input.setText(text);
        if(StringUtils.length(text) > 0){
            edit_input.setSelection(text.length());
        }
        edit_input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                KeyboardUtils.hideSoftInput(v);
                return true;
            }
            return false;
        });

        softKeyboardHelper =  new SoftKeyboardHelper()
                .registerView(edit_input)
                .setOnSoftKeyboardChangeListener(new SoftKeyboardHelper.OnSoftKeyboardChangeListener() {
                    @Override
                    public void onSoftKeyboardChanged(int keyboardHeightInPx) {
                    }

                    @Override
                    public void onSoftKeyboardOpened(int keyboardHeightInPx) { }

                    @Override
                    public void onSoftKeyboardClosed() {
                        dismiss();
                    }
                });
    }

    public String getInputText(){
        return edit_input.getText().toString().trim();
    }


    @Override
    protected void onDismiss() {
        super.onDismiss();
        softKeyboardHelper.unregisterView();
    }
}

