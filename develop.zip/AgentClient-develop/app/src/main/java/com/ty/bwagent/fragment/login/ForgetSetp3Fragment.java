package com.ty.bwagent.fragment.login;

import android.os.Bundle;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.tianyu.updater.TYUpdater;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ForgetPassEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.Key;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.LoginViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ToastUtils;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import butterknife.BindView;
import butterknife.OnClick;
import me.yokeyword.fragmentation.ISupportFragment;


public class ForgetSetp3Fragment extends ABBaseFragment {


    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.forget_commit)
    TextView forgetCommit;
    ForgetPassEntity passEntity;
    LoginViewModel loginViewMoel;

    public static ForgetSetp3Fragment getInstance(ForgetPassEntity passEntity) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(ABConfig.KEY_OBJECT,passEntity);
        ForgetSetp3Fragment setp3Fragment = new ForgetSetp3Fragment();
        setp3Fragment.setArguments(bundle);
        return setp3Fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_forget_setp3;
    }

    @Override
    protected void createProvider() {
        passEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        loginViewMoel = new ViewModelProvider(this).get(LoginViewModel.class);
        //监听登录
        loginViewMoel.loginLiveData.observe(this,new NetObserver<BaseEntity<UserInfo>>(){
            @Override
            protected void onSuccess(BaseEntity<UserInfo> baseEntity) {
                UserInfo userInfo = baseEntity.getData();
                saveLoginInfo(userInfo);
                UserInfoCache.getInstance().saveUserInfo(userInfo);
                XLiveDataManager.getInstance().userInfo.postNext(userInfo);
//                goActivity(MainActivity.class);
                MainActivity.startMainActiviy(false);
                getActivity().finish();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
            }

        });
    }

    @Override
    protected void initViewsAndEvents() {
        titleBar.setLeftOnClickListener(view -> {
            killFragment();
        });
    }

    @OnClick(R.id.forget_commit)
    public void onViewClicked() {
        /**
         * 按产品要求，这里不免登陆了，跳回登陆页面
         */
        killFragment();
    }

    private void killFragment(){
        MMKVUtil.removeValueForKey(CacheKey.USER_PASSWORD);
        TYUpdater.getUpdateLiveData().removeObservers(requireActivity());
        popTo(LoginAndRegisterFragment.class,false);
    }

    /**
     * 登录成功，保存登录信息
     */
    private void saveLoginInfo(UserInfo userInfo){
        MMKVUtil.put(Key.LOGIN_TOKEN, userInfo.getToken());
        MMKVUtil.put(Key.AGENT_TOKEN, userInfo.getToken());
        MMKVUtil.put(Key.SYSTYPE, userInfo.getSysType());
        MMKVUtil.put(Key.LOGIN_PHONE, userInfo.getPhone());
        MMKVUtil.put(Key.INVITE_CODE, userInfo.getInviteCode());
        MMKVUtil.put(Key.IS_USER_LOGIN, true);

        MMKVUtil.put(CacheKey.USER_NAME,passEntity.getName());
        MMKVUtil.put(CacheKey.USER_LOGIN_TIME, System.currentTimeMillis());//上次登录时间
        MMKVUtil.put(CacheKey.REMEMBER_PASSWORD,true);
    }
}
