package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.utils.Md5Util;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

/**
 * 忘记密码找回密码
 */
public class ForgetPassWordViewModel extends CodeViewModel {

    public NetLiveData<BaseEntity> findOneLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity> findTwoLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity> findThreeLiveData = new NetLiveData<>();


    /**
     * 忘记密码（手机找回 第一步）
     *
     * @param phone
     */
    public void forgetByPhoneOne(String userName, String phone) {
        NetSdk.create(Api.class)
                .forgetByPhoneOne()
                .params("name", userName)
                .params("phone", phone)
                .asJSONType()
                .send(findOneLiveData);
    }

    /**
     * 忘记密码（手机找回 第二步）
     *
     * @param phone
     */
    public void forgetByPhoneTwo(String userName, String phone, String code,String imageCode) {
        NetSdk.create(Api.class)
                .forgetByPhoneTwo()
                .params("name", userName)
                .params("phone", phone)
                .params("code", code)
                .params("imageCode", imageCode)
                .asJSONType()
                .send(findTwoLiveData);
    }

    /**
     * 忘记密码（手机找回 第二步）
     *
     * @param phone
     */
    public void forgetByPhoneThree(String userName, String phone, String code, String imageCode, String password, String secondPassword) {
        NetSdk.create(Api.class)
                .forgetByPhoneThree()
                .params("name", userName)
                .params("phone", phone)
                .params("code", code)
                .params("imageCode", imageCode)
                .params("password", Md5Util.md5(password))
                .params("secondPassword", Md5Util.md5(secondPassword))
                .asJSONType()
                .send(findThreeLiveData);
    }


    /**
     * 忘记密码（邮箱找回 第一步）
     *
     * @param email
     */
    public void forgetByEmailOne(String userName, String email) {
        NetSdk.create(Api.class)
                .forgetByEmailOne()
                .params("name", userName)
                .params("email", email)
                .asJSONType()
                .send(findOneLiveData);

    }

    /**
     * 忘记密码（邮箱找回 第二步）
     *
     * @param email
     */
    public void forgetByEmailTwo(String userName, String email, String code,String imageCode) {
        NetSdk.create(Api.class)
                .forgetByEmailTwo()
                .params("name", userName)
                .params("email", email)
                .params("code", code)
                .params("imageCode", imageCode)
                .asJSONType()
                .send(findTwoLiveData);

    }

    /**
     * 忘记密码（邮箱找回 第三步）
     *
     * @param email
     */
    public void forgetByEmailThree(String userName, String email, String code,String imageCode, String password, String secondPassword) {
        NetSdk.create(Api.class)
                .forgetByEmailThree()
                .params("name", userName)
                .params("email", email)
                .params("code", code)
                .params("imageCode", imageCode)
                .params("password", Md5Util.md5(password))
                .params("secondPassword", Md5Util.md5(secondPassword))
                .asJSONType()
                .send(findThreeLiveData);

    }

}
