package com.ty.bwagent.fragment.subordinate

import android.os.Bundle
import androidx.core.content.ContextCompat
import com.ty.bwagent.R
import com.ty.bwagent.bean.ReviewListEntity
import com.ty.common.ui.ABBaseFragment
import com.ty.utils.StringUtils
import kotlinx.android.synthetic.main.frag_sub_audit_detail.*

/**
 * 下级审批详情
 */
class SubAuditDetailFragment : ABBaseFragment() {

    var listBean: ReviewListEntity.ListBean? = null

    companion object {
        fun getInstant(bundle: Bundle): SubAuditDetailFragment {
            var fragment = SubAuditDetailFragment();
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun createProvider() {
    }

    override fun getLayoutId(): Int {
        return R.layout.frag_sub_audit_detail
    }

    override fun initViewsAndEvents() {
        listBean = arguments?.getParcelable("listBean");

        listBean?.let {
            tv_name.text = it.memberName//
            tv_real_name.text = "真实姓名：" + if (StringUtils.isEmpty(it.reviewAt)) "" else it.realName//
            tv_phone.text = "手机号码：" + if (StringUtils.isEmpty(it.phone)) "" else it.phone//
            apply_time.text = if (StringUtils.isEmpty(it.createdAt)) "" else it.createdAt//
            audio_time.text = if (StringUtils.isEmpty(it.reviewAt)) "" else it.reviewAt//

            //审核状态0待审核1审核拒绝2审批通过
            when (it.reviewStatus) {
                0//待审核
                -> {
                    tv_state.text = "待审核"
                    tv_state.setTextColor(ContextCompat.getColor(mContext,R.color.generic_heise))
                }
                1//审核拒绝
                -> {
                    tv_state.setTextColor(ContextCompat.getColor(mContext,R.color.generic_warning))
                    tv_state.text = "审核拒绝"
                }
                2//审批通过
                -> {
                    tv_state.setTextColor(ContextCompat.getColor(mContext,R.color.generic_lvse_a))
                    tv_state.text = "审核通过"
                }
            }
            tv_remark.text = it.remark
        }

    }


}