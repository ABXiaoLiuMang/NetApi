package com.ty.bwagent.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.ty.utils.NetworkUtils;


public class NetChangedReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        XLiveDataManager.getInstance().netChangeLiveData.postValue(NetworkUtils.isConnected());
    }
}

