package com.ty.bwagent.bean;

import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.net.callback.XEntity;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ToastUtils;

public class BaseEntity<T>  implements XEntity {

    private int code;
    private T data;
    private String msg;
    private String setResponse;

    public int getStatus() {
        return code;
    }

    public T getData() {
        return data;
    }

    @Override
    public boolean isOk() {
        return code == 0;
    }

    @Override
    public int getCode() {
        return code;
    }

    @Override
    public String getErrMsg() {
        return msg;
    }

    @Override
    public void setResponse(String result) {
        this.setResponse = result;
    }

    @Override
    public void error() {
        switch (code) {
            case 10401:
            case 10402:
            case 10403:
                //  //处理维护的界面UI
                SystemModel.sMaintainInfo.setNext(this);
                break;
            case 22033://该设备存在风险，无法使用本平台
                SystemModel.loginOut.postValue(true);
                break;
            case 10004://登录失效，请重新登录
                ToastUtils.showLong(msg);
                MMKVUtil.removeValueForKey(CacheKey.USER_PASSWORD);
                SystemModel.loginOut.postValue(true);
                break;
            case 26305://用户没有绑定手机
                if(data instanceof UserInfo){
//                    UserInfo userInfo = (UserInfo) data;
//                    if(0 == userInfo.getSysType()){//普通代理
//                        SystemModel.loginUserInfo.postValue((UserInfo) getData());
//                    }
                    SystemModel.loginUserInfo.postValue((UserInfo) getData());
                }
                break;
        }
    }

    public String getMessage() {
        return msg;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
