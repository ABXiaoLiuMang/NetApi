package com.ty.bwagent.viewmodel;

import androidx.lifecycle.MutableLiveData;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MMessage;
import com.ty.bwagent.bean.MessageSys;
import com.ty.net.NetCall;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

public class MessageViewModel extends ReadedViewModel {

    public MutableLiveData<String> delMsgLiveData = new MutableLiveData<>();

    //消息列表(通知)
    public NetLiveData<BaseEntity<MMessage>> noticeLiveData = new NetLiveData<>();

    //消息列表(活动)
    public NetLiveData<BaseEntity<MMessage>> activityLiveData = new NetLiveData<>();

    //消息列表（系统功能）
    public NetLiveData<BaseEntity<MessageSys>> messageSysLiveData = new NetLiveData<>();

    //消息列表
    public void msgList(int msgType,int pageNum,int pageSize) {
        NetCall<BaseEntity<MMessage>>  netCall = NetSdk.create(Api.class)
                .msgList()
                .params("msgType",msgType)
                .params("pageNum",pageNum)
                .params("pageSize",pageSize)
                .params("userSystem",2)
                .asJSONType();
        if(msgType == 1){
            netCall .send(noticeLiveData);
        }else {
            netCall .send(activityLiveData);
        }
    }

    //公告列表
    public void msgSystemList(int pageNum,int pageSize) {
        NetSdk.create(Api.class)
                .msgSystemList()
                .params("pageNum",pageNum)
                .params("pageSize",pageSize)
                .asJSONType()
                .send(messageSysLiveData);
    }




}
