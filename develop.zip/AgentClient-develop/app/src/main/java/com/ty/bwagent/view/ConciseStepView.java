package com.ty.bwagent.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.R;
import com.ty.tysite.SiteSdk;
import com.ty.tysite.utils.ResourceSiteUtils;
import com.ty.utils.ResUtils;

public class ConciseStepView extends ConstraintLayout {

    View loginLine1;
    View loginLine2;
    TextView loginPostion1;
    TextView loginPostion2;
    TextView loginPostion3;
    TextView loginText1;
    TextView loginText2;
    TextView loginText3;

    private Context mContext;
    private int Step;
    private int holdBg;
    private int normalBg;

    public ConciseStepView(Context context) {
        this(context, null);
    }

    public ConciseStepView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }


    public ConciseStepView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        TypedArray mTypedArray = context.obtainStyledAttributes(attrs, R.styleable.StepView);
        Step = mTypedArray.getInt(R.styleable.StepView_Step, 1);
        mTypedArray.recycle();
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        holdBg = ResourceSiteUtils.getloginSetUpHold();
        normalBg = R.drawable.login_setp_normal;

        View rootView = LayoutInflater.from(mContext).inflate(R.layout.x_lgoin_setpview, this, true);
        loginLine1 = rootView.findViewById(R.id.login_line1);
        loginLine2 = rootView.findViewById(R.id.login_line2);
        loginPostion1 = rootView.findViewById(R.id.login_postion_1);
        loginPostion2 = rootView.findViewById(R.id.login_postion_2);
        loginPostion3 = rootView.findViewById(R.id.login_postion_3);
        loginText1 = rootView.findViewById(R.id.login_text_1);
        loginText2 = rootView.findViewById(R.id.login_text_2);
        loginText3 = rootView.findViewById(R.id.login_text_3);

        int main_style_color = SiteSdk.ins().styleColor();
        switch (Step) {
            case 1:
                loginText1.setTextColor(ResUtils.getColor(main_style_color));
                loginPostion1.setBackgroundResource(holdBg);
                break;
            case 2:
                loginText1.setTextColor(ResUtils.getColor(main_style_color));
                loginPostion1.setBackgroundResource(holdBg);
                loginText2.setTextColor(ResUtils.getColor(main_style_color));
                loginPostion2.setBackgroundResource(holdBg);
                loginLine1.setBackgroundColor(ResUtils.getColor(main_style_color));
                break;
            case 3:
                loginText1.setTextColor(ResUtils.getColor(main_style_color));
                loginPostion1.setBackgroundResource(holdBg);
                loginText2.setTextColor(ResUtils.getColor(main_style_color));
                loginPostion2.setBackgroundResource(holdBg);
                loginText3.setTextColor(ResUtils.getColor(main_style_color));
                loginPostion3.setBackgroundResource(holdBg);
                loginLine1.setBackgroundColor(ResUtils.getColor(main_style_color));
                loginLine2.setBackgroundColor(ResUtils.getColor(main_style_color));
                break;
        }

    }
}
