package com.ty.bwagent.adapter;

import android.text.TextUtils;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.common.Key;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;


/**
 * 描述
 * <p> 推广列表适配器
 * author:Dale
 */
public class ExtensionAdapter extends BaseQuickAdapter<ExtensionEntity, BaseViewHolder> {

    String title;
    String inviteCode;
    public ExtensionAdapter(String title) {
        super(R.layout.recycle_item_extension);
        this.title = title;
        inviteCode = MMKVUtil.getString(Key.INVITE_CODE);
    }

    @Override
    protected void convert(BaseViewHolder helper, ExtensionEntity mExtensionEntity) {

        helper.setText(R.id.extension_tv_register, StringUtils.getFormatString(ResUtils.getString(R.string.generic_register_number), mExtensionEntity.getRegisterNum()));

        if (TextUtils.isEmpty(inviteCode)) {
            helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl());
        } else {
            if (StringUtils.equals("h5", mExtensionEntity.getClientType())) {
                helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl() + "/entry/register/?i_code=" + inviteCode);
            } else if (StringUtils.equals("pc", mExtensionEntity.getClientType())) {
                helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl() + "/register/?i_code=" + inviteCode);
            } else {
                helper.setText(R.id.extension_tv_link, mExtensionEntity.getUrl() + "/?i_code=" + inviteCode);
            }
        }

        if (StringUtils.equals("全部", title)) {
            switch (mExtensionEntity.getClientType()) {
                case "h5":
                    helper.setText(R.id.extension_tv_title, "主站H5");
                    break;
                case "pc":
                    helper.setText(R.id.extension_tv_title, "主站PC");
                    break;
                case "site":
                    helper.setText(R.id.extension_tv_title, "全站APP");
                    break;
                case "sportApp":
                    helper.setText(R.id.extension_tv_title, "体育APP");
                    break;
            }
        } else {
            helper.setText(R.id.extension_tv_title, title);
        }

        helper.setVisible(R.id.extension_iv_url, mExtensionEntity.isExclusive());
    }
}

