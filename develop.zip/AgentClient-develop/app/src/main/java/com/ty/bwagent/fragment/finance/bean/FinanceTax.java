package com.ty.bwagent.fragment.finance.bean;

/**
 * 描述:红利月度明细
 * <p>
 * author:Dale
 */
public class FinanceTax {

    /**
     * category : QQH5
     * money : 0.0
     */

    private String category; //类 1 typay, 2: 后台手动上分 , 3 佣金钱包转入充值
    private double money; //金额

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }
}
