package com.ty.bwagent.fragment.finance.bean;

import java.util.List;

/**
 * 描述:月度详细-返水模型
 * <p>
 * author:Dale
 */
public class FinanceWater {

    List<String> maxRates;//等级

}
