package com.ty.bwagent.common;

/**
 * Desc:
 * Created by Jeff on 2019/2/16
 **/
public enum  LoadDataStatus {
    /**
     * 未开始
     */
    NONE,
    /**
     * 加载中
     */
    LOADING,
    /**
     * 失败
     */
    ERROR,
    /**
     * 成功
     */
    SUCCESS,
}