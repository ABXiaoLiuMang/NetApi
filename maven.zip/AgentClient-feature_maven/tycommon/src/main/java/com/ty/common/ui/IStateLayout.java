package com.ty.common.ui;

import android.view.View;

import com.ty.common.view.StateLayout;

public interface IStateLayout extends StateLayout.OnRetryListener{

    View getContentView();

    StateLayout getStateLayout();

}
