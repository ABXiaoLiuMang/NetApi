package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.AboutSponsor;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.fragment.deposit.viewmodel.TurnConfigViewModel;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class AboutViewModel extends TurnConfigViewModel {

    public NetLiveData<BaseEntity<ContactUsEntity>> contactUsLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity<List<AboutSponsor>>> sponsorLiveData = new NetLiveData<>();

    //联系我们
    public void contactUs(){
        NetSdk.create(Api.class)
                .contactUs()
                .asJSONType()
                .send(contactUsLiveData);
    }

    //关于我们赞助
    public void getSponsor(){
        NetSdk.create(Api.class)
                .getSponsor()
                .asJSONType()
                .send(sponsorLiveData);
    }
}
