package com.ty.bwagent.exchange;

public class CalculateState {
    private boolean isOperateDown;
    private boolean isDotDown;
    private boolean isAdd;
    private boolean isEqual;

    public boolean isOperateDown() {
        return isOperateDown;
    }

    public void setOperateDown(boolean operateDown) {
        isOperateDown = operateDown;
    }

    public boolean isDotDown() {
        return isDotDown;
    }

    public void setDotDown(boolean dotDown) {
        isDotDown = dotDown;
    }

    public boolean isAdd() {
        return isAdd;
    }

    public void setAdd(boolean add) {
        isAdd = add;
    }

    public boolean isEqual() {
        return isEqual;
    }

    public void setEqual(boolean equal) {
        isEqual = equal;
    }
}
