package com.ty.bwagent.utils;

import android.util.Log;

import com.bw.tmapmanager.domains.TmapDomainsManager;
import com.bw.tmapmanager.utils.Constant;
import com.bw.tmapmanager.utils.EmptyUtils;
import com.bw.tmapmanager.utils.Logutils;
import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.api.BaseUrlManager;
import com.ty.bwagent.api.HttpSignUtils;
import com.ty.utils.AppUtil;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Date;
import java.util.Map;
import java.util.Random;

public class NetService {

    public static InputStream getInputStreamByUrl(String address) {
        String siteIdKey = BuildConfig.appType;//站点Id
        URL url;
        HttpURLConnection urlConnection;
        String nonce = Utils.getRandomString(16);
        long timestamp =Utils.getSecondTimestamp(new Date());
        try {
            Map<String, Object> map = getSignUrl(address);
            String signUrl = "";
            if (map != null && map.size() != 0) {
                signUrl = (String) map.get(Constant.urlKey);
            }
            if (EmptyUtils.stringIsEmpty(signUrl)) {
                signUrl = address;
            }
            url = new URL(signUrl);

            urlConnection = (HttpURLConnection) url.openConnection();
            String deviceId = AppUtil.getUUID();
            urlConnection.setRequestProperty("TB-CLIENT-TYPE", "agent_android");
            urlConnection.setRequestProperty("Content-Type", "image/jpeg");
            urlConnection.setRequestProperty("TB-VERSION", AppUtil.getVersionName());
            urlConnection.setRequestProperty("TB-UUID", deviceId);
            urlConnection.setRequestProperty("TB-SITE-ID", siteIdKey);
            urlConnection.setRequestProperty("X-KK-APPKEY", Key.appkey);
            urlConnection.setRequestProperty("X-KK-NONCE", nonce);
            urlConnection.setRequestProperty("X-KK-SIGN", Utils.sign("{}", Key.secret, nonce, timestamp));
            urlConnection.setRequestProperty("X-KK-SV", "1");
            urlConnection.setRequestProperty("X-KK-TIMESTAMP", String.valueOf(timestamp));
            urlConnection.setRequestProperty("Accept-Encoding", "gzip deflate");
            if (map != null && map.size() != 0) {
                Map<String, String> childMap = (Map<String, String>) map.get(Constant.Key);
                initHeader(urlConnection, childMap);
            }
            urlConnection.setReadTimeout(10 * 1000);
            urlConnection.setConnectTimeout(10 * 1000);
            urlConnection.setRequestMethod("POST");
            return urlConnection.getInputStream();
        } catch (Exception e) {
            LogUtils.e(e.getMessage());
            return null;
        }
    }


    private static Map<String, Object> getSignUrl(String address) {
        String[] tokens = BaseUrlManager.ins().currentDomain().getTokens();
        if (tokens == null || tokens.length == 0) {
            return null;
        }
        String host = address;
        try {
            URL mUrl = new URL(host);
            host = mUrl.getHost();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        HttpSignUtils.signParams(host, tokens[0], tokens[1], tokens[2]);
        String urlLink = address;
        Log.i("info", "================linkUrl:" + urlLink);
        //完成初始化后，获取加签的数据参数
        Map<String, Object> map = TmapDomainsManager.getInstance().configCDNAtuthWithURL(urlLink);
        return map;
    }

    private static void initHeader(HttpURLConnection urlConnection, Map<String, String> childMap) {
        if (childMap != null && childMap.size() != 0) {
            for (Map.Entry<String, String> child : childMap.entrySet()) {
                String key = child.getKey();
                String value = child.getValue();
                if (EmptyUtils.stringIsEmpty(key) || EmptyUtils.stringIsEmpty(value)) {
                    continue;
                }
                Logutils.logi("key===" + key + "\n value===" + value);
                urlConnection.setRequestProperty(key, value);
            }
        }
    }

}
