package com.ty.bwagent.fragment;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.config.PictureConfig;
import com.luck.picture.lib.config.PictureMimeType;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.enums.PopupType;
import com.lxj.xpopup.interfaces.XPopupImageLoader;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.AddImageAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.OverFlowBean;
import com.ty.bwagent.bean.UpFileEntity;
import com.ty.bwagent.dialog.ImagePopupView;
import com.ty.bwagent.dialog.UpHeadPopup;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.ImageLoader;
import com.ty.bwagent.viewmodel.MyCenterViewModel;
import com.ty.bwagent.viewmodel.OverFlowViewModle;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.SoftKeyboardHelper;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.OnClick;

import static com.ty.bwagent.adapter.AddImageAdapter.ADDI_MAGE;
import static com.ty.bwagent.adapter.OverFlowListAdapter.STATE_APPLY;
import static com.ty.bwagent.adapter.OverFlowListAdapter.STATE_EDITE;
import static com.ty.bwagent.adapter.OverFlowListAdapter.STATE_SEE;

public class OverFlowEditDetailFragment extends ABBaseFragment {

    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.et_lianjie)
    ClearEditText et_lianjie;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.tv_device_web)
    TextView tvDeviceWeb;
    @BindView(R.id.tv_device_app)
    TextView tvDeviceApp;
    @BindView(R.id.tv_device_h5)
    TextView tvDeviceH5;
    @BindView(R.id.tv_account)
    TextView tv_account;
    @BindView(R.id.tv_show_device)
    TextView tvShowDevice;
    @BindView(R.id.tv_image_say)
    TextView tvImageSay;
    @BindView(R.id.tv_submit)
    TextView tv_submit;
    @BindView(R.id.et_reason)
    ClearEditText et_reason;
    @BindView(R.id.ll_beizhu)
    LinearLayout ll_beizhu;
    @BindView(R.id.tv_beizhu)
    TextView tv_beizhu;
    @BindView(R.id.tv_examp)
    TextView tv_examp;
    @BindView(R.id.tv_tips)
    TextView tv_tips;
    @BindView(R.id.tv_xing1)
    TextView tv_xing1;
    @BindView(R.id.tv_xing)
    TextView tv_xing;
    @BindView(R.id.iv_examp)
    ImageView iv_examp;
    @BindView(R.id.scroll_view)
    NestedScrollView scrollView;
    private AddImageAdapter addImageAdapter;
    private OverFlowViewModle overFlowViewModle;
    private MyCenterViewModel myCenterViewModel;
    private int promoteDevice = 0;
    private OverFlowBean.ListBean listBean;
    private String operate;//see apply edite
    private BaseEntity<List<UpFileEntity>> listBaseEntity;
    private SoftKeyboardHelper softKeyboardHelper;

    public static OverFlowEditDetailFragment getInstance(Bundle bundle) {
        OverFlowEditDetailFragment fragment = new OverFlowEditDetailFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.layout_overflow_detail_edite;
    }

    @Override
    protected void initViewsAndEvents() {
        initView();
        initeDate();
        initListener();
        registerKeyboardListener();
    }

    private void initView() {
        listBean = bundle.getParcelable(ABConfig.KEY_OBJECT);
        operate = bundle.getString(ABConfig.KEY_TAG);

        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 3));
        addImageAdapter = new AddImageAdapter(getActivity());
        recyclerView.setAdapter(addImageAdapter);

        // 底部加横线 ， 添加Paint.ANTI_ALIAS_FLAG是线会变得清晰去掉锯齿
        tv_examp.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);

        tv_tips.setText("提示：只能找回通过自身代理链接注册的下级会员，且注册三天时间内有效。");
        tv_tips.setTextColor(getResources().getColor(R.color.generic_huise));
    }

    private void initeDate() {
        switch (operate) {//see apply edite
            case STATE_SEE://查看
                if (!StringUtils.isEmpty(listBean.getPromoteUrl())) {
                    et_lianjie.setText(listBean.getPromoteUrl());
                } else {
                    et_lianjie.setHint("");
                }
                et_lianjie.setEnabled(false);
                et_lianjie.setClearIconVisible(false);
                titleBar.setTiteTextView("申请详情");
                tvDeviceWeb.setVisibility(View.GONE);
                tvDeviceApp.setVisibility(View.GONE);
                tvDeviceH5.setVisibility(View.GONE);
                tvShowDevice.setVisibility(View.VISIBLE);
                tv_xing1.setVisibility(View.INVISIBLE);
                tv_xing.setVisibility(View.INVISIBLE);
                setDeviceSelect(listBean.getPromoteDevice());

                if (!StringUtils.isEmpty(listBean.getApplyReason())) {
                    et_reason.setText(listBean.getApplyReason());
                } else {
                    et_reason.setHint("");
                }
                et_reason.setEnabled(false);
                et_reason.setClearIconVisible(false);

                tv_submit.setVisibility(View.GONE);
                tvImageSay.setVisibility(View.GONE);
                tv_examp.setVisibility(View.GONE);
                iv_examp.setVisibility(View.GONE);
                tv_tips.setVisibility(View.GONE);
                if (!StringUtils.isEmpty(listBean.getApplyImg())) {
                    String[] split = listBean.getApplyImg().split(",");
                    ArrayList<String> images = new ArrayList<>();
                    for (int i = 0; i < split.length; i++) {
                        images.add(split[i]);
                    }
                    addImageAdapter.setEdite(false);
                    addImageAdapter.setDate(images);
                }
                break;
            case STATE_APPLY://申请
                titleBar.setTiteTextView("溢出申请");
                tvDeviceWeb.setVisibility(View.VISIBLE);
                tvDeviceApp.setVisibility(View.VISIBLE);
                tvDeviceH5.setVisibility(View.VISIBLE);
                tvShowDevice.setVisibility(View.GONE);
                tv_submit.setVisibility(View.VISIBLE);
                tvImageSay.setVisibility(View.VISIBLE);
                tv_examp.setVisibility(View.VISIBLE);
                iv_examp.setVisibility(View.VISIBLE);
                tv_tips.setVisibility(View.VISIBLE);
                tv_xing1.setVisibility(View.VISIBLE);
                tv_xing.setVisibility(View.VISIBLE);

                ArrayList<String> images1 = new ArrayList<>();
                images1.add(ADDI_MAGE);
                addImageAdapter.setEdite(true);
                addImageAdapter.setDate(images1);

                break;
            case STATE_EDITE://编辑
                titleBar.setTiteTextView("溢出申请");
                setDeviceSelect(listBean.getPromoteDevice());
                et_lianjie.setText(listBean.getPromoteUrl());
                et_lianjie.setEnabled(true);
                tvDeviceWeb.setVisibility(View.VISIBLE);
                tvDeviceApp.setVisibility(View.VISIBLE);
                tvDeviceH5.setVisibility(View.VISIBLE);
                tvShowDevice.setVisibility(View.GONE);
                tvImageSay.setVisibility(View.VISIBLE);
                tv_examp.setVisibility(View.VISIBLE);
                iv_examp.setVisibility(View.VISIBLE);
                tv_tips.setVisibility(View.VISIBLE);
                et_reason.setText(listBean.getApplyReason());
                et_reason.setEnabled(true);
                tv_submit.setVisibility(View.VISIBLE);
                tv_xing1.setVisibility(View.VISIBLE);
                tv_xing.setVisibility(View.VISIBLE);

                if (!StringUtils.isEmpty(listBean.getApplyImg())) {
                    String[] split = listBean.getApplyImg().split(",");
                    ArrayList<String> images = new ArrayList<>();
                    for (int i = 0; i < split.length; i++) {
                        images.add(split[i]);
                    }
                    if (images.size() < 6) {
                        images.add(ADDI_MAGE);
                    }
                    addImageAdapter.setEdite(true);
                    addImageAdapter.setDate(images);
                }
                break;
        }
        tv_account.setText(listBean.getMemberName());

        if (StringUtils.isEmpty(listBean.getRemark())) {
            ll_beizhu.setVisibility(View.GONE);
        } else {
            ll_beizhu.setVisibility(View.VISIBLE);
            tv_beizhu.setText(listBean.getRemark());
        }

    }

    @Override
    protected void createProvider() {

        overFlowViewModle = new ViewModelProvider((ABBaseFragment) getPreFragment()).get(OverFlowViewModle.class);
        myCenterViewModel = new ViewModelProvider(this).get(MyCenterViewModel.class);

        myCenterViewModel.uploadMultiFileLiveData.observe(this, new NetObserver<BaseEntity<List<UpFileEntity>>>() {

            @Override
            protected void onSuccess(BaseEntity<List<UpFileEntity>> listBaseEntity) {
                OverFlowEditDetailFragment.this.listBaseEntity = listBaseEntity;
                submite();
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showToast(errMsg);
                dismissProgressDialog();
            }
        });

        overFlowViewModle.applyFlowOverNetLiveData.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if (baseEntity == null) {
                    return;
                }
                dismissProgressDialog();
                ToastUtils.showLong("提交成功");
                pop();
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showToast(errMsg);
                dismissProgressDialog();
            }
        });


    }


    @OnClick({R.id.tv_submit, R.id.container, R.id.tv_examp, R.id.container_main, R.id.tv_device_web, R.id.tv_device_app, R.id.tv_device_h5})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_submit:
                if (checkDate()) {
                    showProgressDialog();
                    ArrayList<File> needUpFiles = addImageAdapter.getNeedUpImages();
                    if (needUpFiles.size() > 0) {//需要上传的图片
                        myCenterViewModel.uploadMultiFile(needUpFiles);
                    } else {
                        submite();
                    }
                }
                break;
            case R.id.tv_device_web:
                KeyboardUtils.hideSoftInput(rootView);
                setDeviceSelect(2);
                break;
            case R.id.tv_device_app:
                KeyboardUtils.hideSoftInput(rootView);
                setDeviceSelect(1);
                break;
            case R.id.tv_device_h5:
                KeyboardUtils.hideSoftInput(rootView);
                setDeviceSelect(3);
                break;
            case R.id.container:
            case R.id.container_main:
                KeyboardUtils.hideSoftInput(rootView);
                break;
            case R.id.tv_examp:
                ArrayList<Object> list = new ArrayList<>();
                String path = ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + getResources().getResourcePackageName(R.mipmap.icon_over_tips) + "/" + getResources().getResourceTypeName(R.mipmap.icon_over_tips) + "/" + getResources().getResourceEntryName(R.mipmap.icon_over_tips);
                list.add(path);
                showPreImages(iv_examp, list, 0);
                break;
        }
    }


    //提交请求
    private void submite() {
        if (operate.equals(STATE_EDITE)) {
            overFlowViewModle.updateApplyFlowOver(listBean.getId(), et_lianjie.getText().toString().trim(), promoteDevice, et_reason.getText().toString().trim(), getUpImagePath(), listBean.getUpdateAt());
        } else {
            overFlowViewModle.applyFlowOver(listBean.getId(), et_lianjie.getText().toString().trim(), promoteDevice, et_reason.getText().toString().trim(), getUpImagePath());
        }
    }

    //选择设备 初始化设备
    private void setDeviceSelect(int device) {// 1 app 2 web 3 h5
        promoteDevice = device;
        tvDeviceWeb.setBackgroundResource(R.drawable.etittext_select_bg);
        tvDeviceWeb.setTextColor(ResUtils.getColor(R.color.generic_huise));
        tvDeviceApp.setBackgroundResource(R.drawable.etittext_select_bg);
        tvDeviceApp.setTextColor(ResUtils.getColor(R.color.generic_huise));
        tvDeviceH5.setBackgroundResource(R.drawable.etittext_select_bg);
        tvDeviceH5.setTextColor(ResUtils.getColor(R.color.generic_huise));
        if (device == 2) {
            tvShowDevice.setText("WEB");
            tvDeviceWeb.setTextColor(ResUtils.getColor(R.color.white));
            tvDeviceWeb.setBackgroundResource(R.drawable.site_bnt_solid_bg);
        } else if (device == 1) {
            tvShowDevice.setText("APP");
            tvDeviceApp.setTextColor(ResUtils.getColor(R.color.white));
            tvDeviceApp.setBackgroundResource(R.drawable.site_bnt_solid_bg);
        } else if (device == 3) {
            tvShowDevice.setText("H5");
            tvDeviceH5.setTextColor(ResUtils.getColor(R.color.white));
            tvDeviceH5.setBackgroundResource(R.drawable.site_bnt_solid_bg);
        }

    }

    //检查数据
    private boolean checkDate() {
        if (promoteDevice == 0) {
            ToastUtils.showToast("推广设备不能为空");
            return false;
        }
        if (addImageAdapter.getImages().size() == 0) {
            ToastUtils.showLong("请至少上传一张图片");
            return false;
        }
        return true;
    }


    private void initListener() {
        addImageAdapter.setOnItemClickListener(new AddImageAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(ImageView imageView, int position) {
                KeyboardUtils.hideSoftInput(rootView);
                if (addImageAdapter.getItem(position).equals(ADDI_MAGE)) {
                    showHeadDialog();
                } else {
                    ArrayList<Object> list = new ArrayList<>();
                    for (int i = 0; i < addImageAdapter.getImages().size(); i++) {
                        list.add(addImageAdapter.getImages().get(i));
                    }
                    showPreImages(imageView, list, position);
                }
            }

            @Override
            public void OnDeleteClick(int position, String imagPath) {
                addImageAdapter.deletePosition(position, imagPath);
            }
        });

        final int[] scrollX = {0};
        final int[] scrollY = {0};
        recyclerView.setOnTouchListener((v, event) -> {//点击空白区域
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                scrollX[0] = (int) event.getX();
                scrollY[0] = (int) event.getY();
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (v.getId() != 0 && Math.abs(scrollX[0] - event.getX()) <= 5 && Math.abs(scrollY[0] - event.getY()) <= 5) {
                    //recyclerView空白处点击事件
                    KeyboardUtils.hideSoftInput(rootView);
                }
            }
            return false;
        });


    }

    ImagePopupView popupView;

    //预览图片
    private void showPreImages(ImageView imageView, ArrayList<Object> list, int position) {
        if (list == null || (list != null && list.size() == 0)) {
            return;
        }
        popupView = new ImagePopupView(getActivity());
        popupView.setSrcView(imageView, position)
                .setImageUrls(list)
                .isInfinite(false)
                .isShowPlaceholder(false)
                .setPlaceholderColor(-1)
                .setPlaceholderStrokeColor(-1)
                .setPlaceholderRadius(-1)
                .isShowSaveButton(false).setSrcViewUpdateListener((popupView1, position1) -> {
            popupView.updateSrcView(recyclerView.getChildAt(position).findViewById(R.id.iv_image));
        }).setXPopupImageLoader(new ImageLoader());
        new XPopup.Builder(getContext()).popupType(PopupType.ImageViewer).asCustom(popupView).show();
    }

    public static class ImageLoader implements XPopupImageLoader {
        @Override
        public void loadImage(int position, @NonNull Object url, @NonNull ImageView imageView) {
            //必须指定Target.SIZE_ORIGINAL，否则无法拿到原图，就无法享用天衣无缝的动画
            Glide.with(imageView).load(url).apply(new RequestOptions().placeholder(R.mipmap.icon_share_bg).override(Target.SIZE_ORIGINAL)).into(imageView);
        }

        @Override
        public File getImageFile(@NonNull Context context, @NonNull Object uri) {
            try {
                return Glide.with(context).downloadOnly().load(uri).submit().get();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    public boolean onBackPressedSupport() {
        if (popupView != null && popupView.isShow()) {
            popupView.dismiss();
            return true;
        }
        return super.onBackPressedSupport();
    }

    /**
     * 软键盘输入框管理
     */
    private void registerKeyboardListener() {
        // 键盘弹出密码输入框需要更新位置，整体布局上移
        softKeyboardHelper = new SoftKeyboardHelper()
                .registerActivity(getActivity())
                .setOnSoftKeyboardChangeListener(new SoftKeyboardHelper.OnSoftKeyboardChangeListener() {
                    @Override
                    public void onSoftKeyboardChanged(int keyboardHeightInPx) {
                    }

                    @Override
                    public void onSoftKeyboardOpened(int keyboardHeightInPx) {
                        rootView.scrollTo(0, SizeUtils.dp2px(50));
                    }

                    @Override
                    public void onSoftKeyboardClosed() {
                        rootView.scrollTo(0, 0);
                    }
                });


    }

    /**
     * 用户选择头像弹窗
     */
    UpHeadPopup upHeadPopup;

    private void showHeadDialog() {
        upHeadPopup = DialogUtil.upHeadPopupDailog(this, new UpHeadPopup.Builder().
                setEnableCrop(false).
                setSelectList(addImageAdapter.getSelectMediaList()).
                setMaxNum(6 - addImageAdapter.getImages().size() + addImageAdapter.getSelectMediaList().size()).
                setMixMum(1).setEnablePreview(true));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PictureConfig.CHOOSE_REQUEST && data == null) {
            App.goPhoto = true;
        }
        if (requestCode == PictureConfig.CHOOSE_REQUEST && data != null) {
            addImageAdapter.setLoacationDate(PictureSelector.obtainMultipleResult(data));
        }
    }

    //获取图片的参数
    private String getUpImagePath() {
        List<String> images = addImageAdapter.getImages();
        StringBuffer upImageSb = new StringBuffer();
        if (listBaseEntity != null && listBaseEntity.getData().size() > 0) {
            for (int i = 0; i < images.size(); i++) {
                for (int j = 0; j < listBaseEntity.getData().size(); j++) {
                    if (!PictureMimeType.isHttp(images.get(i))) {
                        if (images.get(i).endsWith(listBaseEntity.getData().get(j).getFileName())) {
                            images.set(i, listBaseEntity.getData().get(j).getFileUrl());
                        }
                    }
                }
            }
        }
        for (String image : images) {
            upImageSb.append(image + ",");
        }
        return upImageSb.substring(0, upImageSb.length() - 1);
    }


    @Override
    public void onStop() {
        super.onStop();
        overFlowViewModle.applyFlowOverNetLiveData.postNext(null);
        KeyboardUtils.hideSoftInput(rootView);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        overFlowViewModle.applyFlowOverNetLiveData.removeObservers(getActivity());
        softKeyboardHelper.unregisterView();
    }
}
