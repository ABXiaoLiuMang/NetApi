package com.ty.bwagent.viewmodel;

/**
 * 登录异常，需要短信验证
 */
public class VerifyModel extends CodeViewModel {

}
