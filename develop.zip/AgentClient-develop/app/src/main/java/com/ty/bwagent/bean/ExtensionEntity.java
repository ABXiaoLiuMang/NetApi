package com.ty.bwagent.bean;

/**
 * 描述: 推广连接模型
 * <p>
 * author:Dale
 */
public class ExtensionEntity {

    /**
     * clientType : pc
     * exclusive : false
     * url : http://main-consumer-web1.bwhou2020.com
     */

    private String clientType;
    private boolean exclusive;
    private String url;
    private String title;//专属域名的title
    private int registerNum;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public boolean isExclusive() {
        return exclusive;
    }

    public void setExclusive(boolean exclusive) {
        this.exclusive = exclusive;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getRegisterNum() {
        return registerNum;
    }

    public void setRegisterNum(int registerNum) {
        this.registerNum = registerNum;
    }
}
