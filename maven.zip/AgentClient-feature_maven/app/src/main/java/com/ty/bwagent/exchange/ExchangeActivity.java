package com.ty.bwagent.exchange;

import android.os.Process;
import android.view.KeyEvent;

import com.ty.bwagent.R;
import com.ty.common.ui.ABBaseActivity;
import com.ty.utils.ExitUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.ToastUtils;


public class ExchangeActivity extends ABBaseActivity {

    private ExchangeFragment mExchangeFragment;

    @Override
    protected int getLayoutId() {
        ScreenUtils.adaptScreen4VerticalSlide(this, 360);
        return R.layout.exchange_activity_exchange;
    }

    @Override
    protected void createProvider() {}

    @Override
    protected void initViewsAndEvents() {
        mExchangeFragment = new ExchangeFragment();
        loadRootFragment(R.id.root, mExchangeFragment);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            exit();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void exit() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if (count > 1) {
            pop();
        } else {
            exitApp(2000);
        }
    }

    private long mExitTime;
    public void exitApp(long doubleClickTime) {
        try {
            if (doubleClickTime <= 0){
                Process.killProcess(Process.myPid());
                System.gc();
                System.exit(0);
            }else if ((System.currentTimeMillis() - mExitTime) > doubleClickTime) {
                ToastUtils.showLong("再按一次退出程序");
                mExitTime = System.currentTimeMillis();
            } else {
                ExitUtils.getInstance().finishAll();
                Process.killProcess(Process.myPid());
                System.gc();
                System.exit(0);
            }
        } catch (Exception e) {
        }
    }

}
