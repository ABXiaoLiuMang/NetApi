package com.ty.bwagent.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.ty.bwagent.R;

import static com.ty.bwagent.view.XMaintainView.SpecialType.access_limit;
import static com.ty.bwagent.view.XMaintainView.SpecialType.area_forbid;
import static com.ty.bwagent.view.XMaintainView.SpecialType.system_maintain;

public class XMaintainView extends ConstraintLayout {
    private int specialType;//特殊类型
    private ImageView ivInner;//中间的图标
    private TextView tv_tag_tips;//ip前缀
    private TextView tv_ip;//ip
    private TextView tvTitle;//标题
    private TextView tvContent;//内容描述
    private TextView tvCallService;//在线客服/联系客服
    private TextView tvContinue;//继续访问

    public XMaintainView(Context context) {
        super(context);
    }

    public XMaintainView(Context context, AttributeSet attrs) {
        super(context, attrs);
        LayoutInflater.from(context).inflate(R.layout.generic_special_maintain_layout, this, true);
        initView();
        obtainAttributes(context, attrs);
        initData();
    }

    //视图
    private void initView() {
        ivInner = findViewById(R.id.ivInner);
        tvTitle = findViewById(R.id.tvTitle);
        tv_ip = findViewById(R.id.tv_ip);
        tv_tag_tips = findViewById(R.id.tv_tag_tips);
        tvContent = findViewById(R.id.tvContent);
        tvCallService = findViewById(R.id.tvCallService);
        tvContinue = findViewById(R.id.tvContinue);
    }

    /**
     * 配置
     */
    private interface Config {
        //访问限制
        int access_limit_title = R.string.generic_access_limit;//标题
        int access_limit_content = R.string.generic_access_limit_content;//内容
        int access_limit_inner = R.mipmap.generic_ic_maintain_403_inner;

        // 地区访问限制
        int area_forbid_title = R.string.generic_area_forbid;//标题
        int area_forbid_content =R.string.generic_area_forbid_content;// 地区访问限制 内容
        int area_forbid__inner = R.mipmap.generic_ic_area_forbid_inner;

        //系统维护
        int system_maintain_title = R.string.generic_system_maintain;//标题
        int system_maintain_content = R.string.generic_system_maintain_content;//内容
        int system_maintain_inner = R.mipmap.generic_ic_maintain_weihu_inner;

    }


    /**
     * 客服按钮
     *
     * @return 客服按钮
     */
    public TextView getCallService() {
        return tvCallService;
    }

    public TextView getTvContinue() {
        return tvContinue;
    }

    public TextView getTv_ip() {
        return tv_ip;
    }

    public TextView getTv_tag_tips() {
        return tv_tag_tips;
    }

    public XMaintainView setSpecialType(@SpecialType int specialType) {
        this.specialType = specialType;
        switch (specialType) {
            case access_limit://访问限制
                tvCallService.setVisibility(VISIBLE);
                tvContinue.setVisibility(GONE);
                setRule(Config.access_limit_title, Config.access_limit_content, Config.access_limit_inner);
                break;

            case area_forbid://地区访问警告
                tvCallService.setVisibility(VISIBLE);
                tvContinue.setVisibility(VISIBLE);
                setRule(Config.area_forbid_title, Config.area_forbid_content, Config.area_forbid__inner);
                break;

            case system_maintain://系统维护
                tvCallService.setVisibility(VISIBLE);
                tvContinue.setVisibility(GONE);
                setRule(Config.system_maintain_title, Config.system_maintain_content, Config.system_maintain_inner);
                break;

        }
        return this;
    }

    //设置规则
    private void setRule(int titleRes, int contentRes, int innerRes) {
        if (titleRes != -1) {
            tvTitle.setText(titleRes);
        }

        if (contentRes != -1) {
            tvContent.setText(contentRes);
        }

        if (innerRes != -1) {
            ivInner.setImageResource(innerRes);
        }
    }

    //初始化数据
    private void initData() {
        setSpecialType(specialType);
    }

    private void obtainAttributes(Context context, AttributeSet attrs) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.XSpecialView);
        int n = a.getIndexCount();
        for (int i = 0; i < n; i++) {
            int attr = a.getIndex(i);
            if (attr == R.styleable.XSpecialView_special_type) {
                specialType = a.getInt(R.styleable.XSpecialView_special_type, 0);
            }
        }
        a.recycle();
    }

    public @interface SpecialType {
        int access_limit = 0;//访问限制
        int system_maintain = 1;//系统维护
        int area_forbid = 2 ; // 地区限制 区域限制
    }
}

