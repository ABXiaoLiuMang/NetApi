package com.ty.bwagent.viewmodel;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.ty.utils.DownTimerHelper;

public class TimerModelView extends ViewModel {

    /**
     * 60秒倒计时
     */
    public MutableLiveData<Long> timerLiveData = new MutableLiveData<>();

    /**
     * 限制登录时间倒计时
     */
    public MutableLiveData<Long> hourLiveData = new MutableLiveData<>();

    private DownTimerHelper mTimer;

    public void startTimer(Lifecycle lifecycle){
        createTimer();
        mTimer.start(lifecycle);
    }

    private void createTimer() {
        if (mTimer == null) {
            //第二个参数 是倒计时间隔
            mTimer = new DownTimerHelper(60 * 1000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    timerLiveData.setValue(millisUntilFinished);
                }

                @Override
                public void onFinish() {
                    cancelTimer();
                    timerLiveData.setValue(0L);
                }
            };
        } else {
            mTimer.setTotalTime(60 * 1000);
        }
    }


    public void startTimer(Lifecycle lifecycle,long time){
        createTimer(time);
        mTimer.start(lifecycle);
    }

    private void createTimer(long time) {
        if (mTimer == null) {
            //第二个参数 是倒计时间隔
            mTimer = new DownTimerHelper(time, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    timerLiveData.setValue(millisUntilFinished);
                }

                @Override
                public void onFinish() {
                    cancelTimer();
                    timerLiveData.setValue(0L);
                }
            };
        } else {
            mTimer.setTotalTime(time);
        }
    }

    public void cancelTimer() {
        if (mTimer != null) {
            mTimer.cancel();
        }
    }
}
