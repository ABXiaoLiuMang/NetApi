package com.ty.bwagent.bean;

public class ServiceEntity {

    /**
     * code : service_web1
     * name : 主线客服
     * url : https://chat.5b3x6.com/chat/chatClient/chatbox.jsp?companyID=5889092&configID=3
     */

    private String code;
    private String name;
    private String url;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
