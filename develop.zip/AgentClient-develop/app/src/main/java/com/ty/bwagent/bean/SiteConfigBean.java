package com.ty.bwagent.bean;

public class SiteConfigBean {


    /**
     * agentDepositSetting : {"max":"1000","min":"100","stint":"10000"}
     * showAgentDeposit : 0
     * showAgentDepositMenu : 0
     * showTeamModel : 1
     * teamModelSetting : {"max":"10000","min":"1000","stint":"20000"}
     */

    private AgentDepositSettingBean agentDepositSetting;
    private int showAgentDeposit;
    private int showAgentDepositMenu;
    private int showTeamModel;
    private TeamModelSettingBean teamModelSetting;

    public AgentDepositSettingBean getAgentDepositSetting() {
        return agentDepositSetting;
    }

    public void setAgentDepositSetting(AgentDepositSettingBean agentDepositSetting) {
        this.agentDepositSetting = agentDepositSetting;
    }

    public int getShowAgentDeposit() {
        return showAgentDeposit;
    }

    public void setShowAgentDeposit(int showAgentDeposit) {
        this.showAgentDeposit = showAgentDeposit;
    }

    public int getShowAgentDepositMenu() {
        return showAgentDepositMenu;
    }

    public void setShowAgentDepositMenu(int showAgentDepositMenu) {
        this.showAgentDepositMenu = showAgentDepositMenu;
    }

    public int getShowTeamModel() {
        return showTeamModel;
    }

    public void setShowTeamModel(int showTeamModel) {
        this.showTeamModel = showTeamModel;
    }

    public TeamModelSettingBean getTeamModelSetting() {
        return teamModelSetting;
    }

    public void setTeamModelSetting(TeamModelSettingBean teamModelSetting) {
        this.teamModelSetting = teamModelSetting;
    }

    public static class AgentDepositSettingBean {
        /**
         * max : 1000
         * min : 100
         * stint : 10000
         */

        private String max;
        private String min;
        private String stint;

        public String getMax() {
            return max;
        }

        public void setMax(String max) {
            this.max = max;
        }

        public String getMin() {
            return min;
        }

        public void setMin(String min) {
            this.min = min;
        }

        public String getStint() {
            return stint;
        }

        public void setStint(String stint) {
            this.stint = stint;
        }
    }

    public static class TeamModelSettingBean {
        /**
         * max : 10000
         * min : 1000
         * stint : 20000
         */

        private String max;
        private String min;
        private String stint;

        public String getMax() {
            return max;
        }

        public void setMax(String max) {
            this.max = max;
        }

        public String getMin() {
            return min;
        }

        public void setMin(String min) {
            this.min = min;
        }

        public String getStint() {
            return stint;
        }

        public void setStint(String stint) {
            this.stint = stint;
        }
    }
}
