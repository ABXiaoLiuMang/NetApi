package com.ty.bwagent.viewmodel;

import android.text.TextUtils;

import androidx.lifecycle.ViewModel;

import com.tianyu.updater.TYUpdater;
import com.tianyu.updater.entity.TYUpdateBean;
import com.tianyu.updater.entity.UpdateEntity;
import com.tianyu.updater.okhttp.callback.TYComCallback;
import com.ty.bwagent.R;
import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.RestrictEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.net.callback.DownCallBack;
import com.ty.utils.FileUtils;
import com.ty.utils.ResUtils;

import okhttp3.Call;

public class SettingViewModel extends ViewModel {

    //退出登录
    public NetLiveData<BaseEntity> logOutLivaData = new NetLiveData<>();

    //检查更新
    public NetLiveData<UpdateEntity> updateResult = new NetLiveData<>();




    //退出登录
    public void logout() {
        NetSdk.create(Api.class)
                .logout()
                .send(logOutLivaData);
    }

    /**
     * 检查更新
     */
    public void checkUpdate(){
        TYUpdater.get().checkUpdate(new TYComCallback<TYUpdateBean>(){
            @Override
            public void onError(Call call, String msg) {
                updateResult.setError(10102245, ResUtils.getString(R.string.timeout_error));
            }

            @Override

            public void onSuccess(TYUpdateBean tyUpdateBean){
                if (tyUpdateBean != null) {
                    if (!TextUtils.isEmpty(tyUpdateBean.getVersion())) {
                        UpdateEntity updateInfo = updateResult.getData();
                        if (updateInfo == null) {
                            updateInfo = new UpdateEntity();
                        }
                        updateInfo.setTYUpdateInfo(tyUpdateBean);
                        updateResult.setNext(updateInfo);
                    } else {
                        updateResult.setError(10102112, ResUtils.getString(R.string.generic_latest_version));
                    }
                } else {
                    updateResult.setError(10102112, ResUtils.getString(R.string.generic_latest_version));
                }
            }
        });
    }

}
