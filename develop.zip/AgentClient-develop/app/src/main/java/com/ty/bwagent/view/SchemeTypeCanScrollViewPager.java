package com.ty.bwagent.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;

import androidx.viewpager.widget.ViewPager;

/**
 * 方案设置模块里ViewPager 解决EditeText 在划不动的问题
 */
public class SchemeTypeCanScrollViewPager extends ViewPager {

    public SchemeTypeCanScrollViewPager(Context context) {
        this(context, null);
    }

    public SchemeTypeCanScrollViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected boolean canScroll(View v, boolean checkV, int dx, int x, int y) {
        if (v instanceof EditText) {
            return false;
        }
        return super.canScroll(v, checkV, dx, x, y);
    }
}