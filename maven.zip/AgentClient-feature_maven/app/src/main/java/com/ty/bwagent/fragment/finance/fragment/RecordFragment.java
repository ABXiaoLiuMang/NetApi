package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.fragment.finance.adapter.RecordAdapter;
import com.ty.bwagent.fragment.finance.bean.Record;
import com.ty.bwagent.fragment.finance.viewmodel.RecordViewModel;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.utils.LogUtils;
import com.ty.utils.TimeUtils;

import java.util.Date;
import java.util.List;

/**
 * 提款记录界面
 */
public class RecordFragment extends ABRefreshFragment<Record.ListBean> {


    protected int status = 0;//提款状态(0全部,1成功,2失败,3提款中,4审核中)
    protected int pageNum = 1;
    protected int pageSize = 10;
    protected String startDate;
    protected String endDate;
    protected int index = 0;
    RecordViewModel mRecordViewModel;
    ImageView iv_logo;
    TextView tv_tips;

    public static RecordFragment getInstance(int index) {
        RecordFragment fragment = new RecordFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ABConfig.KEY_TAG,index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_record;
    }

    @Override
    protected void createProvider() {
        mRecordViewModel = new ViewModelProvider(this).get(RecordViewModel.class);
        mRecordViewModel.recordLiveData.observe(this,new NetObserver<BaseEntity<Record>>(){

            @Override
            protected void onSuccess(BaseEntity<Record> listBaseEntity) {
                recyclerView.setVisibility(View.VISIBLE);
                dismissProgressDialog();
                List<Record.ListBean> beanList =  listBaseEntity.getData().getList();
                if (pageNum == 1) {
                    listAdapter.setNewData(beanList);

                } else {
                    listAdapter.addData(beanList);
                }
                refreshLayout.finishRefresh();
                refreshLayout.finishLoadMore();
                if (beanList.size() < pageSize) {
                    refreshLayout.finishLoadMoreWithNoMoreData();
                }
                iv_logo.setImageResource(R.mipmap.record_empty_bg);
                tv_tips.setText("暂无提款记录");
            }

            @Override
            protected void onError(int code, String errMsg) {
                recyclerView.setVisibility(View.VISIBLE);
                dismissProgressDialog();
                refreshLayout.finishRefresh();
                refreshLayout.finishLoadMore();
                iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
                tv_tips.setText("网络不给力");
            }
        });


        Fragment fragment = getParentFragment();
        if(fragment != null && fragment instanceof RecordTabFragment){
            RecordTabFragment tabFragment = (RecordTabFragment) fragment;
            tabFragment.filterLiveData.observe(this, recordFilterEntity ->{
                if(index == recordFilterEntity.getPosition()){
                    status = recordFilterEntity.getStatus();
                    pageNum = 1;
                    if(recordFilterEntity.getPosition() == 0){
                        startDate = recordFilterEntity.getStartDate();
                        endDate = recordFilterEntity.getEndDate();
                    }
                    mRecordViewModel.withdrawalListFilter(startDate,endDate,status,pageNum,pageSize);
                }
            });
        }
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        recyclerView.setVisibility(View.INVISIBLE);
        index  = bundle.getInt(ABConfig.KEY_TAG);
        endDate = TimeUtils.getDiffDate(0);
        switch (index){
            case 0://全部（最多也就30天）
            case 3://30天
                startDate = TimeUtils.getDiffDate(-29);
                break;
            case 1://7天
                startDate = TimeUtils.getDiffDate(-6);
                break;
            case 2://15天
                startDate = TimeUtils.getDiffDate(-14);
                break;
        }
    }

    boolean loadData = false;
    @Override
    public void onResume() {
        super.onResume();
        if(!loadData){
            showProgressDialog();
            mRecordViewModel.withdrawalListFilter(startDate,endDate,status,pageNum,pageSize);
            loadData = true;
        }
    }

    @Override
    public BaseQuickAdapter<Record.ListBean, BaseViewHolder> getListAdapter() {
        return new RecordAdapter();
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public View getEmptyView() {
        View empty = View.inflate(mContext, R.layout.empty_record, null);
        iv_logo = empty.findViewById(R.id.iv_logo);
        tv_tips = empty.findViewById(R.id.tv_tips);
        return empty;
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//        Record mRecord = (Record) adapter.getItem(position);
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum++;
        mRecordViewModel.withdrawalListFilter(startDate,endDate,status,pageNum,pageSize);
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        pageNum = 1;
        mRecordViewModel.withdrawalListFilter(startDate,endDate,status,pageNum,pageSize);
    }


}
