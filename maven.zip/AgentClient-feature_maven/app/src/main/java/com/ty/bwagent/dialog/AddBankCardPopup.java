package com.ty.bwagent.dialog;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lxj.xpopup.core.BottomPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.AddBankCardPopubAdapter;
import com.ty.bwagent.bean.AddBankCardEntity;

import java.util.List;

public class AddBankCardPopup extends BottomPopupView {

    TextView tv_cancel;
    RecyclerView rcv_type;
    Context context;
    List<AddBankCardEntity> entityList;
    public MutableLiveData<AddBankCardEntity> selectLiveData = new MutableLiveData<>();

    private AddBankCardPopubAdapter popubAdapter;

    public AddBankCardPopup(@NonNull Context context, List<AddBankCardEntity> entityList) {
        super(context);
        this.context = context;
        this.entityList = entityList;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_add_bankcard;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_cancel = findViewById(R.id.tv_cancel);
        rcv_type = findViewById(R.id.rcv_type);
        rcv_type.setLayoutManager(new LinearLayoutManager(context));
        popubAdapter = new AddBankCardPopubAdapter(entityList);
        popubAdapter.setOnItemClickListener((adapter, view, position) -> {
            popubAdapter.setSelectPosition(position);
            selectLiveData.postValue((AddBankCardEntity) adapter.getItem(position));
            dismiss();
        });
        rcv_type.setAdapter(popubAdapter);
        tv_cancel.setOnClickListener(v -> dismiss());
    }

}
