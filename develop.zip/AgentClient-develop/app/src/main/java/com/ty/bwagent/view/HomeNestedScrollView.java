package com.ty.bwagent.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;

//bugly 极个吧用户轮播滑动 pointerIndex out of range
//com.ty.view.viewpager.XBannerViewPager.onInterceptTouchEvent(XBannerViewPager.java:118)
public class HomeNestedScrollView extends NestedScrollView {

    public HomeNestedScrollView(@NonNull Context context) {
        super(context);
    }

    public HomeNestedScrollView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public HomeNestedScrollView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        try {
            return super.onInterceptTouchEvent(ev);
        } catch (IllegalArgumentException ex) {
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        try {
            return super.onTouchEvent(ev);
        } catch (Exception e) {

        }
        return false;
    }
}
