package com.ty.bwagent.view;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.ActiveRateEntity;
import com.ty.bwagent.view.chart.PieEntity;
import com.ty.bwagent.view.chart.PieView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 两个饼状图封装在一起算了
 */
public class XPieView extends ConstraintLayout {

    Context mContext;

    PieView monthPieView;
    PieView todayPieView;
    TextView pipview_point;

    public XPieView(Context context) {
        this(context, null);
    }

    public XPieView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }


    public XPieView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        View view = LayoutInflater.from(mContext).inflate(R.layout.x_pieview, this, true);
        monthPieView = view.findViewById(R.id.monthPieView);
        todayPieView = view.findViewById(R.id.todayPieView);
        pipview_point = view.findViewById(R.id.pipview_point);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        gd.setShape(GradientDrawable.OVAL);
        gd.setSize(SizeUtils.dp2px(7),SizeUtils.dp2px(7));
        gd.setBounds(0, 0, gd.getMinimumWidth(), gd.getMinimumHeight());
        pipview_point.setCompoundDrawables(gd, null, null, null);
    }

    public void initPieView(ActiveRateEntity activeRateEntity) {
        List<PieEntity> pieEntityList = new ArrayList<>();
        pieEntityList.add(new PieEntity((float) activeRateEntity.getDayNotActiveRate(), "", ResUtils.getColor(R.color.generic_pipview_color), ResUtils.getColor(R.color.generic_heise)));
        pieEntityList.add(new PieEntity((float) activeRateEntity.getDayActiveRate(), "", ResUtils.getColor(SiteSdk.ins().styleColor()), ResUtils.getColor(R.color.generic_heise)));
        todayPieView.setData(pieEntityList)
                .setShowAnimator(false)
                .refresh();

        pieEntityList = new ArrayList<>();
        pieEntityList.add(new PieEntity((float) activeRateEntity.getMonthNotActiveRate(), "", ResUtils.getColor(R.color.generic_pipview_color), ResUtils.getColor(R.color.generic_heise)));
        pieEntityList.add(new PieEntity((float) activeRateEntity.getMonthActiveRate(), "", ResUtils.getColor(SiteSdk.ins().styleColor()), ResUtils.getColor(R.color.generic_heise)));
        monthPieView.setData(pieEntityList)
                .setShowAnimator(false)
                .refresh();

    }
}
