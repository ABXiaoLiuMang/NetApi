package com.ty.bwagent.bean;

public class NoticeEntity {

    /**
     * appImageUrl : null
     * content : eswtgestewt
     * createdAt : 2020-01-22T00:27:16
     * title : tewwtwe
     */

    private String appImageUrl;
    private String content;
    private String createdAt;
    private String title;

    public String getAppImageUrl() {
        return appImageUrl;
    }

    public void setAppImageUrl(String appImageUrl) {
        this.appImageUrl = appImageUrl;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
