package com.ty.bwagent.exchange;

public class CurrencyData {
    private String code;
    private String name;

    public String getCode() {
        return code;
    }

    public CurrencyData setCode(String code) {
        this.code = code;
        return this;
    }

    public String getName() {
        return name;
    }

    public CurrencyData setName(String name) {
        this.name = name;
        return this;
    }
}
