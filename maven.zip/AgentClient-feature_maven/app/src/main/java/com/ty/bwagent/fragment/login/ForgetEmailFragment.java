package com.ty.bwagent.fragment.login;

import android.view.View;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ForgetPassEntity;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.viewmodel.ForgetPassWordViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.SingleOnClickListener;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.SpanManager;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

public class ForgetEmailFragment extends ABBaseFragment {

    ForgetPassWordViewModel forgetPassWordViewModel;
    String userName;
    String email;
    @BindView(R.id.forget_phone_warning)
    TextView forgetPhoneWarning;
    @BindView(R.id.forget_et_username)
    ClearEditText forgetEtUsername;
    @BindView(R.id.forget_tv_email)
    ClearEditText forgetTvEmail;
    @BindView(R.id.forget_commit)
    TextView forgetCommit;
    @BindView(R.id.forget_custom)
    TextView forgetCustom;

    public static ForgetEmailFragment getInstance() {
        return new ForgetEmailFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_forgetpass_email;
    }

    @Override
    protected void createProvider() {
        forgetPassWordViewModel = new ViewModelProvider(this).get(ForgetPassWordViewModel.class);

        //邮箱找回密码第一步
        forgetPassWordViewModel.findOneLiveData.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ForgetPassEntity forgetPassEntity = new ForgetPassEntity();
                forgetPassEntity.setFromPhone(false)
                        .setName(userName)
                        .setEmail(email);
                ((ABBaseFragment) getParentFragment()).start(ForgetSetp1Fragment.getInstance(forgetPassEntity));
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
//                forgetPhoneWarning.setText(errMsg);
            }
        });

    }

    @Override
    protected void initViewsAndEvents() {
        SpanManager.callServiceSpan(forgetCustom, ResUtils.getString(R.string.generic_forgetpass_alert), ResUtils.getColor(SiteSdk.ins().styleColor()), "联系客服", new SingleOnClickListener() {
            @Override
            public void onSingleClick(View view) {
                goActivity(OnlineActivity.class);
            }
        });
        initVerify();
    }

    @OnClick({ R.id.forget_commit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.forget_commit:
                userName = forgetEtUsername.getText().toString().trim();
                email = forgetTvEmail.getText().toString().trim();
                forgetPassWordViewModel.forgetByEmailOne(userName, email);
                break;
        }
    }

    /**
     * 处理各类输入框验证逻辑
     */
    private void initVerify() {
        new InputResultCalculator(Arrays.asList(forgetTvEmail, forgetEtUsername), ok -> forgetCommit.setEnabled(ok));

        new InputResultCalculator(Arrays.asList(forgetTvEmail, forgetEtUsername), ok -> {
            userName = forgetEtUsername.getText().toString();
            email = forgetTvEmail.getText().toString();
            if (VerifyUtils.isUserName(userName) && ParameterVerification.isEmail(email)) {
                forgetCommit.setEnabled(ok);
            } else {
                forgetCommit.setEnabled(false);
            }
        });

        VerifyUtils.verifyUserName(forgetEtUsername, forgetPhoneWarning);
        VerifyUtils.verifyEmail(forgetTvEmail, forgetPhoneWarning);
    }
}
