package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 描述:消息中心列表对象
 * <p>
 * author:Dale
 */
public class MMessage {

    /**
     * endRow : 0
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : true
     * isLastPage : true
     * list : [{"content":"恭喜您，已经通过亚博管理12平台合营申请审核，通过合营后台可以获取您的的专属推广链接，还可以点击右上角的联系我们，获取你的专属代理专员","groupId":null,"groupType":1,"icon":{"icon_32_32":"http://img.bwhou2020.com/15761512096471.png","icon_96_96":"http://img.bwhou2020.com/15761512096512.png","icon_64_64":"http://img.bwhou2020.com/15761512096500.png"},"id":"_6KtPnABnuB_x0uLtpMC","imgUrl":"","isRead":0,"memberId":92019143121,"msgType":1,"sendTime":"2020-02-13 21:12:16","siteId":"1","sticky":0,"title":"成为合营伙伴","type":1}]
     * navigateFirstPage : 1
     * navigateLastPage : 1
     * navigatePages : 8
     * navigatepageNums : [1]
     * nextPage : 0
     * pageNum : 1
     * pageSize : 15
     * pages : 1
     * prePage : 0
     * size : 1
     * startRow : 0
     * total : 1
     */

    private int endRow;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private int navigateFirstPage;
    private int navigateLastPage;
    private int navigatePages;
    private int nextPage;
    private int pageNum;
    private int pageSize;
    private int pages;
    private int prePage;
    private int size;
    private int startRow;
    private int total;
    private List<ListBean> list;
    private List<Integer> navigatepageNums;

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public List<Integer> getNavigatepageNums() {
        return navigatepageNums;
    }

    public void setNavigatepageNums(List<Integer> navigatepageNums) {
        this.navigatepageNums = navigatepageNums;
    }

    public static class ListBean implements Parcelable {
        /**
         * content : 恭喜您，已经通过亚博管理12平台合营申请审核，通过合营后台可以获取您的的专属推广链接，还可以点击右上角的联系我们，获取你的专属代理专员
         * groupId : null
         * groupType : 1
         * icon : {"icon_32_32":"http://img.bwhou2020.com/15761512096471.png","icon_96_96":"http://img.bwhou2020.com/15761512096512.png","icon_64_64":"http://img.bwhou2020.com/15761512096500.png"}
         * id : _6KtPnABnuB_x0uLtpMC
         * imgUrl :
         * isRead : 0
         * memberId : 92019143121
         * msgType : 1
         * sendTime : 2020-02-13 21:12:16
         * siteId : 1
         * sticky : 0
         * title : 成为合营伙伴
         * type : 1
         */

        private String content;//消息内容
        private String groupId;
        private int groupType;
        private IconBean icon;
        private String id;//主键id
        private String imgUrl;//图片地址
        private int isRead;//是否已读0未读，1已读
        private long memberId;//会员id
        private int msgType;//1.通知 2.活动 3.公告 4.赛事公
        private String sendTime;//发送时间
        private String siteId;//站点id
        private int sticky;//通知，活动（置顶），公告（重要）
        private String title;//消息标题
        private int type;

        public ListBean(){}

        protected ListBean(Parcel in) {
            content = in.readString();
            groupId = in.readString();
            groupType = in.readInt();
            id = in.readString();
            imgUrl = in.readString();
            isRead = in.readInt();
            memberId = in.readLong();
            msgType = in.readInt();
            sendTime = in.readString();
            siteId = in.readString();
            sticky = in.readInt();
            title = in.readString();
            type = in.readInt();
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(content);
            dest.writeString(groupId);
            dest.writeInt(groupType);
            dest.writeString(id);
            dest.writeString(imgUrl);
            dest.writeInt(isRead);
            dest.writeLong(memberId);
            dest.writeInt(msgType);
            dest.writeString(sendTime);
            dest.writeString(siteId);
            dest.writeInt(sticky);
            dest.writeString(title);
            dest.writeInt(type);
        }

        @Override
        public int describeContents() {
            return 0;
        }

        public static final Creator<ListBean> CREATOR = new Creator<ListBean>() {
            @Override
            public ListBean createFromParcel(Parcel in) {
                return new ListBean(in);
            }

            @Override
            public ListBean[] newArray(int size) {
                return new ListBean[size];
            }
        };

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getGroupId() {
            return groupId;
        }

        public void setGroupId(String groupId) {
            this.groupId = groupId;
        }

        public int getGroupType() {
            return groupType;
        }

        public void setGroupType(int groupType) {
            this.groupType = groupType;
        }

        public IconBean getIcon() {
            return icon;
        }

        public void setIcon(IconBean icon) {
            this.icon = icon;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public int getIsRead() {
            return isRead;
        }

        public void setIsRead(int isRead) {
            this.isRead = isRead;
        }

        public long getMemberId() {
            return memberId;
        }

        public void setMemberId(long memberId) {
            this.memberId = memberId;
        }

        public int getMsgType() {
            return msgType;
        }

        public void setMsgType(int msgType) {
            this.msgType = msgType;
        }

        public String getSendTime() {
            return sendTime;
        }

        public void setSendTime(String sendTime) {
            this.sendTime = sendTime;
        }

        public String getSiteId() {
            return siteId;
        }

        public void setSiteId(String siteId) {
            this.siteId = siteId;
        }

        public int getSticky() {
            return sticky;
        }

        public void setSticky(int sticky) {
            this.sticky = sticky;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public static class IconBean {
            /**
             * icon_32_32 : http://img.bwhou2020.com/15761512096471.png
             * icon_96_96 : http://img.bwhou2020.com/15761512096512.png
             * icon_64_64 : http://img.bwhou2020.com/15761512096500.png
             */

            private String icon_32_32;
            private String icon_96_96;
            private String icon_64_64;

            public String getIcon_32_32() {
                return icon_32_32;
            }

            public void setIcon_32_32(String icon_32_32) {
                this.icon_32_32 = icon_32_32;
            }

            public String getIcon_96_96() {
                return icon_96_96;
            }

            public void setIcon_96_96(String icon_96_96) {
                this.icon_96_96 = icon_96_96;
            }

            public String getIcon_64_64() {
                return icon_64_64;
            }

            public void setIcon_64_64(String icon_64_64) {
                this.icon_64_64 = icon_64_64;
            }
        }
    }
}
