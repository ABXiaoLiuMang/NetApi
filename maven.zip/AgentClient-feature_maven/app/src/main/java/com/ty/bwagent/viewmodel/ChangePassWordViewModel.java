package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.utils.Md5Util;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.StringUtils;

/**
 * 修改密码
 */
public class ChangePassWordViewModel extends ViewModel {

    //修改密码
    public NetLiveData<BaseEntity> changePassLiveData = new NetLiveData<>();

    /**
     * @param password        密码
     * @param confirmPassword 确认密码
     */
    public void changePassWord(String oldPassword, String password,String confirmPassword) {

        if (StringUtils.length(oldPassword) < 6) {
            changePassLiveData.setError(0, "请输入6-12位原始密码");
            return;
        }
        if (StringUtils.length(password) < 6) {
            changePassLiveData.setError(0, "请输入6-12位字母或数字的密码");
            return;
        }

        if (!StringUtils.equals(password, confirmPassword)) {
            changePassLiveData.setError(0, "新密码和确认密码输入不一致");
            return;
        }

        NetSdk.create(Api.class)
                .changePassWord()
                .params("password", Md5Util.md5(oldPassword))
                .params("newPassword",Md5Util.md5(password))
                .params("surePassword",Md5Util.md5(confirmPassword))
                .params("step","1")
                .params("changeType","4")
                .asJSONType()
                .send(changePassLiveData);
    }

}
