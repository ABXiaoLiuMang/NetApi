package com.ty.bwagent.dialog;

import android.content.Context;
import android.text.method.ScrollingMovementMethod;

import androidx.annotation.NonNull;

import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;

public class NoticeSimplePopup extends ConfirmPopupView {

    public NoticeSimplePopup(@NonNull Context context) {
        super(context);
    }


    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_member_center;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_content.setMovementMethod(ScrollingMovementMethod.getInstance());
        tv_content.setScrollbarFadingEnabled(true);
    }
}
