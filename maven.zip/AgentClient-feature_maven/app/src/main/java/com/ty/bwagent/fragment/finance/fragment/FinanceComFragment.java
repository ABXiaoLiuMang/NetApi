package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.utils.Utils;
import com.ty.common.util.ABConfig;
import com.ty.utils.MathUtil;

/**
 * 佣金界面
 */
public class FinanceComFragment extends FinanceDetailsFragment{


    TextView tv_month;//查询月份
    TextView tv_money;//佣金金额
    TextView account_total;//佣金比例

    public static FinanceComFragment getInstance(Bundle bundle) {
        FinanceComFragment fragment = new FinanceComFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_com;
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        tv_month = rootView.findViewById(R.id.tv_month);
        tv_money = rootView.findViewById(R.id.tv_monty);
        account_total = rootView.findViewById(R.id.account_total);

        String startData = bundle.getString(ABConfig.KEY_TAG);
        tv_month.setText(startData);
        tv_money.setText(Utils.roundDownMoney(financeEntity.getCommission()));
        account_total.setText(MathUtil.twoNumber(financeEntity.getRate() * 100) +"%");//佣金比例
    }
}
