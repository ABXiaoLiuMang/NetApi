package com.ty.bwagent.adapter;

import android.view.ViewGroup;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.QuickEntity;

import java.util.Iterator;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;

/**
 * 描述 首页快捷入口是适配器
 * <p>
 * author:Dale
 */
public class HomeAdapter extends BaseQuickAdapter<QuickEntity, BaseViewHolder> {


    public final static String MEMBERTAB = "成员管理";
    public final static String EXTENSIONTAB = "推广工具";
    public final static String FINANCETAB = "佣金报表";
    public final static String SAVEMONEY = "代理代存";
    public final static String DRAWING = "佣金提款";
    public final static String TURNMONEY = "代理转账";
    public final static String MATERIALLIST = "推广素材";
    public final static String TEAMCENTER = "团队中心";
    public final static String GAMERECORD = "游戏记录";
    public final static String OVERFLOW = "溢出申请";
    public final static String SUBORDINATEAGENT = "下级代理";
    public final static String SCHEMESET = "方案设置";
    public final static String SUBORDINATEAUDIT = "下级审核";


    public HomeAdapter() {
        super(R.layout.recycle_item_quick_home);
    }

    int itemHeight = 0;

    public void setItemHeight(int itemHeight) {
        this.itemHeight = itemHeight;
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, QuickEntity mQuickEntity) {

        if (itemHeight > 0) {
            ConstraintLayout item_rootView = helper.getView(R.id.item_rootView);
            ViewGroup.LayoutParams lp = item_rootView.getLayoutParams();
            lp.height = itemHeight;
            item_rootView.setLayoutParams(lp);
        }
        helper.setText(R.id.home_tv_title, mQuickEntity.getTitle());
        helper.setImageResource(R.id.home_iv_icon, mQuickEntity.getResId());

        helper.setVisible(R.id.iv_red_dot, mQuickEntity.isShowRedDot());

    }

    //方案设置红点展示 返佣方案 和返水方案有一个没有设置就显示红点
    public boolean isCommissionShowRedDot = false;//返佣的
    public boolean isRebateShowRedDot = false;//返水

    public void setSchemeRedDot(int type, boolean isCommiteShowRedDot, boolean isRebateShowRedDot) {
        if (type == 1) {
            this.isCommissionShowRedDot = isCommiteShowRedDot;
        }
        if (type == 2) {
            this.isRebateShowRedDot = isRebateShowRedDot;
        }
        setRedDotShow();
    }

    public void setRedDotShow() {
        for (int i = 0; i < getData().size(); i++) {
            if (getData().get(i).getTitle().equals(SCHEMESET)) {
                if (this.isCommissionShowRedDot || this.isRebateShowRedDot) {
                    getData().get(i).setShowRedDot(true);
                } else {
                    getData().get(i).setShowRedDot(false);
                }
                break;
            }
            notifyDataSetChanged();
        }
    }


    /**
     * 增加无限极
     */
    public void addInfinite() {
        getData().add(new QuickEntity(SUBORDINATEAGENT, R.mipmap.home_item_subagent_bg, false));//下级代理
        getData().add(new QuickEntity(SCHEMESET, R.mipmap.home_item_teamset_bg, false));//方案设置
        getData().add(new QuickEntity(SUBORDINATEAUDIT, R.mipmap.home_item_next_bg, false));//下级审核
    }

    /**
     * 去除无限极
     */
    public void reMoveInfinite(){
        removeModle(SUBORDINATEAGENT);
        removeModle(SCHEMESET);
        removeModle(SUBORDINATEAUDIT);
    }


    //取消团队模式
    public void removeMemBerCenterModle() {
        removeModle(TEAMCENTER);
        removeModle(TURNMONEY);
    }

    //增加团队模式
    public void addMemBerCenterModle() {
        addModle(TEAMCENTER);
        addModle(TURNMONEY);
    }

    //增加代理代存
    public void addDepositModle() {
        addModle(SAVEMONEY);
    }

    //取消代理代存
    public void removeDepositModle() {
        removeModle(SAVEMONEY);
    }


    //增加功能显示
    public void addModle(String modle) {
        if (!isHasModle(modle)) {
            List<QuickEntity> quickEntityList = getData();
            //代理代存判断
            if (modle.equals(SAVEMONEY)) {
                quickEntityList.add(3, new QuickEntity(SAVEMONEY, R.mipmap.home_item_save_bg, false));
            }

            if (isHasModle(SAVEMONEY)) {
                if (modle.equals(TEAMCENTER)) {
                    quickEntityList.add(5, new QuickEntity(TEAMCENTER, R.mipmap.home_item_menber_center_bg, false));
                }
                if (modle.equals(TURNMONEY)) {
                    if (isHasModle(TEAMCENTER)) {
                        quickEntityList.add(6, new QuickEntity(TURNMONEY, R.mipmap.home_item_zhuanzhang_bg, false));
                    } else {
                        quickEntityList.add(5, new QuickEntity(TURNMONEY, R.mipmap.home_item_zhuanzhang_bg, false));
                    }
                }
            } else {
                if (modle.equals(TEAMCENTER)) {
                    quickEntityList.add(4, new QuickEntity(TEAMCENTER, R.mipmap.home_item_menber_center_bg, false));
                }
                if (modle.equals(TURNMONEY)) {
                    if (isHasModle(TEAMCENTER)) {
                        quickEntityList.add(5, new QuickEntity(TURNMONEY, R.mipmap.home_item_zhuanzhang_bg, false));
                    } else {
                        quickEntityList.add(4, new QuickEntity(TURNMONEY, R.mipmap.home_item_zhuanzhang_bg, false));
                    }
                }
            }
            notifyDataSetChanged();
        }
    }

    //是否是有XX功能
    public boolean isHasModle(String modle) {
        boolean isModle = false;
        List<QuickEntity> data = getData();
        if (data == null) {
            isModle = false;
        }
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getTitle().equals(modle)) {
                isModle = true;
                break;
            }
        }
        return isModle;
    }

    //取消XX功能
    public void removeModle(String modle) {
        List<QuickEntity> data = getData();
        Iterator<QuickEntity> it = data.iterator();
        while (it.hasNext()) {
            QuickEntity next = it.next();
            if (next.getTitle().equals(modle)) {
                it.remove();
            }
        }
        notifyDataSetChanged();
    }
}
