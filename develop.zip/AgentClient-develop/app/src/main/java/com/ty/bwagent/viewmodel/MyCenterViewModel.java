package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.UpFileEntity;
import com.ty.net.NetCall;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.io.File;
import java.util.List;

public class MyCenterViewModel extends ReadedViewModel {

    //上传头像(第一步文件)
    public NetLiveData<BaseEntity<UpFileEntity>> uploadLiveData = new NetLiveData<>();

    //上传头像(第二步)
    public NetLiveData<BaseEntity> insertAvatarLiveData = new NetLiveData<>();

    //上传头像(第二步)
    public NetLiveData<BaseEntity<List<UpFileEntity>>> uploadMultiFileLiveData = new NetLiveData<>();

    // 更新展示qq号
    public NetLiveData<BaseEntity> updateQqTypeLiveData = new NetLiveData<>();


    //上传头像图片
    public void uploadFile(File file) {
        NetSdk.create(Api.class)
                .uploadFile()
                .params("file", file)
                .send(uploadLiveData);
    }

    //多张图片上传
    public void uploadMultiFile(List<File> files) {
        NetCall<BaseEntity<List<UpFileEntity>>> netCall = NetSdk.create(Api.class)
                .uploadMultiFile();
        netCall.params("files", files);
        netCall.send(uploadMultiFileLiveData);
    }

    public void insertMemberAvatar(String avatarUrl) {
        NetSdk.create(Api.class)
                .insertMemberAvatar()
                .params("avatarUrl", avatarUrl)
                .asJSONType()
                .send(insertAvatarLiveData);
    }

    /**
     * @param qqType qq号是否展示 0是 1否
     */
    public void updateQqType(String qqType) {
        NetSdk.create(Api.class)
                .updateQqType()
                .params("qqType", qqType)
                .asJSONType()
                .send(updateQqTypeLiveData);
    }
}
