package com.ty.bwagent.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.ty.bwagent.R;
import com.ty.pickerview.WheelView;
import com.ty.pickerview.adapter.ArrayWheelAdapter;
import com.ty.pickerview.adapter.NumericWheelAdapter;
import com.ty.pickerview.listener.ISelectTimeCallback;
import com.ty.pickerview.listener.OnItemSelectedListener;
import com.ty.pickerview.utils.ChinaDate;
import com.ty.utils.ResUtils;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

/**
 * 提款记录中两个滚轮时间封装
 */
public class XPickerView extends LinearLayout {

    private Context mContext;
    private WheelView wv_year;
    private WheelView wv_month;
    private WheelView wv_day;

    private static final int DEFAULT_START_YEAR = 2010;
    private static final int DEFAULT_END_YEAR = Calendar.getInstance().get(Calendar.YEAR);
    private static final int DEFAULT_START_MONTH = 1;
    private static final int DEFAULT_END_MONTH = Calendar.getInstance().get(Calendar.MONTH) + 1;
    private static final int DEFAULT_START_DAY = 1;
    private static final int DEFAULT_END_DAY = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
    private int startYear = DEFAULT_START_YEAR;
    private int endYear = DEFAULT_END_YEAR;
    private int startMonth = DEFAULT_START_MONTH;
    private int endMonth = DEFAULT_END_MONTH;
    private int startDay = DEFAULT_START_DAY;
    private int endDay = DEFAULT_END_DAY; //表示31天的
    private int currentYear;
    private ISelectTimeCallback mSelectChangeCallback;


    public XPickerView(Context context) {
        this(context, null);
    }

    public XPickerView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public XPickerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setOrientation(LinearLayout.HORIZONTAL);
        View view = LayoutInflater.from(mContext).inflate(R.layout.x_pickerview, this, true);
        wv_year = view.findViewById(R.id.year);
        wv_month = view.findViewById(R.id.month);
        wv_day = view.findViewById(R.id.day);
    }


    /**
     * @param year
     * @param month
     * @param day
     */
    public void setSolar(int year, final int month, int day) {
        // 添加大小月月份并将其转换为list,方便之后的判断
        String[] months_big = {"1", "3", "5", "7", "8", "10", "12"};
        String[] months_little = {"4", "6", "9", "11"};

        final List<String> list_big = Arrays.asList(months_big);
        final List<String> list_little = Arrays.asList(months_little);

        currentYear = year;
        // 年
        wv_year.setAdapter(new NumericWheelAdapter(startYear, endYear));// 设置"年"的显示数据
        wv_year.setCurrentItem(year - startYear);// 初始化时显示的数据
        wv_year.setGravity(Gravity.CENTER);
        wv_year.setLabel(ResUtils.getString(R.string.pickerview_year));
        wv_year.isCenterLabel(false);
        wv_year.setLineSpacingMultiplier(2f);
        // 月

        if (startYear == endYear) {//开始年等于终止年
            wv_month.setAdapter(new NumericWheelAdapter(startMonth, endMonth));
            wv_month.setCurrentItem(month + 1 - startMonth);
        } else if (year == startYear) {
            //起始日期的月份控制
            wv_month.setAdapter(new NumericWheelAdapter(startMonth, 12));
            wv_month.setCurrentItem(month + 1 - startMonth);
        } else if (year == endYear) {
            //终止日期的月份控制
            wv_month.setAdapter(new NumericWheelAdapter(1, endMonth));
            wv_month.setCurrentItem(month);
        } else {
            wv_month.setAdapter(new NumericWheelAdapter(1, 12));
            wv_month.setCurrentItem(month);
        }
        wv_month.setGravity(Gravity.CENTER);
        wv_month.setLabel(ResUtils.getString(R.string.pickerview_month));
        wv_month.isCenterLabel(false);
        wv_month.setLineSpacingMultiplier(2f);
        // 日

        if (startYear == endYear && startMonth == endMonth) {
            if (list_big.contains(String.valueOf(month + 1))) {
                if (endDay > 31) {
                    endDay = 31;
                }
                wv_day.setAdapter(new NumericWheelAdapter(startDay, endDay));
            } else if (list_little.contains(String.valueOf(month + 1))) {
                if (endDay > 30) {
                    endDay = 30;
                }
                wv_day.setAdapter(new NumericWheelAdapter(startDay, endDay));
            } else {
                // 闰年
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
                    if (endDay > 29) {
                        endDay = 29;
                    }
                    wv_day.setAdapter(new NumericWheelAdapter(startDay, endDay));
                } else {
                    if (endDay > 28) {
                        endDay = 28;
                    }
                    wv_day.setAdapter(new NumericWheelAdapter(startDay, endDay));
                }
            }
            wv_day.setCurrentItem(day - startDay);
        } else if (year == startYear && month + 1 == startMonth) {
            // 起始日期的天数控制
            if (list_big.contains(String.valueOf(month + 1))) {

                wv_day.setAdapter(new NumericWheelAdapter(startDay, 31));
            } else if (list_little.contains(String.valueOf(month + 1))) {

                wv_day.setAdapter(new NumericWheelAdapter(startDay, 30));
            } else {
                // 闰年
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {

                    wv_day.setAdapter(new NumericWheelAdapter(startDay, 29));
                } else {

                    wv_day.setAdapter(new NumericWheelAdapter(startDay, 28));
                }
            }
            wv_day.setCurrentItem(day - startDay);
        } else if (year == endYear && month + 1 == endMonth) {
            // 终止日期的天数控制
            if (list_big.contains(String.valueOf(month + 1))) {
                if (endDay > 31) {
                    endDay = 31;
                }
                wv_day.setAdapter(new NumericWheelAdapter(1, endDay));
            } else if (list_little.contains(String.valueOf(month + 1))) {
                if (endDay > 30) {
                    endDay = 30;
                }
                wv_day.setAdapter(new NumericWheelAdapter(1, endDay));
            } else {
                // 闰年
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
                    if (endDay > 29) {
                        endDay = 29;
                    }
                    wv_day.setAdapter(new NumericWheelAdapter(1, endDay));
                } else {
                    if (endDay > 28) {
                        endDay = 28;
                    }
                    wv_day.setAdapter(new NumericWheelAdapter(1, endDay));
                }
            }
            wv_day.setCurrentItem(day - 1);
        } else {
            // 判断大小月及是否闰年,用来确定"日"的数据
            if (list_big.contains(String.valueOf(month + 1))) {

                wv_day.setAdapter(new NumericWheelAdapter(1, 31));
            } else if (list_little.contains(String.valueOf(month + 1))) {

                wv_day.setAdapter(new NumericWheelAdapter(1, 30));
            } else {
                // 闰年
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {

                    wv_day.setAdapter(new NumericWheelAdapter(1, 29));
                } else {

                    wv_day.setAdapter(new NumericWheelAdapter(1, 28));
                }
            }
            wv_day.setCurrentItem(day - 1);
        }

        wv_day.setGravity(Gravity.CENTER);
        wv_day.setLabel(ResUtils.getString(R.string.pickerview_day));
        wv_day.isCenterLabel(false);
        wv_day.setLineSpacingMultiplier(2f);

        // 添加"年"监听
        wv_year.setOnItemSelectedListener(index -> {
            int year_num = index + startYear;
            currentYear = year_num;
            int currentMonthItem = wv_month.getCurrentItem();//记录上一次的item位置
            // 判断大小月及是否闰年,用来确定"日"的数据
            if (startYear == endYear) {
                //重新设置月份
                wv_month.setAdapter(new NumericWheelAdapter(startMonth, endMonth));

                if (currentMonthItem > wv_month.getAdapter().getItemsCount() - 1) {
                    currentMonthItem = wv_month.getAdapter().getItemsCount() - 1;
                    wv_month.setCurrentItem(currentMonthItem);
                }

                int monthNum = currentMonthItem + startMonth;

                if (startMonth == endMonth) {
                    //重新设置日
                    setReDay(year_num, monthNum, startDay, endDay, list_big, list_little);
                } else if (monthNum == startMonth) {
                    //重新设置日
                    setReDay(year_num, monthNum, startDay, 31, list_big, list_little);
                } else if (monthNum == endMonth) {
                    setReDay(year_num, monthNum, 1, endDay, list_big, list_little);
                } else {//重新设置日
                    setReDay(year_num, monthNum, 1, 31, list_big, list_little);
                }
            } else if (year_num == startYear) {//等于开始的年
                //重新设置月份
                wv_month.setAdapter(new NumericWheelAdapter(startMonth, 12));

                if (currentMonthItem > wv_month.getAdapter().getItemsCount() - 1) {
                    currentMonthItem = wv_month.getAdapter().getItemsCount() - 1;
                    wv_month.setCurrentItem(currentMonthItem);
                }

                int month1 = currentMonthItem + startMonth;
                if (month1 == startMonth) {
                    //重新设置日
                    setReDay(year_num, month1, startDay, 31, list_big, list_little);
                } else {
                    //重新设置日
                    setReDay(year_num, month1, 1, 31, list_big, list_little);
                }

            } else if (year_num == endYear) {
                //重新设置月份
                wv_month.setAdapter(new NumericWheelAdapter(1, endMonth));
                if (currentMonthItem > wv_month.getAdapter().getItemsCount() - 1) {
                    currentMonthItem = wv_month.getAdapter().getItemsCount() - 1;
                    wv_month.setCurrentItem(currentMonthItem);
                }
                int monthNum = currentMonthItem + 1;

                if (monthNum == endMonth) {
                    //重新设置日
                    setReDay(year_num, monthNum, 1, endDay, list_big, list_little);
                } else {
                    //重新设置日
                    setReDay(year_num, monthNum, 1, 31, list_big, list_little);
                }

            } else {
                //重新设置月份
                wv_month.setAdapter(new NumericWheelAdapter(1, 12));
                //重新设置日
                setReDay(year_num, wv_month.getCurrentItem() + 1, 1, 31, list_big, list_little);
            }

            if (mSelectChangeCallback != null) {
                mSelectChangeCallback.onTimeSelectChanged();
            }
        });


        // 添加"月"监听
        wv_month.setOnItemSelectedListener(index -> {
            int month_num = index + 1;

            if (startYear == endYear) {
                month_num = month_num + startMonth - 1;
                if (startMonth == endMonth) {
                    //重新设置日
                    setReDay(currentYear, month_num, startDay, endDay, list_big, list_little);
                } else if (startMonth == month_num) {

                    //重新设置日
                    setReDay(currentYear, month_num, startDay, 31, list_big, list_little);
                } else if (endMonth == month_num) {
                    setReDay(currentYear, month_num, 1, endDay, list_big, list_little);
                } else {
                    setReDay(currentYear, month_num, 1, 31, list_big, list_little);
                }
            } else if (currentYear == startYear) {
                month_num = month_num + startMonth - 1;
                if (month_num == startMonth) {
                    //重新设置日
                    setReDay(currentYear, month_num, startDay, 31, list_big, list_little);
                } else {
                    //重新设置日
                    setReDay(currentYear, month_num, 1, 31, list_big, list_little);
                }

            } else if (currentYear == endYear) {
                if (month_num == endMonth) {
                    //重新设置日
                    setReDay(currentYear, wv_month.getCurrentItem() + 1, 1, endDay, list_big, list_little);
                } else {
                    setReDay(currentYear, wv_month.getCurrentItem() + 1, 1, 31, list_big, list_little);
                }

            } else {
                //重新设置日
                setReDay(currentYear, month_num, 1, 31, list_big, list_little);
            }
            if (mSelectChangeCallback != null) {
                mSelectChangeCallback.onTimeSelectChanged();
            }
        });
        setChangedListener(wv_day);
        setContentTextSize();
    }

    private void setContentTextSize() {
        wv_day.setTextSize(18);
        wv_month.setTextSize(18);
        wv_year.setTextSize(18);
    }


    private void setChangedListener(WheelView wheelView) {
        if (mSelectChangeCallback != null) {
            wheelView.setOnItemSelectedListener(index -> mSelectChangeCallback.onTimeSelectChanged());
        }
    }

    private void setReDay(int year_num, int monthNum, int startD, int endD, List<String> list_big, List<String> list_little) {
        int currentItem = wv_day.getCurrentItem();

        if (list_big.contains(String.valueOf(monthNum))) {
            if (endD > 31) {
                endD = 31;
            }
            wv_day.setAdapter(new NumericWheelAdapter(startD, endD));
        } else if (list_little.contains(String.valueOf(monthNum))) {
            if (endD > 30) {
                endD = 30;
            }
            wv_day.setAdapter(new NumericWheelAdapter(startD, endD));
        } else {
            if ((year_num % 4 == 0 && year_num % 100 != 0)
                    || year_num % 400 == 0) {
                if (endD > 29) {
                    endD = 29;
                }
                wv_day.setAdapter(new NumericWheelAdapter(startD, endD));
            } else {
                if (endD > 28) {
                    endD = 28;
                }
                wv_day.setAdapter(new NumericWheelAdapter(startD, endD));
            }
        }

        if (currentItem > wv_day.getAdapter().getItemsCount() - 1) {
            currentItem = wv_day.getAdapter().getItemsCount() - 1;
            wv_day.setCurrentItem(currentItem);
        }
    }

    /**
     * 返回选择的时间
     * @return
     */
    public String getTime() {
        StringBuilder sb = new StringBuilder();
        if (currentYear == startYear) {
            if ((wv_month.getCurrentItem() + startMonth) == startMonth) {
                sb.append((wv_year.getCurrentItem() + startYear)).append("-")
                        .append((wv_month.getCurrentItem() + startMonth)).append("-")
                        .append((wv_day.getCurrentItem() + startDay));
            } else {
                sb.append((wv_year.getCurrentItem() + startYear)).append("-")
                        .append((wv_month.getCurrentItem() + startMonth)).append("-")
                        .append((wv_day.getCurrentItem() + 1));
            }

        } else {
            sb.append((wv_year.getCurrentItem() + startYear)).append("-")
                    .append((wv_month.getCurrentItem() + 1)).append("-")
                    .append((wv_day.getCurrentItem() + 1));
        }

        return sb.toString();
    }

    public void setSelectChangeCallback(ISelectTimeCallback mSelectChangeCallback) {
        this.mSelectChangeCallback = mSelectChangeCallback;
    }
}
