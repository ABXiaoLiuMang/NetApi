package com.ty.bwagent.adapter;

import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.AboutSponsor;
import com.ty.bwagent.exchange.StringUtil;
import com.ty.bwagent.view.chart.ChartEntity;
import com.ty.utils.StringUtils;

import java.util.List;


/**
 * 描述:关于赞助 适配器
 * author:Dale
 */
public class AboutSponsorAdapter extends BaseQuickAdapter<AboutSponsor, BaseViewHolder> {


    /**
     * firstCreative : 都是对的
     * id : 55
     * infoUrl : /app/activity/friend
     * keyCreative : 都是对的
     * secondCreative : 都是对的
     * shareTitle : 都是对的
     * shareUrl : http://static.bwhou2020.com/1578325892400855.jpg
     * sponsoredIconUrl : https://img.bwhou2020.com/1580732859628480.jpg
     * sponsoredTile : 赞助配置
     * sponsoredUrl : https://img.bwhou2020.com/1580732840344152.jpg
     */

    public AboutSponsorAdapter() {
        super(R.layout.recycle_item_about_sponsor);
    }

    @Override
    protected void convert(BaseViewHolder helper, AboutSponsor item) {
        helper.setText(R.id.sponsor_name, item.getName());
        ImageView sponsor_icon = helper.getView(R.id.sponsor_icon);
        if(!StringUtils.isEmpty(item.getImageUrl())){
            Glide.with(mContext).load(item.getImageUrl()).into(sponsor_icon);
        }
    }


}
