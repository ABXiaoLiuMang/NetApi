package com.ty.bwagent.fragment.finance.adapter;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.finance.bean.FinanceTotal;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XTextView;
import com.ty.utils.MathUtil;


/**
 * 描述
 * <p>
 * author:Dale
 */
public class FinanceVenueAdapter extends BaseQuickAdapter<FinanceTotal, BaseViewHolder> {

    public FinanceVenueAdapter() {
        super(R.layout.recycle_item_finance_venue);
    }

    @Override
    protected void convert(BaseViewHolder helper, FinanceTotal entity) {
        XTextView total_water = helper.getView(R.id.total_water);
        helper.setText(R.id.total_title,entity.getVenueName());
        total_water.setMontyText(entity.getProfit());//总输赢
        helper.setText(R.id.total_rate, MathUtil.parseNumber(entity.getCommissionRate() * 100) +"%");//费率
        helper.setText(R.id.total_monty, Utils.roundDownMoney(entity.getThirdPartySpend()));//场馆费

        ((TextView)helper.getView(R.id.total_rate)).setTypeface(TypefaceUtils.DIN_MEDIUM);
        ((TextView)helper.getView(R.id.total_monty)).setTypeface(TypefaceUtils.DIN_MEDIUM);

        if(getItemCount() == 2){//表示只有一行数据，因为第一行是headView
            helper.setBackgroundRes(R.id.finance_rootView,R.drawable.finance_buttom_corners_w_bg);
        }else{
            if(helper.getAdapterPosition() % 2 == 0){

                if(helper.getAdapterPosition() + 1 == getItemCount()){//表示是最后一个
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_buttom_corners_x_bg);
                }else {
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_center_corners_x_bg);
                }

            }else {
                if(helper.getAdapterPosition() + 1 == getItemCount()){//表示是最后一个
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_buttom_corners_w_bg);
                }else {
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_center_corners_w_bg);
                }
            }
        }
    }

}
