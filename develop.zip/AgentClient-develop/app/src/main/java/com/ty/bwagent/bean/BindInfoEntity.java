package com.ty.bwagent.bean;

public class BindInfoEntity {


    /**
     * address :
     * agentStatus : null
     * avatar : https://static.4gh0fx.com/1577419251059212/imageAvatar01@3x.png
     * birthday : null
     * createdAt : 2020-04-28 22:19:12
     * email : 679643234@qq.com
     * firstLogin : 1
     * gameUrl :
     * id : 324
     * inviteCode : 3738166
     * lastLoginDeviceId : 7A2F8174-970D-4C7D-B210-5BAC97FA83CC
     * lastLoginIp : 202.187.89.149
     * lastLoginTime : 2020-04-28 22:19:13
     * name : mmmnnn65
     * nickName :
     * onLine : false
     * password : e424a097700e98ebcf0bea0bfc617c86
     * phone : 13956872578
     * qq :
     * realName :
     * registerDeviceId :
     * registerIp : 202.187.89.149
     * salt : 55ee3514-4738-4d2e-b248-b68057b8e403
     * sex : 0
     * siteId : null
     * sourceUrl : http://web-10.bwhou2028.com/register
     * status : 1
     * sysType : 0
     * tagId :
     * teamId : null
     * token : DL_a74d31e02f1a47aa82b23dc4301d2eea
     * topId : 0
     * type :
     * updatedAt : 2020-04-28 22:19:12
     * wechat :
     */

    private String address;
    private Object agentStatus;
    private String avatar;
    private Object birthday;
    private String createdAt;
    private String email;
    private int firstLogin;
    private String gameUrl;
    private int id;
    private String inviteCode;
    private String lastLoginDeviceId;
    private String lastLoginIp;
    private String lastLoginTime;
    private String name;
    private String nickName;
    private boolean onLine;
    private String password;
    private String phone;
    private String qq;
    private String realName;
    private String registerDeviceId;
    private String registerIp;
    private String salt;
    private int sex;
    private Object siteId;
    private String sourceUrl;
    private int status;
    private int sysType;
    private String tagId;
    private Object teamId;
    private String token;
    private int topId;
    private String type;
    private String updatedAt;
    private String wechat;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Object getAgentStatus() {
        return agentStatus;
    }

    public void setAgentStatus(Object agentStatus) {
        this.agentStatus = agentStatus;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public Object getBirthday() {
        return birthday;
    }

    public void setBirthday(Object birthday) {
        this.birthday = birthday;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getFirstLogin() {
        return firstLogin;
    }

    public void setFirstLogin(int firstLogin) {
        this.firstLogin = firstLogin;
    }

    public String getGameUrl() {
        return gameUrl;
    }

    public void setGameUrl(String gameUrl) {
        this.gameUrl = gameUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInviteCode() {
        return inviteCode;
    }

    public void setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode;
    }

    public String getLastLoginDeviceId() {
        return lastLoginDeviceId;
    }

    public void setLastLoginDeviceId(String lastLoginDeviceId) {
        this.lastLoginDeviceId = lastLoginDeviceId;
    }

    public String getLastLoginIp() {
        return lastLoginIp;
    }

    public void setLastLoginIp(String lastLoginIp) {
        this.lastLoginIp = lastLoginIp;
    }

    public String getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(String lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public boolean isOnLine() {
        return onLine;
    }

    public void setOnLine(boolean onLine) {
        this.onLine = onLine;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getRegisterDeviceId() {
        return registerDeviceId;
    }

    public void setRegisterDeviceId(String registerDeviceId) {
        this.registerDeviceId = registerDeviceId;
    }

    public String getRegisterIp() {
        return registerIp;
    }

    public void setRegisterIp(String registerIp) {
        this.registerIp = registerIp;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public Object getSiteId() {
        return siteId;
    }

    public void setSiteId(Object siteId) {
        this.siteId = siteId;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getSysType() {
        return sysType;
    }

    public void setSysType(int sysType) {
        this.sysType = sysType;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    public Object getTeamId() {
        return teamId;
    }

    public void setTeamId(Object teamId) {
        this.teamId = teamId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getTopId() {
        return topId;
    }

    public void setTopId(int topId) {
        this.topId = topId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getWechat() {
        return wechat;
    }

    public void setWechat(String wechat) {
        this.wechat = wechat;
    }
}
