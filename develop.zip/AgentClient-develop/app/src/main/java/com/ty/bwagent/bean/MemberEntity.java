package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * 下级成员列表
 */
public class MemberEntity {

    /**
     * endRow : 0
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : false
     * isLastPage : false
     * list : [{"availableMoney":null,"avater":"http://img.bwhou2020.com/1576480523173011.png","createdAt":"2020-02-05 21:12:16","dayTotalProfit":0,"id":92019143125,"lastLoginTime":"2020-02-13 22:16:33","monthTotalProfit":0,"name":"dale567q","realName":"","status":1,"totalProfit":0,"vipLevel":""}]
     */

    private int endRow;
    private int pageNum;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private List<ListBean> list;

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean implements Parcelable {
        /**
         * availableMoney : null
         * avater : http://img.bwhou2020.com/1576480523173011.png
         * createdAt : 2020-02-05 21:12:16
         * dayTotalProfit : 0.0
         * id : 92019143125
         * lastLoginTime : 2020-02-13 22:16:33
         * monthTotalProfit : 0.0
         * name : dale567q
         * realName :
         * status : 1
         * totalProfit : 0.0
         * vipLevel :
         */

        private double availableMoney;//钱包余额
        private String avater;//会员头像地址
        private String createdAt;//注册时间
        private double dayTotalProfit;//当日输赢
        private String id;
        private String lastLoginTime;//最后登陆时间
        private double monthTotalProfit;//本月输赢
        private String name;//用户名
        private String realName;//真实姓名
        private int status;//会员状态(0停用，1启用)
        private double totalProfit;//总输赢
        private String vipLevel;//VIP等级
        private int active;//0：非活跃 1：活跃
        private int changeAgent;//0: 非转代  1: 转代


        public int getActive() {
            return active;
        }

        public void setActive(int active) {
            this.active = active;
        }

        public int getChangeAgent() {
            return changeAgent;
        }

        public void setChangeAgent(int changeAgent) {
            this.changeAgent = changeAgent;
        }

        public ListBean(){}

        protected ListBean(Parcel in) {
            availableMoney = in.readDouble();
            avater = in.readString();
            createdAt = in.readString();
            dayTotalProfit = in.readDouble();
            id = in.readString();
            lastLoginTime = in.readString();
            monthTotalProfit = in.readDouble();
            name = in.readString();
            realName = in.readString();
            status = in.readInt();
            totalProfit = in.readDouble();
            vipLevel = in.readString();
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeDouble(availableMoney);
            dest.writeString(avater);
            dest.writeString(createdAt);
            dest.writeDouble(dayTotalProfit);
            dest.writeString(id);
            dest.writeString(lastLoginTime);
            dest.writeDouble(monthTotalProfit);
            dest.writeString(name);
            dest.writeString(realName);
            dest.writeInt(status);
            dest.writeDouble(totalProfit);
            dest.writeString(vipLevel);
        }

        @Override
        public int describeContents() {
            return 0;
        }

        public static final Creator<ListBean> CREATOR = new Creator<ListBean>() {
            @Override
            public ListBean createFromParcel(Parcel in) {
                return new ListBean(in);
            }

            @Override
            public ListBean[] newArray(int size) {
                return new ListBean[size];
            }
        };

        public double getAvailableMoney() {
            return availableMoney;
        }

        public void setAvailableMoney(double availableMoney) {
            this.availableMoney = availableMoney;
        }

        public String getAvater() {
            return avater;
        }

        public void setAvater(String avater) {
            this.avater = avater;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public double getDayTotalProfit() {
            return dayTotalProfit;
        }

        public void setDayTotalProfit(double dayTotalProfit) {
            this.dayTotalProfit = dayTotalProfit;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getLastLoginTime() {
            return lastLoginTime;
        }

        public void setLastLoginTime(String lastLoginTime) {
            this.lastLoginTime = lastLoginTime;
        }

        public double getMonthTotalProfit() {
            return monthTotalProfit;
        }

        public void setMonthTotalProfit(double monthTotalProfit) {
            this.monthTotalProfit = monthTotalProfit;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getRealName() {
            return realName;
        }

        public void setRealName(String realName) {
            this.realName = realName;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public double getTotalProfit() {
            return totalProfit;
        }

        public void setTotalProfit(double totalProfit) {
            this.totalProfit = totalProfit;
        }

        public String getVipLevel() {
            return vipLevel;
        }

        public void setVipLevel(String vipLevel) {
            this.vipLevel = vipLevel;
        }
    }
}
