package com.ty.bwagent.utils;

import android.graphics.Typeface;

import com.ty.bwagent.App;

public class TypefaceUtils {
    /**
     * 金额字体
     */
    public static Typeface DIN_MEDIUM = Typeface.createFromAsset(App.getInstance().getAssets(), "fonts/DIN-Medium.otf");

    /**
     * 比率数字的特殊字体
     */
    public static Typeface rateNumTypeface = Typeface.createFromAsset(App.getInstance().getAssets(), "fonts/rate_num.ttc");

}
