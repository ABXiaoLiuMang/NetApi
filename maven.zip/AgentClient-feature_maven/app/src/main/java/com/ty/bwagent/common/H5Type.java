package com.ty.bwagent.common;

/**
 * Desc:
 * Created by Jeff on 2019/2/21
 **/
public enum H5Type {
    /**
     * 视频动画域名   name : live_base_url
     */
    LIVE_BASE_URL("live_base_url"),

    /**
     * 直播地址  name : live_play
     */
    LIVE_PATH("live_play"),
    /**
     * 赞助链接  name : sponsor
     */
    SPONSOR_LINK("sponsor"),
    /**
     * 体育下注教程  name : sport_bet_tutorial
     */
    SPORT_BET_TUTORIAL("sport_bet_tutorial"),
    /**
     * 支付宝转银行卡教程  name : alipay_to_card_tutorial
     */
    ALIPAY_TO_BANK_TUTORIAL("alipay_to_card_tutorial"),
    /**
     * 全站新手教程  name : new_fish_tutorial
     */
    NEW_FISH_TURORIAL("new_fish_tutorial"),
    /**
     * 世界杯活动地址  name : world_cup_activity_discount
     */
    WORLD_CUP_ACTIVITY_LINK("world_cup_activity_discount"),
    /**
     * h5主域名1  name : h5_domain
     */
    H5_DOMAIN("h5_domain"),
    /**
     * ebetapp下载地址ios端发发发  name : ebet_app_download_url_ios
     */
    EBET_APP_DOWNLOAD_URL_IOS("ebet_app_download_url_ios"),
    /**
     * ebetapp下载地址android端  name : ebet_app_download_url_android
     */
    EBET_APP_DOWNLOAD_URL_ANDROID("ebet_app_download_url_android"),
    /**
     * 优惠活动地址发发发  name : discount_link
     */
    DISCOUNT_LINK("discount_link"),
    /**
     * 盘口教程1  name : handicap_teaching
     */
    HANDICAP_TEACHING("handicap_teaching"),
    /**
     * 主客服地址  name : customer_service_main
     */
    CUSTOMER_SERVICE_MAIN("customer_service_main"),
    /**
     * 分客服地址  name : customer_service_2
     */
    CUSTOMER_SERVICE_2("customer_service_2"),

    /**
     * 免费电话 name：phone_customer_service
     */
    PHONE_CUSTOMER_SERVICE("phone_customer_service"),
    /**
     * 投注模拟器  name : betting_simulator
     */
    BETTING_SIMULATOR("betting_simulator"),
    /**
     * 微信扫码 支付教程地址  name : wechat_qcode_pay
     */
    WECHAT_QCODE_PAY("wechat_qcode_pay"),
    /**
     * 存款教程
     */
    DEPOSIT_COURSE("deposit_course"),
    /**
     * 体育下载页面
     */
    SPORT_DOWNLOAD_URL("sport_download_url"),
    /**
     * 全站下载页面
     */
    GAME_DOWNLOAD_URL("game_download_url"),
    /**
     * 代理页面
     */
    AGENT("agent"),
    /**
     * 豪礼赠送页面
     */
    GIFT("gift"),

    /**
     * 好友推荐
     */
    RECOMMENDED("recommended"),

    /**
     * VIP详情
     */
    VIP_DETAILS("vip_details"),

    /**
     *体育投注教程-连串过关
     */
    SPORT_HOW_BET_PARLAY("sport_how_bet_level"),

    /**
     *体育投注教程-单注投注
     */
    SPORT_HOW_BET("sport_how_bet"),

    /**
     * 微信扫码 添加好友 教程地址  name : wechat_qcode_friend
     */
    WECHAT_QCODE_FRIEND("wechat_qcode_friend");



    String value;

    H5Type(String value) {
        this.value = value;
    }

    public String value(){
        return value;
    }
}
