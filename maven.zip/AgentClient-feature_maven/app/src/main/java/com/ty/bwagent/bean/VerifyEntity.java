package com.ty.bwagent.bean;

public class VerifyEntity {

    /**
     * code : 22004
     * data : 16358487896
     * errorSn :
     * msg : 系统检测到您本次登录操作异常，为保障账户安全，已向您注册手机号163****7896发送验证码，请完成验证
     */

    private int code;
    private String data;
    private String errorSn;
    private String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getErrorSn() {
        return errorSn;
    }

    public void setErrorSn(String errorSn) {
        this.errorSn = errorSn;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
