package com.ty.bwagent.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

/**
 * 已经读未读消息处理
 */
public class ReadMsgViewModel extends ViewModel {
    // 标识一条为已读
    public NetLiveData<BaseEntity> readedLiveData = new NetLiveData<>();
    // 一键阅读（全部）
    public NetLiveData<BaseEntity> aLLReadedLiveData = new NetLiveData<>();

    //一键阅读
    public MutableLiveData<Integer> msgTypeLiveData = new MutableLiveData<>();

    /**
     * 1.通知 2.活动
     * @param msgType 一键阅读
     */
    public void onekeyReaded(int msgType) {
        msgTypeLiveData.postValue(msgType);
        NetSdk.create(Api.class)
                .onekeyReaded()
                .params("userSystem","2")//用户体系(空默认为会员)1会员，2代理
                .params("msgType",msgType)//用户体系(空默认为会员)1会员，2代理
                .asJSONType()
                .send(aLLReadedLiveData);
    }

    /**
     * 标识一条消息为已读状态
     * @param id 消息id
     */
    public void msgReaded(String id) {
        NetSdk.create(Api.class)
                .msgReaded()
                .params("id",id)
                .asJSONType()
                .send(readedLiveData);
    }

}
