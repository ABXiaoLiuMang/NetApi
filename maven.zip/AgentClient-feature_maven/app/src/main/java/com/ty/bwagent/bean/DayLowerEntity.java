package com.ty.bwagent.bean;

/**
 * 查询日增长曲线数据
 */
public class DayLowerEntity {

    /**
     * count : 0
     * createTime : 2020-01-14
     */

    private int count;
    private String createTime;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
}
