package com.ty.bwagent.fragment.finance.bean;

/**
 * 描述: 总输赢/场馆费月度明细
 * <p>
 * author:Dale
 */
public class FinanceTotal {

    /**
     * amount : 0.0
     * commissionRate : 0.05
     * netAmount : 0
     * netProfit : 0.0
     * profit : 0.0
     * promo : 0.0
     * riskAdjust : 0.0
     * thirdPartySpend : 0.0
     * venueId : 2
     * venueName : IM棋牌1
     */

    private double amount;//金额
    private double commissionRate;//场馆费率
    private double netAmount;//流水(有效下注)
    private double netProfit;//净输赢
    private double profit;//总输赢
    private double promo;//优惠（红利）
    private double riskAdjust;//输赢调整
    private double thirdPartySpend;//场馆费
    private int venueId;//场馆Id
    private String venueName;//场馆名

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }

    public double getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(double netAmount) {
        this.netAmount = netAmount;
    }

    public double getNetProfit() {
        return netProfit;
    }

    public void setNetProfit(double netProfit) {
        this.netProfit = netProfit;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public double getPromo() {
        return promo;
    }

    public void setPromo(double promo) {
        this.promo = promo;
    }

    public double getRiskAdjust() {
        return riskAdjust;
    }

    public void setRiskAdjust(double riskAdjust) {
        this.riskAdjust = riskAdjust;
    }

    public double getThirdPartySpend() {
        return thirdPartySpend;
    }

    public void setThirdPartySpend(double thirdPartySpend) {
        this.thirdPartySpend = thirdPartySpend;
    }

    public int getVenueId() {
        return venueId;
    }

    public void setVenueId(int venueId) {
        this.venueId = venueId;
    }

    public String getVenueName() {
        return venueName;
    }

    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }
}
