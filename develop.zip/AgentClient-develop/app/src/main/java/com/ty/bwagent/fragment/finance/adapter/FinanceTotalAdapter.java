package com.ty.bwagent.fragment.finance.adapter;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.finance.bean.FinanceTotal;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XTextView;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;
import java.util.List;


/**
 * 描述 场馆总输赢
 * <p>
 * author:Dale
 */
public class FinanceTotalAdapter extends BaseQuickAdapter<List<String>, BaseViewHolder> {

    public FinanceTotalAdapter() {
        super(R.layout.recycle_item_finance_water);
    }

    public List<String> listsTitle = new ArrayList<>();
    public List<List<String>> listsContent = new ArrayList<>();

    //设置数据
    public void setDate(List<FinanceTotal> financeTotals) {

        if (financeTotals == null) {
            return;
        }

        try {

            for (int i = 0; i < financeTotals.size(); i++) {
                if (i == 0) {
                    listsTitle.add("场馆");
                    listsTitle.add(financeTotals.get(i).getVenueName());
                } else {
                    listsTitle.add(financeTotals.get(i).getVenueName());
                }
            }

            for (int i = 0; i < listsTitle.size(); i++) {
                List<String> item = new ArrayList<>();
                for (int j = 0; j < financeTotals.size(); j++) {
                    if (i == 0) {
                        if (j == 0) {
                            item.add("流水");
                            item.add(Utils.parsListMoney(financeTotals.get(j).getNetAmount()).toString());
                        } else {
                            item.add(Utils.parsListMoney(financeTotals.get(j).getNetAmount()).toString());
                        }
                    } else if (i == 1) {
                        if (j == 0) {
                            item.add("总输赢");
                            item.add(Utils.parsListMoney(financeTotals.get(j).getProfit()).toString() + "");
                        } else {
                            item.add(Utils.parsListMoney(financeTotals.get(j).getProfit()).toString() + "");
                        }
                    } else if (i == 2) {
                        if (j == 0) {
                            item.add("场馆费率");
                            item.add(MathUtil.parseNumber(financeTotals.get(j).getCommissionRate() * 100) + "%");
                        } else {
                            item.add(MathUtil.parseNumber(financeTotals.get(j).getCommissionRate() * 100) + "%");
                        }
                    } else if (i == 3) {
                        if (j == 0) {
                            item.add("场馆费");
                            item.add(Utils.parsListMoney(financeTotals.get(j).getThirdPartySpend()).toString());
                        } else {
                            item.add(Utils.parsListMoney(financeTotals.get(j).getThirdPartySpend()).toString());
                        }
                    }
                }
                listsContent.add(item);
            }
            setNewData(listsContent);
        } catch (Exception e) {
            setNewData(listsContent);
        }

    }

    //获取流水
    public String getWaterDate(List<FinanceTotal> financeTotals) {
        double waterDate = 0.00;
        if (financeTotals != null) {
            for (int i = 0; i < financeTotals.size(); i++) {
                if (financeTotals.get(i) != null) {
                    waterDate = waterDate + financeTotals.get(i).getNetAmount();
                }
            }
        }
        return Utils.parsListMoney(waterDate).toString();
    }

    @Override
    protected void convert(BaseViewHolder helper, List<String> listMap) {

        LinearLayout water_rootView = helper.getView(R.id.water_rootView);
        water_rootView.removeAllViews();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(SizeUtils.dp2px(80), SizeUtils.dp2px(50));
        lp.gravity = Gravity.CENTER;
        for (int i = 0; i < listMap.size(); i++) {
            TextView textView = new TextView(mContext);
            textView.setTextColor(ResUtils.getColor(R.color.generic_heise));
            textView.setTextSize(12);
            textView.setGravity(Gravity.CENTER);
//            if (i == 0) {
            textView.setText(listMap.get(i));
//            } else {
//                textView.setText(MathUtil.twoNumber(listMap.get(i)) + "%");
//            }
            water_rootView.addView(textView, lp);
        }


    }

}
