package com.ty.bwagent.fragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import com.ty.bwagent.R;
import com.ty.common.util.ABConfig;

/**
 * 推广主界面
 */
public class ExtensionTabFragment extends BaseViewPagerFragment {

//    h5(主站h5),pc(主站pc),site(全站APP),sportApp(体育App) 根据终端类型获取推广链接地址,不传值得话默认查询全部
    String [] clientType = new String[]{"","h5","pc","site","sportApp"};

    public static ExtensionTabFragment getInstance() {
        return new ExtensionTabFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_extension_tab;
    }

    @Override
    protected void createProvider() {
    }


    @Override
    protected boolean getAdjustMode() {
        return false;
    }

    @Override
    public Fragment getCurrentItem(int position) {
        Bundle bundle = new Bundle();
        bundle.putString(ABConfig.KEY_TEXT,clientType[position]);
        bundle.putString(ABConfig.KEY_TITLE,tabTitles[position]);
        return ExtensionFragment.getInstance(bundle);
    }

    @Override
    public String[] getTabTitles() {
        return new String[]{"全部","主站H5","主站PC","全站APP","体育APP"};
    }

}
