package com.ty.bwagent.update;

import android.app.Activity;
import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.core.CenterPopupView;
import com.tianyu.updater.TYUpdater;
import com.tianyu.updater.dialog.IUpdateDialog;
import com.tianyu.updater.entity.IUpdateInfo;
import com.tianyu.updater.entity.UpdateEntity;
import com.tianyu.updater.utils.ApkInstaller;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.CacheKey;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.NetworkUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;

import org.apache.http.conn.ConnectTimeoutException;

import java.net.SocketTimeoutException;

import javax.net.ssl.SSLException;

public class XUpdatePopupViewNew extends CenterPopupView implements IUpdateDialog {

    UpdateEntity updateInfo;
    LinearLayout layout_btn;//按钮布局
    LinearLayout layout_progress;//进度条布局
    View line_popup;//横线，显示进度时隐藏
    ProgressBar mProgress;
    TextView tv_progress;
    private XDialogManager xDialogManager;
    private XUpdateManager.UpdateCallBack updateCallBack;
    private boolean isShowing = false;
    protected TextView tv_title, tv_content, tv_cancel, tv_confirm;


    public XUpdatePopupViewNew(@NonNull Context context, XDialogManager xDialogManager, XUpdateManager.UpdateCallBack updateCallBack) {
        super(context);
        this.xDialogManager = xDialogManager;
        this.updateCallBack = updateCallBack;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_download;
    }


    @Override
    protected void onCreate() {
        tv_title = findViewById(R.id.tv_title);
        tv_content = findViewById(R.id.tv_content);
        tv_cancel = findViewById(R.id.tv_cancel);
        tv_confirm = findViewById(R.id.tv_confirm);
        line_popup = findViewById(R.id.line_popup);
        layout_btn = findViewById(R.id.layout_btn);
        layout_progress = findViewById(R.id.layout_progress);
        mProgress = findViewById(R.id.mProgress);
        tv_progress = findViewById(R.id.tv_progress);
        tv_title.setText(updateInfo.getUpdateTitle());
        tv_content.setText(updateInfo.getUpdateContent());
        tv_content.setMovementMethod(ScrollingMovementMethod.getInstance());
        tv_content.setScrollbarFadingEnabled(true);
        if (updateInfo.isForce()) {
            hideCancelBtn();
        }
        TYUpdater.get()
//                .setNotificationInfo(new NotificationEntity().setShowNotification(true))
//                .setDialogView(this)
//                .setUpdateInfo(updateInfo)
                .start();
    }

    public CenterPopupView hideCancelBtn(){
        tv_cancel.setVisibility(View.GONE);
        tv_confirm.setText(ResUtils.getString(R.string.generic_update_tips));
        return this;
    }

    @Override
    public Activity getActivity() {
        return (Activity) getContext();
    }

    @Override
    public View getConfirmInstallView() {
        return tv_confirm;
    }

    @Override
    public View getCancelView() {
        return tv_cancel;
    }

    @Override
    public void onDownloadStart(String url) {
        try {//预防奔溃
            if (NetworkUtils.isAvailable()) {
                layout_btn.setVisibility(View.GONE);
                line_popup.setVisibility(View.INVISIBLE);
                layout_progress.setVisibility(View.VISIBLE);
            } else {
                ToastUtils.showLong("网络异常，请重试");
            }
        }catch (Exception e){

        }
    }

    @Override
    public void onDownloadProgress(long progress, long total, boolean isChange) {
        double rate = progress * 1f / total;
        int progressInt = (int) Math.round(rate * 100);
        mProgress.setProgress(progressInt);
        tv_progress.setText(progressInt + "%");

        if(updateCallBack != null){
            if(progressInt==100){
                updateCallBack.onDoweLoadFinish();
            }
        }
    }

    @Override
    public void onDownloadFinish(ApkInstaller installer) {
        hideCancelBtn();
        tv_confirm.setText(R.string.install);
        layout_btn.setVisibility(View.VISIBLE);
        line_popup.setVisibility(View.VISIBLE);
        layout_progress.setVisibility(View.GONE);
    }

    @Override
    public void onDownloadError(Throwable throwable) {
        if (throwable != null && (throwable instanceof SocketTimeoutException || throwable instanceof ConnectTimeoutException)) {
            ToastUtils.showLong("网络异常，请重试");
        } else if (!NetworkUtils.isAvailable() && throwable instanceof SSLException) {
            ToastUtils.showLong("网络异常，请重试");
        }
        LogUtils.e("throwable instanceOf " + throwable.getClass());
        layout_progress.setVisibility(View.GONE);
        layout_btn.setVisibility(View.VISIBLE);
    }

    @Override
    public void onInstallApkFails(String message) {
    }

    @Override
    public void setUpdateInfo(IUpdateInfo updateInfo) {
       this.updateInfo = (UpdateEntity) updateInfo;
    }

    @Override
    public void dismiss() {
        super.dismiss();
        if(updateCallBack != null){
            updateCallBack.onUpdateonDismiss();
        }
        TYUpdater.get().removeView();
    }

    @Override
    public void closeDialog() {
        dismiss();
        isShowing = false;
    }

    @Override
    protected void onShow() {
        super.onShow();
        isShowing = true;
    }

    @Override
    public void showDialog() {
        LogUtils.d("showDialog   getActivity = " + getActivity());
        if (xDialogManager != null) {
            LogUtils.d("showDialog = ture");
            xDialogManager.showUpdate(this);
        } else {
            show();
        }
        LogUtils.d("showDialog  is xDialogManager = " + ( xDialogManager != null));
    }

    @Override
    public boolean isShowing() {
        return isShowing;
    }
}
