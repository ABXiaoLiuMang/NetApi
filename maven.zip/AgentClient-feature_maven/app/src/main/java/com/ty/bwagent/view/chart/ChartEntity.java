package com.ty.bwagent.view.chart;

/**
 * 柱状图模型对象
 */
public class ChartEntity {

    /**
     * commission : 0
     * commissionDate : 2019-02-01
     */

    private double commission;
    private String commissionDate;

    public double getCommission() {
        return commission;
    }

    public void setCommission(double commission) {
        this.commission = commission;
    }

    public String getCommissionDate() {
        return commissionDate;
    }

    public void setCommissionDate(String commissionDate) {
        this.commissionDate = commissionDate;
    }
}
