package com.ty.bwagent.fragment.finance.fragment;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.fragment.BaseViewPagerFragment;
import com.ty.bwagent.viewmodel.MoneyViewModel;
import com.ty.utils.KeyboardUtils;

/**
 * 佣金提款tab界面
 */
public class DrawingTabFragment extends BaseViewPagerFragment {

    MoneyViewModel moneyViewModel;

    public static DrawingTabFragment getInstance() {
        return new DrawingTabFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_drawing_tab;
    }

    @Override
    protected void createProvider() {
        moneyViewModel = new ViewModelProvider(getActivity()).get(MoneyViewModel.class);
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        moneyViewModel.getDrawPhone();
    }

    @Override
    public Fragment getCurrentItem(int position) {
        if(position == 0){
            return DrawingCardFragment.getInstance();
        }else {
            return DrawWalletFragment.getInstance();
        }
    }

    @Override
    public String[] getTabTitles() {
        return new String[]{"提款至银行卡", "提款至中心钱包"};
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        KeyboardUtils.hideSoftInput(getActivity());
    }
}
