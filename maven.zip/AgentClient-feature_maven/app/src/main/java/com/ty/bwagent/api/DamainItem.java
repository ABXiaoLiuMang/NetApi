package com.ty.bwagent.api;

public class DamainItem {
//    域名
    private String host;

    private String[] tokens;

    public DamainItem(String host, String[] tokens) {
        this.host = host;
        this.tokens = tokens;
    }

    public void setTokens(String[] tokens) {
        this.tokens = tokens;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String[] getTokens() {
        return tokens;
    }
}
