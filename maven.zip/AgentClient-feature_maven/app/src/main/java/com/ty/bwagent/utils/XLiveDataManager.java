package com.ty.bwagent.utils;

import android.text.TextUtils;

import com.tianyu.updater.TYUpdater;
import com.tianyu.updater.entity.TYUpdateBean;
import com.tianyu.updater.entity.UpdateEntity;
import com.tianyu.updater.okhttp.callback.TYComCallback;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.bean.UnRendTypeEntity;
import com.ty.bwagent.bean.UserEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.update.XUpdateManager;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;

import okhttp3.Call;

public class XLiveDataManager {

    //检查更新
    public NetLiveData<UpdateEntity> updateResult = new NetLiveData<>();

    // 具体消息类型未读量
    public NetLiveData<BaseEntity<UnRendTypeEntity>> unreadTypeLiveData = new NetLiveData<>();

    //全局个人用户信息
    public NetLiveData<UserInfo> userInfo = new NetLiveData<>();

    //我的模块（个人用户信息,各处未脱敏用到的电话邮箱等，以上面全局不一样的是，全局个人信息都脱敏了，在电话获取短信验证码时无法使用）
    public NetLiveData<BaseEntity<UserEntity>> userLiveData = new NetLiveData<>();

    //关于和客服等数据
    public NetLiveData<ContactUsEntity> contactUsLiveData = new NetLiveData<>();

    private static volatile XLiveDataManager ourInstance = null;

    public static XLiveDataManager getInstance() {
        if (ourInstance == null) {
            synchronized (XLiveDataManager.class) {
                if (ourInstance == null) {
                    ourInstance = new XLiveDataManager();
                }
            }
        }
        return ourInstance;
    }

    private XLiveDataManager() {
    }

    //获取个人用户信息
    public void getUserInfo() {
        NetSdk.create(Api.class)
                .getUserInfo()
                .send(userLiveData);
    }

    /**
     * 退出登录时清除所有数据，现在测试发现退出登录新的账号，
     * 本单列中的livedata会带入旧账号的所有个人信息
     */
    public void loginOut(){
        UserInfoCache.getInstance().cleanUserInfo();
        XUpdateManager.getInstance().clean();
        MMKVUtil.removeValueForKey(Key.IS_USER_LOGIN);
        MMKVUtil.removeValueForKey(Key.LOGIN_TOKEN);
        MMKVUtil.removeValueForKey(Key.AGENT_TOKEN);
        MMKVUtil.removeValueForKey(Key.SYSTYPE);
        MMKVUtil.removeValueForKey(Key.LOGIN_PHONE);
        MMKVUtil.removeValueForKey(Key.INVITE_CODE);
//        MMKVUtil.removeValueForKey(CacheKey.USER_PASSWORD);
//        MMKVUtil.removeValueForKey(CacheKey.REMEMBER_PASSWORD);
        ourInstance = null;
    }



    /**
     * 检查更新
     */
    public void checkUpdate(){
        TYUpdater.get().checkUpdate(new TYComCallback<TYUpdateBean>(){
            @Override
            public void onError(Call call, String msg) {
                updateResult.setError(10102245, ResUtils.getString(R.string.timeout_error));
            }

            @Override

            public void onSuccess(TYUpdateBean tyUpdateBean){
                if (tyUpdateBean != null) {
                    if (!TextUtils.isEmpty(tyUpdateBean.getVersion())) {
                        UpdateEntity updateInfo = updateResult.getData();
                        if (updateInfo == null) {
                            updateInfo = new UpdateEntity();
                        }
                        updateInfo.setTYUpdateInfo(tyUpdateBean);
                        updateResult.setNext(updateInfo);
                    } else {
                        updateResult.setError(10102112, ResUtils.getString(R.string.generic_latest_version));
                    }
                } else {
                    updateResult.setError(10102112, ResUtils.getString(R.string.generic_latest_version));
                }
            }
        });
    }

}
