package com.ty.bwagent.fragment.finance.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.fragment.finance.bean.FinanceTax;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class FinanceTaxViewModel extends ViewModel {


    //红利月度明细
    public NetLiveData<BaseEntity<List<FinanceTax>>> taxNetLiveData = new NetLiveData<>();

    /**
     * 红利月度明细
     * @param commissionDate
     */
    public void queryPromoList(String commissionDate){
        NetSdk.create(Api.class)
                .queryPromoList()
                .params("commissionDate",commissionDate)
                .asJSONType()
                .send(taxNetLiveData);
    }

}
