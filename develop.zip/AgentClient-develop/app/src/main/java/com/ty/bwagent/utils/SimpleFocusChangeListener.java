package com.ty.bwagent.utils;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SimpleFocusChangeListener implements View.OnFocusChangeListener {

    private TextView tvWarning;
    private EditText etUserName;

    public SimpleFocusChangeListener(TextView tvWarning, EditText etUserName, EditText editText) {
        this.tvWarning = tvWarning;
        this.etUserName = etUserName;
        editText.setOnFocusChangeListener(this);
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        String userName = etUserName.getText().toString().trim();
        if (hasFocus && VerifyUtils.isUserName(userName)) {
            tvWarning.setText("");
        }
    }
}
