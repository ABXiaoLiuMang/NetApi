package com.ty.bwagent.adapter;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.TeamCommissionEntity;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XTextView;
import com.ty.utils.MathUtil;


/**
 * 描述 团队中心 团队财务适配器
 */
public class MemberFinalCommissionAdapter extends BaseQuickAdapter<TeamCommissionEntity.ListBean, BaseViewHolder> {

    private int fragPosition;

    public MemberFinalCommissionAdapter(int fragPosition) {
        super(fragPosition == 1 ? R.layout.recycle_item_member_final : R.layout.recycle_item_member_commission);
        this.fragPosition = fragPosition;
    }

    @Override
    protected void convert(BaseViewHolder helper, TeamCommissionEntity.ListBean item) {
        if (fragPosition == 1) {
            setFinalDate(helper, item);
        } else {
            setCommission(helper, item);
        }

    }

    //团队佣金
    private void setCommission(BaseViewHolder helper, TeamCommissionEntity.ListBean item) {
        try {
            TextView tv_name = helper.getView(R.id.tv_name);//名字
            tv_name.setText(item.getAgentName());
            tv_name.setTypeface(TypefaceUtils.DIN_MEDIUM);

            helper.setVisible(R.id.iv_flag, item.getIsCaptain() == 1);//团队长

            TextView tv_rate = helper.getView(R.id.tv_rate);//佣金比例
            tv_rate.setText(MathUtil.twoNumber(item.getRate() * 100) + "%");
            tv_rate.setTypeface(TypefaceUtils.DIN_MEDIUM);

            TextView tv_subordinateUserCount = helper.getView(R.id.tv_subordinateUserCount);//下级人数
            tv_subordinateUserCount.setText(Utils.fmtMicrometer(item.getSubordinateUserCount() + ""));
            tv_subordinateUserCount.setTypeface(TypefaceUtils.DIN_MEDIUM);

            TextView tv_active = helper.getView(R.id.tv_active);//活跃人数
            tv_active.setText(Utils.fmtMicrometer(item.getActive() + ""));
            tv_active.setTypeface(TypefaceUtils.DIN_MEDIUM);

            XTextView tv_netProfit = helper.getView(R.id.tv_netProfit);//净输赢
            tv_netProfit.setMontyText(item.getNetProfit());

            XTextView tv_czProfit = helper.getView(R.id.tv_czProfit);//冲正后净输赢
            tv_czProfit.setMontyText(item.getCzProfit());

            TextView tv_lastBalance = helper.getView(R.id.tv_lastBalance);//上月结余
            tv_lastBalance.setText(Utils.parsListMoney(item.getLastBalance()));
            tv_lastBalance.setTypeface(TypefaceUtils.DIN_MEDIUM);

            TextView tv_riskAdjust = helper.getView(R.id.tv_riskAdjust);//佣金调整
            tv_riskAdjust.setText(Utils.parsListMoney(item.getCorrection()));
            tv_riskAdjust.setTypeface(TypefaceUtils.DIN_MEDIUM);

            TextView tv_commission = helper.getView(R.id.tv_commission);//佣金
            tv_commission.setText(Utils.parsListMoney(item.getCommission()));
            tv_commission.setTypeface(TypefaceUtils.DIN_MEDIUM);
        } catch (Exception e) {

        }

    }

    //团队财务
    private void setFinalDate(BaseViewHolder helper, TeamCommissionEntity.ListBean item) {

        try {
            TextView tv_name = helper.getView(R.id.tv_name);//名字
            tv_name.setText(item.getAgentName());
            tv_name.setTypeface(TypefaceUtils.DIN_MEDIUM);
            helper.setVisible(R.id.iv_flag, item.getIsCaptain() == 1);//团队长

            TextView tv_deposit = helper.getView(R.id.tv_deposit);//存款
            tv_deposit.setText(Utils.parsListMoney(item.getDeposit()));
            tv_deposit.setTypeface(TypefaceUtils.DIN_MEDIUM);

            TextView tv_draw = helper.getView(R.id.tv_active);//提款
            tv_draw.setText(Utils.parsListMoney(item.getDraw()));
            tv_draw.setTypeface(TypefaceUtils.DIN_MEDIUM);

            TextView tv_promo = helper.getView(R.id.tv_promo);//红利
            tv_promo.setText(Utils.parsListMoney(item.getPromo()));
            tv_promo.setTypeface(TypefaceUtils.DIN_MEDIUM);

            TextView tv_rebate = helper.getView(R.id.tv_rebate);//返水
            tv_rebate.setText(Utils.parsListMoney(item.getRebate()));
            tv_rebate.setTypeface(TypefaceUtils.DIN_MEDIUM);

            XTextView tv_profit = helper.getView(R.id.tv_lastBalance);//总输赢
            tv_profit.setMontyText(item.getProfit());//

            XTextView tv_rate = helper.getView(R.id.tv_netProfit);//净输赢
            tv_rate.setMontyText(item.getNetProfit());//

            TextView tv_commission = helper.getView(R.id.tv_commission);//场馆费
            tv_commission.setText(Utils.parsListMoney(item.getThirdPartySpend()));
            tv_commission.setTypeface(TypefaceUtils.DIN_MEDIUM);
        } catch (Exception e) {

        }
    }


}
