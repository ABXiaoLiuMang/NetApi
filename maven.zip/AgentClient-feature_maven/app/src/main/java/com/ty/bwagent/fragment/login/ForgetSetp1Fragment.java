package com.ty.bwagent.fragment.login;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ForgetPassEntity;
import com.ty.bwagent.bean.ValidateCodeEntity;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.viewmodel.ForgetPassWordViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.util.SingleOnClickListener;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.SpanManager;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

public class ForgetSetp1Fragment extends ABBaseFragment {

    ForgetPassWordViewModel forgetPassWordViewModel;

    ForgetPassEntity passEntity;
    @BindView(R.id.tv_forget_key)
    TextView tvForgetKey;
    @BindView(R.id.tv_forget_value)
    TextView tvForgetValue;
    @BindView(R.id.forget_et_code)
    ClearEditText forgetEtCode;
    @BindView(R.id.forget_tv_code)
    TextView forgetTvCode;
    @BindView(R.id.forget_et_imgcode)
    ClearEditText forgetEtImgcode;
    @BindView(R.id.forget_tv_imgcode)
    ImageView forgetTvImgcode;
    @BindView(R.id.forget_commit)
    TextView forgetCommit;
    @BindView(R.id.forget_custom)
    TextView forgetCustom;
    String code;
    String imgCode;
    boolean timerStart = false;

    public static ForgetSetp1Fragment getInstance(ForgetPassEntity passEntity) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(ABConfig.KEY_OBJECT,passEntity);
        ForgetSetp1Fragment fragment = new ForgetSetp1Fragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_forgetpass_setp1;
    }

    @Override
    protected void createProvider() {
        forgetPassWordViewModel = new ViewModelProvider(this).get(ForgetPassWordViewModel.class);
        //验证码倒计时
        forgetPassWordViewModel.timerLiveData.observe(this, aLong -> {
            if (aLong == 0) {
                timerStart = false;
                forgetTvCode.setText(ResUtils.getString(R.string.generic_reset_code));
                forgetTvCode.setEnabled(true);
            } else {
                timerStart = true;
                forgetTvCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time), aLong));
                forgetTvCode.setEnabled(false);
            }
        });


        /**
         * 获取验证码监听
         */
        forgetPassWordViewModel.sendCodeLiveData.observe(this, new SimpleObserver<BaseEntity>() {

            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ToastUtils.showLong(ResUtils.getString(R.string.generic_has_send));
                MMKVUtil.put(Key.VERIFYTIME,System.currentTimeMillis());
                forgetPassWordViewModel.startTimer(getLifecycle());
            }
        });

        forgetPassWordViewModel.verifyLivedata.observe(this,new SimpleObserver<ValidateCodeEntity>(){
            @Override
            protected void onSuccess(ValidateCodeEntity validateCodeEntity) {
                if(validateCodeEntity != null && validateCodeEntity.getBitmap() != null){
                    forgetEtImgcode.setText("");
                    forgetTvImgcode.setImageBitmap(validateCodeEntity.getBitmap());
                }else {
                    ToastUtils.showLong("网络异常，请重试");
                }
            }

        });

        //邮箱找回密码第二步()
        forgetPassWordViewModel.findTwoLiveData.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                //清空倒计时
                forgetPassWordViewModel.cancelTimer();
                forgetTvCode.setText(ResUtils.getString(R.string.generic_reset_code));
                forgetTvCode.setEnabled(true);

                passEntity.setCode(code)
                        .setImgCode(imgCode);
                start(ForgetSetp2Fragment.getInstance(passEntity));
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
                if(code == 10409){//验证码失效，刷新
                    forgetPassWordViewModel.autoLoadVerify();
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        passEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        SpanManager.callServiceSpan(forgetCustom, ResUtils.getString(R.string.generic_forgetpass_alert), ResUtils.getColor(SiteSdk.ins().styleColor()), "联系客服", new SingleOnClickListener() {
            @Override
            public void onSingleClick(View view) {
                goActivity(OnlineActivity.class);
            }
        });
        initVerify();
        forgetPassWordViewModel.autoLoadVerify();

        long lastTime = MMKVUtil.getLong(Key.VERIFYTIME,0);
        long intervalTime = System.currentTimeMillis() - lastTime;
        if (passEntity.isFromPhone()) {
            if(intervalTime > 60 * 1000){
                forgetPassWordViewModel.sendCode(passEntity.getPhone(),true);
            }else {
                forgetPassWordViewModel.startTimer(getLifecycle(), 60 * 1000 - intervalTime);
            }
            forgetEtCode.setHint(ResUtils.getString(R.string.generic_input_code));
            tvForgetKey.setText(ResUtils.getString(R.string.generic_phone_code_send));
            tvForgetValue.setText(Utils.getHidePhone(passEntity.getPhone()));
        } else {
            if(intervalTime > 60 * 1000){
                forgetPassWordViewModel.sendCode(passEntity.getEmail(),false);
            }else {
                forgetPassWordViewModel.startTimer(getLifecycle(), 60 * 1000 - intervalTime);
            }
            tvForgetKey.setText(ResUtils.getString(R.string.generic_email_code_send));
            tvForgetValue.setText(Utils.getHideEmail(passEntity.getEmail()));
            forgetEtCode.setHint(ResUtils.getString(R.string.generic_input_code1));
        }
    }

    @OnClick({R.id.forget_tv_imgcode, R.id.forget_commit,R.id.forget_tv_code})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.forget_tv_imgcode://刷新图形验证码
                forgetPassWordViewModel.drivingLoadVerify();
                break;
            case R.id.forget_commit://下一步
                String userName = passEntity.getName();
                 code = forgetEtCode.getText().toString().trim();
                 imgCode = forgetEtImgcode.getText().toString().trim();
                if(passEntity.isFromPhone()){
                    String phone = passEntity.getPhone();
                    forgetPassWordViewModel.forgetByPhoneTwo(userName,phone,code,imgCode);
                }else {
                    String email = passEntity.getEmail();
                    forgetPassWordViewModel.forgetByEmailTwo(userName,email,code,imgCode);
                }

                break;
            case R.id.forget_tv_code://重新获取
                if(passEntity.isFromPhone()){
                    forgetPassWordViewModel.sendCode(passEntity.getPhone(),true);
                }else {
                    forgetPassWordViewModel.sendCode(passEntity.getEmail(),false);
                }

                break;
        }
    }

    /**
     * 处理各类输入框验证逻辑
     */
    private void initVerify() {
        new InputResultCalculator(Arrays.asList(forgetEtCode, forgetEtImgcode), ok -> forgetCommit.setEnabled(ok));
    }

}
