package com.ty.bwagent.bean;

/**
 * 个人佣金信息
 */
public class CommissionEntity {

    /**
     * agentMoney : 0.0
     * commissionStatus : 1
     * monthCommission : 0
     * totalCommission : 0
     */

    private double agentMoney;//佣金余额
    private int commissionStatus;//佣金发放状态：0记录；1已发放
    private double monthCommission;//预计可赚取佣金
    private double totalCommission;//累计赚取佣金
    private double rate;//佣金比例
    private int showCommissionRate;//是否显示佣金比例 0展示 1隐藏


    public int getShowCommissionRate() {
        return showCommissionRate;
    }

    public void setShowCommissionRate(int showCommissionRate) {
        this.showCommissionRate = showCommissionRate;
    }

    public double getAgentMoney() {
        return agentMoney;
    }

    public void setAgentMoney(double agentMoney) {
        this.agentMoney = agentMoney;
    }

    public int getCommissionStatus() {
        return commissionStatus;
    }

    public void setCommissionStatus(int commissionStatus) {
        this.commissionStatus = commissionStatus;
    }

    public double getMonthCommission() {
        return monthCommission;
    }

    public void setMonthCommission(double monthCommission) {
        this.monthCommission = monthCommission;
    }

    public double getTotalCommission() {
        return totalCommission;
    }

    public void setTotalCommission(double totalCommission) {
        this.totalCommission = totalCommission;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
}
