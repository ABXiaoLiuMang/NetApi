package com.ty.bwagent.fragment.finance.bean;

/**
 * 描述:
 * <p>
 * author:Dale
 */
public class DrawingRecord {

}
