package com.ty.common.ui;

import android.view.View;

import androidx.lifecycle.LifecycleOwner;

import com.ty.common.view.StateLayout;

public class StateDelegate {

    protected StateLayout stateLayout;
    protected View contentLayout;

    public StateDelegate(IStateLayout layout, LifecycleOwner lifecycleOwner) {
        contentLayout = layout.getContentView();
        this.stateLayout = layout.getStateLayout();
        contentLayout.setVisibility(View.GONE);
        this.stateLayout.setVisibility(View.VISIBLE);
        this.stateLayout.setOnRetryListener(layout);
        this.stateLayout.bindLifecycle(lifecycleOwner);
    }

    public void showLoading() {
        stateLayout.setState(StateLayout.STATE_LOADING);
    }

    public void showNetError() {
        stateLayout.setState(StateLayout.STATE_NET_ERROR);
    }

    public void showEmpty() {
        stateLayout.setState(StateLayout.STATE_EMPTY);
    }

    public void showContent() {
        stateLayout.setVisibility(View.GONE);
        contentLayout.setVisibility(View.VISIBLE);
    }
}
