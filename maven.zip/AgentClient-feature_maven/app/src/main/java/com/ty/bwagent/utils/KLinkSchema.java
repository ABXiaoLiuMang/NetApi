package com.ty.bwagent.utils;

import android.text.TextUtils;

public enum KLinkSchema {
    //http
    Http("http://"),
    //https
    Https("https://"),
    //none
    None(""),
    //相对地址
    Normal("normal");

    private String schema;

    private int jumpType;//0内部跳转  1.打开浏览器
    private int urlType;//0三方地址  1自己的地址

    KLinkSchema(String schema) {
        this.schema = schema;
    }

    public String getSchema() {
        return schema;
    }

    public KLinkSchema setSchema(String schema) {
        this.schema = schema;
        return this;
    }

    /**
     * 是否是内部跳转
     * @return true 内部跳转  false 打开浏览器
     */
    public boolean isInnerJump(){
        return jumpType == 0;
    }

    /**
     * 是否是自己的url地址
     * @return true自己app的url地址 false 第三方的地址
     */
    public boolean isOurUrl() {
        return urlType == 1;
    }

    public KLinkSchema setJumpType(int jumpType) {
        this.jumpType = jumpType;
        return this;
    }
    public KLinkSchema setUrlType(int urlType) {
        this.urlType = urlType;
        return this;
    }

    /**
     * 从link中获取对应的Schema类型
     *
     * @param link 服务器配置的
     * @return Schema类型
     */
    public static KLinkSchema getFromLink(String link) {
        if (TextUtils.isEmpty(link)) {
            return None;
        }

        //tyx://
        for (KLinkSchema linkSchema : values()) {
            if (TextUtils.equals(linkSchema.schema, link)) {
                return linkSchema;
            } else if (link.startsWith("https")) {
                return Https;
            } else if (link.startsWith("http")) {
                return Http;
            } else {
                return Normal;
            }
        }
        //None
        return None;
    }

}
