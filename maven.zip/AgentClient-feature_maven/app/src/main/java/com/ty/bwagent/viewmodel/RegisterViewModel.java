package com.ty.bwagent.viewmodel;

import com.ty.bwagent.R;
import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.Md5Util;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

public class RegisterViewModel extends CodeViewModel {

    //注册
    public NetLiveData<BaseEntity<UserInfo>> registerLiveData = new NetLiveData<>();

    public void register(String userName, String password, String phone, String code) {

        if (!VerifyUtils.isUserName(userName)) {
            registerLiveData.setError(0, ResUtils.getString(R.string.generic_username_warn));
            return;
        }

        if (!VerifyUtils.isUserPassWord(password)) {
            registerLiveData.setError(0, ResUtils.getString(R.string.generic_password_warn));
            return;
        }

        if (StringUtils.length(phone) < 11) {
            registerLiveData.setError(0, ResUtils.getString(R.string.generic_phone_warn));
            return;
        }

        if (!ParameterVerification.isPhoneNumber(phone)) {
            registerLiveData.setError(0, ResUtils.getString(R.string.phone_input_err));
            return;
        }

        if (!VerifyUtils.isCode(code)) {
            registerLiveData.setError(0, ResUtils.getString(R.string.generic_code_warn));
           return;
        }

        NetSdk.create(Api.class)
                .register()
                .params("password",Md5Util.md5(password))
                .params("phone",phone)
                .params("name",userName)
                .params("phoneCode",code)
                .params("iCode","")
                .asJSONType()
                .send(registerLiveData);

    }

}
