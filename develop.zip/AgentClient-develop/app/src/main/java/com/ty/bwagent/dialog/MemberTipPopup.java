package com.ty.bwagent.dialog;

import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.DialogTextHeightChangeShow;

public class MemberTipPopup extends ConfirmPopupView {

    public MemberTipPopup(@NonNull Context context) {
        super(context);

    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_member_center;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        tv_content.setMovementMethod(ScrollingMovementMethod.getInstance());
        tv_content.setScrollbarFadingEnabled(true);

        TextView contentView = getContentTextView();
        String trim = contentView.getText().toString().trim();
        LinearLayout ll_main = findViewById(R.id.ll_main);
        DialogTextHeightChangeShow dialogTextHeightChangeShow = new DialogTextHeightChangeShow(ll_main, contentView, 4.5);
        dialogTextHeightChangeShow.setTextHeight(trim);
    }

    @Override
    protected void onShow() {
        super.onShow();
        MainActivity.isDialogShow = true;
    }

    @Override
    protected void onDismiss() {
        super.onDismiss();
        MainActivity.isDialogShow = false;
    }
}
