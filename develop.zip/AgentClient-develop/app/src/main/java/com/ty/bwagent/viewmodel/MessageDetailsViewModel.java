package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

public class MessageDetailsViewModel extends ViewModel {

    // 删除一条通知消息
    public NetLiveData<BaseEntity> deleteLiveData = new NetLiveData<>();

    /**
     * 消息id 批量处理多个id用逗号隔开
     * @param id 消息id
     */
    public void msgDelete(String id) {
        NetSdk.create(Api.class)
                .msgDelete()
                .params("id",id)
                .asJSONType()
                .send(deleteLiveData);
    }
}
