package com.ty.bwagent.fragment.login;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.widget.ImageView;

import com.ty.bwagent.R;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 火狐注册
 */
public class RegisterHuohuFragment extends RegisterFragment {

    @BindView(R.id.register_et_qq)
    ClearEditText registerEtQq;
    @BindView(R.id.register_et_email)
    ClearEditText registerEtEmail;
    String userQQ;
    String userEmail;
    @BindView(R.id.register_et_confirmpassword)
    ClearEditText registerEtConfirmpassword;
    @BindView(R.id.register_eye_confirmpass)
    ImageView registerEyeConfirmpass;

    public static RegisterHuohuFragment getInstance() {
        return new RegisterHuohuFragment();
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_register_huohu;
    }


    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
    }

    /**
     * 注册提交
     */
    @Override
    protected void registerCommit() {
        String confirmPassWord = registerEtConfirmpassword.getText().toString().trim();
        userName = registerEtUsername.getText().toString().trim();
        passWord = registerEtPassword.getText().toString().trim();
        phone = registerEtPhone.getText().toString().trim();
        userQQ = registerEtQq.getText().toString().trim();
        userEmail = registerEtEmail.getText().toString().trim();
        String code = registerEtCode.getText().toString().trim();
        if(!StringUtils.equals(confirmPassWord,passWord)){
            ToastUtils.showLong("两次密码输入不一致");
            return;
        }
        registerTvWarning.setText("");
        registerViewMoel.registerByHuohu(userName, passWord, phone, code, userQQ, userEmail);
    }

    /**
     * 提交按钮可点击状态监听
     */
    @Override
    protected void initCommitEnabled() {
        new InputResultCalculator(Arrays.asList(registerEtUsername, registerEtPassword, registerEtConfirmpassword,registerEtPhone, registerEtCode, registerEtQq), ok -> {
            String userName = registerEtUsername.getText().toString().trim();
            if (VerifyUtils.isUserName(userName)) {
                registerCommit.setEnabled(ok);
            } else {
                registerCommit.setEnabled(false);
            }
        });
    }

    private void showHideConfirmPassWord() {
        TransformationMethod type = registerEtConfirmpassword.getTransformationMethod();
        if (PasswordTransformationMethod.getInstance().equals(type)) {
            registerEtConfirmpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            registerEyeConfirmpass.setImageResource(R.mipmap.login_eye_show_bg);
        } else {
            registerEtConfirmpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            registerEyeConfirmpass.setImageResource(R.mipmap.login_eye_hide_bg);
        }
        registerEtConfirmpassword.setSelection(registerEtConfirmpassword.getText().toString().length());
    }

    @OnClick(R.id.register_eye_confirmpass)
    public void onViewClicked() {
        showHideConfirmPassWord();
    }
}
