package com.ty.bwagent.viewmodel;

import com.ty.bwagent.R;
import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.BindInfoEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

public class BindPhoneViewModel extends CodeViewModel {


    /**
     * 绑定结果
     */
    public NetLiveData<BaseEntity<BindInfoEntity>> bindLiveData = new NetLiveData<>();

    /**
     * 绑定电话
     *
     * @param phone
     */
    public void bindPhone(String phone, String code) {
        if (!ParameterVerification.isPhoneNumber(phone)) {
            bindLiveData.postError(0, ResUtils.getString(R.string.phone_input_err));
            return;
        }

        if (!StringUtils.isEmpty(code) && StringUtils.length(code) < 4) {
            bindLiveData.postError(0, ResUtils.getString(R.string.code_input_err));
            return;
        }


        NetSdk.create(Api.class)
                .bindPhone()
                .params("code", code)
                .params("phone", phone)
                .asJSONType()
                .send(bindLiveData);
    }

}
