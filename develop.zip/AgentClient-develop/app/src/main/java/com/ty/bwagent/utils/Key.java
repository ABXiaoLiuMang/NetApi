package com.ty.bwagent.utils;

public class Key extends com.ty.constant.Key{

    public static final String LOGIN_TOKEN = "login_token";//缓存登录token key
    public static final String AGENT_TOKEN = "agent_token";//缓存登录token key
    public static final String INVITE_CODE = "invite_code";//缓存登录邀请码
    public static final String IS_USER_LOGIN = "isLogin";//缓存是否登录
    public static final String SYSTYPE = "sysType";//缓存登录 是否是管代
    public static final String LOGIN_PHONE = "login_phone";//缓存登录电话

    public static String appkey = "2ZYAq3AVZL";
    public static String secret = "sdlXM5uNbBiWbpjA";

    /**
     * 测试环境bugly id
     */
    public static String BUGLY_ID_DEBUG = "b6fb263966";

    /**
     * 正式环境BuglyId
     */
    public static String BUGLY_ID_PRODUCT = "aa189d1900";

    //听云测试key
    public static String TING_YUN_KEY_DEBUG = "6e597f8f0c884a6ca6c425b5dca2334e";

    //听云正式key
    public static String TING_YUN_KEY_PRODUCT = "aeeff7b8d3d34c1ab9bc79cc8adda5a1";

    /**
     *正式版
     */
    public transient static final String RELEASE = "release";

    /**
     *正式https版本
     */
    public transient static final String HTTPS_RELEASE = "https_release";

}
