package com.ty.bwagent.fragment.finance.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.fragment.finance.bean.FinanceTotal;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class FinanceTotalViewModel extends ViewModel {

    //总输赢/场馆费月度明细
    public NetLiveData<BaseEntity<List<FinanceTotal>>> totalNetLiveData = new NetLiveData<>();

    /**
     * 总输赢/场馆费月度明细
     * @param commissionDate
     */
    public void queryProfitDetail(String commissionDate){
        NetSdk.create(Api.class)
                .queryProfitDetail()
                .params("commissionDate",commissionDate)
                .asJSONType()
                .send(totalNetLiveData);
    }

}
