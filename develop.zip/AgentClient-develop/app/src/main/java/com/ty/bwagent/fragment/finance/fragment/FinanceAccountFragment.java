package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.fragment.finance.adapter.FinanceAccountAdapter;
import com.ty.bwagent.fragment.finance.bean.FinanceAccount;
import com.ty.bwagent.fragment.finance.viewmodel.FinanceAccountiewModel;
import com.ty.bwagent.utils.Utils;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.SimpleObserver;

import java.util.List;

/**
 * 月度详细-账户调整
 */

public class FinanceAccountFragment extends ABRefreshFragment<FinanceAccount> {

    FinanceAccountiewModel mFinanceAccountiewModel;

    LinearLayout title_layout;//顶部标题布局
    TextView tv_month;//查询月份
    TextView account_total;//账户调整
    TextView month_text;//月度明细月份
    FinanceEntity financeEntity;//佣金明细对象
    private LinearLayout ll_net;

    public static FinanceAccountFragment getInstance(Bundle bundle) {
        FinanceAccountFragment fragment = new FinanceAccountFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_details;
    }

    @Override
    protected void createProvider() {
        mFinanceAccountiewModel = new ViewModelProvider(this).get(FinanceAccountiewModel.class);
        mFinanceAccountiewModel.accountNetLiveData.observe(this,new SimpleObserver<BaseEntity<List<FinanceAccount>>>(){

            @Override
            protected void onSuccess(BaseEntity<List<FinanceAccount>> listBaseEntity) {
                ll_net.setVisibility(View.GONE);
                if(listBaseEntity.getData().size() > 0){
                    title_layout.setVisibility(View.VISIBLE);
                }else {
                    title_layout.setVisibility(View.GONE);
                }
                listAdapter.setNewData(listBaseEntity.getData());
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                ll_net.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();

        ll_net = rootView.findViewById(R.id.ll_net);
        TextView bnt_nonet = rootView.findViewById(R.id.bnt_nonet);

        financeEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        String startData = bundle.getString(ABConfig.KEY_TAG);
        mFinanceAccountiewModel.queryAdjustList(startData);
        tv_month.setText(startData);
        month_text.setText(startData);
        account_total.setText(Utils.roundDownMoney(financeEntity.getRiskAdjust()));

        bnt_nonet.setOnClickListener(v -> mFinanceAccountiewModel.queryAdjustList(startData));

    }


    @Override
    public int getMode() {
        return Mode.DISABLED;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public View getHeaderView() {
        View header = View.inflate(mContext, R.layout.header_finance_account,null);
        title_layout = header.findViewById(R.id.title_layout);
        tv_month = header.findViewById(R.id.tv_month);
        account_total = header.findViewById(R.id.account_total);
        month_text = header.findViewById(R.id.month_text);
        return header;
    }


    @Override
    public BaseQuickAdapter<FinanceAccount, BaseViewHolder> getListAdapter() {
        return new FinanceAccountAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//        FinanceAccount mFinanceAccount = (FinanceAccount) adapter.getItem(position);
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
    }


}
