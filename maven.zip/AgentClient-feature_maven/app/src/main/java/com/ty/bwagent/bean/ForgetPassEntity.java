package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class ForgetPassEntity implements Parcelable {
    String name;//用户名
    String phone;//电话
    String code;//验证码
    String imgCode;//图形验证码
    String email;//邮箱
    String password;//密码
    boolean fromPhone;//true：电话找回跳过来 false:邮箱过来

    public ForgetPassEntity() {
    }

    protected ForgetPassEntity(Parcel in) {
        name = in.readString();
        phone = in.readString();
        code = in.readString();
        imgCode = in.readString();
        email = in.readString();
        password = in.readString();
        fromPhone = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(password);
        dest.writeString(phone);
        dest.writeString(code);
        dest.writeString(imgCode);
        dest.writeString(email);
        dest.writeByte((byte) (fromPhone ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ForgetPassEntity> CREATOR = new Creator<ForgetPassEntity>() {
        @Override
        public ForgetPassEntity createFromParcel(Parcel in) {
            return new ForgetPassEntity(in);
        }

        @Override
        public ForgetPassEntity[] newArray(int size) {
            return new ForgetPassEntity[size];
        }
    };

    public String getName() {
        return name;
    }

    public ForgetPassEntity setName(String name) {
        this.name = name;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public ForgetPassEntity setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    public String getCode() {
        return code;
    }

    public ForgetPassEntity setCode(String code) {
        this.code = code;
        return this;
    }

    public String getImgCode() {
        return imgCode;
    }

    public ForgetPassEntity setImgCode(String imgCode) {
        this.imgCode = imgCode;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public ForgetPassEntity setEmail(String email) {
        this.email = email;
        return this;
    }

    public boolean isFromPhone() {
        return fromPhone;
    }

    public ForgetPassEntity setFromPhone(boolean fromPhone) {
        this.fromPhone = fromPhone;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public ForgetPassEntity setPassword(String password) {
        this.password = password;
        return this;
    }

    @Override
    public String toString() {
        return "ForgetPassEntity{" +
                "name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", code='" + code + '\'' +
                ", imgCode='" + imgCode + '\'' +
                ", email='" + email + '\'' +
                ", fromPhone=" + fromPhone +
                '}';
    }
}
