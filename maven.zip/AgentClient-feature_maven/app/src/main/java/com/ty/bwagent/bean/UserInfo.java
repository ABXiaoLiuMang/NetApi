package com.ty.bwagent.bean;

import com.ty.utils.StringUtils;

public class UserInfo {


    /**
     * address :
     * avatar : http://img.bwhou2020.com/1576480523173011.png
     * birthday : null
     * createdAt : null
     * email :
     * firstLogin : 1
     * gameUrl :
     * id : 92019187943
     * inviteCode : 9728795
     * lastLoginIp :
     * name : dale369
     * nickName :
     * phone : 13545565652
     * qq :
     * realName :
     * registerIp : 172.16.172.68
     * sex : null
     * status : 1
     * sysType : 0
     * tagId :
     * token : DL_da5fe0c97d424e97b1ca76d6e12c04a6
     * topId : 0
     * updatedAt : null
     * wechat :
     */

    private String address;
    private String avatar;
    private String birthday;
    private String createdAt;
    private String email;
    private int firstLogin;
    private String gameUrl;
    private long id;
    private String inviteCode;
    private String lastLoginIp;
    private String name;
    private String nickName;
    private String phone;
    private String qq;
    private String realName;
    private String registerIp;
    private String sex;
    private int status;
    private int sysType;//代理类型：0 普通代理 1 官方代理
    private String tagId;
    private String token;
    private int topId;
    private String updatedAt;
    private String wechat;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getEmail() {
        if(!StringUtils.isEmpty(email) && StringUtils.length(email) > 3){
            return email.substring(0, 3) + "****" + email.substring(email.indexOf("@"));
        }
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getFirstLogin() {
        return firstLogin;
    }

    public void setFirstLogin(int firstLogin) {
        this.firstLogin = firstLogin;
    }

    public String getGameUrl() {
        return gameUrl;
    }

    public void setGameUrl(String gameUrl) {
        this.gameUrl = gameUrl;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getInviteCode() {
        return inviteCode;
    }

    public void setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode;
    }

    public String getLastLoginIp() {
        return lastLoginIp;
    }

    public void setLastLoginIp(String lastLoginIp) {
        this.lastLoginIp = lastLoginIp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPhone() {
        if(!StringUtils.isEmpty(phone) && StringUtils.length(phone) == 11){
            return phone.substring(0, 3) + "****" + phone.substring(7);
        }
        return phone;
    }

    /**
     * 未脱敏的真实电话号码
     * @return
     */
    public String getRealPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getRegisterIp() {
        return registerIp;
    }

    public void setRegisterIp(String registerIp) {
        this.registerIp = registerIp;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getSysType() {
        return sysType;
    }

    public void setSysType(int sysType) {
        this.sysType = sysType;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getTopId() {
        return topId;
    }

    public void setTopId(int topId) {
        this.topId = topId;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getWechat() {
        return wechat;
    }

    public void setWechat(String wechat) {
        this.wechat = wechat;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "address='" + address + '\'' +
                ", avatar='" + avatar + '\'' +
                ", birthday='" + birthday + '\'' +
                ", createdAt='" + createdAt + '\'' +
                ", email='" + email + '\'' +
                ", firstLogin=" + firstLogin +
                ", gameUrl='" + gameUrl + '\'' +
                ", id=" + id +
                ", inviteCode='" + inviteCode + '\'' +
                ", lastLoginIp='" + lastLoginIp + '\'' +
                ", name='" + name + '\'' +
                ", nickName='" + nickName + '\'' +
                ", phone='" + phone + '\'' +
                ", qq='" + qq + '\'' +
                ", realName='" + realName + '\'' +
                ", registerIp='" + registerIp + '\'' +
                ", sex='" + sex + '\'' +
                ", status=" + status +
                ", sysType=" + sysType +
                ", tagId='" + tagId + '\'' +
                ", token='" + token + '\'' +
                ", topId=" + topId +
                ", updatedAt='" + updatedAt + '\'' +
                ", wechat='" + wechat + '\'' +
                '}';
    }
}
