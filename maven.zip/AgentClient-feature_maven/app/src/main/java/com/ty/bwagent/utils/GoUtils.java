package com.ty.bwagent.utils;

import android.content.Intent;

import androidx.fragment.app.FragmentActivity;

import com.ty.bwagent.App;
import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.ui.LoginActivity;
import com.ty.bwagent.ui.MainActivity;
import com.ty.utils.ExitUtils;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;

import java.util.Date;

public class GoUtils {


    public static void checkSwitch(FragmentActivity activity) {
        /**
         * 初始化用户名密码（已经登录过,14天内免登陆逻辑处理）
         * 超过14天，清除密码手动登录
         */
        String userName = MMKVUtil.getString(CacheKey.USER_NAME);
        String passWord = MMKVUtil.getString(CacheKey.USER_PASSWORD);
        boolean isRemember = MMKVUtil.getBoolean(CacheKey.REMEMBER_PASSWORD);
        String token = MMKVUtil.getString(Key.LOGIN_TOKEN);
        String phone = MMKVUtil.getString(Key.LOGIN_PHONE);//登录用户的电话
        int sysType = MMKVUtil.getInt(Key.SYSTYPE);//代理类型：0 普通代理 1 官方代理

        LogUtils.d("checkSwitch siteIdKey:" + MMKVUtil.getString(Key.SITEIDKEY, BuildConfig.appType)
                + "  userName:" + userName + "  passWord:" + passWord + " token:" + token);


        if (!StringUtils.isEmpty(passWord) && !StringUtils.isEmpty(userName) && !StringUtils.isEmpty(token)) {
            Date endDay = TimeUtils.millis2Date(MMKVUtil.getLong(CacheKey.USER_LOGIN_TIME, 0));//上次登录时间
            int intervalDay = TimeUtils.getIntervalDays2(new Date(), endDay);//间隔天数
            LogUtils.d("登录间隔天数:" + intervalDay);
            if (intervalDay < 14 && isRemember) {
                if(sysType == 0 && StringUtils.isEmpty(phone)){//普通代理判断并且没有绑定电话
                    activity. startActivity(new Intent(activity, LoginActivity.class));
                    activity.finish();
                }else {
                    MainActivity.startMainActiviy(true);
                    activity.finish();
                }
            } else {
                activity. startActivity(new Intent(activity, LoginActivity.class));
                activity.finish();
            }
        } else {
            activity. startActivity(new Intent(activity, LoginActivity.class));
            activity.finish();
        }
    }
}
