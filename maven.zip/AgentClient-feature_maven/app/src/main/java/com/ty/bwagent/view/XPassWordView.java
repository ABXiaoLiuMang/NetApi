package com.ty.bwagent.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.ty.bwagent.R;
import com.ty.utils.SizeUtils;
import com.ty.view.ClearEditText;

/**
 * 密码输入框封装
 */
public class XPassWordView extends ConstraintLayout{

    Context mContext;
    String key_text;
    String intput_hint;
    ClearEditText et_pass;
    TextView tv_key;
    ImageView iv_eye;

    public XPassWordView(Context context) {
        this(context, null);
    }

    public XPassWordView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public XPassWordView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        TypedArray mTypedArray = mContext.obtainStyledAttributes(attrs, R.styleable.XPassWordView);
        key_text = mTypedArray.getString(R.styleable.XPassWordView_key_text);
        intput_hint = mTypedArray.getString(R.styleable.XPassWordView_intput_hint);
        mTypedArray.recycle();
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setPadding(SizeUtils.dp2px(14),0,SizeUtils.dp2px(14),0);
        View view = LayoutInflater.from(mContext).inflate(R.layout.x_password_view, this, true);
        tv_key = view.findViewById(R.id.tv_key);
        et_pass = view.findViewById(R.id.et_pass);
        iv_eye = view.findViewById(R.id.iv_eye);

        if(!TextUtils.isEmpty(key_text)){
            tv_key.setText(key_text);
        }
        if(!TextUtils.isEmpty(intput_hint)){
            et_pass.setHint(intput_hint);
        }

        iv_eye.setOnClickListener(v -> showHidePassWord());
    }

    private void showHidePassWord(){
        TransformationMethod type= et_pass.getTransformationMethod();
        if (PasswordTransformationMethod.getInstance().equals(type)){
            et_pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            iv_eye.setImageResource(R.mipmap.login_eye_show_bg);
        }else {
            et_pass.setTransformationMethod(PasswordTransformationMethod.getInstance());
            iv_eye.setImageResource(R.mipmap.login_eye_hide_bg);
        }
        int length = et_pass.getText().toString().length();
        et_pass.setSelection(length);
    }

    public ClearEditText getPassEditText() {
        return et_pass;
    }

    public String getPassText() {
        return et_pass.getText().toString().trim();
    }
}
