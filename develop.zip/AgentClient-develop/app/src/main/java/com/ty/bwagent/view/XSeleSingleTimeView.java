package com.ty.bwagent.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.ty.bwagent.R;
import com.ty.pickerview.builder.TimePickerBuilder;
import com.ty.pickerview.view.TimePickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;

import java.util.Calendar;
import java.util.Date;

/**
 * 又是一个数据的弹窗MMP
 * 佣金中时间（年月）选择封装
 */
public class XSeleSingleTimeView extends LinearLayout implements View.OnClickListener {

    Context mContext;
    TextView start_time;
    TextView search;
    String month;//当前选中月份
    OnSearchListener onSearchListener;

    //12个月
    public XSeleSingleTimeView(Context context) {
        this(context, null);
    }

    public XSeleSingleTimeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public XSeleSingleTimeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
    }

    public void setOnSearchListener(OnSearchListener onSearchListener) {
        this.onSearchListener = onSearchListener;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setOrientation(LinearLayout.HORIZONTAL);
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.x_select_single_layout, this, true);
        start_time = rootView.findViewById(R.id.start_time);
        search = rootView.findViewById(R.id.search);
        start_time.setOnClickListener(this);
        search.setOnClickListener(this);
        month = TimeUtils.getDiffMonth(0);
        start_time.setText(month);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search:
                if (StringUtils.isEmpty(month)) {
                    ToastUtils.showLong("请选择开始时间");
                    return;
                }
                if (onSearchListener != null) {
                    onSearchListener.onSearch(month);
                }
                break;
            case R.id.start_time:
                showStartPickerDialog();
                break;
        }
    }

    public interface OnSearchListener {
        void onSearch(String month);
    }

    TimePickerView timeStartPickerView;

    private void showStartPickerDialog() {
        if (timeStartPickerView == null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            timeStartPickerView = new TimePickerBuilder(getContext(), (date, v) -> {
                month = TimeUtils.DATE_FORMAT_MM.format(date);
                start_time.setText(month);

            }).setSubmitText("确定")
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setSubmitColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setDate(calendar)
                    .setTitleText("")
                    .setType(new boolean[]{true, true, false, false, false, false})
                    .build();
        }

        timeStartPickerView.show();
    }

    public void onReset() {
        timeStartPickerView = null;
        month = TimeUtils.getDiffMonth(0);
        start_time.setText(month);
    }

}
