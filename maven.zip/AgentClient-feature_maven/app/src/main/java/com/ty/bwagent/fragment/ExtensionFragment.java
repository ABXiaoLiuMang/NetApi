package com.ty.bwagent.fragment;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.lxj.xpopup.XPopup;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.ExtensionAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ExtensionEntity;
import com.ty.bwagent.dialog.SharePopup;
import com.ty.bwagent.viewmodel.ExtensionModel;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.constant.PermissionConstants;
import com.ty.net.callback.NetObserver;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;

import java.util.List;

/**
 * 推广item
 */
public class ExtensionFragment extends ABRefreshFragment<ExtensionEntity> {

    ExtensionModel mExtensionModel;
    String clientType;
    String title;

    public static ExtensionFragment getInstance(Bundle bundle) {
        ExtensionFragment fragment = new ExtensionFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void createProvider() {
        mExtensionModel = new ViewModelProvider(this).get(ExtensionModel.class);
        //监听推广列表数据
        mExtensionModel.entityNetLiveData.observe(this,new NetObserver<BaseEntity<List<ExtensionEntity>>>(){
            @Override
            protected void onSuccess(BaseEntity<List<ExtensionEntity>> listBaseEntity) {
                List<ExtensionEntity> entityList = listBaseEntity.getData();
                listAdapter.setNewData(entityList);
                refreshLayout.setVisibility(View.VISIBLE);
                refreshLayout.finishRefresh();
                dismissProgressDialog();
            }

            @Override
            protected void onError(int code, String errMsg) {
                refreshLayout.setVisibility(View.VISIBLE);
                dismissProgressDialog();
                refreshLayout.finishRefresh(false);
            }

        });
    }

    @Override
    protected int getLayoutId() {
        return R.layout.x_refresh;
    }

    @Override
    protected void initViewsAndEvents() {
        clientType = bundle.getString(ABConfig.KEY_TEXT);
        title = bundle.getString(ABConfig.KEY_TITLE);
        super.initViewsAndEvents();
        refreshLayout.setVisibility(View.GONE);
    }

    boolean loadData = false;
    @Override
    public void onResume() {
        super.onResume();
        if(!loadData){
            showProgressDialog();
            mExtensionModel.domainByClientType(clientType);
            loadData = true;
        }
    }


    @Override
    public View getEmptyView() {
        return View.inflate(mContext, R.layout.empty_extension, null);
    }

    @Override
    public int getMode() {
        return Mode.PULL_FROM_START;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public BaseQuickAdapter<ExtensionEntity, BaseViewHolder> getListAdapter() {
        return new ExtensionAdapter(title);
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        ExtensionEntity mExtensionEntity = (ExtensionEntity) adapter.getItem(position);
        showNoticeDialog(mExtensionEntity);
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {

    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        mExtensionModel.domainByClientType(clientType);
    }

    private void showNoticeDialog(ExtensionEntity mExtensionEntity){
        SharePopup sharePopup = new SharePopup(mContext,mExtensionEntity);
        new XPopup.Builder(mContext)
                .asCustom(sharePopup)
                .show();
    }

}
