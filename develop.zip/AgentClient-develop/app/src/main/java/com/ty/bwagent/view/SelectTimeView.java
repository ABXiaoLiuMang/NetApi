package com.ty.bwagent.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.pickerview.builder.TimePickerBuilder;
import com.ty.pickerview.view.TimePickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import androidx.annotation.Nullable;

/**
 * 只选择年月（和选择年月日分开MMP）
 * 佣金中时间（年月）选择封装
 */
public class SelectTimeView extends LinearLayout implements View.OnClickListener {

    Context mContext;
    public TextView start_time;
    public TextView end_time;
    String startTime = "";
    String endTime = "";
    int interval;//可筛选的间隔的月份 默认12个月

    public SelectTimeView(Context context) {
        this(context, null);
    }

    public SelectTimeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SelectTimeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        TypedArray mTypedArray = mContext.obtainStyledAttributes(attrs, R.styleable.selectTimeView);
        interval = mTypedArray.getInt(R.styleable.selectTimeView_interval, 11);
        mTypedArray.recycle();
    }


    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setOrientation(LinearLayout.HORIZONTAL);
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.layout_select_time, this, true);
        start_time = rootView.findViewById(R.id.start_time);
        end_time = rootView.findViewById(R.id.end_time);
        start_time.setOnClickListener(this);
        end_time.setOnClickListener(this);

        start_time.setText("开始时间");
        end_time.setText("结束时间");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start_time:
                showStartPickerDialog();
                break;
            case R.id.end_time:
                showEndPickerDialog();
                break;
        }
    }


    TimePickerView timeStartPickerView;

    private void showStartPickerDialog() {
        KeyboardUtils.hideSoftInput(this);

        if (timeStartPickerView == null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            timeStartPickerView = new TimePickerBuilder(getContext(), (date, v) -> {
                String stime = TimeUtils.DATE_FORMAT_DATE.format(date);
//                if (daysBetween(stime, endTime)) {
                startTime = stime;
                start_time.setText(startTime);
//                }
            }).setSubmitText("确定")
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setSubmitColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setDate(calendar)
                    .setTitleText("")
                    .setType(new boolean[]{true, true, true, false, false, false})
                    .build();
        }

        timeStartPickerView.show();
    }

    TimePickerView timeEndPickerView;

    private void showEndPickerDialog() {
        KeyboardUtils.hideSoftInput(this);

        if (timeEndPickerView == null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            timeEndPickerView = new TimePickerBuilder(getContext(), (date, v) -> {
                String eTime = TimeUtils.DATE_FORMAT_DATE.format(date);
//                if (daysBetween(startTime, eTime)) {
                endTime = eTime;
                end_time.setText(endTime);
//                }
            }).setSubmitText("确定")
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setSubmitColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setDate(calendar)
                    .setTitleText("")
                    .setType(new boolean[]{true, true, true, false, false, false})
                    .build();
        }

        timeEndPickerView.show();
    }


    public boolean daysBetween(String sTime, String eTime) {
        try {
            Date smdate = TimeUtils.DATE_FORMAT_DATE.parse(sTime);
            Date bdate = TimeUtils.DATE_FORMAT_DATE.parse(eTime);
            int between_days = TimeUtils.getIntervalDays2(bdate, smdate);
            if (between_days < 0) {
                return false;
            }
        } catch (ParseException e) {
            return true;
        }
        return true;
    }

    public void setInitTime(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        if (timeEndPickerView != null) {
            timeEndPickerView.setDate(calendar);
        }
        if (timeStartPickerView != null) {
            timeStartPickerView.setDate(calendar);
        }
        start_time.setText(TimeUtils.toString(date, "yyyy-MM-dd"));
        end_time.setText(TimeUtils.toString(date, "yyyy-MM-dd"));
    }

    public void onReset() {
        timeStartPickerView = null;
        timeEndPickerView = null;
        startTime = "";//初始化时间，默认7个月这里传 -6
        endTime = "";
        start_time.setText("开始时间");
        end_time.setText("结束时间");
    }


    //获取开时时间
    public String getStartTime() {
        return StringUtils.isEmpty(startTime) ? "" : startTime;
    }

    //获取开时时间
    public String getEndTime() {
        return StringUtils.isEmpty(endTime) ? "" : endTime;
    }


}
