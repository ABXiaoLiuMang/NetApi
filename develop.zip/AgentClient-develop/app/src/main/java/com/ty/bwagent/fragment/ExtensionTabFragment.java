package com.ty.bwagent.fragment;


import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;
import butterknife.BindView;

import com.tencent.bugly.proguard.v;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.CategoriesType;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.bean.DictTypeEntity;
import com.ty.bwagent.dialog.SelectDialogItemPopup;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.ExtensionUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.viewmodel.ExtensionModel;
import com.ty.bwagent.viewmodel.HomeViewModel;
import com.ty.common.util.ABConfig;
import com.ty.common.view.magicindicator.ViewPagerHelper;
import com.ty.common.view.magicindicator.buildins.commonnavigator.CommonNavigator;
import com.ty.net.callback.NetObserver;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 推广主界面
 */
public class ExtensionTabFragment extends BaseViewPagerFragment {

    private HomeViewModel mHomeViewModel;
    private ArrayList<CategoriesType> categoriesTypes;
    private ExtensionModel mExtensionModel;

    @BindView(R.id.ll_net)
    LinearLayout ll_net;
    @BindView(R.id.bnt_nonet)
    TextView bnt_nonet;

    @Override
    public boolean isNeedIniteIndicatoer() {
        return false;
    }

    public static ExtensionTabFragment getInstance() {
        return new ExtensionTabFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_extension_tab;
    }

    @Override
    protected void createProvider() {
        mHomeViewModel = new ViewModelProvider(getParentFragment()).get(HomeViewModel.class);
        mExtensionModel = new ViewModelProvider(this).get(ExtensionModel.class);

        //关于数据 是否显示火狐的域名
        mHomeViewModel.contactUsLiveData.observe(this, new NetObserver<BaseEntity<ContactUsEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<ContactUsEntity> entity) {
                if (categoriesTypes != null) {//防止多次请求后 会导致内存泄漏
                    return;
                }
                ll_net.setVisibility(View.GONE);
                categoriesTypes = ExtensionUtils.getCategoriesType(entity);
                tabTitles = getTabTitles();
                initMagicIndicator();
            }

            @Override
            protected void onLoading(boolean show) {
                super.onLoading(show);
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ll_net.setVisibility(View.VISIBLE);
                ToastUtils.showLong(errMsg);
            }
        });


        //这里有H5类型接口请求返回
        mExtensionModel.dictTypeH5NetLiveData.observe(this, new NetObserver<BaseEntity<List<DictTypeEntity>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<DictTypeEntity>> dictTypeEntities) {
                addDictType(dictTypeEntities);
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
            }
        });

        //这里有web接口请求返回
        mExtensionModel.dictTypeWebNetLiveData.observe(this, new NetObserver<BaseEntity<List<DictTypeEntity>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<DictTypeEntity>> dictTypeEntities) {
                addDictType(dictTypeEntities);
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
            }
        });

    }


    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();

        typeBackTime = 0;
        mExtensionModel.dictTypeQuery(1, mExtensionModel.dictTypeH5NetLiveData);
        mExtensionModel.dictTypeQuery(2, mExtensionModel.dictTypeWebNetLiveData);
        mHomeViewModel.contactUs();

        titleBar.setShowRight(View.INVISIBLE);
        titleBar.setRightOnClickListener(view -> showFilterDialog());
        bnt_nonet.setOnClickListener(v -> {
            if (!DoubleClickUtils.isDoubleClick3S()) {
                mHomeViewModel.contactUs();
            }
        });
    }

    @Override
    protected void initMagicIndicator() {
        super.initMagicIndicator();
        initListener();
        viewPager.setOffscreenPageLimit(tabTitles.length);
    }


    private void initListener() {
        viewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position) {
                    case 1:
                        titleBar.setShowRight(View.VISIBLE);//先隐藏 后面改需求再打开
                        break;
                    default:
                        titleBar.setShowRight(View.INVISIBLE);
                }
            }
        });

    }

    @Override
    public String[] getTabTitles() {
        if (categoriesTypes != null) {
            return ExtensionUtils.getTitle(categoriesTypes);
        } else {
            return new String[0];
        }
    }

    @Override
    protected boolean getAdjustMode() {
        if (tabTitles.length >= 5) {
            return false;
        } else {
            return true;
        }
    }


    private List<DictTypeEntity> stateList = new ArrayList<>();
    private String searchDate;
    private boolean isFromClickTitle = false;

    //筛选回调
    private void showFilterDialog() {

        if (typeBackTime == 2) {
            isFromClickTitle = false;
            List<String> states = new ArrayList<>();
            for (int i = 0; i < stateList.size(); i++) {
                states.add(stateList.get(i).getDictValue());
            }
            states.add(0, "全部");
            DialogUtil.createSelectItemDailog(mContext, new SelectDialogItemPopup.Builder().setTitle("专属域名类型")
                    .setBtnSubmit("完成")
                    .setDateList(states).setHasShadowBg(true).setSelectName(searchDate).setOnClickListener(currentItem -> {
                        searchDate = states.get(currentItem);
                        mExtensionModel.typeChangeUpNetLiveData.postValue(searchDate);
                    })
            );
        } else {
            typeBackTime = 0;
            stateList.clear();
            isFromClickTitle = true;
            mExtensionModel.dictTypeQuery(1, mExtensionModel.dictTypeH5NetLiveData);
            mExtensionModel.dictTypeQuery(2, mExtensionModel.dictTypeWebNetLiveData);
        }
    }


    @Override
    public Fragment getCurrentItem(int position) {
        Bundle bundle = new Bundle();
        if (categoriesTypes != null) {
            bundle.putParcelable(ABConfig.KEY_OBJECT, categoriesTypes.get(position));
            bundle.putInt(ABConfig.KEY_TAG, position);
        }
        return ExtensionFragment.getInstance(bundle);
    }

    int typeBackTime = 0;

    //是否类型的两个接口都请求完成 考虑一个请求成功 一个没成功 还在请求等多种情况
    private void addDictType(BaseEntity<List<DictTypeEntity>> listBaseEntity) {
        typeBackTime++;

        try {
            if (listBaseEntity == null && (listBaseEntity != null && listBaseEntity.getData() == null)) {
                return;
            }
            if (stateList != null && stateList.size() > 0) {
                boolean isExsitWeb = false;
                boolean isExsitH5 = false;

                for (int i = 0; i < stateList.size(); i++) {
                    if (stateList.get(i).equals("agent_private_domain_h5")) {
                        isExsitH5 = true;
                    }
                    if (stateList.get(i).equals("agent_private_domain_web")) {
                        isExsitWeb = true;
                    }
                }

                if (listBaseEntity.getData().size() > 0) {
                    if (listBaseEntity.getData().get(0).getDictCode().equals("agent_private_domain_h5")) {
                        if (isExsitH5) {
                            return;
                        }
                    }
                    if (listBaseEntity.getData().get(0).getDictCode().equals("agent_private_domain_web")) {
                        if (isExsitWeb) {
                            return;
                        }
                    }
                }
            }

            List<DictTypeEntity> stateListTemp = new ArrayList<>();
            for (int i = 0; i < listBaseEntity.getData().size(); i++) {
                if (listBaseEntity.getData().get(i) != null) {
                    stateListTemp.add(listBaseEntity.getData().get(i));
                }
            }
            //排序 web在前 h5在后
            if (listBaseEntity.getData().get(0).getDictCode().equals("agent_private_domain_h5")) {
                stateList.addAll(stateListTemp);
            } else {
                stateList.addAll(0, stateListTemp);
            }
        } catch (Exception e) {

        }
        if (isFromClickTitle && typeBackTime == 2) {
            showFilterDialog();
        }
    }


}
