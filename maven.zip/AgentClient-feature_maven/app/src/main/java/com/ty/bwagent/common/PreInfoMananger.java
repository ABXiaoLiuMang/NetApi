package com.ty.bwagent.common;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LifecycleOwner;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.net.callback.NetObserver;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;

import java.util.List;
import java.util.Map;

/**
 * Desc:请求网络的预加载功能
 * Created by Jeff on 2019/2/15
 **/
public class PreInfoMananger {
    /**
     * preInfo定时刷新的时间间隔
     */
    private static final long REFRESH_INTERVAL = 30 * 60 * 1000;
    static final String H5_URL_INFO = "h5_url_key";

    static final String SERVICE_LIST_KEY = "service_list_key";
    static final String LIVE_BASE_URL_KEY = "live_base_url_key";
    private static final String PREINFO_KEY = "preInfo";
    public static String PRE_INFO_SUCCESS_DATA = "pre_info_success_data";// preInfo 成功时 数据
    //当前加载数据的状态
    private LoadDataStatus currLoadStatus = LoadDataStatus.NONE;

    public NetLiveData<BaseEntity<String>> preInfo = new NetLiveData<>();

    /**
     * 最后一次 获取preinfo的时间
     */
    private long lastGetPreInfoTime = 0;

    private PreInfoMananger() {
    }

    public static PreInfoMananger getInstance() {
        return Holder.INSTANCE;
    }


    private static class Holder {
        static final PreInfoMananger INSTANCE = new PreInfoMananger();
    }

    public void init() {
        currLoadStatus = LoadDataStatus.NONE;
    }

    /**
     * preInfo的结果
     * 不要使用 SP 不要保存复杂对象
     */
    @Nullable
    @Deprecated
    public BaseEntity getPreInfoResult() {
        BaseEntity data = preInfo.getData();
        if (data == null) {
            data = MMKVUtil.getObject(PREINFO_KEY, BaseEntity.class);
        }

        return data;
    }

    /**
     * 获取预加载的html链接
     *
     * @param type html的类型 {@link H5Type}
     * @return html链接
     */
    @SuppressWarnings("unused")
    public String getH5Url(H5Type type) {
        Map<String, String> links = CacheUtil.getObject(H5_URL_INFO, new TypeToken<Map<String, String>>() {
        });
        if (links != null) {
            return links.get(type.value());
        }
        return null;
    }

    /**
     * 获取视频动画域名
     */
    @SuppressWarnings("unused")
    public String getLiveBaseUrl() {
        Map<String, String> links = CacheUtil.getObject(H5_URL_INFO, new TypeToken<Map<String, String>>() {
        });
        if (links != null) {
            return links.get(LIVE_BASE_URL_KEY);
        }
        return null;
    }


    /**
     * 获取客服链接的列表
     */
    @SuppressWarnings("unused")
    public List<H5UrlBean> getServiceList() {
        return CacheUtil.getObject(SERVICE_LIST_KEY, new TypeToken<List<H5UrlBean>>() {
        });
    }

    public void addListener(@NonNull LifecycleOwner owner, @NonNull NetObserver<BaseEntity<String>> observer) {
        preInfo.observe(owner, observer);
    }

    @SuppressWarnings("unused")
    public void addListener(@NonNull NetObserver<BaseEntity<String>> observer) {
        preInfo.observeForever(observer);
    }

    @SuppressWarnings("unused")
    public void removeListener(@NonNull NetObserver<BaseEntity<String>> observer) {
        preInfo.removeObserver(observer);
    }


    @SuppressWarnings("UnusedReturnValue")
    public PreInfoMananger loadPreInfo(boolean isUpdate) {

        if (isUpdate && currLoadStatus != LoadDataStatus.LOADING) {
            currLoadStatus = LoadDataStatus.NONE;
        }

        if (currLoadStatus == LoadDataStatus.LOADING) {
            return this;
        }

        long currTime = System.currentTimeMillis();
        //超过时间限制,重置状态
        if (currTime - lastGetPreInfoTime < REFRESH_INTERVAL) {
            currLoadStatus = LoadDataStatus.NONE;
        }
        if (currLoadStatus == LoadDataStatus.SUCCESS) {
            handlerSuccess(preInfo.getData());
            return this;
        }
        currLoadStatus = LoadDataStatus.LOADING;
        return this;
    }

    public void getPreInfo() {
        NetSdk.create(Api.class)
                .getPreInfo()
                .params("platformType",2)
                .asJSONType()
                .send(preInfo);
        preInfo.observeForever(new NetObserver<BaseEntity<String>>(){

            @Override
            protected void onSuccess(BaseEntity<String> baseEntity) {
                if (baseEntity != null) {
                    LogUtils.e("getPreInfo: " + new Gson().toJson(baseEntity));
                    PreInfoParser.getInstance().parse(baseEntity);
                    currLoadStatus = LoadDataStatus.SUCCESS;
                    handlerSuccess(baseEntity);
                    lastGetPreInfoTime = System.currentTimeMillis();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                currLoadStatus = LoadDataStatus.NONE;//清空状态
                preInfo.setError(code, null);
            }
        });
    }

    /**
     * 地区 限制 提醒
     */
    public void checkoutAreaWarn() {
//
//        NetLiveData<BaseEntity> netLiveData = new NetLiveData<>();
//        NetSdk.create(Api.class)
//                .checkRestrict()
//                .params("platformType",2)
//                .asJSONType()
//                .send(SystemModel.areaWarnResult);
//        netLiveData.observeForever(new NetObserver<BaseEntity>(){
//
//            @Override
//            protected void onSuccess(BaseEntity baseEntity) {
//                if (baseEntity != null) {
//                    if (baseEntity.getCode() == 10403) {
//                        SystemModel.areaWarnResult.postNext(baseEntity);
//                    }
//                }
//            }
//
//            @Override
//            protected void onError(int code, String errMsg) {
//                if(code == 10403){
//                    BaseEntity baseEntity = new BaseEntity();
//                    baseEntity.setMsg(errMsg);
//                    baseEntity.setCode(code);
//                    SystemModel.areaWarnResult.postNext(baseEntity);
//                }
//            }
//        });
    }

    private void handlerSuccess(BaseEntity<String> entity) {
        this.preInfo.setNext(entity);
        currLoadStatus = LoadDataStatus.SUCCESS;
        String preInfoData = entity.getData();
        if (!TextUtils.isEmpty(preInfoData)) {
            MMKVUtil.put(PRE_INFO_SUCCESS_DATA, preInfoData);
        }

    }
}