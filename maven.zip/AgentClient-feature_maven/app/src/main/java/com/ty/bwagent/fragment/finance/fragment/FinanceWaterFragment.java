package com.ty.bwagent.fragment.finance.fragment;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.bean.ValueBean;
import com.ty.bwagent.fragment.finance.adapter.FinanceWaterAdapter;
import com.ty.bwagent.fragment.finance.viewmodel.FinanceWaterViewModel;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.Utils;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 月度详细-返水
 */
public class FinanceWaterFragment extends ABRefreshFragment<List<String>> {

    FinanceWaterViewModel mFinanceMontyViewModel;
    FinanceEntity financeEntity;//佣金明细对象
    List<String> title = new ArrayList<>();//等级
    @BindView(R.id.tv_month)
    TextView tvMonth;//查询月份
    @BindView(R.id.tv_monty)
    TextView tvMoney;//返水金额
    @BindView(R.id.tv_service)
    TextView tvService;
    @BindView(R.id.layout_head)
    LinearLayout layout_head;//recycleview左边表头
    @BindView(R.id.point1)
    ImageView point1;
    @BindView(R.id.point2)
    ImageView point2;
    @BindView(R.id.point3)
    ImageView point3;
    @BindView(R.id.point4)
    ImageView point4;


    public static FinanceWaterFragment getInstance(Bundle bundle) {
        FinanceWaterFragment fragment = new FinanceWaterFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_water;
    }

    @Override
    protected void createProvider() {
        mFinanceMontyViewModel = new ViewModelProvider(this).get(FinanceWaterViewModel.class);

        //返水
        mFinanceMontyViewModel.financeNetLiveData.observe(this, new NetObserver<BaseEntity<Map<String, List<ValueBean>>>>() {

            @Override
            protected void onSuccess(BaseEntity<Map<String, List<ValueBean>>> baseEntity) {
                Map<String, List<ValueBean>> map = baseEntity.getData();
                title.add("会员等级");
                for (Map.Entry<String, List<ValueBean>> entry : map.entrySet()) {
                    List<ValueBean> valueBeans = entry.getValue();
                    title.add(valueBeans.get(0).getVenueName());
                }
                FinanceWaterAdapter financeWaterAdapter = (FinanceWaterAdapter) listAdapter;
                financeWaterAdapter.setDatas(map);
                initHeader(title);
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        layout_head = rootView.findViewById(R.id.layout_head);
        tvMonth = rootView.findViewById(R.id.tv_month);
        tvMoney = rootView.findViewById(R.id.tv_monty);
        financeEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        String startData = bundle.getString(ABConfig.KEY_TAG);
        tvMonth.setText(startData);
        tvMoney.setText(Utils.roundDownMoney(financeEntity.getRebate()));
        mFinanceMontyViewModel.financeWater(startData);

        Utils.setTextViewLine(tvService, ResUtils.getString(R.string.generic_service));

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(ResUtils.getColor(SiteSdk.ins().styleColor()));
        gd.setShape(GradientDrawable.OVAL);
        gd.setSize(SizeUtils.dp2px(7),SizeUtils.dp2px(7));
        point1.setBackground(gd);
        point2.setBackground(gd);
        point3.setBackground(gd);
        point4.setBackground(gd);
    }


    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false);
    }

    @Override
    public int getMode() {
        return Mode.DISABLED;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }


    @Override
    public BaseQuickAdapter<List<String>, BaseViewHolder> getListAdapter() {
        return new FinanceWaterAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
    }


    private void initHeader(List<String> listMap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(SizeUtils.dp2px(70), SizeUtils.dp2px(50));
        lp.gravity = Gravity.CENTER;
        for (int i = 0; i < listMap.size(); i++) {
            TextView textView = new TextView(mContext);
            textView.setTextColor(ResUtils.getColor(R.color.generic_heise));
            textView.setTextSize(12);
            textView.setGravity(Gravity.CENTER);
            textView.setText(listMap.get(i));
            layout_head.addView(textView, lp);
        }
    }

    @OnClick(R.id.tv_service)
    public void onViewClicked() {
//        SpanManager.callServiceSpan(forgetCustom, ResUtils.getString(R.string.generic_forgetpass_alert), ResUtils.getColor(R.color.main_style_color), "联系客服", new SingleOnClickListener() {
//            @Override
//            public void onSingleClick(View view) {
//                ToastUtils.showLong("联系客服");
//            }
//        });
        goActivity(OnlineActivity.class);
    }
}
