package com.ty.bwagent.utils;

public class AppEnv {
    /**
     * debug版本
     */
    public transient static final String DEBUG = "debug";

    /**
     * 隔离预发布版本
     */
    public transient static final String GELI_PRE_RELEASE = "geli_pre_release";
    /**
     *预发布版本
     */
    public transient static final String PRE_RELEASE = "pre_release";
    /**
     *正式版
     */
    public transient static final String RELEASE = "release";

    /**
     *正式https版本
     */
    public transient static final String HTTPS_RELEASE = "https_release";


    /**
     * 当前的app环境
     */
    private String currentEnv;

    public String getCurrentEnv() {
        return currentEnv;
    }

    public void setCurrentEnv(String currentEnv) {
        this.currentEnv = currentEnv;
    }
}
