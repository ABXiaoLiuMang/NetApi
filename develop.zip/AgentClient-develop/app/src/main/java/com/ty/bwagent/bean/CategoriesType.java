package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

//1-全站、2-体育、3-棋牌、4-彩票、5-真人、6-全站体育 多个以,分开
//h5(主站h5),pc(主站pc),site(全站APP),sportApp(体育App),privateDomain(专属域名), person(真人), chess(棋牌),
// lottery(彩票) 根据终端类型获取推广链接地址,不传值得话默认查询全部
public class CategoriesType implements Parcelable {

    int type;
    String name;//站点名字
    String parames;//请求列表参数

    public CategoriesType(int type, String name, String parames) {
        this.type = type;
        this.name = name;
        this.parames = parames;
    }

    protected CategoriesType(Parcel in) {
        type = in.readInt();
        name = in.readString();
        parames = in.readString();
    }

    public static final Creator<CategoriesType> CREATOR = new Creator<CategoriesType>() {
        @Override
        public CategoriesType createFromParcel(Parcel in) {
            return new CategoriesType(in);
        }

        @Override
        public CategoriesType[] newArray(int size) {
            return new CategoriesType[size];
        }
    };

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getParames() {
        return parames;
    }

    public void setParames(String parames) {
        this.parames = parames;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(type);
        dest.writeString(name);
        dest.writeString(parames);
    }
}