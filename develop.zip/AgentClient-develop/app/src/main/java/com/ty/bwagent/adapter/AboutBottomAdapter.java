package com.ty.bwagent.adapter;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.ContactUsEntity;


/**
 * 描述:关于底部适配器
 *
 */
public class AboutBottomAdapter extends BaseQuickAdapter<ContactUsEntity.BaseInfo, BaseViewHolder> {

    public AboutBottomAdapter() {
        super(R.layout.recycle_item_about_bottom);
    }

    @Override
    protected void convert(BaseViewHolder helper, ContactUsEntity.BaseInfo item) {
        helper.setText(R.id.tv_name, item.getDeviceText());
        helper.setText(R.id.about_content, item.getDeviceNum());
        ImageView sponsor_icon = helper.getView(R.id.sponsor_icon);
        Glide.with(mContext).load(item.getImageUrl()).into(sponsor_icon);
    }


}
