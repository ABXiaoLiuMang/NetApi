package com.ty.bwagent.api;

import androidx.annotation.NonNull;

import com.bw.tmapmanager.domains.TmapDomainsManager;
import com.bw.tmapmanager.utils.Constant;
import com.bw.tmapmanager.utils.EmptyUtils;
import com.ty.net.NetSdk;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class BaseRetryInterceptor implements Interceptor {

    @NonNull
    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        HttpUrl url = chain.request().url();
        String urlStr = url.toString();
        String host = url.host();
        Request request = chain.request();
        Response response = chain.proceed(request);
        int code = response.code();
        while (code == 403 || code == 502) {
            try {
                response.close();
                DamainItem domainAndToken = BaseUrlManager.ins().nextDomain();
                if (domainAndToken == null) {
                    break;
                }
                String newDomain = domainAndToken.getHost();
                NetSdk.getConfig().baseUrl(newDomain);
                request = getRequest(chain,domainAndToken,urlStr.replace(host,getHost(newDomain)));
                response = chain.proceed(request);
                code = response.code();
            }catch (Exception e){}
        }

        return response;
    }


    private Request getRequest(Chain chain,DamainItem damainItem,String urlStr){
        String[] tokens = BaseUrlManager.ins().currentDomain().getTokens();
        // 完成初始化后，获取加签的数据参数
        HttpSignUtils.signParams(damainItem.getHost(), tokens[0], tokens[1], tokens[2]);
        Map<String, Object> requestMap = TmapDomainsManager.getInstance().configCDNAtuthWithURL(urlStr);
        // 获取加签后的url
        String singUrl = (String) requestMap.get(Constant.urlKey);
        if (EmptyUtils.stringIsEmpty(singUrl)) {
            singUrl = urlStr;
        }
        // 将yundun加签的header信息通过addHeader添加到Request.Builder的Header里面去
        Request.Builder builder = chain.request().newBuilder().url(singUrl);
        // Headers.Builder builder = headers.newBuilder();
        Map<String, String> childMap = (Map<String, String>) requestMap.get(Constant.Key);
        if (childMap != null && childMap.size() != 0) {
            for (Map.Entry<String, String> child : childMap.entrySet()) {
                String key = child.getKey();
                String value = child.getValue();
                if (EmptyUtils.stringIsEmpty(key) || EmptyUtils.stringIsEmpty(value)) {
                    continue;
                }
                builder.removeHeader(key);
                builder.addHeader(key, value);
            }
        }
        Request request = builder.build();
        return request;
    }

    private String getHost(String link) {
        URL url;
        String host = "";
        try {
            url = new URL(link);
            host = url.getHost();
        } catch (MalformedURLException e) {
        }
        return host;
    }

}
