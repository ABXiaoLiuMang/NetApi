package com.ty.bwagent.fragment.news;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshInternal;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.MessageSysAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MessageSys;
import com.ty.bwagent.header.MyClassicsRefreshFooter;
import com.ty.bwagent.header.MyClassicsRefreshHeader;
import com.ty.bwagent.viewmodel.MessageViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;

import java.util.List;

/**
 * 系统公告列表
 */
public class MessageSysFragment extends ABRefreshFragment<MessageSys.ListBean> {

    MessageViewModel mMessageViewModel;
    int msgType;//3.公告

    int pageNum = 1;
    int pageSize = 15;

    /**
     * @param msgType 消息类型1.通知 2.活动 3.公告
     * @return
     */
    public static MessageSysFragment getInstance(int msgType) {
        MessageSysFragment fragment = new MessageSysFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ABConfig.KEY_TAG, msgType);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_message;
    }

    @Override
    protected void createProvider() {
        msgType = bundle.getInt(ABConfig.KEY_TAG);
        mMessageViewModel = new ViewModelProvider(this).get(MessageViewModel.class);

        //监听消息列表数据
        mMessageViewModel.messageSysLiveData.observe(this, new NetObserver<BaseEntity<MessageSys>>() {
            @Override
            protected void onSuccess(BaseEntity<MessageSys> listBaseEntity) {
                dismissProgressDialog();
                List<MessageSys.ListBean> listBeans = listBaseEntity.getData().getList();
                if(pageNum == 1){
                    refreshLayout.setVisibility(View.VISIBLE);
                    listAdapter.setNewData(listBeans);
                    refreshLayout.finishRefresh();
                }else {
                    listAdapter.addData(listBeans);
                    refreshLayout.finishLoadMore();
                }
                if(listBeans.size() < pageNum){
                    refreshLayout.finishLoadMoreWithNoMoreData();
                }
            }



            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                refreshLayout.setVisibility(View.VISIBLE);
                if(pageSize == 1){
                    refreshLayout.finishRefresh(false);
                }else {
                    refreshLayout.finishLoadMore(false);
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        refreshLayout.setVisibility(View.GONE);
        RefreshInternal refreshHeader = refreshLayout.getRefreshHeader();
        RefreshInternal refreshFooter = refreshLayout.getRefreshFooter();
        if(refreshHeader instanceof MyClassicsRefreshHeader){
            ((MyClassicsRefreshHeader)refreshHeader).bindLifecycle(this);
        }
        if(refreshFooter instanceof MyClassicsRefreshFooter){
            ((MyClassicsRefreshFooter)refreshFooter).bindLifecycle(this);
        }

    }

    boolean loadData = false;
    @Override
    public void onResume() {
        super.onResume();
        if(!loadData){
            showProgressDialog();
            mMessageViewModel.msgSystemList(pageNum, pageSize);
            loadData = true;
        }
    }

    @Override
    public View getEmptyView() {
        return View.inflate(mContext, R.layout.empty_message, null);
    }

    @Override
    public BaseQuickAdapter<MessageSys.ListBean, BaseViewHolder> getListAdapter() {
        return new MessageSysAdapter();
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        MessageSys.ListBean mMMessage = (MessageSys.ListBean) adapter.getItem(position);
        Bundle bundle = new Bundle();
        bundle.putParcelable(ABConfig.KEY_OBJECT,mMMessage);
        bundle.putInt(ABConfig.KEY_TAG,msgType);
        ((ABBaseFragment) getParentFragment()).start(MessageDetailsFragment.getInstance(bundle));
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum++;
        mMessageViewModel.msgSystemList(pageNum, pageSize);
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        pageNum = 1;
        mMessageViewModel.msgSystemList(pageNum, pageSize);
    }

    @Override
    public void onStop() {
        super.onStop();
        refreshLayout.finishRefresh();
        refreshLayout.finishLoadMore();
    }
}
