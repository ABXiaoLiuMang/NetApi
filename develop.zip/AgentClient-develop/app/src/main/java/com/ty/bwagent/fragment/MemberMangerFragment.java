package com.ty.bwagent.fragment;

import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.MemberMangerTableAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.TeamMenberInfoEntity;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.table.TableView;
import com.ty.bwagent.viewmodel.NewMemberCenterViewModel;
import com.ty.bwagent.viewmodel.TeamViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.NetObserver;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.List;

import butterknife.BindView;


public class MemberMangerFragment extends ABBaseFragment implements OnRefreshListener, OnLoadMoreListener, View.OnClickListener {

    @BindView(R.id.tableView)
    TableView tableView;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;

    @BindView(R.id.tv_message)
    TextView tv_message;
    @BindView(R.id.ll_nodate)
    LinearLayout ll_nodate;

    @BindView(R.id.tv_team_name)
    TextView tvTeamName;
    @BindView(R.id.tv_team_number)
    TextView tvTeamNumber;
    @BindView(R.id.tv_next_num)
    TextView tvNextNum;
    @BindView(R.id.iv_image)
    ImageView iv_logo;

    private String searchDate;

    int pageNum = 1;
    int pageSize = 15;

    private MemberMangerTableAdapter memberFinacialTableAdapter;
    private TeamViewModel teamViewModel;
    private Handler handler;

    /**
     * @return
     */
    public static MemberMangerFragment getInstance() {
        return new MemberMangerFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_member_manager_center;
    }

    @Override
    protected void createProvider() {

    }

    @Override
    protected void initViewsAndEvents() {

    }

    private boolean isFirst = true;

    @Override
    public void onResume() {
        super.onResume();
        if (isFirst) {//懒加载处理
            isFirst = false;
            initDate();
            handler = new Handler();
            handler.postDelayed(this::initView, 300);//延迟300ms进入时 不卡顿
        }
    }

    private void initDate() {

        teamViewModel = new ViewModelProvider(this).get(NewMemberCenterViewModel.class);
        teamViewModel.teamMenberInfoLiveData.observe(this, new NetObserver<BaseEntity<TeamMenberInfoEntity>>() {

            @Override
            protected void onSuccess(BaseEntity<TeamMenberInfoEntity> teamCommissionInfo) {
                dismissProgressDialog();
                if (teamCommissionInfo == null || (teamCommissionInfo != null && teamCommissionInfo.getData() == null)) {
                    return;
                }

                if (teamCommissionInfo != null && teamCommissionInfo.getData() != null) {
                    tvTeamName.setText(teamCommissionInfo.getData().getTeamName());
                    tvTeamNumber.setText(Utils.fmtMicrometer(teamCommissionInfo.getData().getSubMemberCount() + ""));
                    tvNextNum.setText(Utils.fmtMicrometer(teamCommissionInfo.getData().getAgentCount() + ""));
                }

                tvTeamNumber.setTypeface(TypefaceUtils.DIN_MEDIUM);
                tvNextNum.setTypeface(TypefaceUtils.DIN_MEDIUM);
                tvTeamName.setTypeface(TypefaceUtils.DIN_MEDIUM);

                List<TeamMenberInfoEntity.ListBean> listBeans = teamCommissionInfo.getData().getList();
                if (pageNum == 1) {
                    listBeans.add(0, new TeamMenberInfoEntity.ListBean());
                    memberFinacialTableAdapter = new MemberMangerTableAdapter(getActivity(), listBeans);
                    tableView.setAdapter(memberFinacialTableAdapter);

                    refreshLayout.finishRefresh();
                } else {
                    if (memberFinacialTableAdapter != null) {
                        memberFinacialTableAdapter.addDatas(listBeans);
                    }
                    refreshLayout.finishLoadMore();
                }
                if (teamCommissionInfo != null && teamCommissionInfo.getData() != null) {
                    pageNum = teamCommissionInfo.getData().getPageNum();
                    if (pageNum == teamCommissionInfo.getData().getPages()) {
                        refreshLayout.finishLoadMoreWithNoMoreData();
                    }
                }
                showNoDateView();
            }

            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                ToastUtils.showLong(errMsg);
                showNoDateView();

                if (pageNum == 1) {
                    refreshLayout.finishRefresh();
                } else {
                    refreshLayout.finishLoadMore();
                }
            }
        });

        tv_message.setText("暂无数据");
    }

    private void showNoDateView() {
        if (memberFinacialTableAdapter == null) {
            tableView.setVisibility(View.GONE);
            ll_nodate.setVisibility(View.VISIBLE);
            iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
            tv_message.setText("网络不给力");
            refreshLayout.finishLoadMoreWithNoMoreData();
            return;
        } else {
            tableView.setVisibility(View.VISIBLE);
            ll_nodate.setVisibility(View.GONE);
            iv_logo.setImageResource(R.mipmap.message_empty_bg);
            tv_message.setText("暂无数据");
        }

        if (memberFinacialTableAdapter.getRowCount() == 1) {
            memberFinacialTableAdapter.setNoDate();
            ll_nodate.setVisibility(View.VISIBLE);
        } else {
            tableView.setVisibility(View.VISIBLE);
            ll_nodate.setVisibility(View.GONE);
        }
    }


    private void initView() {

        if (ll_nodate == null) {
            return;
        }

        ll_nodate.setOnClickListener(this);
        refreshLayout.setOnRefreshListener(this);
        refreshLayout.setOnLoadMoreListener(this);

        tv_message.setText("暂无数据");

        showProgressDialog();
        teamViewModel.getTeamMenberList(searchDate, pageNum, pageSize);
    }


    public void searchDate(String accountName) {
        pageNum = 1;
        searchDate = accountName;
        KeyboardUtils.hideSoftInput(tvTeamName);
        showProgressDialog();
        teamViewModel.getTeamMenberList(searchDate, pageNum, pageSize);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_nodate:
                if (ll_nodate != null) {
                    KeyboardUtils.hideSoftInput(getActivity());
                }
                break;
        }
    }


    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum++;
        teamViewModel.getTeamMenberList(searchDate, pageNum, pageSize);
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        pageNum = 1;
        teamViewModel.getTeamMenberList(searchDate, pageNum, pageSize);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
    }
}
