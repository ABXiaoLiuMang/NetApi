package com.ty.bwagent.fragment.finance.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.AddBankCardEntity;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class AddBankCardViewModel extends ViewModel {

    //查询银行列表
    public NetLiveData<BaseEntity<List<AddBankCardEntity>>> banksLiveData = new NetLiveData<>();

    //验证银行卡
    public NetLiveData<BaseEntity> cardLiveData = new NetLiveData<>();

    /**
     * 查询银行列表
     */
    public void queryBanks(){
        NetSdk.create(Api.class)
                .queryBanks()
                .params("dictCode","bank_code")
                .asJSONType()
                .send(banksLiveData);
    }

    /**
     * 验证银行卡
     * @param bankCard 银行卡号
     * @param bankCode 开户银行编码
     * @param name 持卡人姓名
     */
    public void validateBankCard(String bankCard,String bankCode,String name){
        NetSdk.create(Api.class)
                .validateBankCard()
                .params("bankCard",bankCard)
                .params("bankCode",bankCode)
                .params("name",name)
                .asJSONType()
                .send(cardLiveData);
    }

}
