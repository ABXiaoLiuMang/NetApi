package com.ty.bwagent.bean;

/**
 * 个人用户信息
 */
public class UserEntity {

    /**
     * avatar : http://103.41.124.222:8080/assets/img/logo/full.png
     * email : fsfs@qq.com
     * inviteCode : 8337504
     * name : test
     * phone : 79797897
     * realName : xiaoji
     * joinedDays : 3
     */

    private String avatar;
    private String email;
    private String inviteCode;
    private String name;
    private String phone;
    private String realName;
    private String joinedDays;
    private String createdAt;
    private String subMembers;
    private String vipLevel;

    public String getAvatar() {
        return "http://t8.baidu.com/it/u=3571592872,3353494284&fm=79&app=86&size=h300&n=0&g=4n&f=jpeg?sec=1589298414&t=85a730d20c1c9532dfcdb9a07430bae4";
//        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInviteCode() {
        return inviteCode;
    }

    public void setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getJoinedDays() {
        return joinedDays;
    }

    public void setJoinedDays(String joinedDays) {
        this.joinedDays = joinedDays;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getSubMembers() {
        return subMembers;
    }

    public void setSubMembers(String subMembers) {
        this.subMembers = subMembers;
    }

    public String getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(String vipLevel) {
        this.vipLevel = vipLevel;
    }
}
