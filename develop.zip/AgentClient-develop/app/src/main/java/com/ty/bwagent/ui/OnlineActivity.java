package com.ty.bwagent.ui;

import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.ServiceEntity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;

import java.util.List;

/**
 * 在线客服
 */
public class OnlineActivity extends BaseAgentWebActivity {

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        titleBar.setTiteTextView(ResUtils.getString(R.string.generic_line_service));
    }

    @Nullable
    @Override
    protected String getUrl() {
        String serviceText = MMKVUtil.getString(CacheKey.CUSTOMER_SERVICE);
        List<ServiceEntity> serviceEntityList = new Gson().fromJson(serviceText, new TypeToken<List<ServiceEntity>>() {
        }.getType());
        if (serviceEntityList != null && serviceEntityList.size() > 0) {
            return serviceEntityList.get(0).getUrl();
        }
        return "";
    }
}

