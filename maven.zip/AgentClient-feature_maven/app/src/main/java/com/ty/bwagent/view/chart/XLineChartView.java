package com.ty.bwagent.view.chart;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.DayLowerEntity;
import com.ty.utils.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class XLineChartView extends RelativeLayout {

    BrokenLineView brokenLineView;
    TextView count4;
    TextView count3;
    TextView count2;
    TextView count1;
    TextView count0;
    Context mContext;


    public XLineChartView(Context context) {
        this(context, null);
    }

    public XLineChartView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public XLineChartView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        View view = LayoutInflater.from(mContext).inflate(R.layout.x_linechart_view, this, true);
        count0 = view.findViewById(R.id.count_0);
        count1 = view.findViewById(R.id.count_1);
        count2 = view.findViewById(R.id.count_2);
        count3 = view.findViewById(R.id.count_3);
        count4 = view.findViewById(R.id.count_4);
        brokenLineView = view.findViewById(R.id.mBrokenLineView);
    }

    public void initDatas(List<DayLowerEntity> lowerEntities) {
        ArrayList<String> xRawData = new ArrayList<>();
        ArrayList<ArrayList<Integer>> mYDatas = new ArrayList<>();
        ArrayList<Integer> yData = new ArrayList<>();
        for (DayLowerEntity dayLowerEntity : lowerEntities) {
            xRawData.add(dayLowerEntity.getCreateTime().substring(5, 10));
            yData.add(dayLowerEntity.getCount());
        }
        mYDatas.add(yData);
        intMaxValue(mYDatas);
        brokenLineView.initViewDatas(xRawData, yData);
    }


    private void intMaxValue(ArrayList<ArrayList<Integer>> mYDatas) {
        int maxValue;
        double tmp = 0;
        for (ArrayList<Integer> yData : mYDatas) {
            for (Integer aDouble : yData) {
                if (aDouble > tmp) {
                    tmp = aDouble;
                }
            }
        }

        if (tmp >= 4) {
            int v = (int) (tmp / 4);
            int length = (v + "").length() - 1;
            int i = (int) ((v / (int) Math.pow(10, length) + 1) * Math.pow(10, length));
            maxValue = i * 4;
        } else {
            maxValue = 4;
        }

        count0.setText(StringUtils.parseString(maxValue * 0 / 4));
        count1.setText(StringUtils.parseString(maxValue * 1 / 4));
        count2.setText(StringUtils.parseString(maxValue * 2 / 4));
        count3.setText(StringUtils.parseString(maxValue * 3 / 4));
        count4.setText(StringUtils.parseString(maxValue * 4 / 4));
    }
}
