package com.ty.bwagent.bean;

/***
 * 赞助
 */
public class AboutSponsor {


    /**
     * content :
     * createdAt : 2020-03-07 13:57:19
     * createdBy : haley
     * id : 722281
     * ifAgent : 1
     * imageUrl : http://img.bwhou2028.com/1585572349557258.png
     * isDelete : 0
     * linkType : null
     * linkUrl :
     * messgeNameCode : 3
     * messgeTypeCode : 1
     * name : 23234
     * path :
     * siteId : 0
     * sort : 456
     * status : 1
     * updatedAt : 2020-04-07 08:18:15
     * updatedBy : krystal
     */

    private String content;
    private String createdAt;
    private String createdBy;
    private int id;
    private int ifAgent;
    private String imageUrl;
    private int isDelete;
    private Object linkType;
    private String linkUrl;
    private int messgeNameCode;
    private int messgeTypeCode;
    private String name;
    private String path;
    private int siteId;
    private int sort;
    private int status;
    private String updatedAt;
    private String updatedBy;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIfAgent() {
        return ifAgent;
    }

    public void setIfAgent(int ifAgent) {
        this.ifAgent = ifAgent;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }

    public Object getLinkType() {
        return linkType;
    }

    public void setLinkType(Object linkType) {
        this.linkType = linkType;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public int getMessgeNameCode() {
        return messgeNameCode;
    }

    public void setMessgeNameCode(int messgeNameCode) {
        this.messgeNameCode = messgeNameCode;
    }

    public int getMessgeTypeCode() {
        return messgeTypeCode;
    }

    public void setMessgeTypeCode(int messgeTypeCode) {
        this.messgeTypeCode = messgeTypeCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
}
