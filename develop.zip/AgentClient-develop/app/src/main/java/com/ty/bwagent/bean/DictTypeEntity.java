package com.ty.bwagent.bean;

public class DictTypeEntity {


    /**
     * category : 1
     * code : 1
     * defaultVal : 1
     * dictCode : agent_private_domain_h5
     * dictName : 代理专属H5域名类型
     * dictValue : 注册页
     * ext1 : 1
     * id : 1881
     * remark : https://devbwoss.z3x9u9.com/H5注册页
     */

    private int category;
    private String code;
    private String defaultVal;
    private String dictCode;
    private String dictName;
    private String dictValue;
    private String ext1;
    private int id;
    private String remark;

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDefaultVal() {
        return defaultVal;
    }

    public void setDefaultVal(String defaultVal) {
        this.defaultVal = defaultVal;
    }

    public String getDictCode() {
        return dictCode;
    }

    public void setDictCode(String dictCode) {
        this.dictCode = dictCode;
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName;
    }

    public String getDictValue() {
        return dictValue;
    }

    public void setDictValue(String dictValue) {
        this.dictValue = dictValue;
    }

    public String getExt1() {
        return ext1;
    }

    public void setExt1(String ext1) {
        this.ext1 = ext1;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
