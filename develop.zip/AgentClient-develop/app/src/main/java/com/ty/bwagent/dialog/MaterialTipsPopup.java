package com.ty.bwagent.dialog;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.core.CenterPopupView;
import com.ty.bwagent.R;

/**
 * 分享素材温馨提示弹窗
 */
public class MaterialTipsPopup extends CenterPopupView {

    TextView tv_confirm;
    Context mContext;

    public MaterialTipsPopup(@NonNull Context context) {
        super(context);
        mContext = context;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_material_tips;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_confirm = findViewById(R.id.tv_confirm);
        tv_confirm.setOnClickListener(v -> {
            dismiss();
        });
    }


}
