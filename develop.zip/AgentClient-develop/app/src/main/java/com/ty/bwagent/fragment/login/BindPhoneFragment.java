package com.ty.bwagent.fragment.login;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.BindInfoEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.ui.MainActivity;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.BindPhoneViewModel;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.utils.ImageResoureSiteUtils;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.LogUtils;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 登录需要绑定电话号码
 */
public class BindPhoneFragment extends ABBaseFragment {

    BindPhoneViewModel bindViewModel;
    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.iv_verify_logo)
    ImageView ivVerifyLogo;
    @BindView(R.id.tv_verify_err)
    TextView tvVerifyErr;
    @BindView(R.id.bind_tv_warning)
    TextView bindTvWarning;
    @BindView(R.id.et_phone)
    ClearEditText etPhone;
    @BindView(R.id.verify_et_code)
    ClearEditText verifyEtCode;
    @BindView(R.id.tv_code)
    TextView tvCode;
    @BindView(R.id.bind_commit)
    TextView bindCommit;

    String phone;
    String verifyCode;

    public static BindPhoneFragment getInstance() {
        return new BindPhoneFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_bind_phone;
    }

    @Override
    protected void createProvider() {
        bindViewModel = new ViewModelProvider(this).get(BindPhoneViewModel.class);
        //验证码倒计时
        bindViewModel.timerLiveData.observe(this, aLong -> {
            if (aLong == 0) {
                tvCode.setText(ResUtils.getString(R.string.generic_reset_code));
                tvCode.setEnabled(true);
            } else {
                tvCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time), aLong));
                tvCode.setEnabled(false);
            }
        });

        //发送验证码
        bindViewModel.codeLivedata.observe(this, new SimpleObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                bindViewModel.startTimer(getLifecycle());
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                tvCode.setEnabled(true);
            }
        });

        //监听绑定
        bindViewModel.bindLiveData.observe(this, new NetObserver<BaseEntity<BindInfoEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<BindInfoEntity> baseEntity) {
                SystemModel.loginUserInfo.postValue(null);
                ToastUtils.showLong("绑定成功");
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                userInfo.setPhone(phone);
                userInfo.setFirstLogin(baseEntity.getData().getFirstLogin());
                UserInfoCache.getInstance().saveUserInfo(userInfo);
                XLiveDataManager.getInstance().userInfo.postNext(userInfo);
//                goActivity(MainActivity.class);
                MainActivity.startMainActiviy(false);
                getActivity().finish();
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                bindTvWarning.setText(errMsg);
            }

        });
    }

    @Override
    protected void initViewsAndEvents() {
        initVerify();
        titleBar.setRightOnClickListener(view -> {
//            ToastUtils.showLong("用户没有绑定手机");
            SystemModel.loginUserInfo.postValue(null);
            pop();
        });

        ivVerifyLogo.setBackgroundResource(ImageResoureSiteUtils.login_logo());

    }

    @OnClick({R.id.tv_code, R.id.bind_commit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_code:
                phone = etPhone.getText().toString();
                tvCode.setEnabled(false);
                bindViewModel.getPhoneCode(phone);
                break;
            case R.id.bind_commit:
                bindViewModel.bindPhone(phone, verifyCode);
                break;
        }
    }

    /**
     * 处理各类输入框验证逻辑
     */
    private void initVerify() {
        new InputResultCalculator(Arrays.asList(etPhone), ok -> {
            phone = etPhone.getText().toString();
            if (ParameterVerification.isPhoneNumber(phone)) {
                tvCode.setEnabled(ok);
            } else {
                tvCode.setEnabled(false);
            }
        });
        new InputResultCalculator(Arrays.asList(etPhone, verifyEtCode), ok -> {
            phone = etPhone.getText().toString();
            verifyCode = verifyEtCode.getText().toString();
            if (VerifyUtils.isCode(verifyCode) && ParameterVerification.isPhoneNumber(phone)) {
                bindCommit.setEnabled(ok);
            } else {
                bindCommit.setEnabled(false);
            }
        });
        VerifyUtils.verifyPhone(etPhone, bindTvWarning);
        VerifyUtils.verifyCode(verifyEtCode, bindTvWarning);
        etPhone.setWarnTv(bindTvWarning);
    }

}
