package com.ty.bwagent.adapter;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.MemberGameRecordEntity;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XFormatTextView;
import com.ty.bwagent.view.XTextView;


/**
 * 描述 游戏记录适配器
 * <p>
 * author:Dale
 */
public class GameRecordAdapter extends BaseQuickAdapter<MemberGameRecordEntity.ListBean, BaseViewHolder> {

    public GameRecordAdapter() {
        super(R.layout.recycle_item_game_record);
    }

    @Override
    protected void convert(BaseViewHolder helper, MemberGameRecordEntity.ListBean item) {

        helper.setText(R.id.tv_time, item.getBetTime());
        helper.setText(R.id.tv_name, item.getName());
//        helper.setText(R.id.tv_order, "订单号:" + item.getBillNo());//订单号
        helper.setText(R.id.tv_deposit, item.getVenueName());//场馆名称
        helper.setText(R.id.tv_active, item.getGameName());//游戏名称
        helper.setText(R.id.tv_promo, Utils.parsListMoney(item.getBetAmount()));//投注金额
        helper.setText(R.id.tv_rebate, Utils.parsListMoney(item.getValidBetAmount()));//有效投注
        helper.setText(R.id.tv_state, getState(item));//状态

        TextView tv_order = helper.getView(R.id.tv_order);//订单号
        tv_order.setText(item.getBillNo());

        XFormatTextView tv_shuying = helper.getView(R.id.tv_lastBalance);//输赢
        tv_shuying.setMontyText(item.getNetAmount());

        TextView tv_money = helper.getView(R.id.tv_promo);//投注金额
        tv_money.setTypeface(TypefaceUtils.DIN_MEDIUM);
        TextView tv_touzhu = helper.getView(R.id.tv_rebate);//有效投注
        tv_touzhu.setTypeface(TypefaceUtils.DIN_MEDIUM);

    }

    public String getState(MemberGameRecordEntity.ListBean item) {

        String state = "";
        switch (item.getFlag()) {
            case 0:
                state = "未结算";
                break;
            case 1:
                state = "已结算";
                break;
            case 2:
                state = "取消";
                break;
            case 3:
                state = "无效";
                break;
        }
        return state;

    }


}
