package com.ty.bwagent.bean;

/**
 * 代理转账下级用户信息
 */
public class TurnUserEntity {

    /**
     * qq :
     * realName :
     * sysType : null
     * phone : 164****6768
     * subMembers :
     * inviteCode : 9496093
     * name : ouou6
     * paymentPassword :
     * avatar :
     * email :
     * status : 1
     */

    private String qq;
    private String realName;
    private Object sysType;
    private String phone;
    private String subMembers;
    private String inviteCode;
    private String name;
    private String paymentPassword;
    private String avatar;
    private String email;
    private int status;

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public Object getSysType() {
        return sysType;
    }

    public void setSysType(Object sysType) {
        this.sysType = sysType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSubMembers() {
        return subMembers;
    }

    public void setSubMembers(String subMembers) {
        this.subMembers = subMembers;
    }

    public String getInviteCode() {
        return inviteCode;
    }

    public void setInviteCode(String inviteCode) {
        this.inviteCode = inviteCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPaymentPassword() {
        return paymentPassword;
    }

    public void setPaymentPassword(String paymentPassword) {
        this.paymentPassword = paymentPassword;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
