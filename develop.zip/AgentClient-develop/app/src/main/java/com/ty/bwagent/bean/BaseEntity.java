package com.ty.bwagent.bean;

import android.os.Looper;

import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.Key;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.net.callback.XEntity;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.utils.TopActivityManager;
import com.ty.utils.WeakHandler;

public class BaseEntity<T> implements XEntity {

    private int code;
    private T data;
    private String msg;
    private String result;

    public int getStatus() {
        return code;
    }

    public T getData() {
        return data;
    }

    @Override
    public boolean isOk() {
        return code == 0;
    }

    @Override
    public int getCode() {
        return code;
    }

    @Override
    public String getErrMsg() {
        return msg;
    }

    @Override
    public void setResponse(String result) {
        this.result = result;
    }

    public String getResult() {
        return result;
    }

    @Override
    public void error() {
        switch (code) {
            case 10401://10401维护
            case 10402://10402 ip受限
//            case 10403://10403 ip警告
                //  //处理维护的界面UI
                SystemModel.areaWarnResult.postValue(code);
                ToastUtils.showLong(msg);
                break;
            case 22033://该设备存在风险，无法使用本平台
                SystemModel.loginOut.postValue(true);
                break;
            case 10004://登录失效，请重新登录
            case 26304://登录失效，请重新登录
                if(MMKVUtil.getBoolean(Key.IS_USER_LOGIN,false)){
                    new WeakHandler(Looper.getMainLooper()).post(() -> ToastUtils.showLong(msg));
                }
                MMKVUtil.removeValueForKey(CacheKey.USER_PASSWORD);
                SystemModel.loginOut.postValue(true);
                break;
            case 26305://用户没有绑定手机
                if (data instanceof UserInfo) {
                    SystemModel.loginUserInfo.postValue((UserInfo) getData());
                }
                if (StringUtils.equals("MainActivity", TopActivityManager.getInstance().getCurActivity().getClass().getSimpleName())) {
                    SystemModel.loginOut.postValue(true);
                }
                break;

        }
    }

    public String getMessage() {
        return msg;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
