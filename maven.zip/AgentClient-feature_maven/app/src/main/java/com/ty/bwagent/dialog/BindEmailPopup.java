package com.ty.bwagent.dialog;

import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupAnimation;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.BindViewModel;
import com.ty.common.util.AlphaAnimator;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

/**
 * 绑定邮箱弹窗
 */
public class BindEmailPopup extends ConfirmPopupView {

    ClearEditText et_input_code;
    ClearEditText et_input;
    TextView btn_getCode;//获取验证码
    String emailText;//输入框内容
    BindViewModel bindViewModel;
    Fragment fragment;
    BasePopupView progressDialog;

    public BindEmailPopup(Fragment fragment) {
        super(fragment.getContext());
        this.fragment = fragment;
        this.title = "绑定邮箱地址";
        bindViewModel = new BindViewModel();
    }


    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_bindemail;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        et_input_code = findViewById(R.id.et_input_code);
        et_input = findViewById(R.id.et_input);
        btn_getCode = findViewById(R.id.btn_bind);

        btn_getCode.setOnClickListener(v -> {
            emailText = et_input.getText().toString().trim();
            tv_content.setText("");
            bindViewModel.getEmailCode(emailText);
        });

        et_input.addTextChangedListener(new SimpleTextWatcher(){
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tv_content.setText("");
            }
        });


        VerifyUtils.verifyEmail(et_input,tv_content);
        VerifyUtils.verifyCode(et_input_code,tv_content);
        setListener(() -> {
            emailText = et_input.getText().toString().trim();
            String verifyCode = et_input_code.getText().toString().trim();
            bindViewModel.bindEmail(emailText,verifyCode);

        },null);
        initViewsAndEvents();

    }

    /**
     * 一系列监听回调
     */
    private void initViewsAndEvents(){
        //监听验证码
        bindViewModel.codeLivedata.observeForever(new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if(baseEntity ==null){
                    return;
                }
                bindViewModel.startTimer(fragment.getLifecycle());
            }
            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }
            @Override
            protected void onError(int code, String errMsg) {
                tv_content.setText(errMsg);
            }
        });

        //监听绑定结果
        bindViewModel.bindLiveData.observeForever(new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if(baseEntity != null){
                    ToastUtils.showLong("绑定成功");
                    UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                    userInfo.setEmail(emailText);
                    UserInfoCache.getInstance().saveUserInfo(userInfo);
                    XLiveDataManager.getInstance().userInfo.postNext(userInfo);
                }
                dismiss();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText(errMsg);
            }

        });

        //验证码倒计时
        bindViewModel.timerLiveData.observeForever(aLong -> {
            if(aLong == 0){
                btn_getCode.setText(ResUtils.getString(R.string.generic_reset_code));
                btn_getCode.setEnabled(true);
            }else {
                btn_getCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time),aLong));
                btn_getCode.setEnabled(false);
            }
        });
        onVerification();
    }

    @Override
    public void dismiss() {
        bindViewModel.timerLiveData.removeObservers(fragment);
        bindViewModel.codeLivedata.removeObservers(fragment);
        bindViewModel.bindLiveData.removeObservers(fragment);
        bindViewModel.cancelTimer();
        super.dismiss();
    }


    private void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(fragment.getContext());
            progressDialog = new XPopup.Builder(fragment.getContext())
                    .isRequestFocus(false)  //loading不要焦点
                    .hasShadowBg(false)
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        progressDialog.show();
    }

    private void dismissProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    /**
     * 验证输入
     */
    private void onVerification(){
        new InputResultCalculator(Arrays.asList(et_input), ok -> {
            String inputText = et_input.getText().toString().trim();
            if(!ParameterVerification.isEmail(inputText)){
                btn_getCode.setEnabled(false);
                return;
            }
            btn_getCode.setEnabled(ok);
        });
    }
}
