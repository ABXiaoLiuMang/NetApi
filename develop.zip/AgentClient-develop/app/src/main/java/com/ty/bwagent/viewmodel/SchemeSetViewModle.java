package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.SchemeSetCommissionEntity;
import com.ty.bwagent.bean.SchemeSetRebateEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import okhttp3.MediaType;

public class SchemeSetViewModle extends ViewModel {


    //返佣-我的方案
    public NetLiveData<BaseEntity<List<SchemeSetCommissionEntity>>> commissionLivaData = new NetLiveData<>();
    //无限代web-返佣-下级方案
    public NetLiveData<BaseEntity<List<SchemeSetCommissionEntity>>> myLowerCommissionLivaData = new NetLiveData<>();
    //无限代web-返佣-更新方案
    public NetLiveData<BaseEntity> updateMyLowerLivaData = new NetLiveData<>();

    //返水-我的方案
    public NetLiveData<BaseEntity<List<SchemeSetRebateEntity>>> discountLivaData = new NetLiveData<>();
    //返水-下属方案
    public NetLiveData<BaseEntity<List<SchemeSetRebateEntity>>> lowerDiscountLivaData = new NetLiveData<>();

    //无限代web-返佣-更新方案
    public NetLiveData<BaseEntity> updateDiscountLivaData = new NetLiveData<>();


    /**
     * 无限代web-返佣-我的方案
     */
    public void myCommission() {
        NetSdk.create(Api.class)
                .myCommission()
                .asJSONType()
                .send(commissionLivaData);
    }

    /**
     * 无限代web-返佣-下级方案
     */
    public void myLowerCommission() {
        NetSdk.create(Api.class)
                .myLowerCommission()
                .asJSONType()
                .send(myLowerCommissionLivaData);
    }

    /**
     * 无限代web-返佣-新增方案
     */
    public void insertMyLowerCommission(SchemeSetCommissionEntity schemeSetCommissionEntity) {
        NetSdk.create(Api.class)
                .insertMyLowerCommission()
                .params(schemeSetCommissionEntity)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .send(updateMyLowerLivaData);
    }
 /**
     * 无限代web-返佣-更新方案
     */
    public void updateMyLowerCommission(SchemeSetCommissionEntity schemeSetCommissionEntity) {
        NetSdk.create(Api.class)
                .updateMyLowerCommission()
                .params(schemeSetCommissionEntity)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .send(updateMyLowerLivaData);
    }


    /**
     * 无限代web-返水-我的方案
     */
    public void myDiscount() {
        NetSdk.create(Api.class)
                .myDiscount()
                .asJSONType()
                .send(discountLivaData);
    }

    /**
     * 无限代web-返水-下级方案
     */
    public void myLowerDiscount() {
        NetSdk.create(Api.class)
                .myLowerDiscount()
                .asJSONType()
                .send(lowerDiscountLivaData);
    }

    /**
     * //无限代web-返水-新增方案
     */
    public void insertMyLowerDiscount(SchemeSetRebateEntity schemeSetRebateEntity) {
        NetSdk.create(Api.class)
                .insertMyLowerDiscount()
                .params(schemeSetRebateEntity)
                .send(updateDiscountLivaData);
    }
  /**
     * //无限代web-返水-更新方案
     */
    public void updateMyLowerDiscount(SchemeSetRebateEntity schemeSetRebateEntity) {
        NetSdk.create(Api.class)
                .updateMyLowerDiscount()
                .params(schemeSetRebateEntity)
                .send(updateDiscountLivaData);
    }

}
