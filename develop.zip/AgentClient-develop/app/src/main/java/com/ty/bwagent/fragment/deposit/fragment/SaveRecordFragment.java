package com.ty.bwagent.fragment.deposit.fragment;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.fragment.deposit.adapter.SaveRecoreAdapter;
import com.ty.bwagent.fragment.deposit.adapter.TurnRecoreAdapter;
import com.ty.bwagent.fragment.deposit.bean.DepositRecord;
import com.ty.bwagent.fragment.deposit.viewmodel.DepositViewModel;
import com.ty.net.callback.NetObserver;
import com.ty.utils.TimeUtils;

import java.util.List;

/**
 * 代理 代存记录
 */
public class SaveRecordFragment extends DepositBaseFragment<DepositRecord.ListBean> {

    DepositViewModel mDepositViewModel;
    ImageView iv_logo;
    TextView tv_tips;

    public static SaveRecordFragment getInstance() {
        return new SaveRecordFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_turn_save;
    }

    @Override
    protected void requestRecordData(String startDate, String endDate, int status, int pageNum, int pageSize) {
        mDepositViewModel.agentDepositRecordList(startDate,endDate,status,pageNum,pageSize);
    }

    @Override
    protected void createProvider() {
        super.createProvider();
        mDepositViewModel = new ViewModelProvider(this).get(DepositViewModel.class);
        mDepositViewModel.depositNetLiveData.observe(this,new NetObserver<BaseEntity<DepositRecord>>(){

            @Override
            protected void onSuccess(BaseEntity<DepositRecord> listBaseEntity) {
                recyclerView.setVisibility(View.VISIBLE);
                dismissProgressDialog();
                List<DepositRecord.ListBean> beanList =  listBaseEntity.getData().getList();
                if (pageNum == 1) {
                    listAdapter.setNewData(beanList);

                } else {
                    listAdapter.addData(beanList);
                }
                refreshLayout.finishRefresh();
                refreshLayout.finishLoadMore();
                if (beanList.size() < pageSize) {
                    refreshLayout.finishLoadMoreWithNoMoreData();
                }
                iv_logo.setImageResource(R.mipmap.record_empty_bg);
                tv_tips.setText("暂无代存记录");
            }

            @Override
            protected void onError(int code, String errMsg) {
                recyclerView.setVisibility(View.VISIBLE);
                dismissProgressDialog();
                refreshLayout.finishRefresh();
                refreshLayout.finishLoadMore();
                iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
                tv_tips.setText("网络不给力");
            }
        });



    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        recyclerView.setVisibility(View.INVISIBLE);
        startDate = TimeUtils.getDiffDate(-29);
        endDate = TimeUtils.getDiffDate(0);
        titleBar.setTiteTextView("代存记录");
    }



    @Override
    public View getEmptyView() {
        View empty = View.inflate(mContext, R.layout.empty_deposit_record, null);
        iv_logo = empty.findViewById(R.id.iv_logo);
        tv_tips = empty.findViewById(R.id.tv_tips);
        return empty;
    }

    @Override
    public BaseQuickAdapter<DepositRecord.ListBean, BaseViewHolder> getListAdapter() {
        return new SaveRecoreAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//        DepositRecord mDepositRecore = (DepositRecord) adapter.getItem(position);
    }




}
