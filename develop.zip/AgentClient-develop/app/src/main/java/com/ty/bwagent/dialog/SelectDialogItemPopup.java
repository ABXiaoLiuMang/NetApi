package com.ty.bwagent.dialog;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.lxj.xpopup.core.BottomPopupView;
import com.lxj.xpopup.interfaces.XPopupCallback;
import com.ty.bwagent.R;
import com.ty.bwagent.ui.MainActivity;
import com.ty.pickerview.WheelView;
import com.ty.pickerview.adapter.ArrayWheelAdapter;
import com.ty.pickerview.listener.OnItemSelectedListener;
import com.ty.utils.StringUtils;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;

/**
 * 分享对话框
 */
public class SelectDialogItemPopup extends BottomPopupView implements View.OnClickListener {

    private WheelView wheelview;
    private TextView btnCancel;
    private TextView tvTitle;
    private TextView btnSubmit;

    private String title;
    private String selectName;

    private List<String> dateList = new ArrayList<>();

    private OnClickListener onClickListener;
    private Builder builder;

    public SelectDialogItemPopup(@NonNull Context context, Builder builder) {
        super(context);
        this.builder = builder;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_select;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        initView();
        initDate();
        initListener();

    }


    private void initView() {
        wheelview = findViewById(R.id.wheelview);
        btnCancel = findViewById(R.id.btnCancel);
        tvTitle = findViewById(R.id.tvTitle);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnCancel.setOnClickListener(this);
        btnSubmit.setOnClickListener(this);
    }


    private void initDate() {

        this.title = builder.getTitle();
        this.dateList = builder.getDateList();
        this.onClickListener = builder.getOnClickListener();
        this.selectName = builder.getSelectName();
        btnSubmit.setText(builder.getBtnSubmit());

        wheelview.setAdapter(new ArrayWheelAdapter(dateList));
        wheelview.setCyclic(false);
        wheelview.setLineSpacingMultiplier(2.0f);

        if (StringUtils.isEmpty(selectName)) {
            wheelview.setCurrentItem(0);
        } else {
            for (int i = 0; i < dateList.size(); i++) {
                if (dateList.get(i).equals(selectName)) {
                    wheelview.setCurrentItem(i);
                    break;
                }
            }
        }

        if (!StringUtils.isEmpty(title)) {
            tvTitle.setText(title);
        }
    }


    private void initListener() {
        wheelview.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(int index) {

            }
        });

        btnSubmit.setOnClickListener(v -> {
            if (onClickListener != null) {
                onClickListener.OnClick(wheelview.getCurrentItem());
                dismiss();
            }

        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSubmit:
                break;
            case R.id.btnCancel:
                dismiss();
                break;
        }
    }



    public static class Builder {
        private String title;
        private String selectName;
        private String btnSubmit="确定";
        private List<String> dateList = new ArrayList<>();
        private OnClickListener onClickListener;
        private XPopupCallback xPopupCallback;
        private Boolean hasShadowBg = true; // 是否有半透明的背景

        public String getTitle() {
            return title;
        }

        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }

        public String getBtnSubmit() {
            return btnSubmit;
        }

        public Builder setBtnSubmit(String btnSubmit) {
            this.btnSubmit = btnSubmit;
            return this;
        }

        public Boolean getHasShadowBg() {
            return hasShadowBg;
        }

        public Builder setHasShadowBg(Boolean hasShadowBg) {
            this.hasShadowBg = hasShadowBg;
            return this;
        }

        public XPopupCallback getxPopupCallback() {
            return xPopupCallback;
        }

        public Builder setxPopupCallback(XPopupCallback xPopupCallback) {
            this.xPopupCallback = xPopupCallback;
            return this;
        }

        public String getSelectName() {
            return selectName;
        }

        public Builder setSelectName(String selectName) {
            this.selectName = selectName;
            return this;
        }

        public List<String> getDateList() {
            return dateList;
        }

        public Builder setDateList(List<String> dateList) {
            this.dateList = dateList;
            return this;
        }

        public OnClickListener getOnClickListener() {
            return onClickListener;
        }

        public Builder setOnClickListener(OnClickListener onClickListener) {
            this.onClickListener = onClickListener;
            return this;
        }
    }

    public interface OnClickListener {
        public void OnClick(int currentItem);
    }


}
