package com.ty.bwagent.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ty.bwagent.R;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.utils.ResUtils;
import com.ty.utils.StatusBarUtil;

public class H5Activity extends BaseAgentWebActivity {

    TitleBar titleBar;
    Bundle bundle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        bundle = getIntent().getExtras();
        super.onCreate(savedInstanceState);
        StatusBarUtil.setTransparentForWindow(this);
        StatusBarUtil.setLightMode(this);//状态栏图标黑色
        setContentView(R.layout.activity_h5);
        titleBar = findViewById(R.id.titleBar);
        titleBar.setLeftOnClickListener(view -> finish());
        titleBar.setTiteTextView(bundle.getString(ABConfig.KEY_TITLE));
    }

    @NonNull
    @Override
    protected ViewGroup getAgentWebParent() {
        return findViewById(R.id.layout);
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (mAgentWeb != null && mAgentWeb.handleKeyEvent(keyCode, event)) {
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected int getIndicatorColor() {
        return ResUtils.getColor(R.color.main_style_color);
    }

    @Override
    protected void setTitle(WebView view, String title) {
        super.setTitle(view, title);
        if (!TextUtils.isEmpty(title)) {
            if (title.length() > 10) {
                title = title.substring(0, 10).concat("...");
            }
        }
        titleBar.setTiteTextView(title);
    }

    @Override
    protected int getIndicatorHeight() {
        return 3;
    }

    @Nullable
    @Override
    protected String getUrl() {
        return bundle.getString(ABConfig.KEY_TEXT);
    }

//    protected @Nullable
//    WebChromeClient getWebChromeClient() {
//        return new WebChromeClient() {
//            @Override
//            public void onProgressChanged(WebView view, int newProgress) {
//                // 增加Javascript异常监控
//                //BuglyManager.setJavascriptMonitor(view);
//                super.onProgressChanged(view, newProgress);
//            }
//
//            @Override
//            public void onReceivedTitle(WebView view, String title) {
//                super.onReceivedTitle(view, title);
//                String mTitle = titleBar.getTiteTextView();
//                if (StringUtils.isEmpty(mTitle)) {
//                    titleBar.setTiteTextView(title);
//                }
//            }
//        };
//    }
}

