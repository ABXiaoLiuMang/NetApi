package com.ty.bwagent.fragment.share;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.ImageViewerPopupView;
import com.lxj.xpopup.enums.PopupType;
import com.lxj.xpopup.interfaces.XPopupImageLoader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.MaterialAdapter;
import com.ty.bwagent.bean.AddBankCardEntity;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MaterialEntity;
import com.ty.bwagent.bean.MaterialFilterEntity;
import com.ty.bwagent.dialog.ImagePopupView;
import com.ty.bwagent.dialog.MaterialFilterPopup;
import com.ty.bwagent.utils.DialogUtil;
import com.ty.bwagent.utils.ImageLoader;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.MaterialViewModel;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.NetworkUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;

import java.io.File;
import java.util.List;

import butterknife.BindView;

/**
 * 素材列表界面
 */
public class MaterialListFragment extends ABRefreshFragment<MaterialEntity.ListBean> implements BaseQuickAdapter.OnItemChildClickListener {

    @BindView(R.id.titleBar)
    TitleBar titleBar;

    MaterialViewModel mMaterialViewModel;
    MutableLiveData<MaterialFilterEntity> filterLiveData = new MutableLiveData<>();
    String imageType = "";
    String imageTitle = "";
    String imageSize = "";
    int pageSize = 10;
    int pageNumber = 1;
    ImageView iv_logo;
    TextView tv_tips;
    boolean loadConfing = false;

    public static MaterialListFragment getInstance() {
        return new MaterialListFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_material_list;
    }

    @Override
    protected void createProvider() {
        mMaterialViewModel = new ViewModelProvider(this).get(MaterialViewModel.class);
        filterLiveData.observe(this, filterEntity -> {
            refreshLayout.setNoMoreData(false);
            showProgressDialog();
            pageNumber = 1;
            imageSize = filterEntity.getSize();
            imageTitle = filterEntity.getTitle();
            imageType = filterEntity.getType();
            mMaterialViewModel.selectMaterialList(imageType,imageTitle,imageSize,pageSize,pageNumber);
        });
        mMaterialViewModel.materialListLiveData.observe(this,new SimpleObserver<BaseEntity<MaterialEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<MaterialEntity> materialBaseEntity) {
                dismissProgressDialog();
                if(materialBaseEntity.getData() == null){
                    listAdapter.setNewData(null);
                    return;
                }
                List<MaterialEntity.ListBean> entityList = materialBaseEntity.getData().getList();
                if (pageNumber == 1) {
                    listAdapter.setNewData(entityList);
                    refreshLayout.finishRefresh();
                    recyclerView.scrollToPosition(0);
                } else {
                    listAdapter.addData(entityList);
                    refreshLayout.finishLoadMore();
                }
                if (entityList.size() < pageSize) {
                    refreshLayout.finishLoadMoreWithNoMoreData();
                }

                iv_logo.setImageResource(R.mipmap.message_empty_bg);
                tv_tips.setText("暂无数据");
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code,errMsg);
                dismissProgressDialog();
                if(pageNumber == 1){
                    refreshLayout.finishRefresh(false);
                }else {
                    refreshLayout.finishLoadMore(false);
                }

                iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
                tv_tips.setText("网络不给力");
            }
        });

        /**
         * 推广素材图片类型
         */
        mMaterialViewModel.imageTypeLiveData.observe(this,new NetObserver<BaseEntity<List<AddBankCardEntity>>>(){
            @Override
            protected void onSuccess(BaseEntity<List<AddBankCardEntity>> listBaseEntity) {
                ((MaterialAdapter)listAdapter).setTypeKey(listBaseEntity.getData());
                loadConfing = true;
            }

            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        XLiveDataManager.getInstance().netChangeLiveData.observe(this, aBoolean -> {
            if(aBoolean){
                mMaterialViewModel.selectMaterialSizeList();//查询图片尺寸
                mMaterialViewModel.queryImageType();//查询图片类型
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        titleBar.setRightOnClickListener(view ->{
            if (DoubleClickUtils.isLongDoubleClick()) {
                return;
            }
            if(loadConfing){
                showFilterDialog();
            }else if(NetworkUtils.isConnected()){
                mMaterialViewModel.selectMaterialSizeList();//查询图片尺寸
                mMaterialViewModel.queryImageType();//查询图片类型
            }else {
                ToastUtils.showLong(ResUtils.getString(R.string.timeout_error));
            }
        });

        titleBar.setTitleRightDrawable(R.mipmap.member_ask_bg);

        //顶部提示弹窗
        titleBar.setTitleOnClickListener(view -> DialogUtil.showMaterialTipsDialog(mContext));

        listAdapter.setOnItemChildClickListener(this);
        showProgressDialog();
        mMaterialViewModel.selectMaterialList(imageType,imageTitle,imageSize,pageSize,pageNumber);
        mMaterialViewModel.selectMaterialSizeList();//查询图片尺寸
        mMaterialViewModel.queryImageType();//查询图片类型


        //获取域名
        Looper.myQueue().addIdleHandler(() -> {
            mMaterialViewModel.domainByClientType();
            return false;
        });

    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public BaseQuickAdapter<MaterialEntity.ListBean, BaseViewHolder> getListAdapter() {
        return new MaterialAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
    }

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        MaterialEntity.ListBean listBean;
        switch (view.getId()){
            case R.id.tv_big_pic:
                View iv_share_icon = ((ViewGroup) view.getParent()).findViewById(R.id.iv_share_icon);
                if (iv_share_icon != null) {
                    iv_share_icon.performClick();
                }
                break;
            case R.id.tv_code_pic:
                listBean = (MaterialEntity.ListBean) adapter.getItem(position);
                Bundle bundle = new Bundle();
                bundle.putParcelable(ABConfig.KEY_OBJECT,listBean);
                start(ShareEditFragment.getInstance(bundle));
                break;
            case R.id.iv_share_icon:
                listBean = (MaterialEntity.ListBean) adapter.getItem(position);
                showPicDialog((ImageView) view, listBean.getImageUrl(), new ImageLoader());
                break;
        }
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNumber++;
        mMaterialViewModel.selectMaterialList(imageType,imageTitle,imageSize,pageSize,pageNumber);
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        pageNumber = 1;
        mMaterialViewModel.selectMaterialList(imageType,imageTitle,imageSize,pageSize,pageNumber);
    }

    @Override
    public View getEmptyView() {
        View emptyView = View.inflate(mContext, R.layout.empty_material, null);
        iv_logo = emptyView.findViewById(R.id.iv_logo);
        tv_tips = emptyView.findViewById(R.id.tv_empty);
        return emptyView;
    }

    @Override
    public boolean onBackPressedSupport() {
        if(popupView != null && popupView.isShow()){
            popupView.dismiss();
            return true;
        }
        if(filterPopup != null && filterPopup.isShow()){
            filterPopup.dismiss();
            return true;
        }
        return super.onBackPressedSupport();
    }

    ImageViewerPopupView popupView;

    /**
     * 大图浏览对话框
     * @param srcView
     * @param url
     * @param imageLoader
     */
    private void showPicDialog(ImageView srcView, String url, XPopupImageLoader imageLoader) {
        popupView = new ImagePopupView(mContext)
                .setSingleSrcView(srcView, url)
                .isShowSaveButton(false)
                .setXPopupImageLoader(imageLoader);
        new XPopup.Builder(mContext)
                .popupType(PopupType.ImageViewer)
                .dismissOnTouchOutside(false)
                .dismissOnBackPressed(true)
                .asCustom(popupView)
                .show();
    }

    /**
     * 筛选对话框
     */
    MaterialFilterPopup filterPopup;

    private void showFilterDialog() {
        if (filterPopup == null) {
            filterPopup = new MaterialFilterPopup(mContext, filterLiveData, mMaterialViewModel.sizeListLiveData, mMaterialViewModel.imageTypeLiveData);
            new XPopup.Builder(mContext)
                    .atView(titleBar)
                    .asCustom(filterPopup);
        }
        if (filterPopup.isShow()) {
            filterPopup.dismiss();
        } else {
            filterPopup.show();
        }
    }

}
