package com.ty.bwagent.bean;

import java.util.List;

/**
 *
 */
public class TeamCommissionEntity {


    /**
     * navigatepageNums : [1]
     * startRow : 1
     * hasNextPage : false
     * prePage : 0
     * nextPage : 0
     * endRow : 3
     * pageSize : 10
     * list : [{"venueList":[],"remark":"","topName":"","categoryName":"","releaseAt":null,"netProfit":-20,"promo":0,"czProfit":-1924,"agentRemark":"","commissionStatus":0,"balance":-1924,"rate":0,"subordinateUserCount":4,"commission":0,"commissionDate":"2020-03","id":4989448,"profit":-20,"memberId":null,"plateDetail":"","rebate":0,"active":3,"agentName":"boby","draw":0,"adminName":"","lastBalance":-1904,"thirdPartySpend":0,"inviteCode":2081202,"deposit":200,"isCaptain":1,"riskAdjust":0,"category":1,"correction":0},{"venueList":[],"remark":"","topName":"","categoryName":"","releaseAt":null,"netProfit":0,"promo":0,"czProfit":-11981.06,"agentRemark":"","commissionStatus":0,"balance":-11981.06,"rate":0,"subordinateUserCount":9,"commission":0,"commissionDate":"2020-03","id":4989224,"profit":0,"memberId":null,"plateDetail":"","rebate":0,"active":0,"agentName":"Easyhou","draw":0,"adminName":"","lastBalance":-11981.06,"thirdPartySpend":0,"inviteCode":8647669,"deposit":0,"isCaptain":0,"riskAdjust":0,"category":1,"correction":0},{"venueList":[],"remark":"","topName":"testouou","categoryName":"","releaseAt":null,"netProfit":0,"promo":0,"czProfit":0,"agentRemark":"","commissionStatus":0,"balance":0,"rate":0,"subordinateUserCount":0,"commission":0,"commissionDate":"2020-03","id":7393846,"profit":0,"memberId":null,"plateDetail":"","rebate":0,"active":0,"agentName":"ouou6","draw":0,"adminName":"","lastBalance":0,"thirdPartySpend":0,"inviteCode":9496093,"deposit":0,"isCaptain":0,"riskAdjust":0,"category":0,"correction":0}]
     * pageNum : 1
     * navigatePages : 8
     * navigateFirstPage : 1
     * total : 3
     * pages : 1
     * size : 3
     * isLastPage : true
     * hasPreviousPage : false
     * navigateLastPage : 1
     * isFirstPage : true
     */

    private int startRow;
    private boolean hasNextPage;
    private int prePage;
    private int nextPage;
    private int endRow;
    private int pageSize;
    private int pageNum;
    private int navigatePages;
    private int navigateFirstPage;
    private int total;
    private int pages;
    private int size;
    private boolean isLastPage;
    private boolean hasPreviousPage;
    private int navigateLastPage;
    private boolean isFirstPage;
    private List<Integer> navigatepageNums;
    private List<ListBean> list;
    private TotalSumVo totalSumVo;

    public TotalSumVo getTotalSumVo() {
        return totalSumVo;
    }

    public void setTotalSumVo(TotalSumVo totalSumVo) {
        this.totalSumVo = totalSumVo;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public List<Integer> getNavigatepageNums() {
        return navigatepageNums;
    }

    public void setNavigatepageNums(List<Integer> navigatepageNums) {
        this.navigatepageNums = navigatepageNums;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }


    public static class TotalSumVo {

        /**
         * activeSum : 1
         * commissionSum : 0.0
         * correctionSum : 0.0
         * czProfitSum : -27810.12
         * lastBalanceSum : -27810.12
         * netProfitSum : 0.0
         * rate : 0.0
         * subordinateUserCountSum : 20
         */

        private long activeSum;
        private double commissionSum;
        private double correctionSum;
        private double czProfitSum;
        private double lastBalanceSum;
        private double netProfitSum;
        private double rate;
        private long subordinateUserCountSum;

        public long getActiveSum() {
            return activeSum;
        }

        public void setActiveSum(long activeSum) {
            this.activeSum = activeSum;
        }

        public double getCommissionSum() {
            return commissionSum;
        }

        public void setCommissionSum(double commissionSum) {
            this.commissionSum = commissionSum;
        }

        public double getCorrectionSum() {
            return correctionSum;
        }

        public void setCorrectionSum(double correctionSum) {
            this.correctionSum = correctionSum;
        }

        public double getCzProfitSum() {
            return czProfitSum;
        }

        public void setCzProfitSum(double czProfitSum) {
            this.czProfitSum = czProfitSum;
        }

        public double getLastBalanceSum() {
            return lastBalanceSum;
        }

        public void setLastBalanceSum(double lastBalanceSum) {
            this.lastBalanceSum = lastBalanceSum;
        }

        public double getNetProfitSum() {
            return netProfitSum;
        }

        public void setNetProfitSum(double netProfitSum) {
            this.netProfitSum = netProfitSum;
        }

        public double getRate() {
            return rate;
        }

        public void setRate(double rate) {
            this.rate = rate;
        }

        public long getSubordinateUserCountSum() {
            return subordinateUserCountSum;
        }

        public void setSubordinateUserCountSum(long subordinateUserCountSum) {
            this.subordinateUserCountSum = subordinateUserCountSum;
        }
    }

    public static class ListBean {
        /**
         * venueList : []
         * remark :
         * topName :
         * categoryName :
         * releaseAt : null
         * netProfit : -20.0
         * promo : 0.0
         * czProfit : -1924.0
         * agentRemark :
         * commissionStatus : 0
         * balance : -1924.0
         * rate : 0.0
         * subordinateUserCount : 4
         * commission : 0.0
         * commissionDate : 2020-03
         * id : 4989448
         * profit : -20.0
         * memberId : null
         * plateDetail :
         * rebate : 0.0
         * active : 3
         * agentName : boby
         * draw : 0.0
         * adminName :
         * lastBalance : -1904.0
         * thirdPartySpend : 0.0
         * inviteCode : 2081202
         * deposit : 200.0
         * isCaptain : 1
         * riskAdjust : 0.0
         * category : 1
         * correction : 0.0
         */

        private String remark;
        private String topName;
        private String categoryName;
        private Object releaseAt;
        private double netProfit;
        private double promo;
        private double czProfit;
        private String agentRemark;
        private int commissionStatus;
        private double balance;
        private double rate;
        private long subordinateUserCount;
        private double commission;
        private String commissionDate;
        private int id;
        private double profit;
        private Object memberId;
        private String plateDetail;
        private double rebate;
        private long active;
        private String agentName;
        private double draw;
        private String adminName;
        private double lastBalance;
        private double thirdPartySpend;
        private int inviteCode;
        private double deposit;
        private int isCaptain;
        private double riskAdjust;
        private int category;
        private double correction;
        private List<?> venueList;

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getTopName() {
            return topName;
        }

        public void setTopName(String topName) {
            this.topName = topName;
        }

        public String getCategoryName() {
            return categoryName;
        }

        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }

        public Object getReleaseAt() {
            return releaseAt;
        }

        public void setReleaseAt(Object releaseAt) {
            this.releaseAt = releaseAt;
        }

        public double getNetProfit() {
            return netProfit;
        }

        public void setNetProfit(double netProfit) {
            this.netProfit = netProfit;
        }

        public double getPromo() {
            return promo;
        }

        public void setPromo(double promo) {
            this.promo = promo;
        }

        public double getCzProfit() {
            return czProfit;
        }

        public void setCzProfit(double czProfit) {
            this.czProfit = czProfit;
        }

        public String getAgentRemark() {
            return agentRemark;
        }

        public void setAgentRemark(String agentRemark) {
            this.agentRemark = agentRemark;
        }

        public int getCommissionStatus() {
            return commissionStatus;
        }

        public void setCommissionStatus(int commissionStatus) {
            this.commissionStatus = commissionStatus;
        }

        public double getBalance() {
            return balance;
        }

        public void setBalance(double balance) {
            this.balance = balance;
        }

        public double getRate() {
            return rate;
        }

        public void setRate(double rate) {
            this.rate = rate;
        }

        public long getSubordinateUserCount() {
            return subordinateUserCount;
        }

        public void setSubordinateUserCount(long subordinateUserCount) {
            this.subordinateUserCount = subordinateUserCount;
        }

        public double getCommission() {
            return commission;
        }

        public void setCommission(double commission) {
            this.commission = commission;
        }

        public String getCommissionDate() {
            return commissionDate;
        }

        public void setCommissionDate(String commissionDate) {
            this.commissionDate = commissionDate;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public double getProfit() {
            return profit;
        }

        public void setProfit(double profit) {
            this.profit = profit;
        }

        public Object getMemberId() {
            return memberId;
        }

        public void setMemberId(Object memberId) {
            this.memberId = memberId;
        }

        public String getPlateDetail() {
            return plateDetail;
        }

        public void setPlateDetail(String plateDetail) {
            this.plateDetail = plateDetail;
        }

        public double getRebate() {
            return rebate;
        }

        public void setRebate(double rebate) {
            this.rebate = rebate;
        }

        public long getActive() {
            return active;
        }

        public void setActive(long active) {
            this.active = active;
        }

        public String getAgentName() {
            return agentName;
        }

        public void setAgentName(String agentName) {
            this.agentName = agentName;
        }

        public double getDraw() {
            return draw;
        }

        public void setDraw(double draw) {
            this.draw = draw;
        }

        public String getAdminName() {
            return adminName;
        }

        public void setAdminName(String adminName) {
            this.adminName = adminName;
        }

        public double getLastBalance() {
            return lastBalance;
        }

        public void setLastBalance(double lastBalance) {
            this.lastBalance = lastBalance;
        }

        public double getThirdPartySpend() {
            return thirdPartySpend;
        }

        public void setThirdPartySpend(double thirdPartySpend) {
            this.thirdPartySpend = thirdPartySpend;
        }

        public int getInviteCode() {
            return inviteCode;
        }

        public void setInviteCode(int inviteCode) {
            this.inviteCode = inviteCode;
        }

        public double getDeposit() {
            return deposit;
        }

        public void setDeposit(double deposit) {
            this.deposit = deposit;
        }

        public int getIsCaptain() {
            return isCaptain;
        }

        public void setIsCaptain(int isCaptain) {
            this.isCaptain = isCaptain;
        }

        public double getRiskAdjust() {
            return riskAdjust;
        }

        public void setRiskAdjust(double riskAdjust) {
            this.riskAdjust = riskAdjust;
        }

        public int getCategory() {
            return category;
        }

        public void setCategory(int category) {
            this.category = category;
        }

        public double getCorrection() {
            return correction;
        }

        public void setCorrection(double correction) {
            this.correction = correction;
        }

        public List<?> getVenueList() {
            return venueList;
        }

        public void setVenueList(List<?> venueList) {
            this.venueList = venueList;
        }
    }
}
