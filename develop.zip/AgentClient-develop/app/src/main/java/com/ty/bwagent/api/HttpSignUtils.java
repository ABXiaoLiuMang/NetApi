package com.ty.bwagent.api;

import com.bw.tmapmanager.domains.TmapDomainsManager;
import com.bw.tmapmanager.utils.EmptyUtils;
import com.bw.tmapmanager.utils.Logutils;
import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.utils.Key;
import com.ty.utils.AppUtil;
import com.ty.utils.MMKVUtil;

import java.util.HashMap;
import java.util.Map;

import okhttp3.Request;

public class HttpSignUtils {


    /**
     * 设置公共响应头
     *
     * @return
     */
    public static HashMap getBaseHeader() {

        HashMap<String,String> headHashMap = new HashMap<>();
        headHashMap.put("TB-CLIENT-TYPE", "agent_android");//客户端信息
        headHashMap.put("TB-VERSION", AppUtil.getVersionName());//当前app版本号
        headHashMap.put("Content-Type", "application/json");
        headHashMap.put("TB-CLIENT-FINANCE-TYPE", "app");
        headHashMap.put("X-KK-APPKEY", Key.appkey);
        headHashMap.put("Accept-Encoding", "gzip deflate");
        headHashMap.put("TB-UUID", AppUtil.getUUID());//客户端唯一识别码
        headHashMap.put("TB-TOKEN", MMKVUtil.getString(Key.LOGIN_TOKEN, ""));//会员token
        headHashMap.put("TB-AGENT-TOKEN", MMKVUtil.getString(Key.AGENT_TOKEN, ""));//代理登录token
        headHashMap.put("TB-SITE-ID", BuildConfig.appType);//站点Id

        return headHashMap;
    }


    public static Request addHeader(Map<String, String> childMap, String signUrl){
        Request.Builder builder = new Request.Builder();
        if (!EmptyUtils.mapIsEmpty(childMap)) {
            for (Map.Entry<String, String> child : childMap.entrySet()) {
                String key = child.getKey();
                String value = child.getValue();
                if (EmptyUtils.stringIsEmpty(key) || EmptyUtils.stringIsEmpty(value)) {
                    continue;
                }
                Logutils.logi("key===" + key + "\n value===" + value);
                builder.addHeader(key, value);
            }
        }
        Request request = builder.url(signUrl).get().build();
        return request;
    }

    /**
     * 域名初始化
     * @param host：域名
     * @param alscdnToken：alscdn平台的Token
     * @param yundunToken：yundun平台的Token
     * @param chuangyuToken：chuangyu平台的Token
     */
    public static void signParams(String host, String alscdnToken, String yundunToken, String chuangyuToken){
        Map<String, Object> parentMap = new HashMap<>();
        Map<String, String> childMapSign = new HashMap<>();
        if (null != alscdnToken){
            childMapSign.put("alscdn", alscdnToken);
        }
        if (null != yundunToken){
            childMapSign.put("yundun", yundunToken);
        }

        if (null != chuangyuToken){
            childMapSign.put("chuangyu", chuangyuToken);
        }
        if (EmptyUtils.stringIsEmpty(host)){
            Logutils.logi("域名不能为空");
            return;
        }
        parentMap.put(host, childMapSign);
        TmapDomainsManager.getInstance().updateCDNmainHost(parentMap);
    }
}

