package com.ty.bwagent.bean;

import java.util.List;

public class TeamMenberInfoEntity {


    /**
     * teamName : sdkjfahsl
     * navigatepageNums : [1]
     * startRow : 1
     * hasNextPage : false
     * prePage : 0
     * nextPage : 0
     * endRow : 1
     * pageSize : 10
     * list : [{"createdAt":"2020-02-08 00:32:10","captainId":0,"tStatus":"0","inviteCode":"2081202","teamId":23,"agentName":"boby","isCaptain":1,"id":4897,"subMemberNum":4,"memberId":201095,"updatedAt":"2020-02-08 18:12:20"}]
     * pageNum : 1
     * navigatePages : 8
     * navigateFirstPage : 1
     * total : 1
     * pages : 1
     * size : 1
     * subMemberCount : 13
     * isLastPage : true
     * hasPreviousPage : false
     * navigateLastPage : 1
     * isFirstPage : true
     * agentCount : 3
     */

    private String teamName;
    private int startRow;
    private boolean hasNextPage;
    private int prePage;
    private int nextPage;
    private int endRow;
    private int pageSize;
    private int pageNum;
    private int navigatePages;
    private int navigateFirstPage;
    private int total;
    private int pages;
    private int size;
    private int subMemberCount;
    private boolean isLastPage;
    private boolean hasPreviousPage;
    private int navigateLastPage;
    private boolean isFirstPage;
    private int agentCount;
    private List<Integer> navigatepageNums;
    private List<ListBean> list;

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getSubMemberCount() {
        return subMemberCount;
    }

    public void setSubMemberCount(int subMemberCount) {
        this.subMemberCount = subMemberCount;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public int getAgentCount() {
        return agentCount;
    }

    public void setAgentCount(int agentCount) {
        this.agentCount = agentCount;
    }

    public List<Integer> getNavigatepageNums() {
        return navigatepageNums;
    }

    public void setNavigatepageNums(List<Integer> navigatepageNums) {
        this.navigatepageNums = navigatepageNums;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * createdAt : 2020-02-08 00:32:10
         * captainId : 0
         * tStatus : 0
         * inviteCode : 2081202
         * teamId : 23
         * agentName : boby
         * isCaptain : 1
         * id : 4897
         * subMemberNum : 4
         * memberId : 201095
         * updatedAt : 2020-02-08 18:12:20
         */

        private String createdAt;
        private int captainId;
        private String tStatus;
        private String inviteCode;
        private int teamId;
        private String agentName;
        private int isCaptain;
        private int id;
        private String subMemberNum;
        private int memberId;
        private String updatedAt;


        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public int getCaptainId() {
            return captainId;
        }

        public void setCaptainId(int captainId) {
            this.captainId = captainId;
        }

        public String getTStatus() {
            return tStatus;
        }

        public void setTStatus(String tStatus) {
            this.tStatus = tStatus;
        }

        public String getInviteCode() {
            return inviteCode;
        }

        public void setInviteCode(String inviteCode) {
            this.inviteCode = inviteCode;
        }

        public int getTeamId() {
            return teamId;
        }

        public void setTeamId(int teamId) {
            this.teamId = teamId;
        }

        public String getAgentName() {
            return agentName;
        }

        public void setAgentName(String agentName) {
            this.agentName = agentName;
        }

        public int getIsCaptain() {
            return isCaptain;
        }

        public void setIsCaptain(int isCaptain) {
            this.isCaptain = isCaptain;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getSubMemberNum() {
            return subMemberNum;
        }

        public void setSubMemberNum(String subMemberNum) {
            this.subMemberNum = subMemberNum;
        }

        public int getMemberId() {
            return memberId;
        }

        public void setMemberId(int memberId) {
            this.memberId = memberId;
        }

        public String getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
        }
    }
}
