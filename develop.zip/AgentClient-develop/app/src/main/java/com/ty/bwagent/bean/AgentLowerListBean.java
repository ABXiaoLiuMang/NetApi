package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class AgentLowerListBean {


    /**
     * endRow : 9
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : true
     * isLastPage : true
     * list : [{"agentIds":"","agentLevel":null,"agentName":"test005","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":111225,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"mmmnnn133","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":92019143607,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"mmmnnn212","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":92019143608,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"mmmnnn123","commission":0,"commissionDate":"","createdAt":"2020-07-17 17:11:13","czProfit":0,"lastBalance":0,"memberCount":0,"memberId":92019143609,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"thor111","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":92019143610,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"thor112","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":92019143611,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"thor113","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":92019143612,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"thor1111","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":92019143613,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"test001","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":111221,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null},{"agentIds":"","agentLevel":null,"agentName":"ggyhhhhh","commission":0,"commissionDate":"","createdAt":null,"czProfit":0,"lastBalance":0,"memberCount":0,"memberId":92019143614,"netProfit":0,"rate":"","subordinateUserCount":0,"topId":null}]
     * navigateFirstPage : 1
     * navigateLastPage : 1
     * navigatePages : 8
     * navigatepageNums : [1]
     * nextPage : 0
     * pageNum : 1
     * pageSize : 10
     * pages : 1
     * prePage : 0
     * size : 10
     * startRow : 0
     * total : 10
     */

    private int endRow;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private int navigateFirstPage;
    private int navigateLastPage;
    private int navigatePages;
    private int nextPage;
    private int pageNum;
    private int pageSize;
    private int pages;
    private int prePage;
    private int size;
    private int startRow;
    private int total;
    private List<ListBean> list;
    private List<Integer> navigatepageNums;

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public List<Integer> getNavigatepageNums() {
        return navigatepageNums;
    }

    public void setNavigatepageNums(List<Integer> navigatepageNums) {
        this.navigatepageNums = navigatepageNums;
    }

    public static class ListBean implements Parcelable {
        /**
         * agentIds :
         * agentLevel : null
         * agentName : test005
         * commission : 0
         * commissionDate :
         * createdAt : null
         * czProfit : 0
         * lastBalance : 0
         * memberCount : 0
         * memberId : 111225
         * netProfit : 0
         * rate :
         * subordinateUserCount : 0
         * topId : null
         */

        private String agentIds;
        private Object agentLevel;
        private String agentName;
        private double commission;
        private String commissionDate;
        private String createdAt;
        private double czProfit;
        private double lastBalance;
        private long memberCount;
        private double memberId;
        private double netProfit;
        private String rate;
        private long subordinateUserCount;
        private String topId;

        protected ListBean(Parcel in) {
            agentIds = in.readString();
            agentName = in.readString();
            commission = in.readDouble();
            commissionDate = in.readString();
            createdAt = in.readString();
            czProfit = in.readDouble();
            lastBalance = in.readDouble();
            memberCount = in.readLong();
            memberId = in.readDouble();
            netProfit = in.readDouble();
            rate = in.readString();
            subordinateUserCount = in.readLong();
            topId = in.readString();
        }

        public static final Creator<ListBean> CREATOR = new Creator<ListBean>() {
            @Override
            public ListBean createFromParcel(Parcel in) {
                return new ListBean(in);
            }

            @Override
            public ListBean[] newArray(int size) {
                return new ListBean[size];
            }
        };

        public String getAgentIds() {
            return agentIds;
        }

        public void setAgentIds(String agentIds) {
            this.agentIds = agentIds;
        }

        public Object getAgentLevel() {
            return agentLevel;
        }

        public void setAgentLevel(Object agentLevel) {
            this.agentLevel = agentLevel;
        }

        public String getAgentName() {
            return agentName;
        }

        public void setAgentName(String agentName) {
            this.agentName = agentName;
        }

        public double getCommission() {
            return commission;
        }

        public void setCommission(double commission) {
            this.commission = commission;
        }

        public String getCommissionDate() {
            return commissionDate;
        }

        public void setCommissionDate(String commissionDate) {
            this.commissionDate = commissionDate;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public double getCzProfit() {
            return czProfit;
        }

        public void setCzProfit(double czProfit) {
            this.czProfit = czProfit;
        }

        public double getLastBalance() {
            return lastBalance;
        }

        public void setLastBalance(double lastBalance) {
            this.lastBalance = lastBalance;
        }

        public long getMemberCount() {
            return memberCount;
        }

        public void setMemberCount(long memberCount) {
            this.memberCount = memberCount;
        }

        public double getMemberId() {
            return memberId;
        }

        public void setMemberId(double memberId) {
            this.memberId = memberId;
        }

        public double getNetProfit() {
            return netProfit;
        }

        public void setNetProfit(double netProfit) {
            this.netProfit = netProfit;
        }

        public String getRate() {
            return rate;
        }

        public void setRate(String rate) {
            this.rate = rate;
        }

        public long getSubordinateUserCount() {
            return subordinateUserCount;
        }

        public void setSubordinateUserCount(long subordinateUserCount) {
            this.subordinateUserCount = subordinateUserCount;
        }

        public String getTopId() {
            return topId;
        }

        public void setTopId(String topId) {
            this.topId = topId;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(agentIds);
            dest.writeString(agentName);
            dest.writeDouble(commission);
            dest.writeString(commissionDate);
            dest.writeString(createdAt);
            dest.writeDouble(czProfit);
            dest.writeDouble(lastBalance);
            dest.writeLong(memberCount);
            dest.writeDouble(memberId);
            dest.writeDouble(netProfit);
            dest.writeString(rate);
            dest.writeLong(subordinateUserCount);
            dest.writeString(topId);
        }
    }
}
