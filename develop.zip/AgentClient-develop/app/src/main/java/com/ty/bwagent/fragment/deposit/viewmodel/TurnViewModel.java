package com.ty.bwagent.fragment.deposit.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.TurnUserEntity;
import com.ty.bwagent.utils.Md5Util;
import com.ty.bwagent.viewmodel.CodeViewModel;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

/**
 * 代理 转账
 */
public class TurnViewModel extends CodeViewModel {

    //代理转账提交结果
    public NetLiveData<BaseEntity> depositTurnLiveData = new NetLiveData<>();

    //代理转账-获取下级用户信息接口
    public NetLiveData<BaseEntity<TurnUserEntity>> turnUserInfoLiveData = new NetLiveData<>();

    //官代转账提交
    public void commitMainTurn(int proxyType, String account,String money,String password,String note){
        NetSdk.create(Api.class)
                .agentTransfer()
                .params("proxyType",proxyType)//转账类型 0 佣金转账 1额度转账
                .params("agentName",account)
                .params("amount",money)
                .params("payPassword", Md5Util.md5(password))
                .params("remark",note)
                .params("validateType","2")//1 手机短信 2 支付密码
                .asJSONType()
                .send(depositTurnLiveData);
    }

    //普代转账提交
    public void commitLowerTurn(int proxyType, String account,String money,String code,String note){
        NetSdk.create(Api.class)
                .agentTransfer()
                .params("proxyType",proxyType)//转账类型 0 佣金转账 1额度转账
                .params("agentName",account)
                .params("amount",money)
                .params("phoneCode", code)
                .params("remark",note)
                .params("validateType","1")//1 手机短信 2 支付密码
                .asJSONType()
                .send(depositTurnLiveData);
    }

    //代理转账-获取下级用户信息接口
    public void agentTransferInfo(String agentName){
        NetSdk.create(Api.class)
                .agentTransferInfo()
                .params("agentName",agentName)
                .asJSONType()
                .send(turnUserInfoLiveData);
    }
}
