package com.ty.bwagent.dialog;

import android.content.Context;

import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.utils.ResUtils;

import androidx.annotation.NonNull;

public class CommonDialogPopView extends ConfirmPopupView {

    protected int contentTextColor;


    public CommonDialogPopView(@NonNull Context context) {
        super(context);
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        if (contentTextColor != 0) {
            tv_cancel.setTextColor(ResUtils.getColor(contentTextColor));
        }
    }
}
