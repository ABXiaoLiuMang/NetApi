package com.ty.bwagent.bean;

import java.util.List;

/**
 * 返佣方案返回对象
 */
public class SchemeSetRebateEntity {


    private List<RebateDetailBean> rebateDetail;

    public List<RebateDetailBean> getRebateDetail() {
        return rebateDetail;
    }

    public void setRebateDetail(List<RebateDetailBean> rebateDetail) {
        this.rebateDetail = rebateDetail;
    }

    public static class RebateDetailBean {
        /**
         * rate : 0.5
         * name : 电竞
         * id : 2
         * profit : 1000
         */

        private String rate;
        private String name;
        private String id;

        public String getRate() {
            return rate;
        }

        public void setRate(String rate) {
            this.rate = rate;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }


        @Override
        public String toString() {
            return "RebateDetailBean{" +
                    "rate='" + rate + '\'' +
                    ", name='" + name + '\'' +
                    ", id='" + id + '\'' +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "SchemeSetCommissionEntity{" +
                "rebateDetail=" + rebateDetail +
                '}';
    }
}
