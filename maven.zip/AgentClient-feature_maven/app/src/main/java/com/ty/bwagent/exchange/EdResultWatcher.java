package com.ty.bwagent.exchange;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.EditText;

import java.lang.ref.WeakReference;


public class EdResultWatcher implements TextWatcher {

    private EditText edInput;
    private WeakReference<ExchangeFragment> fragmentWeakReference;


    public EdResultWatcher(EditText edInput, ExchangeFragment exchangeFragment) {
        this.edInput = edInput;
        fragmentWeakReference = new WeakReference<>(exchangeFragment);
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {


    }

    @Override
    public void afterTextChanged(Editable editable) {
        if (!StringUtils.touzi_ed_values22.equals(edInput.getText().toString().trim().replaceAll(",", ""))) {
            edInput.setText(StringUtils.addComma(edInput.getText().toString().trim().replaceAll(",", ""), edInput));
            edInput.setSelection(StringUtils.addComma(edInput.getText().toString().trim().replaceAll(",", ""), edInput).length());
        }
        if (!edInput.getText().toString().equals("0") && !TextUtils.isEmpty(edInput.getText().toString())) {
            if (edInput.getText().toString().length() > 6) {
                edInput.setTextSize(30);
            } else {
                edInput.setTextSize(40);
            }
            if (edInput != fragmentWeakReference.get().edCurrentResult) {
                edInput.setTextSize(30);
            }
        }

        if (edInput.getText().toString().length() == 0) {
            edInput.setHint("1");
//            if (fragmentWeakReference.get() != null) {
//                fragmentWeakReference.get().calculateExchange(true);
//            }
        }
    }
}
