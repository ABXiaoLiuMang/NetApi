package com.ty.bwagent.fragment.login;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ForgetPassEntity;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.view.XPassWordView;
import com.ty.bwagent.viewmodel.ForgetPassWordViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.StringUtils;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 找回密码第二步
 */
public class ForgetSetp2Fragment extends ABBaseFragment {

    @BindView(R.id.forget_phone_warning)
    TextView forgetPhoneWarning;

    @BindView(R.id.forget_commit)
    TextView forgetCommit;

    ForgetPassWordViewModel forgetPhoneViewModel;
    @BindView(R.id.x_newPass)
    XPassWordView xNewPass;
    @BindView(R.id.x_confirmPass)
    XPassWordView xConfirmPass;
    String passWord;
    String surePassWord;
    ForgetPassEntity passEntity;

    public static ForgetSetp2Fragment getInstance(ForgetPassEntity passEntity) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(ABConfig.KEY_OBJECT,passEntity);
        ForgetSetp2Fragment setp2Fragment = new ForgetSetp2Fragment();
        setp2Fragment.setArguments(bundle);
        return setp2Fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_forget_setp2;
    }

    @Override
    protected void createProvider() {
        forgetPhoneViewModel = new ViewModelProvider(this).get(ForgetPassWordViewModel.class);
        forgetPhoneViewModel.findThreeLiveData.observe(this, new SimpleObserver<BaseEntity>() {

            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                passEntity.setPassword(passWord);
                start(ForgetSetp3Fragment.getInstance(passEntity));
            }

            @Override
            protected void onLoading(boolean show) {
                if (show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        passEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        initVerify();
    }

    @OnClick({R.id.forget_commit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.forget_commit:
                passWord = xNewPass.getPassText();
                surePassWord = xConfirmPass.getPassText();

                if(StringUtils.equals(passWord,surePassWord)){
                    forgetPhoneWarning.setText("");
                }else {
                    forgetPhoneWarning.setText("两次密码输入不一致");
                    return;
                }


                if(passEntity.isFromPhone()){//电话
                    forgetPhoneViewModel.forgetByPhoneThree(passEntity.getName(),passEntity.getPhone(),passEntity.getCode(),passEntity.getImgCode(),passWord,surePassWord);
                }else {//邮箱
                    forgetPhoneViewModel.forgetByEmailThree(passEntity.getName(),passEntity.getEmail(),passEntity.getCode(),passEntity.getImgCode(),passWord,surePassWord);
                }
                KeyboardUtils.hideSoftInput(view);
                break;
        }
    }


    /**
     * 处理各类输入框验证逻辑
     */
    private void initVerify(){
        new InputResultCalculator(Arrays.asList(xNewPass.getPassEditText(), xConfirmPass.getPassEditText()), ok -> {
             passWord = xNewPass.getPassText();
             surePassWord = xConfirmPass.getPassText();
             if(VerifyUtils.isUserPassWord(passWord) && VerifyUtils.isUserPassWord(surePassWord)){
                 forgetCommit.setEnabled(ok);
             }else {
                 forgetCommit.setEnabled(false);
             }
        });

        VerifyUtils.verifyPassWord(xNewPass.getPassEditText(),forgetPhoneWarning);
        VerifyUtils.verifyPassWord(xConfirmPass.getPassEditText(),forgetPhoneWarning);
    }
}
