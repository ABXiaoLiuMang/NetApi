package com.ty.bwagent.fragment;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.lxj.xpopup.XPopup;
import com.ty.bwagent.R;
import com.ty.bwagent.dialog.MemberFilterPopup;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.KeyboardUtils;

import java.util.ArrayList;

/**
 * 团队中心
 */
public class TeamCenterTabFragment extends BaseViewPagerFragment {

    public static TeamCenterTabFragment getInstance() {
        return new TeamCenterTabFragment();
    }

    ArrayList<Fragment> fragments = new ArrayList<>();

    @Override
    public Fragment getCurrentItem(int position) {
        if (position == 0) {
            MemberMangerFragment fragment = MemberMangerFragment.getInstance();
            fragments.add(fragment);
            return fragment;
        } else {
            MemberFinacialCommisionFragment fragment = MemberFinacialCommisionFragment.getInstance(position);
            fragments.add(fragment);
            return fragment;
        }
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_member_tab_center;
    }

    @Override
    protected void createProvider() {

        viewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                KeyboardUtils.hideSoftInput(titleBar);
            }
        });
        viewPager.setOffscreenPageLimit(2);

        titleBar.setRightOnClickListener(view -> {
            if (DoubleClickUtils.isLongDoubleClick()) {
                return;
            }
            showManagerFilterDialog((time, name) -> {
                try {
                    if (viewPager.getCurrentItem() == 0) {
                        MemberMangerFragment fragment = (MemberMangerFragment) fragments.get(0);
                        fragment.searchDate(name);
                    } else {
                        MemberFinacialCommisionFragment fragment = (MemberFinacialCommisionFragment) fragments.get(viewPager.getCurrentItem());
                        fragment.searchDate(name, time);
                    }
                }catch (Exception e){

                }
            });
        });
    }

    @Override
    public String[] getTabTitles() {
        return new String[]{"团队管理", "团队财务", "团队佣金"};
    }

    @Override
    public void onStop() {
        super.onStop();
        KeyboardUtils.hideSoftInput(titleBar);
    }


    @Override
    public boolean onBackPressedSupport() {
        if (memberFilterPopup != null && memberFilterPopup.isShow()) {
            memberFilterPopup.dismiss();
            return true;
        }
        return super.onBackPressedSupport();
    }

    /**
     * 筛选对话框
     */
    MemberFilterPopup memberFilterPopup;

    private void showManagerFilterDialog(MemberFilterPopup.OnFilterCallBackListener onFilterCallBackListener) {
        if (memberFilterPopup == null) {
            memberFilterPopup = new MemberFilterPopup(this, viewPager.getCurrentItem(), onFilterCallBackListener);
            new XPopup.Builder(mContext)
                    .atView(titleBar)
                    .asCustom(memberFilterPopup);
        }
        memberFilterPopup.setFragPositon(viewPager.getCurrentItem());
        if (memberFilterPopup.isShow()) {
            memberFilterPopup.dismiss();
        } else {
            memberFilterPopup.show();
        }
    }
}
