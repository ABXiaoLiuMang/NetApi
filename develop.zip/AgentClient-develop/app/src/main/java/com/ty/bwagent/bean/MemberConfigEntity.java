package com.ty.bwagent.bean;

public class MemberConfigEntity {

    /**
     * agentDepositSetting : {"max":1000.1,"min":100.1,"stint":10000.1}
     * showAgentDeposit : 0
     * showAgentDepositMenu : 0
     * showTeamModel : 1
     * teamModelSetting : {"max":10000,"min":1000,"stint":20000}
     */

    //代存限额设置
    private AgentDepositSettingBean agentDepositSetting;
    private int showAgentDeposit;//是否展示代理代存tab 0展示 1隐藏
    private int showAgentDepositMenu;//是否展示代理代存菜单 0展示 1隐藏
    private int showTeamModel;//是否展示团队模式,代理转账tab 0展示 1隐藏
    private int showFlowRatio;//是否展示流水 0展示 1隐藏（代理代存）
    //转账限额设置
    private TeamModelSettingBean teamModelSetting;

    public AgentDepositSettingBean getAgentDepositSetting() {
        return agentDepositSetting;
    }

    public void setAgentDepositSetting(AgentDepositSettingBean agentDepositSetting) {
        this.agentDepositSetting = agentDepositSetting;
    }

    public int getShowAgentDeposit() {
        return showAgentDeposit;
    }

    public void setShowAgentDeposit(int showAgentDeposit) {
        this.showAgentDeposit = showAgentDeposit;
    }

    public int getShowAgentDepositMenu() {
        return showAgentDepositMenu;
    }

    public void setShowAgentDepositMenu(int showAgentDepositMenu) {
        this.showAgentDepositMenu = showAgentDepositMenu;
    }

    public int getShowTeamModel() {
        return showTeamModel;
    }

    public void setShowTeamModel(int showTeamModel) {
        this.showTeamModel = showTeamModel;
    }

    public int getShowFlowRatio() {
        return showFlowRatio;
    }

    public void setShowFlowRatio(int showFlowRatio) {
        this.showFlowRatio = showFlowRatio;
    }

    public TeamModelSettingBean getTeamModelSetting() {
        return teamModelSetting;
    }

    public void setTeamModelSetting(TeamModelSettingBean teamModelSetting) {
        this.teamModelSetting = teamModelSetting;
    }

    public static class AgentDepositSettingBean {
        /**
         * max : 1000.1
         * min : 100.1
         * stint : 10000.1
         */

        private double max;
        private double min;
        private double stint;

        public double getMax() {
            return max;
        }

        public void setMax(double max) {
            this.max = max;
        }

        public double getMin() {
            return min;
        }

        public void setMin(double min) {
            this.min = min;
        }

        public double getStint() {
            return stint;
        }

        public void setStint(double stint) {
            this.stint = stint;
        }
    }

    public static class TeamModelSettingBean {
        /**
         * max : 10000.0
         * min : 1000.0
         * stint : 20000.0
         */

        private double max;
        private double min;
        private double stint;

        public double getMax() {
            return max;
        }

        public void setMax(double max) {
            this.max = max;
        }

        public double getMin() {
            return min;
        }

        public void setMin(double min) {
            this.min = min;
        }

        public double getStint() {
            return stint;
        }

        public void setStint(double stint) {
            this.stint = stint;
        }
    }
}
