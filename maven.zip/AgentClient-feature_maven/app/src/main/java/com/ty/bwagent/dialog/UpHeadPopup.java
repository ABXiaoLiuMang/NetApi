package com.ty.bwagent.dialog;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.lxj.xpopup.core.BottomPopupView;
import com.lzy.imagepicker.ImagePicker;
import com.lzy.imagepicker.ui.ImageGridActivity;
import com.lzy.imagepicker.util.GlideImageLoader;
import com.lzy.imagepicker.view.CropImageView;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.ui.ImageCameraGridActivity;
import com.ty.constant.PermissionConstants;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.ToastUtils;

/**
 * 上传头像选择对话框
 */
public class UpHeadPopup extends BottomPopupView implements View.OnClickListener {

    public static int CHANGE_SELECT_HEAD = 100;

    TextView tv_image_sdcard;
    TextView tv_image_photo;
    TextView tv_image_cancel;
    Fragment fragment;

    public UpHeadPopup(@NonNull Fragment fragment) {
        super(fragment.getContext());
        this.fragment = fragment;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_up_head;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        tv_image_sdcard = findViewById(R.id.tv_image_sdcard);
        tv_image_photo = findViewById(R.id.tv_image_photo);
        tv_image_cancel = findViewById(R.id.tv_image_cancel);
        tv_image_sdcard.setOnClickListener(this);
        tv_image_photo.setOnClickListener(this);
        tv_image_cancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_image_sdcard:
                PermissionUtils.permission(PermissionConstants.STORAGE)
                        .callback(new PermissionUtils.SimpleCallback() {
                            @Override
                            public void onGranted() {
                                go2selectImage(false);
                            }
                            @Override
                            public void onDenied() {
                                App.goPhoto = true;
                                ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn));
                            }
                        }).request();
                break;
            case R.id.tv_image_photo:
                PermissionUtils.permission(PermissionConstants.STORAGE,PermissionConstants.CAMERA)
                        .callback(new PermissionUtils.SimpleCallback() {
                            @Override
                            public void onGranted() {
                                App.goPhoto = true;
                                go2selectImage(true);
                            }
                            @Override
                            public void onDenied() {
                                App.goPhoto = true;
                                ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn));
                            }
                        }).request();
                break;
            case R.id.tv_image_cancel:
                dismiss();
                break;
        }
    }


    /**
     *
     * @param photo 是否直接打开照相机
     */
    private void go2selectImage(boolean photo){
        ImagePicker imagePicker = ImagePicker.getInstance();
        imagePicker.setImageLoader(new GlideImageLoader());
        imagePicker.setShowCamera(false);
        imagePicker.setCrop(true);
        imagePicker.setSaveRectangle(false);
        imagePicker.setSelectLimit(1);
        imagePicker.setStyle(CropImageView.Style.CIRCLE);
        imagePicker.setFocusWidth(ScreenUtils.getScreenWidth());
        imagePicker.setFocusHeight(ScreenUtils.getScreenWidth());
        imagePicker.setMultiMode(false);
        imagePicker.setOutPutX(300);
        imagePicker.setOutPutY(300);

        if(photo){
            Intent intent = new Intent(fragment.getContext(), ImageCameraGridActivity.class);
            intent.putExtra(ImageGridActivity.EXTRAS_TAKE_PICKERS, photo); // 是否是直接打开相机
            fragment.startActivityForResult(intent, CHANGE_SELECT_HEAD);
        }else {
            Intent intent = new Intent(fragment.getContext(), ImageGridActivity.class);
            intent.putExtra(ImageGridActivity.EXTRAS_TAKE_PICKERS, photo); // 是否是直接打开相机
            fragment.startActivityForResult(intent, CHANGE_SELECT_HEAD);
        }
    }


    @Override
    protected void onShow() {
        super.onShow();
        App.goPhoto = true;
    }

    @Override
    protected void onDismiss() {
        super.onDismiss();
        App.goPhoto = false;
    }
}
