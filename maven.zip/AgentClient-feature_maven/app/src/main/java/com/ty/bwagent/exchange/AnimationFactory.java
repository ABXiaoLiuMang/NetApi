package com.ty.bwagent.exchange;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.View;

import com.ty.utils.ScreenUtils;


public class AnimationFactory {

    private static final int StartDuration = 500;

    public static AnimatorSet startExChangeIcon(View exChange) {
        AnimatorSet animatorSet = new AnimatorSet();
        float x = ScreenUtils.getScreenWidth() * ((float) (360 - 24) / (float) 360);
        ObjectAnimator animatorY = ObjectAnimator.ofFloat(exChange, "translationY", 0f, -100f);
        ObjectAnimator animatorX = ObjectAnimator.ofFloat(exChange, "translationX", 0f, x - 80);
        animatorSet.play(animatorX).with(animatorY);
        animatorSet.setDuration(StartDuration);
        animatorSet.start();
        return animatorSet;
    }

    public static AnimatorSet restExChangeIcon(View exChange) {
        AnimatorSet animatorSet = new AnimatorSet();
        float x = ScreenUtils.getScreenWidth() * ((float) (360 - 24) / (float) 360);
        ObjectAnimator animatorY = ObjectAnimator.ofFloat(exChange, "translationY", -100f, 0f);
        ObjectAnimator animatorX = ObjectAnimator.ofFloat(exChange, "translationX", x - 80, 0f);
        animatorSet.play(animatorX).with(animatorY);
        animatorSet.setDuration(StartDuration);
        animatorSet.start();
        return animatorSet;
    }


    public static AnimatorSet startLineBlock(View startLine) {
        AnimatorSet animatorSet = new AnimatorSet();
        ObjectAnimator animatorY = ObjectAnimator.ofFloat(startLine, "translationY", 0f, -100f);
        ObjectAnimator animatorX = ObjectAnimator.ofFloat(startLine, "translationX", 0f, -100f);
        animatorSet.play(animatorX).with(animatorY);
        animatorSet.setDuration(StartDuration);
        animatorSet.start();
        return animatorSet;
    }

    public static AnimatorSet restLineBlock(View startLine) {
        AnimatorSet animatorSet = new AnimatorSet();
        ObjectAnimator animatorY = ObjectAnimator.ofFloat(startLine, "translationY", -100f, 0f);
        ObjectAnimator animatorX = ObjectAnimator.ofFloat(startLine, "translationX", -100f, 0f);
        animatorSet.play(animatorX).with(animatorY);
        animatorSet.setDuration(StartDuration);
        animatorSet.start();
        return animatorSet;
    }

    public static AnimatorSet startSelect(View selector) {
        ObjectAnimator animatorY = ObjectAnimator.ofFloat(selector, "translationY", 0f, -100f);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(animatorY);
        animatorSet.setDuration(StartDuration);
        animatorSet.start();
        return animatorSet;
    }

    public static AnimatorSet restSelect(View selector) {
        ObjectAnimator animatorY = ObjectAnimator.ofFloat(selector, "translationY", -100f, 0f);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(animatorY);
        animatorSet.setDuration(StartDuration);
        animatorSet.start();
        return animatorSet;
    }


}
