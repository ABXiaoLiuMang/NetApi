package com.ty.bwagent.adapter;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.bean.FinanceItemEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.FinanceDateUtils;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XFormatTextView;
import com.ty.utils.ResUtils;

import static com.ty.bwagent.utils.FinanceDateUtils.COMMISSION;
import static com.ty.bwagent.utils.FinanceDateUtils.CZPROFIT;
import static com.ty.bwagent.utils.FinanceDateUtils.NETPROFIT;
import static com.ty.bwagent.utils.FinanceDateUtils.PROFIT;
import static com.ty.bwagent.utils.FinanceDateUtils.YONGTATE;


/**
 * 描述
 * <p> 佣金月度详情数据列表适配器
 */
public class FinanceAdapter extends BaseQuickAdapter<FinanceItemEntity, BaseViewHolder> {

    FinanceEntity financeEntity;

    public FinanceAdapter() {
        super(R.layout.recycle_item_finance);
    }

    public void bindFinanceEntity(FinanceEntity financeEntity) {
        this.financeEntity = financeEntity;
        try {
            UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
            if (userInfo.getAgentModel() == 0) {//不是无限极
                setNewData(FinanceDateUtils.getNomalListDate(financeEntity));
            } else {//无极限
                setNewData(FinanceDateUtils.getInfiniteListDate(financeEntity));
            }
        } catch (Exception e) {

        }

    }

    @Override
    protected void convert(BaseViewHolder helper, FinanceItemEntity entity) {
        helper.setText(R.id.finance_title, entity.getTypeName());
        XFormatTextView finance_money = helper.getView(R.id.finance_money);

        if (YONGTATE.equals(entity.getTypeName())) {//佣金比例不显示
            finance_money.setText("");
        } else
            //这三个地方文字带颜色
            if (CZPROFIT.equals(entity.getTypeName()) || NETPROFIT.equals(entity.getTypeName()) || PROFIT.equals(entity.getTypeName())) {
                finance_money.setMontyText(entity.getMonty());
            } else {
                finance_money.setText(Utils.parsListMoney(entity.getMonty()));
                finance_money.setTypeface(TypefaceUtils.DIN_MEDIUM);
                finance_money.setTextColor(ResUtils.getColor(R.color.generic_heise));
            }

        TextView finance_state = helper.getView(R.id.finance_state);
        finance_state.setText(financeEntity.getCommissionStatus() == 1 ? "已发放" : "未发放");
        finance_state.setTextColor(financeEntity.getCommissionStatus() == 1 ? ResUtils.getColor(R.color.generic_lvse) : ResUtils.getColor(R.color.main_style_color));
        helper.setVisible(R.id.finance_state, COMMISSION.equals(entity.getTypeName()));
        helper.setVisible(R.id.finance_info, entity.isShowInfo());
        helper.addOnClickListener(R.id.finance_info);
    }

}
