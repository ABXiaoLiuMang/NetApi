package com.ty.bwagent.fragment.finance.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.fragment.finance.bean.Record;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.LogUtils;
import com.ty.utils.StringUtils;

import java.util.List;

public class RecordViewModel extends ViewModel {


    //筛选获取提款记录
    public NetLiveData<BaseEntity<Record>> recordLiveData = new NetLiveData<>();


    /**
     * 筛选获取提款记录
     *
     * @param startDate 开始时间，年月日
     * @param endDate   结束时间，年月日
     * @param status    提款状态(0全部,1成功,2失败,3提款中,4审核中)
     * @param pageNum
     * @param pageSize
     */
    public void withdrawalListFilter(String startDate, String endDate, int status, int pageNum, int pageSize) {
        NetSdk.create(Api.class)
                .withdrawalListFilter()
                .params("startDate", startDate)
                .params("endDate", endDate)
                .params("status", StringUtils.parseString(status))
                .params("pageNum", StringUtils.parseString(pageNum))
                .params("pageSize", StringUtils.parseString(pageSize))
                .asJSONType()
                .send(recordLiveData);
    }
}
