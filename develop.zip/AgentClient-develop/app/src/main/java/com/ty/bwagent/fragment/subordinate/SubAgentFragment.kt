package com.ty.bwagent.fragment.subordinate

import android.opengl.Visibility
import android.os.Handler
import android.view.View
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.scwang.smartrefresh.layout.api.RefreshLayout
import com.ty.bwagent.R
import com.ty.bwagent.adapter.SubordinateAgentAdapter
import com.ty.bwagent.bean.AgentLowerListBean
import com.ty.bwagent.bean.BaseEntity
import com.ty.bwagent.bean.TeamCountEntity
import com.ty.bwagent.utils.DialogUtil
import com.ty.bwagent.utils.Utils
import com.ty.bwagent.viewmodel.SubAgentViewModle
import com.ty.common.ui.ABRefreshFragment
import com.ty.common.util.ABConfig
import com.ty.net.callback.NetObserver
import com.ty.utils.KeyboardUtils
import com.ty.utils.ToastUtils
import kotlinx.android.synthetic.main.empty_message.*
import kotlinx.android.synthetic.main.frag_subordinater_agent.*
import kotlinx.android.synthetic.main.fragment_team_manager.view.*

/**
 * 下级代理列表
 */
class SubAgentFragment : ABRefreshFragment<AgentLowerListBean.ListBean>(), View.OnClickListener {

    private lateinit var subAgentViewModle: SubAgentViewModle

    var pageNum = 1
    var pageSize = 10;

    companion object {
        fun getInstant(): SubAgentFragment {
            return SubAgentFragment()
        }
    }

    override fun getLayoutId(): Int {
        return R.layout.frag_subordinater_agent
    }

    override fun createProvider() {
        subAgentViewModle = ViewModelProvider(this).get(SubAgentViewModle::class.java)
        subAgentViewModle.reviewListLiveData.observe(this, object : NetObserver<BaseEntity<AgentLowerListBean>>() {

            override fun onSuccess(agentLowerListBean: BaseEntity<AgentLowerListBean>?) {
                dismissProgressDialog()
                agentLowerListBean?.data?.let {
                    if (pageNum == 1) {
                        listAdapter.setNewData(it.list)
                        refreshLayout.finishRefresh()
                    } else {
                        listAdapter.addData(it.list)
                        refreshLayout.finishLoadMore()
                    }
                    if (it.size <pageSize) {
                        refreshLayout.finishLoadMoreWithNoMoreData()
                    }
                }

                if (listAdapter.itemCount == 0) {
                    ll_nodate.visibility = View.VISIBLE
                    recyclerView.visibility = View.GONE
                    iv_image.setImageResource(R.mipmap.message_empty_bg)
                    tv_message.text = "暂无数据"
                } else {
                    ll_nodate.visibility = View.GONE
                    recyclerView.visibility = View.VISIBLE
                }
            }

            override fun onError(code: Int, errMsg: String?) {
                dismissProgressDialog()
                ToastUtils.showLong(errMsg)
                if (pageNum == 1) {
                    refreshLayout.finishRefresh(false)
                } else {
                    refreshLayout.finishLoadMore(false)
                }

                if (listAdapter.itemCount == 0) {
                    ll_nodate.visibility = View.VISIBLE
                    recyclerView.visibility = View.GONE
                    iv_image.setImageResource(R.mipmap.generic_ic_no_network_no_data)
                    tv_message.text = "网络不给力"
                } else {
                    ll_nodate.visibility = View.GONE
                    recyclerView.visibility = View.VISIBLE
                }
            }
        });

        subAgentViewModle.getTeamCountLiveData.observe(this, object : NetObserver<BaseEntity<TeamCountEntity>>() {
            override fun onSuccess(teamCountEntity: BaseEntity<TeamCountEntity>?) {
                teamCountEntity?.data?.let {
                    tv_all_num.text = Utils.fmtMicrometer(it.totalCount.toString())
                    tv_agent_num.text = Utils.fmtMicrometer(it.memberCount.toString())
                    if(it.addSubAuthority==0){//是否支持下级  0支持，1不支持。
                        titleBar.tv_right.visibility=VISIBLE
                    }else{
                        titleBar.tv_right.visibility=INVISIBLE
                    }
                }
            }

            override fun onError(code: Int, errMsg: String?) {

            }
        });

    }

    override fun initViewsAndEvents() {
        super.initViewsAndEvents()
        titleBar.setRightOnClickListener {
            DialogUtil.addSubordinatePopup(this) { resert() }
        }
        tv_sure.setOnClickListener(this)
        tv_resert.setOnClickListener(this)
        constaint_layout.setOnClickListener(this)
        ll_nodate.setOnClickListener(this)

        titleBar.tv_right.visibility=INVISIBLE

        showProgressDialog()
        searchDate()
        subAgentViewModle.getTeamCount()
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tv_sure -> {
                KeyboardUtils.hideSoftInput(rootView)
                et_agent.clearFocus()
                showProgressDialog()
                pageNum = 1
                searchDate()
            }
            R.id.tv_resert -> {
                KeyboardUtils.hideSoftInput(rootView)
                et_agent.clearFocus()
                resert()
            }
            R.id.ll_nodate,
            R.id.constaint_layout -> {
                KeyboardUtils.hideSoftInput(rootView);
                et_agent.clearFocus()
            }
        }
    }

    private fun resert() {
        pageNum = 1
        refreshLayout.setNoMoreData(false)
        showProgressDialog()
        sec_month.onReset()
        et_agent.setText("")
        searchDate()
    }

    private fun searchDate() {
        subAgentViewModle.agentLowerList(et_agent.text.toString().trim(), sec_month.getMonthTime(), pageNum, pageSize)
    }


    override fun onLoadMore(refreshLayout: RefreshLayout) {
        pageNum++
        searchDate()
    }

    override fun onRefresh(refreshLayout: RefreshLayout) {
        pageNum = 1
        searchDate()
    }

    override fun onItemClick(adapter: BaseQuickAdapter<*, *>?, view: View?, position: Int) {
        KeyboardUtils.hideSoftInput(rootView)
        et_agent.clearFocus()
        val item = adapter?.getItem(position) as AgentLowerListBean.ListBean
        bundle.putParcelable(ABConfig.KEY_OBJECT, item);
        start(SubAgentDetailFragment.getInstant(bundle))
    }

    override fun getListAdapter(): BaseQuickAdapter<AgentLowerListBean.ListBean, BaseViewHolder> {
        return SubordinateAgentAdapter()
    }

    override fun getItemDecoration(): RecyclerView.ItemDecoration? {
        return null
    }


    override fun onStop() {
        super.onStop()
        KeyboardUtils.hideSoftInput(rootView)
    }

}