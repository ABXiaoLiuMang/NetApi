package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.OverFlowBean;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import androidx.lifecycle.ViewModel;

public class OverFlowViewModel extends ViewModel {

    public NetLiveData<BaseEntity<OverFlowBean>> overFlowListNetLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity> revisionQueryNetLiveData = new NetLiveData<>();


    //查询代理团队信息
    public void getOverFlowList(String memberName, String applyStatus,
                                String createStartDate, String createEndDate,
                                String applyTimeStart, String applyTimeEnd,
                                int pageSize, int pageNum) {
        NetSdk.create(Api.class)
                .applyList()
                .params("memberName", memberName)
                .params("applyStatus", applyStatus)
                .params("createStartDate", createStartDate)
                .params("createEndDate", createEndDate)
                .params("applyTimeStart", applyTimeStart)
                .params("applyTimeEnd", applyTimeEnd)
                .params("pageSize", pageSize)
                .params("pageNum", pageNum)
                .asJSONType()
                .send(overFlowListNetLiveData);
    }

    public void revisionQueryList(String memberName, int pageSize, int pageNum) {
        NetSdk.create(Api.class)
                .revisionQueryList()
                .params("memberName", memberName)
                .params("pageSize", pageSize)
                .params("pageNum", pageNum)
                .asJSONType()
                .send(revisionQueryNetLiveData);
    }

}
