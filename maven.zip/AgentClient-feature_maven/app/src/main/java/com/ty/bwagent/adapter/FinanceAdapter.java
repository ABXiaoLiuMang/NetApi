package com.ty.bwagent.adapter;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.bean.FinanceItemEntity;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XFormatTextView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;

import java.util.ArrayList;
import java.util.List;


/**
 * 描述
 * <p> 佣金月度详情数据列表适配器
 * author:Dale
 */
public class FinanceAdapter extends BaseQuickAdapter<FinanceItemEntity, BaseViewHolder> {

    FinanceEntity financeEntity;

    public FinanceAdapter() {
        super(R.layout.recycle_item_finance);
    }

    public void bindFinanceEntity(FinanceEntity financeEntity) {
        this.financeEntity = financeEntity;
        List<FinanceItemEntity> listBean = new ArrayList<>();

        listBean.add(new FinanceItemEntity("佣金", financeEntity.getCommission(), true));
        listBean.add(new FinanceItemEntity("冲正后净输赢", financeEntity.getCzProfit(), true));
        listBean.add(new FinanceItemEntity("上月结余", financeEntity.getLastBalance(), false));
        listBean.add(new FinanceItemEntity("净输赢", financeEntity.getNetProfit(), true));
        listBean.add(new FinanceItemEntity("总输赢", financeEntity.getProfit(), true));
        listBean.add(new FinanceItemEntity("场馆费", financeEntity.getThirdPartySpend(), true));
        listBean.add(new FinanceItemEntity("红利", financeEntity.getPromo(), true));
        listBean.add(new FinanceItemEntity("返水", financeEntity.getRebate(), true));
        listBean.add(new FinanceItemEntity("账户调整", financeEntity.getRiskAdjust(), false));
        listBean.add(new FinanceItemEntity("佣金调整", financeEntity.getCorrection(), false));
        setNewData(listBean);
    }

    @Override
    protected void convert(BaseViewHolder helper, FinanceItemEntity entity) {
        helper.setText(R.id.finance_title, entity.getTypeName());
        XFormatTextView finance_money = helper.getView(R.id.finance_money);
        //这三个地方文字带颜色
        if(helper.getAdapterPosition() == 1 || helper.getAdapterPosition() == 3 || helper.getAdapterPosition() == 4){
            finance_money.setMontyText(entity.getMonty());
        }else {
            finance_money.setText(Utils.roundDownMoney(entity.getMonty()));
            finance_money.setTextColor(ResUtils.getColor(R.color.generic_heise));
        }

        TextView finance_state = helper.getView(R.id.finance_state);
        finance_state.setText(financeEntity.getCommissionStatus() == 1 ? "已发放" : "未发放");
        finance_state.setTextColor(financeEntity.getCommissionStatus() == 1 ? ResUtils.getColor(R.color.generic_lvse) : ResUtils.getColor(R.color.main_style_color));
        helper.setVisible(R.id.finance_state, helper.getAdapterPosition() == 0);
        helper.setVisible(R.id.finance_info, entity.isShowInfo());
    }



}
