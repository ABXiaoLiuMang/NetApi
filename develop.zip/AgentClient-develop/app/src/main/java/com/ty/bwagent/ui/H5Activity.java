package com.ty.bwagent.ui;

import android.webkit.WebView;

import androidx.annotation.Nullable;

import com.ty.common.util.ABConfig;

public class H5Activity extends BaseAgentWebActivity {

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        titleBar.setTiteTextView(bundle.getString(ABConfig.KEY_TITLE));
    }

    @Override
    protected void setTitle(WebView view, String title) {
        super.setTitle(view, title);
//        if (!TextUtils.isEmpty(title)) {
//            if (title.length() > 10) {
//                title = title.substring(0, 10).concat("...");
//            }
//        }
//        titleBar.setTiteTextView(title);
    }


    @Nullable
    @Override
    protected String getUrl() {
        return bundle.getString(ABConfig.KEY_TEXT);
    }
}

