package com.ty.bwagent.ui;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;

import androidx.annotation.ColorInt;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupAnimation;
import com.lzy.imagepicker.ImagePicker;
import com.lzy.imagepicker.bean.ImageItem;
import com.lzy.imagepicker.ui.ImageGridActivity;
import com.lzy.imagepicker.util.GlideImageLoader;
import com.lzy.imagepicker.view.CropImageView;
import com.ty.bwagent.R;
import com.ty.common.util.AlphaAnimator;
import com.ty.constant.PermissionConstants;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.ToastUtils;
import com.ty.utils.WeakHandler;
import com.ty.webview.AgentWeb;
import com.ty.webview.AgentWebSettingsImpl;
import com.ty.webview.AgentWebUIControllerImplBase;
import com.ty.webview.DefaultWebClient;
import com.ty.webview.IAgentWebSettings;
import com.ty.webview.IWebLayout;
import com.ty.webview.MiddlewareWebChromeBase;
import com.ty.webview.MiddlewareWebClientBase;
import com.ty.webview.PermissionInterceptor;
import com.ty.webview.WebChromeClient;
import com.ty.webview.WebViewClient;

import java.io.File;
import java.util.ArrayList;


public abstract class BaseAgentWebActivity extends AppCompatActivity {

    protected AgentWeb mAgentWeb;
    private ErrorLayoutEntity mErrorLayoutEntity;
    private MiddlewareWebChromeBase mMiddleWareWebChrome;
    private MiddlewareWebClientBase mMiddleWareWebClient;
    protected BasePopupView progressDialog;
    protected WeakHandler weakHandler = new WeakHandler();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        super.setContentView(layoutResID);
        buildAgentWeb();
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        buildAgentWeb();
    }

    protected void buildAgentWeb() {
        ErrorLayoutEntity mErrorLayoutEntity = getErrorLayoutEntity();
        mAgentWeb = AgentWeb.with(this)
                .setAgentWebParent(getAgentWebParent(), new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                .closeIndicator()
                .setWebChromeClient(getWebChromeClient())
                .setWebViewClient(getWebViewClient())
                .setPermissionInterceptor(getPermissionInterceptor())
                .setWebLayout(getWebLayout())
                .setAgentWebUIController(getAgentWebUIController())
                .interceptUnkownUrl()
                .setOpenOtherPageWays(getOpenOtherAppWay())
                .useMiddlewareWebChrome(getMiddleWareWebChrome())
                .useMiddlewareWebClient(getMiddleWareWebClient())
                .setAgentWebWebSettings(getAgentWebSettings())
                .setMainFrameErrorView(mErrorLayoutEntity.layoutRes, mErrorLayoutEntity.reloadId)
                .setSecurityType(AgentWeb.SecurityType.STRICT_CHECK)
                .createAgentWeb()
                .ready()
                .go(getUrl());
    }


    protected @NonNull
    ErrorLayoutEntity getErrorLayoutEntity() {
        if (this.mErrorLayoutEntity == null) {
            this.mErrorLayoutEntity = new ErrorLayoutEntity();
        }
        return mErrorLayoutEntity;
    }

    protected AgentWeb getAgentWeb() {
        return this.mAgentWeb;
    }


    protected static class ErrorLayoutEntity {
        private int layoutRes = R.layout.web_error_page;
        private int reloadId = R.id.tvRefresh;

        public void setLayoutRes(int layoutRes) {
            this.layoutRes = layoutRes;
            if (layoutRes <= 0) {
                layoutRes = -1;
            }
        }

        public void setReloadId(int reloadId) {
            this.reloadId = reloadId;
            if (reloadId <= 0) {
                reloadId = -1;
            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (mAgentWeb != null && mAgentWeb.handleKeyEvent(keyCode, event)) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onPause() {
        if (mAgentWeb != null) {
            mAgentWeb.getWebLifeCycle().onPause();
        }
        super.onPause();

    }

    @Override
    protected void onResume() {
        if (mAgentWeb != null) {
            mAgentWeb.getWebLifeCycle().onResume();
        }
        super.onResume();
    }

    // 记录dialog 显示创建时间
    private long dialogCreateTime;
    protected void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(this);
            progressDialog = new XPopup.Builder(this)
                    .isRequestFocus(false)  //loading不要焦点
                    .hasShadowBg(false)
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        dialogCreateTime = System.currentTimeMillis();
        progressDialog.show();

    }

    protected void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShow()) {
            if (System.currentTimeMillis() - dialogCreateTime < 500) {
                weakHandler.postDelayed(() -> progressDialog.dismiss(),350);
            }else {
                progressDialog.dismiss();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (null == mUploadMessage && null == mUploadMessageLollipop) {
            return;
        }
        if (requestCode != CHANGE_SELECT_HEAD || data == null) {
            cancleUpload();
            return;
        }

        ArrayList<ImageItem> arrayList = (ArrayList<ImageItem>) data.getSerializableExtra(ImagePicker.EXTRA_RESULT_ITEMS);
        if (arrayList.size() == 0) {
            cancleUpload();
            return;
        }
        String path = arrayList.get(0).path;
        if (TextUtils.isEmpty(path)) {
            cancleUpload();
            return;
        }
        Uri uri = Uri.fromFile(new File(path));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mUploadMessageLollipop.onReceiveValue(new Uri[]{uri});
            mUploadMessage = null;
            mUploadMessageLollipop = null;
        } else {
            mUploadMessage.onReceiveValue(uri);
            mUploadMessage = null;
        }

    }

    private void cancleUpload() {
        if (mUploadMessage != null) {
            mUploadMessage.onReceiveValue(null);
        }
        mUploadMessage = null;
        if (mUploadMessageLollipop != null) {
            mUploadMessageLollipop.onReceiveValue(null);
        }
        mUploadMessageLollipop = null;
    }


    @Override
    protected void onDestroy() {
        if (mAgentWeb != null) {
            mAgentWeb.getWebLifeCycle().onDestroy();
        }
        super.onDestroy();
    }


    protected
    @Nullable
    String getUrl() {
        return null;
    }

    public @Nullable
    IAgentWebSettings getAgentWebSettings() {
        return AgentWebSettingsImpl.getInstance();
    }

    protected abstract @NonNull
    ViewGroup getAgentWebParent();

    protected @Nullable
    WebChromeClient getWebChromeClient() {
        return new WebChromeClient() {
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
            }
        };
    }

    protected @ColorInt
    int getIndicatorColor() {
        return -1;
    }

    protected int getIndicatorHeight() {
        return -1;
    }

    protected @Nullable
    WebViewClient getWebViewClient() {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                //do you  work
                Log.i("Info", "BaseWebActivity onPageStarted");
                showProgressDialog();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                dismissProgressDialog();
            }
        };
    }

    protected @Nullable
    IWebLayout getWebLayout() {
        return null;
    }

    protected @Nullable
    PermissionInterceptor getPermissionInterceptor() {
        return null;
    }

    public @Nullable
    AgentWebUIControllerImplBase getAgentWebUIController() {
        return null;
    }

    public @Nullable
    DefaultWebClient.OpenOtherPageWays getOpenOtherAppWay() {
        return null;
    }



    private  ValueCallback<Uri> mUploadMessage = null;
    private ValueCallback<Uri[]> mUploadMessageLollipop = null;
    protected @NonNull
    MiddlewareWebChromeBase getMiddleWareWebChrome() {
        return this.mMiddleWareWebChrome = new MiddlewareWebChromeBase() {
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                setTitle(view, title);
            }

            @Override
            public void openFileChooser(ValueCallback<Uri> uploadFile, String acceptType, String capture) {
//                super.openFileChooser(uploadFile, acceptType, capture);
                mUploadMessage = uploadFile;
                obtainPermission();
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
//                return super.onShowFileChooser(webView, filePathCallback, fileChooserParams);
                mUploadMessageLollipop = filePathCallback;
                obtainPermission();
                return true;
            }
        };
    }

    protected void setTitle(WebView view, String title) {

    }

    protected @NonNull
    MiddlewareWebClientBase getMiddleWareWebClient() {
        return this.mMiddleWareWebClient = new MiddlewareWebClientBase() {
        };
    }

    private void obtainPermission(){
        PermissionUtils.permission(PermissionConstants.STORAGE,PermissionConstants.CAMERA)
                .callback(new PermissionUtils.SimpleCallback() {
                    @Override
                    public void onGranted() {
                        openCamera();
                    }
                    @Override
                    public void onDenied() {
                        ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn));
                    }
                }).request();
    }

    public static int CHANGE_SELECT_HEAD = 100;
    private void openCamera(){
        ImagePicker imagePicker = ImagePicker.getInstance();
        imagePicker.setImageLoader(new GlideImageLoader());
        imagePicker.setShowCamera(true);
        imagePicker.setCrop(false);
        imagePicker.setSaveRectangle(false);
        imagePicker.setSelectLimit(1);
        imagePicker.setStyle(CropImageView.Style.CIRCLE);
        imagePicker.setFocusWidth(ScreenUtils.getScreenWidth());
        imagePicker.setFocusHeight(ScreenUtils.getScreenWidth());
        imagePicker.setMultiMode(false);
        imagePicker.setOutPutX(300);
        imagePicker.setOutPutY(300);
        Intent intent = new Intent(this, ImageGridActivity.class);
        startActivityForResult(intent, CHANGE_SELECT_HEAD);
    }


}
