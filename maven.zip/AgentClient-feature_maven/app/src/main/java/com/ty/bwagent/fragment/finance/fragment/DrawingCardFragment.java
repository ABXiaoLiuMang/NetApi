package com.ty.bwagent.fragment.finance.fragment;

import android.graphics.Paint;
import android.view.View;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.lxj.xpopup.XPopup;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BankEntity;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.DrawingEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.dialog.DrawingPopup;
import com.ty.bwagent.fragment.finance.viewmodel.BankViewModel;
import com.ty.bwagent.fragment.finance.viewmodel.DrawingCardViewModel;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.view.XCodeView;
import com.ty.bwagent.viewmodel.MoneyViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.SingleOnClickListener;
import com.ty.common.view.ValueView;

import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.DownTimerHelper;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.MMKVUtil;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.SpanManager;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Random;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 提款到银行卡
 */
public class DrawingCardFragment extends ABBaseFragment {
    MoneyViewModel moneyViewModel;
    BankViewModel bankViewModel;
    DrawingCardViewModel mDrawingCardModel;
    @BindView(R.id.draw_tv_tips)
    TextView drawTvTips;
    @BindView(R.id.draw_card)
    TextView drawCard;
    @BindView(R.id.valueview_card)
    ValueView valueviewCard;
    @BindView(R.id.valueview_draw_monty)
    ValueView valueviewDrawMonty;
    @BindView(R.id.valueview_frozen_monty)
    ValueView valueviewFrozenMonty;
    @BindView(R.id.x_safeBtn)
    TextView x_safeBtn;//按钮金额
    @BindView(R.id.valueview_phone)
    ValueView valueviewPhone;
    @BindView(R.id.xCodeview_code)
    XCodeView xCodeviewCode;//验证码
    @BindView(R.id.drawing_commit)
    TextView drawingCommit;
    @BindView(R.id.drawing_tv_warning)
    TextView drawingTvWarning;
    @BindView(R.id.draw_card_number)
    TextView draw_card_number;
    @BindView(R.id.x_et_money)
    ClearEditText x_et_money;
    BankEntity bankEntity;//添加银行卡后返回数据
    String money;//提款金额
    String realPhone;
    /**
     * 点击安全金额
     */
    double safeMonty;//可取-冻结


    public static DrawingCardFragment getInstance() {
        return new DrawingCardFragment();
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_drawing_card;
    }

    @Override
    protected void createProvider() {
        mDrawingCardModel = new ViewModelProvider(this).get(DrawingCardViewModel.class);
        moneyViewModel = new ViewModelProvider(getActivity()).get(MoneyViewModel.class);
        bankViewModel = new ViewModelProvider(getParentFragment()).get(BankViewModel.class);

        //监听获取未脱敏的电话号码
        moneyViewModel.drawPhoneLiveData.observe(this,new NetObserver<BaseEntity<String>>(){
            @Override
            protected void onSuccess(BaseEntity<String> entity) {
                realPhone= entity.getData();
                valueviewPhone.setTextValue(Utils.getHidePhone(realPhone));//电话号码
            }
            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //佣金余额
        moneyViewModel.commissLiveData.observe(this,new SimpleObserver<BaseEntity<Commission>>(){
            @Override
            protected void onSuccess(BaseEntity<Commission> baseEntity) {
                Commission commission = baseEntity.getData();
                safeMonty = MathUtil.subtract(commission.getAgentMoney(),commission.getAgentFreezedMoney());
                valueviewDrawMonty.setTextValue(Utils.roundDownMoney(safeMonty));//可提取余额
                valueviewFrozenMonty.setTextValue(Utils.roundDownMoney(commission.getAgentFreezedMoney()));//冻结余额
            }
        });

        //添加银行卡监听
        bankViewModel.bankNumberLiveData.observe(this, s -> {
            bankEntity = s;
            String bankCard = bankEntity.getBank_card();
            drawCard.setText("更换");
            String text = bankEntity.getBank_Name() + "  ****" + bankCard.substring(bankCard.length() - 4) + "  " +bankEntity.getReal_name().substring(0,1) +"**";
            draw_card_number.setText(text);////银行卡号
        });

        //提款到银行卡监听
        mDrawingCardModel.drawaCardLiveData.observe(this,new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ToastUtils.showLong(ResUtils.getString(R.string.generic_draw_succ));
                ((ABBaseFragment)getParentFragment()).pop();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                drawingTvWarning.setText(errMsg);
            }
        });


        //监听验证码
        mDrawingCardModel.codeLivedata.observe(this,new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if(baseEntity ==null){
                    return;
                }

                //保存获取成功验证码时间，60秒能不能重复获取
                MMKVUtil.put(Key.VERIFYTIME,System.currentTimeMillis());

                drawingTvWarning.setText("");
                mDrawingCardModel.startTimer(getLifecycle());
            }
            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }
            @Override
            protected void onError(int code, String errMsg) {
                drawingTvWarning.setText(errMsg);
            }
        });

        //验证码倒计时
        mDrawingCardModel.timerLiveData.observe(this, aLong -> {
            if(aLong == 0){
                xCodeviewCode.getCommitBtn().setEnabled(true);
                xCodeviewCode.getCommitBtn().setText(ResUtils.getString(R.string.generic_reset_code));
            }else {
                xCodeviewCode.getCommitBtn().setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time),aLong));
                xCodeviewCode.getCommitBtn().setEnabled(false);
            }
        });


    }

    @Override
    protected void initViewsAndEvents() {
        new InputResultCalculator(Arrays.asList(draw_card_number,x_et_money,xCodeviewCode.getEditText()), ok -> drawingCommit.setEnabled(ok));
        VerifyUtils.verifyCode(xCodeviewCode.getEditText(),drawingTvWarning);
        VerifyUtils.verifyMinMoney(x_et_money,drawingTvWarning);
        SpanManager.callServiceSpan(drawTvTips, ResUtils.getString(R.string.generic_draw_tips), ResUtils.getColor(SiteSdk.ins().styleColor()), "在线客服", new SingleOnClickListener() {
            @Override
            public void onSingleClick(View view) {
               goActivity(OnlineActivity.class);
            }
        });
        drawCard.setVisibility(View.VISIBLE);//添加银行卡按钮

        x_safeBtn.setOnClickListener(v -> {//安全金额按钮
            downTimerHelper();
            initSafeMonty();
        });


        xCodeviewCode.getCommitBtn().setEnabled(true);//获取验证码按钮
        xCodeviewCode.getCommitBtn().setOnClickListener(v -> {//获取验证码按钮
            if(Utils.isClicked60S()){
                mDrawingCardModel.getPhoneCode(realPhone);
            }
        });

        drawCard.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG); //下划线
        drawCard.getPaint().setAntiAlias(true);//抗锯齿

    }

    @OnClick({R.id.draw_card, R.id.drawing_commit})
    public void onViewClicked(View view) {
        if (DoubleClickUtils.isLongDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.draw_card:
                ((ABBaseFragment)getParentFragment()).start(AddBankCardFragment.getInstance());
                break;
            case R.id.drawing_commit:
                money = x_et_money.getText().toString().trim();
                if(StringUtils.parseDouble(money) < 100D){
                    ToastUtils.showLong(ResUtils.getString(R.string.generic_money_small1));
                    return;
                }
                DrawingEntity drawingEntity = new DrawingEntity(money,bankEntity.getBank_card(),bankEntity.getReal_name());
                showCommitDialog(drawingEntity);
                break;
        }
    }


    private void initSafeMonty(){
        double randomMoney;
        if (safeMonty < 200D) {
            randomMoney = 100D + new Random().nextDouble() * (safeMonty - 100);
        } else {
            if(safeMonty > 500000D){//最多50万
                safeMonty = 500000D;
            }
            randomMoney = safeMonty / 2 + new Random().nextDouble() * (safeMonty - safeMonty / 2);
        }
        BigDecimal bigDecimal = new BigDecimal(Double.toString(randomMoney));
        String inputText = bigDecimal.setScale(0, 4).toString();
        x_et_money.setText(inputText);
        x_et_money.setSelection(inputText.length());
    }

    /**
     * 提款金额确认弹窗
     * @param drawingEntity
     */
    private void showCommitDialog(DrawingEntity drawingEntity){
        DrawingPopup drawingPopup = new DrawingPopup(mContext,drawingEntity);
        drawingPopup.setListener(() -> {//提款确认按钮
           String code = xCodeviewCode.getInputString();
           String money = x_et_money.getText().toString().trim();
            mDrawingCardModel.withdrawalToBank(code,bankEntity.getBankCode(),bankEntity.getBank_card(),money,bankEntity.getReal_name(),bankEntity.getBank_address());
        },null)
                .setCancelTextColor(R.color.generic_heise)
                .setConfirmTextColor(R.color.main_style_color)
                .setTitleContent("提示","请确认以下提款信息:",null);

        new XPopup.Builder(getContext())
                .dismissOnBackPressed(false)
                .dismissOnTouchOutside(false)
                .asCustom(drawingPopup)
                .show();
    }

    /**
     * 安全 金额  3秒内不能重复点击
     */
    private void downTimerHelper(){
        DownTimerHelper downTimerHelper = new DownTimerHelper(3 * 1000,1000) {
            @Override
            public void onTick(long untilFinished) {
                x_safeBtn.setEnabled(false);
            }

            @Override
            public void onFinish() {
                x_safeBtn.setEnabled(true);
            }
        };
        downTimerHelper.start(getLifecycle());
    }
}
