package com.ty.bwagent.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.pickerview.builder.TimePickerBuilder;
import com.ty.pickerview.view.TimePickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;

import java.util.Calendar;
import java.util.Date;

import androidx.annotation.Nullable;

/**
 * 又是一个数据的弹窗MMP
 * 佣金中时间（年月）选择封装
 */
public class TeamSeleMonthTimeView extends LinearLayout implements View.OnClickListener {

    Context mContext;
    TextView start_time;
    String month;//当前选中月份
    private LinearLayout ll_item;

    //12个月
    public TeamSeleMonthTimeView(Context context) {
        this(context, null);
    }

    public TeamSeleMonthTimeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TeamSeleMonthTimeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setOrientation(LinearLayout.HORIZONTAL);
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.x_select_month_layout, this, true);
        start_time = rootView.findViewById(R.id.start_time);
        ll_item = rootView.findViewById(R.id.ll_item);
        ll_item.setOnClickListener(this);
        month = TimeUtils.getDiffMonth(-1);
        start_time.setText(month);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_item:
                KeyboardUtils.hideSoftInput(v);
                showStartPickerDialog();
                break;
        }
    }


    TimePickerView timeStartPickerView;

    private void showStartPickerDialog() {
        if (timeStartPickerView == null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            timeStartPickerView = new TimePickerBuilder(getContext(), (date, v) -> {
                month = TimeUtils.DATE_FORMAT_MM.format(date);
                start_time.setText(month);

            }).setSubmitText("确定")
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setSubmitColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setDate(calendar)
                    .setTitleText("")
                    .setType(new boolean[]{true, true, false, false, false, false})
                    .build();
        }

        timeStartPickerView.show();
    }


    public String getMonthTime() {
        return start_time.getText().toString().trim();
    }


    public void onReset() {
        timeStartPickerView = null;
        month = TimeUtils.getDiffMonth(-1);
        start_time.setText(month);
    }

}
