package com.ty.bwagent.fragment.finance.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.finance.bean.FinanceTotal;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XTextView;


/**
 * 描述 场馆总输赢
 * <p>
 * author:Dale
 */
public class FinanceTotalAdapter extends BaseQuickAdapter<FinanceTotal, BaseViewHolder> {

    public FinanceTotalAdapter() {
        super(R.layout.recycle_item_finance_total);
    }

    @Override
    protected void convert(BaseViewHolder helper, FinanceTotal entity) {

        helper.setText(R.id.x_total_title,entity.getVenueName());
        helper.setText(R.id.x_total_water, Utils.roundDownMoney(entity.getNetAmount()));
        XTextView x_total_monty = helper.getView(R.id.x_total_monty);
        x_total_monty.setMontyText(entity.getProfit());

        if(getItemCount() == 2){//表示只有一行数据，因为第一行是headView
            helper.setBackgroundRes(R.id.finance_rootView,R.drawable.finance_buttom_corners_w_bg);
        }else{
            if(helper.getAdapterPosition() % 2 == 0){

                if(helper.getAdapterPosition() + 1 == getItemCount()){//表示是最后一个
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_buttom_corners_x_bg);
                }else {
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_center_corners_x_bg);
                }

            }else {
                if(helper.getAdapterPosition() + 1 == getItemCount()){//表示是最后一个
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_buttom_corners_w_bg);
                }else {
                    helper.setBackgroundRes(R.id.finance_rootView, R.drawable.finance_center_corners_w_bg);
                }
            }
        }

    }

}
