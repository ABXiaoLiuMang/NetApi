package com.ty.bwagent.dialog;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.DepositEntity;
import com.ty.bwagent.bean.DrawingEntity;
import com.ty.bwagent.utils.Utils;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

/**
 * 代转确认对话框
 */
public class DepositPopup extends ConfirmPopupView {

    TextView draw_user;
    TextView draw_realName;
    TextView draw_money;
    TextView draw_state;
    DepositEntity depositEntity;


    public DepositPopup(@NonNull Context context, DepositEntity depositEntity) {
        super(context);
        this.depositEntity = depositEntity;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_deposit;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        draw_user = findViewById(R.id.draw_user);
        draw_realName = findViewById(R.id.draw_realName);
        draw_money = findViewById(R.id.draw_money);
        draw_state = findViewById(R.id.draw_state);

//        用户状态(0停用，1启用)
        draw_state.setVisibility(depositEntity.getStatus()==0?VISIBLE:INVISIBLE);

        if(StringUtils.isEmpty(depositEntity.getRealName())){
            draw_realName.setVisibility(GONE);
        }else {
            draw_realName.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_deposit_user),depositEntity.getRealName()));
        }
        String money = Utils.roundDownMoney(StringUtils.parseDouble(depositEntity.getMoney()));

        if(depositEntity.isTurn()){//ture:代理代转 false 代理代存
            draw_user.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_turn_acc),depositEntity.getNick()));
            draw_money.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_turn_user),money));
        }else {
            draw_user.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_save_acc),depositEntity.getNick()));
            draw_money.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_save_user),money));
        }
    }
}
