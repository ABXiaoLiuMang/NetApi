package com.ty.bwagent.api;

import com.ty.bwagent.BuildConfig;
import com.ty.utils.LogUtils;
import com.ty.utils.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class BaseUrlManager {
    private static class Holder {
        static BaseUrlManager ins = new BaseUrlManager();
    }

    public static BaseUrlManager ins() {
        return Holder.ins;
    }

    private int index = 0;
    private DamainItem current;

    private BaseUrlManager() {
        if (StringUtils.equals("debug", BuildConfig.appEnv)) {//测试
            this.mDomainArray = new ArrayList<>();
            current = new DamainItem("http://api.bwhou2028.com", new String[]{"", "", ""});
        } else if (StringUtils.equals("pre_release", BuildConfig.appEnv)) {//预发
            this.mDomainArray = new ArrayList<>();
            current = new DamainItem("http://api.bwuat2020.com", new String[]{"", "", ""});
        } else {//正式
            this.mDomainArray = createDomains();
            current = mDomainArray.get(index);
        }
    }

    private List<DamainItem> createDomains() {
        List<DamainItem> domains = new ArrayList<>();
        domains.add(new DamainItem("https://api.a730l.com", new String[]{"jpnj9evgpbrcdff7strQeibxwewoGhoh", "076dd9f301f6607a41d920d42f49972f", "d98eaffb3d1a4adaaebd05507adf2cfd"}));
        domains.add(new DamainItem("https://api.43c3v.com", new String[]{"e5pcjljaandrfr0yvMbrheHuznnxzhck", "b5ca237b8f44a7206cb8630710f91166", "7e527819251d474dbfc5df8348429532"}));
        domains.add(new DamainItem("https://api.r98x08.com", new String[]{"ofcvyueecCjebp8nJxhru4thsvgjmjyu", "3565f83f7e63488bea73f6bbdcb7c598", "3af51be85c55497aaefc22752fd66c8c"}));
        domains.add(new DamainItem("https://api.q4y0cr.com", new String[]{"qtihgsumip7ijBlznjqsonj7iyUuruag", "010c1741ec6af50932b79734a876508a", "5329fca8692e48f1b72a40bafc93fc87"}));
        domains.add(new DamainItem("https://api.p714rf.com", new String[]{"djdqyeiavqvaah5oa5CkjKbftpxhjsxb", "2504787d07befd8817f10a0eaad5edcf", "d8754607270d43e58692172fd74d6e20"}));
        domains.add(new DamainItem("https://api.563f2c.com", new String[]{"jracojxrkv9dCxp5vhsrvlfanrqgvjiG", "c9f64cab71de32163c6e6f5b38e2cb48", "e1200346873b4dce8163807b6027e188"}));
        domains.add(new DamainItem("https://api.7z18o.com", new String[]{"ipdkFNrfqhv5qfucuhrjnybwoo2vkwcx", "8b3da88d839f8e2bad857b3ae18f9458", "419206db21804c84ad074ae6f478fe98"}));
        domains.add(new DamainItem("https://api.9a492a.com", new String[]{"xsfleu7lchhnqgwcqcviPjlvt8cegWzr", "1256efd1a527a2e21509d6fff48ab2e1", "8c3b65c595744b9499f8da3ee5cc647e"}));
        domains.add(new DamainItem("https://api.5426f1.com", new String[]{"Fqrxsqqyokcm6rulldmKkftmcgx6ltbe", "b948a284240980ca0eb1606f8535b184", "6bb57fbceadf40f1af6d695451ac0d67"}));
        domains.add(new DamainItem("https://api.m6668r.com", new String[]{"dzhywxgjwwox5epacoA6bvfxmhtfqfbM", "7a8abe4aae6370c55ef39a9c00caee80", "c6dc303f0fad4af49e50921f5584e8b3"}));
        return domains;
    }

    private List<DamainItem> mDomainArray;

    public DamainItem currentDomain() {
        return this.current;
    }

    /**
     * 获取下一条可用域名
     *
     * @return
     */
    public synchronized DamainItem nextDomain() {
        int currentIndex = ++index;
        if (currentIndex >= this.mDomainArray.size()) {
            return null;
        }
        current = this.mDomainArray.get(currentIndex);
        return current;
    }

}
