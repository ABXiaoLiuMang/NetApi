package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.RestrictEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

public class DevicesViewModel extends ViewModel {

    public NetLiveData<String> areaWarnResult = new NetLiveData<>();//地区限制


    //获取ip 地区
    public void checkRestrict() {
        NetSdk.create(Api.class)
                .checkRestrict()
                .asJSONType()
                .send(areaWarnResult);
    }


}
