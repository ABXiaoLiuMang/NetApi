package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.fragment.finance.adapter.FinanceTotalAdapter;
import com.ty.bwagent.fragment.finance.bean.FinanceTotal;
import com.ty.bwagent.fragment.finance.viewmodel.FinanceTotalViewModel;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.view.XFormatTextView;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;
import com.ty.utils.StringUtils;

import java.util.List;

import butterknife.BindView;

/**
 * 月度详细-总输赢
 */
public class FinanceTotalFragment extends ABRefreshFragment<List<String>> {

    FinanceTotalViewModel mFinanceTotalViewModel;
    TextView tv_month;//查询月份
    XFormatTextView win_total;//总输赢
    TextView month_text;//月度明细月份
    TextView win_watter;//总流水

    String startData;
    FinanceEntity financeEntity;//佣金明细对象
    private LinearLayout ll_net;
    private TextView bnt_nonet;

    @BindView(R.id.layout_head)
    LinearLayout layout_head;//recycleview左边表头


    public static FinanceTotalFragment getInstance(Bundle bundle) {
        FinanceTotalFragment fragment = new FinanceTotalFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_totle_details;
    }

    @Override
    protected void createProvider() {
        mFinanceTotalViewModel = new ViewModelProvider(this).get(FinanceTotalViewModel.class);
        mFinanceTotalViewModel.totalNetLiveData.observe(this, new SimpleObserver<BaseEntity<List<FinanceTotal>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<FinanceTotal>> financeTotals) {
                ll_net.setVisibility(View.GONE);
                ((FinanceTotalAdapter) listAdapter).setDate(financeTotals.getData());
                initHeader(((FinanceTotalAdapter) listAdapter).listsTitle);
                win_watter.setText((((FinanceTotalAdapter) listAdapter).getWaterDate(financeTotals.getData()))+"");
            }

            @Override
            protected void onLoading(boolean show) {

                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                ll_net.setVisibility(View.VISIBLE);
            }

        });
    }

    @Override
    public BaseQuickAdapter<List<String>, BaseViewHolder> getListAdapter() {
        return new FinanceTotalAdapter();
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public View getEmptyView() {
        return View.inflate(mContext, R.layout.empty_message, null);
    }


    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();

        ll_net = rootView.findViewById(R.id.ll_net);
        bnt_nonet = rootView.findViewById(R.id.bnt_nonet);
        tv_month = rootView.findViewById(R.id.tv_month);
        win_total = rootView.findViewById(R.id.win_total);
        month_text = rootView.findViewById(R.id.month_text);
        win_watter = rootView.findViewById(R.id.win_watter);

        financeEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
        String winTotle = bundle.getString(ABConfig.KEY_TEXT);
        startData = bundle.getString(ABConfig.KEY_TAG);
        mFinanceTotalViewModel.queryProfitDetail(startData);
        if(financeEntity!=null){
            win_total.setMontyText(financeEntity.getProfit());
        }
        if(!StringUtils.isEmpty(winTotle)){
            win_total.setMontyText(winTotle);
        }

        tv_month.setText(startData);
        month_text.setText(startData);

        win_watter. setTypeface(TypefaceUtils.DIN_MEDIUM);
        bnt_nonet.setOnClickListener(v -> mFinanceTotalViewModel.queryProfitDetail(startData));
    }


    private void initHeader(List<String> listMap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(SizeUtils.dp2px(80), SizeUtils.dp2px(50));
        lp.gravity = Gravity.CENTER;
        for (int i = 0; i < listMap.size(); i++) {
            TextView textView = new TextView(mContext);
            textView.setTextColor(ResUtils.getColor(R.color.generic_heise));
            textView.setTextSize(12);
            textView.setGravity(Gravity.CENTER);
            textView.setText(listMap.get(i));
            layout_head.addView(textView, lp);
        }
    }


    @Override
    public int getMode() {
        return Mode.DISABLED;
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(mContext, RecyclerView.HORIZONTAL, false);
    }


    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
    }


}
