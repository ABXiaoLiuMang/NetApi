package com.ty.bwagent.ui;

import com.lzy.imagepicker.ui.ImageGridActivity;

/**
 * 处理照相机和相册选择锁屏不通逻辑处理问题
 */
public class ImageCameraGridActivity extends ImageGridActivity {
}
