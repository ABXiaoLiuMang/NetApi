package com.ty.bwagent.adapter;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.MMessage;
import com.ty.utils.LogUtils;
import com.ty.utils.StringUtils;
import com.ty.view.CircleImageView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * 描述 消息中心适配器
 * <p>
 * author:Dale
 */
public class MessageAdapter extends BaseQuickAdapter<MMessage.ListBean, BaseViewHolder> {


    boolean allRead = false;

    public MessageAdapter() {
        super(R.layout.recycle_item_message);
    }

    /**
     * 一键阅读，标识全部已读
     */
    public void setAllRead(){
        this.allRead = true;
        notifyDataSetChanged();
    }

    public void setRestRead(){
        this.allRead = false;
    }

    /**
     * 获取未读消息数量
     *
     * @return
     */
    public int getUnReadCount() {
        if(allRead){
            return 0;
        }
        int count = 0;
        for (MMessage.ListBean listBean : mData) {
            if (listBean.getIsRead() == 0) {//未读
                count++;
            }
        }
        return count;
    }

    public void removeId(String msgId){
        for(MMessage.ListBean listBean : mData){
            if(StringUtils.equals(msgId,listBean.getId())){
                mData.remove(listBean);
                break;
            }
        }
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, MMessage.ListBean entity) {
        CircleImageView messageHead = helper.getView(R.id.message_head);
        helper.setText(R.id.message_title, entity.getTitle());
        helper.setText(R.id.message_time, entity.getSendTime());
        helper.setText(R.id.message_text, entity.getContent());
        if(allRead){
            helper.setVisible(R.id.message_dot, false);//是否已读0未读，1已读
        }else {
            helper.setVisible(R.id.message_dot, entity.getIsRead() == 0);//是否已读0未读，1已读
        }
//         messageHead.setImageResource(R.mipmap.icon_message_cz_bg);
//         messageHead.setImageResource(R.mipmap.icon_message_nba_bg);
//         messageHead.setImageResource(R.mipmap.icon_message_sys_bg);
//         messageHead.setImageResource(R.mipmap.icon_message_vip_bg);
        String imageUrl = entity.getImgUrl();
        if (StringUtils.isEmpty(imageUrl) && entity.getIcon() != null) {
            MMessage.ListBean.IconBean iconBean = entity.getIcon();
            imageUrl = iconBean.getIcon_96_96();
        }
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.mipmap.icon_message_cz_bg)
                .error(R.mipmap.icon_message_cz_bg);
        Glide.with(mContext).load(imageUrl).apply(requestOptions).into(messageHead);
    }

}
