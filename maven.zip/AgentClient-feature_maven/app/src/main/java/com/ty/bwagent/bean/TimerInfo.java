package com.ty.bwagent.bean;

public class TimerInfo {
    /**
     * 倒计时的时间
     */
    public long millisUntilFinished;
    /**
     * 是否是第一次启动app
     */
    public boolean isFirstOpenApp;

    public String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getMillisUntilFinished() {
        return millisUntilFinished;
    }

    public void setMillisUntilFinished(long millisUntilFinished) {
        this.millisUntilFinished = millisUntilFinished;
    }

    public boolean isFirstOpenApp() {
        return isFirstOpenApp;
    }

    public void setFirstOpenApp(boolean firstOpenApp) {
        isFirstOpenApp = firstOpenApp;
    }
}
