package com.ty.bwagent.fragment.finance.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ValueBean;
import com.ty.bwagent.fragment.finance.bean.FinanceWater;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;
import java.util.Map;

/**
 * 返水
 */
public class FinanceWaterViewModel extends ViewModel {


    //返水/场馆费月度明细
    public NetLiveData<BaseEntity<Map<String, List<ValueBean>>>> financeNetLiveData = new NetLiveData<>();

    /**
     * 账户调整月度明细
     */
    public void financeWater(String startData){
        NetSdk.create(Api.class)
                .financeWater()
                .params("commissionDate",startData)
                .asJSONType()
                .send(financeNetLiveData);
    }
}
