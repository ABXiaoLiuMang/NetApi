package com.ty.bwagent.fragment.deposit.adapter;

import android.widget.TextView;

import androidx.annotation.LayoutRes;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.deposit.bean.DepositRecord;
import com.ty.bwagent.utils.Utils;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;


/**
 * 描述 代理转账记录 适配器
 * <p>
 * author:Dale
 */
public class TurnRecoreAdapter extends BaseQuickAdapter<DepositRecord.ListBean, BaseViewHolder> {

    public TurnRecoreAdapter() {
        super(R.layout.recycle_item_deposit);
    }

    @Override
    protected void convert(BaseViewHolder helper, DepositRecord.ListBean listBean) {
        helper.setText(R.id.tv_deposit_time,listBean.getCreatedAt());
        TextView deposit_state = helper.getView(R.id.tv_deposit_state);
        //403表示成功 其他表示失败，失败还有其他状态
        if(listBean.getDrawStatus() == 403){
            deposit_state.setText("成功");
            deposit_state.setBackgroundResource(R.mipmap.record_state_succ);
        }else {
            deposit_state.setText("失败");
            deposit_state.setBackgroundResource(R.mipmap.record_state_fail);
        }
        helper.setText(R.id.tv_deposit_account, listBean.getTransferMemberName());
        helper.setText(R.id.tv_deposit_money, Utils.roundDownMoney(listBean.getAmount()));
        helper.setText(R.id.tv_deposit_order, listBean.getBillNo());
        helper.setText(R.id.tv_deposit_note, listBean.getDrawComment());
        helper.setText(R.id.tv_turn_type, listBean.getWithdrawType() == 20203 ? "佣金转账" : "额度转账");// 转账类型 佣金转账 20203 额度转账 20204
    }

}
