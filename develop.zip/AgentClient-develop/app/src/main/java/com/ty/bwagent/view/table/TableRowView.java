package com.ty.bwagent.view.table;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ty.bwagent.R;


public class TableRowView extends RecyclerView{

    public TableRowView(Context context) {
        super(context);
        init();
    }

    public TableRowView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public TableRowView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setHasFixedSize(true);
        setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
    }

    public void setAdapter(TableColumnAdapter adapter) {
        super.setAdapter(adapter);
    }
    public TableColumnAdapter getAdpater() {
        return ((TableColumnAdapter) getAdapter());
    }


    public static class TableColumnAdapter extends RecyclerView.Adapter {
        int row;
        TableAdapter delegate;

        TableColumnAdapter(TableAdapter delegate, int row) {
            this.delegate = delegate;
            this.row = row;
        }
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return delegate.onCreateViewHolder(parent, viewType);
        }

        @Override
        public int getItemViewType(int position) {
            return delegate.getItemViewType(row, position);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            int p = position;
            delegate.onBindViewHolder(holder,row, p);
        }

        public void setRow(int row) {
            if(row != this.row) {
                this.row = row;
                notifyDataSetChanged();
            }

        }

        @Override
        public int getItemCount() {
            return delegate.getColumnCount();
        }
    }
}
