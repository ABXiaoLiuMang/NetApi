package com.ty.bwagent.fragment;

import android.widget.ImageView;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;

import com.ty.bwagent.R;
import com.ty.bwagent.adapter.AboutBottomAdapter;
import com.ty.bwagent.adapter.AboutSponsorAdapter;
import com.ty.bwagent.bean.AboutSponsor;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.view.XRecyclerView;
import com.ty.bwagent.viewmodel.AboutViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteConfig;
import com.ty.tysite.SiteSdk;
import com.ty.tysite.utils.ImageResoureSiteUtils;
import com.ty.utils.AppUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;


public class AboutFragment extends ABBaseFragment {

    AboutViewModel mAboutViewModel;
    @BindView(R.id.ivLogo)
    ImageView ivLogo;
    @BindView(R.id.tvAppName)
    TextView tvAppName;

    @BindView(R.id.mRecyclerView)
    XRecyclerView mRecyclerView;
    @BindView(R.id.recy_bottom)
    XRecyclerView recyBottom;
    AboutSponsorAdapter aboutSponsorAdapter;
    private AboutBottomAdapter aboutBottomAdapter;

    public static AboutFragment getInstance() {
        AboutFragment fragment = new AboutFragment();
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_about;
    }

    @Override
    protected void createProvider() {
        mAboutViewModel = new ViewModelProvider(this).get(AboutViewModel.class);

        mAboutViewModel.contactUsLiveData.observe(this, new SimpleObserver<BaseEntity<ContactUsEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<ContactUsEntity> baseEntity) {

                List<ContactUsEntity.BaseInfo> data = baseEntity.getData().getBaseInfo();
                if (data == null || (data != null && data.size() == 0)) {
                    return;
                }
                List<ContactUsEntity.BaseInfo> baseInfos = new ArrayList<>();
                for (ContactUsEntity.BaseInfo aboutSponsor : data) {
                    if ("0".equals(aboutSponsor.getIsEnable())) {//0展示 1隐藏
                        baseInfos.add(aboutSponsor);
                    }
                }
                aboutBottomAdapter.setNewData(baseInfos);
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                ToastUtils.showToast(errMsg);
            }
        });

        //我的赞助
        mAboutViewModel.sponsorLiveData.observe(this, new NetObserver<BaseEntity<List<AboutSponsor>>>() {
            @Override
            protected void onSuccess(BaseEntity<List<AboutSponsor>> listBaseEntity) {

                if (listBaseEntity == null||(listBaseEntity!=null&&listBaseEntity.getData()==null)) {
                    return;
                }
                if (listBaseEntity.getData().size() == 0) {
                    return;
                }
                List<AboutSponsor> data = listBaseEntity.getData();
                List<AboutSponsor> aboutSponsors = new ArrayList<>();
                for (AboutSponsor aboutSponsor : data) {
                    if (aboutSponsor.getMessgeNameCode() == 5 && aboutSponsor.getStatus() == 0) {
                        aboutSponsors.add(aboutSponsor);
                    }
                }
                if (aboutSponsors.size() > 0) {
                    mRecyclerView.setLayoutManager(new GridLayoutManager(mContext, aboutSponsors.size() <= 4 ? aboutSponsors.size() : 4));
                    aboutSponsorAdapter.setNewData(aboutSponsors);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showToast(errMsg);
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {

        tvAppName.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_app_version), AppUtil.getVersionName()));
        ivLogo.setBackgroundResource(ImageResoureSiteUtils.ivAboutLogo());

        recyBottom.setLayoutManager(new GridLayoutManager(mContext, 3));
        aboutBottomAdapter = new AboutBottomAdapter();
        recyBottom.setAdapter(aboutBottomAdapter);

        aboutSponsorAdapter = new AboutSponsorAdapter();
        mRecyclerView.setAdapter(aboutSponsorAdapter);
        mAboutViewModel.contactUs();
        mAboutViewModel.getSponsor();

    }
}
