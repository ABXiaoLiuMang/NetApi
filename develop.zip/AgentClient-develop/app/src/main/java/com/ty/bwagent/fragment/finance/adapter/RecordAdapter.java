package com.ty.bwagent.fragment.finance.adapter;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.bwagent.fragment.finance.bean.Record;
import com.ty.bwagent.utils.Utils;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;


/**
 * 描述 提款记录适配器
 * <p>
 * author:Dale
 */
public class RecordAdapter extends BaseQuickAdapter<Record.ListBean, BaseViewHolder> {

    public RecordAdapter() {
        super(R.layout.recycle_item_record);
    }

    @Override
    protected void convert(BaseViewHolder helper, Record.ListBean mRecord) {
        TextView record_state = helper.getView(R.id.record_state);
        record_state.setText(mRecord.getStatus());
        if(StringUtils.equals("提款成功",mRecord.getStatus())){
            record_state.setBackgroundResource(R.mipmap.record_state_succ);
        }else if(StringUtils.equals("提款失败",mRecord.getStatus())){
            record_state.setBackgroundResource(R.mipmap.record_state_fail);
        }else {
            record_state.setBackgroundResource(R.mipmap.record_state_other);
        }

        helper.setText(R.id.record_time,mRecord.getCreatedAt().replace("T"," "));//提款时间


        if(StringUtils.isEmpty(mRecord.getBankCard())){
            helper.setGone(R.id.record_card_tips,false);
            helper.setGone(R.id.record_card_number,false);

            helper.setGone(R.id.record_card_name_tips,false);
            helper.setGone(R.id.record_card_name,false);

        }else {
            helper.setGone(R.id.record_card_tips,true);
            helper.setGone(R.id.record_card_number,true);

            helper.setGone(R.id.record_card_name_tips,true);
            helper.setGone(R.id.record_card_name,true);
        }

        if(StringUtils.isEmpty(mRecord.getBankCode())){
            helper.setGone(R.id.record_card_bank_tips,false);
            helper.setGone(R.id.record_card_bank,false);
        }else {
            helper.setGone(R.id.record_card_bank_tips,true);
            helper.setGone(R.id.record_card_bank,true);
        }

        helper.setText(R.id.record_card_number,mRecord.getBankCard());//提款卡号
        helper.setText(R.id.record_card_bank,mRecord.getBankName());//开户银行
        helper.setText(R.id.record_card_name,mRecord.getBankRealname());//户主
        helper.setText(R.id.record_order, mRecord.getBillNo());//订单号
        helper.setText(R.id.record_money, Utils.roundDownMoney(mRecord.getAmount()));//金额
    }

}
