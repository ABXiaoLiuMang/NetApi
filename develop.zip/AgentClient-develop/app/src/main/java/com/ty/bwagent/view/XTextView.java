package com.ty.bwagent.view;

import android.content.Context;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.AttributeSet;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;

import com.ty.bwagent.R;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

/**
 * 金额显示View
 * 1.所有金额保留两位小数显示
 * 2.金额大于0绿色，金额小于0红色 等于0 黑色
 * 3.金额大于一亿，全部显示：9，999.99万
 */
public class XTextView extends AppCompatTextView {
    public XTextView(Context context) {
        super(context);
    }

    public XTextView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public XTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setMontyText(double money) {
        String text ;
        if(money <= -9999999999.99D ){//小于100亿
            text = "-999,999.00万";
        }else if(money <= -10000000D ){//小于1千万
            double m = MathUtil.divide(money,10000D);
            text = Utils.roundDownMoney(m) + "万";
        }else if(- 10000000D < money && money < 10000000D){ //大于负的1千万 小于正的一千万
            text = Utils.roundDownMoney(money);
        }else if(10000000D <= money && money < 9999999999.99D){//大于1千万 小于100亿
            double m = MathUtil.divide(money,10000D);
            text = Utils.roundDownMoney(m) + "万";
        }else {//大于一亿
            text = "999,999.00万";
        }

        setTypeface(TypefaceUtils.DIN_MEDIUM);
        super.setText(text);

        if (money < 0) {
            setTextColor(ResUtils.getColor(R.color.color_f4333c));
        } else if (money > 0) {
            setTextColor(ResUtils.getColor(R.color.generic_lvse));
        } else {
            setTextColor(ResUtils.getColor(R.color.generic_heise));
        }

        if (text.endsWith("万")) {
            SpannableString spannableString = new SpannableString(text);
            ForegroundColorSpan colorSpan = new ForegroundColorSpan(ResUtils.getColor(R.color.generic_heise));
            spannableString.setSpan(colorSpan, spannableString.length() - 1, spannableString.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
            setText(spannableString);
        }
    }


    public void setMontyText(String money) {
        double mMoney = StringUtils.parseDouble(money);
        this.setMontyText(mMoney);
    }
}
