package com.ty.bwagent.fragment.subordinate

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.ty.bwagent.R
import com.ty.bwagent.adapter.CommissionRatioAdapter
import com.ty.bwagent.bean.AgentLowerListBean
import com.ty.bwagent.bean.BaseEntity
import com.ty.bwagent.bean.SchemeSetCommissionEntity
import com.ty.bwagent.fragment.deposit.fragment.TurnMoneyFragment
import com.ty.bwagent.fragment.login.PayPassWordSetFragment
import com.ty.bwagent.utils.DialogUtil
import com.ty.bwagent.utils.TypefaceUtils
import com.ty.bwagent.utils.UserInfoCache
import com.ty.bwagent.utils.Utils
import com.ty.bwagent.view.XTextView
import com.ty.bwagent.viewmodel.SchemeSetViewModle
import com.ty.common.ui.ABBaseFragment
import com.ty.common.util.ABConfig
import com.ty.net.callback.NetObserver
import com.ty.utils.KeyboardUtils
import com.ty.utils.StringUtils
import com.ty.utils.ToastUtils
import kotlinx.android.synthetic.main.frag_suborinate_agent_detail.*
import java.lang.Exception
import java.util.*

/**
 * 下级代理详情
 */
class SubAgentDetailFragment : ABBaseFragment() {


    private lateinit var commissionRatioAdapter: CommissionRatioAdapter
    private var schemeSetViewModle: SchemeSetViewModle? = null

    private var agentLowerBean: AgentLowerListBean.ListBean? = null

    companion object {
        fun getInstant(bundle: Bundle): SubAgentDetailFragment {
            var subAgentDetailFragment = SubAgentDetailFragment();
            subAgentDetailFragment.arguments = bundle
            return subAgentDetailFragment
        }
    }

    override fun createProvider() {

        schemeSetViewModle = ViewModelProvider(this).get(SchemeSetViewModle::class.java)
        //返佣-下级方案
        schemeSetViewModle?.myLowerCommissionLivaData?.observe(this, object : NetObserver<BaseEntity<List<SchemeSetCommissionEntity>>>() {

            override fun onLoading(show: Boolean) {
                super.onLoading(show)
                if (show) {
                    showProgressDialog()
                } else {
                    dismissProgressDialog()
                }
            }

            override fun onSuccess(commissionEntityBaseEntity: BaseEntity<List<SchemeSetCommissionEntity>>?) {

                if (commissionEntityBaseEntity?.data?.get(0)?.rebateDetail != null) {
                    commissionRatioAdapter?.setNewData(commissionEntityBaseEntity?.data?.get(0)?.rebateDetail)
                    setRateDate(0)
                } else {
                    schemeSetViewModle?.myCommission()
                }
            }

            override fun onError(code: Int, errMsg: String) {
                ToastUtils.showToast(errMsg)

            }
        })

        //返佣-我的方案
        schemeSetViewModle?.commissionLivaData?.observe(this, object : NetObserver<BaseEntity<List<SchemeSetCommissionEntity>>>() {

            override fun onSuccess(listBaseEntity: BaseEntity<List<SchemeSetCommissionEntity>>?) {
                listBaseEntity?.data?.get(0)?.rebateDetail.let {
                    commissionRatioAdapter?.setNewData(it)
                    setRateDate(0)
                }

            }

            override fun onError(code: Int, errMsg: String) {
                ToastUtils.showToast(errMsg)
            }
        })
    }

    override fun getLayoutId(): Int {
        return R.layout.frag_suborinate_agent_detail;
    }


    override fun initViewsAndEvents() {
        agentLowerBean = arguments?.getParcelable(ABConfig.KEY_OBJECT);
        commissionRatioAdapter = CommissionRatioAdapter()
        recy_commission.layoutManager = GridLayoutManager(mContext, 3)
        recy_commission.adapter = commissionRatioAdapter

        commissionRatioAdapter?.setOnItemClickListener { _, _, position ->
            commissionRatioAdapter?.setSelect(position)
            setRateDate(position)
        }

        schemeSetViewModle?.myCommission()
        tv_zhuanzhang.setOnClickListener { v -> onClick(v) }

        setDate();
    }

    private fun setRateDate(position: Int) {
        val rebateDetailBean = commissionRatioAdapter.getItem(position) as SchemeSetCommissionEntity.RebateDetailBean
        rebateDetailBean?.let {
            tv_totle_shuying.text = "≥" + Utils.fmtMicrometer(it.profit.toString() + "")
            tv_rate_date.text = it.rate;
        }
    }

    private fun setDate() {

        try {
            agentLowerBean?.let {
                tv_name.text = it.agentName //名字
                tv_name.typeface = TypefaceUtils.DIN_MEDIUM

                tv_subordinateAgent_count.text = Utils.fmtMicrometer(it.subordinateUserCount.toString() + "") //直属代理
                tv_subordinateAgent_count.typeface = TypefaceUtils.DIN_MEDIUM

                tv_subordinateUserCount.text = Utils.fmtMicrometer(it.memberCount.toString() + "")//直属玩家
                tv_subordinateUserCount.typeface = TypefaceUtils.DIN_MEDIUM

                tv_lastBalance.text = Utils.parsListMoney(it.lastBalance)//上月结余
                tv_lastBalance.typeface = TypefaceUtils.DIN_MEDIUM

                tv_czProfit.setMontyText(it.czProfit)//总输赢

                tv_commission.text = Utils.parsListMoney(it.commission)//佣金
                tv_commission.typeface = TypefaceUtils.DIN_MEDIUM

            }
        } catch (e: Exception) {

        }
    }


    fun onClick(v: View?) {
        when (v?.id) {
            R.id.tv_zhuanzhang -> {
                val userInfo = UserInfoCache.getInstance().userInfo
                userInfo?.let {
                    if (it.sysType == 1) {
                        if (StringUtils.isEmpty(userInfo.paymentPassword) || StringUtils.equals("0", userInfo.paymentPassword)) {
                            DialogUtil.confirmPayPassWordDailog(mContext) { start(PayPassWordSetFragment.getInstance()) }
                        } else {
                            bundle.putString(ABConfig.KEY_TAG,agentLowerBean?.agentName);
                            start(TurnMoneyFragment.getInstance(bundle))//官代
                        }
                    } else {
                        bundle.putString(ABConfig.KEY_TAG,agentLowerBean?.agentName);
                       start(TurnMoneyFragment.getInstance(bundle))//普代
                    }
                }
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        KeyboardUtils.hideSoftInput(requireActivity())
    }

}