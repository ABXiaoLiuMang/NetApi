package com.ty.bwagent.fragment.news;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshInternal;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.MessageAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MMessage;
import com.ty.bwagent.header.MyClassicsRefreshFooter;
import com.ty.bwagent.header.MyClassicsRefreshHeader;
import com.ty.bwagent.viewmodel.MessageViewModel;
import com.ty.bwagent.viewmodel.ReadMsgViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.LogUtils;
import com.ty.utils.ToastUtils;

import java.util.List;

/**
 * 消息通知列表
 */
public class MessageFragment extends ABRefreshFragment<MMessage.ListBean> {

    MessageViewModel mMessageViewModel;
    ReadMsgViewModel readMsgViewModel;
    ImageView iv_logo;
    TextView tv_tips;

    int msgType;//消息类型1.通知 2.活动 3.公告
    int pageNum = 1;
    int pageSize = 15;
    int readType;

    /**
     * @param msgType 消息类型1.通知 2.活动 3.公告
     * @return
     */
    public static MessageFragment getInstance(int msgType) {
        MessageFragment fragment = new MessageFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ABConfig.KEY_TAG, msgType);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_message;
    }

    @Override
    protected void createProvider() {
        msgType = bundle.getInt(ABConfig.KEY_TAG);
        readMsgViewModel = new ViewModelProvider(getParentFragment()).get(ReadMsgViewModel.class);
        mMessageViewModel = new ViewModelProvider(getParentFragment()).get(MessageViewModel.class);

        //标识一条为已读
        readMsgViewModel.readedLiveData.observe(this, new SimpleObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                int count = ((MessageAdapter) listAdapter).getUnReadCount();
                if (count == 0) {
                    Fragment fragment = getParentFragment();
                    if (fragment instanceof MessageTabFragment) {
                        MessageTabFragment tabFragment = (MessageTabFragment) fragment;
                        tabFragment.hideDotView(msgType);
                    }
                }
                showRightTitle();
            }
        });
        //一键阅读（全部）
        readMsgViewModel.aLLReadedLiveData.observe(this, new SimpleObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if (readType == msgType) {
                    ((MessageAdapter) listAdapter).setAllRead();
                }
            }
        });

        //一键阅读类型
        readMsgViewModel.msgTypeLiveData.observe(this, integer -> {
            readType = integer;
        });

        //监听删除一条通知消息，刷新
        mMessageViewModel.delMsgLiveData.observe(this, msgId -> {
            LogUtils.d("msgId:" + msgId);
            MessageAdapter messageAdapter = (MessageAdapter) listAdapter;
            messageAdapter.removeId(msgId);
            int count = messageAdapter.getUnReadCount();
            if (count == 0) {
                Fragment fragment = getParentFragment();
                if (fragment instanceof MessageTabFragment) {
                    MessageTabFragment tabFragment = (MessageTabFragment) fragment;
                    tabFragment.hideDotView(msgType);
                }
            }
            showRightTitle();
        });

        if (msgType == 1) {
            //监听消息列表数据
            mMessageViewModel.noticeLiveData.observe(this, netObserver);
        } else {
            mMessageViewModel.activityLiveData.observe(this, netObserver);
        }

    }

    NetObserver<BaseEntity<MMessage>> netObserver = new NetObserver<BaseEntity<MMessage>>() {
        @Override
        protected void onSuccess(BaseEntity<MMessage> listBaseEntity) {
            dismissProgressDialog();
            List<MMessage.ListBean> listBeans = listBaseEntity.getData().getList();
            if (pageNum == 1) {
                refreshLayout.setVisibility(View.VISIBLE);
                listAdapter.setNewData(listBeans);
                refreshLayout.finishRefresh();
            } else {
                listAdapter.addData(listBeans);
                refreshLayout.finishLoadMore();
            }
            if (listBeans.size() < pageNum) {
                refreshLayout.finishLoadMoreWithNoMoreData();
            }

            if (tv_tips != null) {
                iv_logo.setImageResource(R.mipmap.message_empty_bg);
                tv_tips.setText("还没有新的消息");
            }

            showRightTitle();
        }

        @Override
        protected void onError(int code, String errMsg) {
            dismissProgressDialog();
            refreshLayout.setVisibility(View.VISIBLE);
            if (pageNum == 1) {
                refreshLayout.finishRefresh(false);
                showRightTitle();
            } else {
                refreshLayout.finishLoadMore(false);
            }
            ToastUtils.showToast(errMsg);
            if (iv_logo != null) {
                iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
                tv_tips.setText("网络不给力");
            }
        }
    };

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();

        refreshLayout.setVisibility(View.GONE);
        RefreshInternal refreshHeader = refreshLayout.getRefreshHeader();
        RefreshInternal refreshFooter = refreshLayout.getRefreshFooter();
        if (refreshHeader instanceof MyClassicsRefreshHeader) {
            ((MyClassicsRefreshHeader) refreshHeader).bindLifecycle(this);
        }
        if (refreshFooter instanceof MyClassicsRefreshFooter) {
            ((MyClassicsRefreshFooter) refreshFooter).bindLifecycle(this);
        }

    }

    boolean loadData = false;

    @Override
    public void onResume() {
        super.onResume();
        if (!loadData) {
            showProgressDialog();
            mMessageViewModel.msgList(msgType, pageNum, pageSize);
            loadData = true;
        }
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        showRightTitle();
    }

    @Override
    public View getEmptyView() {
        View empty = View.inflate(mContext, R.layout.empty_message, null);
        iv_logo = empty.findViewById(R.id.iv_image);
        tv_tips = empty.findViewById(R.id.tv_message);
        return empty;
    }


    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }

    @Override
    public BaseQuickAdapter<MMessage.ListBean, BaseViewHolder> getListAdapter() {
        return new MessageAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        MMessage.ListBean mMMessage = (MMessage.ListBean) adapter.getItem(position);
        Bundle bundle = new Bundle();
        bundle.putParcelable(ABConfig.KEY_OBJECT, mMMessage);
        bundle.putInt(ABConfig.KEY_TAG, msgType);
        ((ABBaseFragment) getParentFragment()).start(MessageDetailsFragment.getInstance(bundle));
        if (mMMessage.getIsRead() == 0) {//未读，标记为已读
            readMsgViewModel.msgReaded(mMMessage.getId());//标记这条信息为已读
            mMMessage.setIsRead(1);
            listAdapter.setData(position, mMMessage);
        }

    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        pageNum++;
        mMessageViewModel.msgList(msgType, pageNum, pageSize);
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        pageNum = 1;
        mMessageViewModel.msgList(msgType, pageNum, pageSize);

        /**
         * 这里刷新一下未读消息（测试说有信息刷新上面不显示小红点，艹）
         */
        ((MessageAdapter) listAdapter).setRestRead();
        mMessageViewModel.getUnreadForType();
    }

    @Override
    public void onStop() {
        super.onStop();
        refreshLayout.finishRefresh();
        refreshLayout.finishLoadMore();
    }

    private void showRightTitle() {
        Fragment fragment = getParentFragment();
        if (fragment != null && fragment instanceof MessageTabFragment) {
            MessageTabFragment tabFragment = (MessageTabFragment) fragment;
            MessageAdapter messageAdapter = (MessageAdapter) listAdapter;
            int count = messageAdapter.getUnReadCount();
            tabFragment.showRightTitle(count > 0, msgType - 1);
        }
    }
}
