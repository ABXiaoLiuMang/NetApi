package com.ty.bwagent.common;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.utils.MMKVUtil;

/**
 * desc:
 *
 * @author Jeff created on 2019/9/19.
 */
public class PreInfoParser {
    public static final String LOCATION_KEY = "location_key";
    public static final String LOCATION_ADDRESS = "address";
    private static final String CUSTOMER_SERVICE = "customer_service";
    public static final String PRE_INFO_DATA = "sport_preInfo_data";

    public static PreInfoParser getInstance() {
        return Holder.ourInstance;
    }

    private PreInfoParser() {
    }

    private static class Holder {
        static final PreInfoParser ourInstance = new PreInfoParser();
    }

    public void parse(BaseEntity<String> entity) {
        if (entity == null) return;
        String preInfoStr = entity.getData();
        if(!TextUtils.isEmpty(preInfoStr)){
            MMKVUtil.put(PRE_INFO_DATA,preInfoStr);// 把preInfo 保存起来。如果其他接口返回为空，就用保存的
        }

        PreinfoBean preInfo = new Gson().fromJson(entity.getData(), PreinfoBean.class);

        if (preInfo == null) return;
        SiteBaseConfig siteBaseConfig = preInfo.getSiteBaseConfigVo();
        if (siteBaseConfig != null) {
            String customerService = preInfo.getSiteBaseConfigVo().getCustomerService();
            if (TextUtils.isEmpty(customerService)) {
                return;
            }
            MMKVUtil.put(CUSTOMER_SERVICE, customerService);
            MMKVUtil.put("siteDomainUrl", siteBaseConfig.getSiteDomainUrl());
            String h5_domain=preInfo.getSiteBaseConfigVo().getH5DomainUrl();
            if (h5_domain.startsWith("http://")||h5_domain.startsWith("https://")){
                MMKVUtil.put("h5_domain", h5_domain);
            }
            MMKVUtil.put("sportAppDomainUrl", siteBaseConfig.getSportAppDomainUrl());
        }


        //用户Ip地址
        if (null != preInfo && !TextUtils.isEmpty(preInfo.getIp())) {
            MMKVUtil.put(LOCATION_KEY, preInfo.getIp());
        }
        if (null != preInfo && !TextUtils.isEmpty(preInfo.getIp())) {
            MMKVUtil.put(LOCATION_ADDRESS, preInfo.getAddress());
        }
    }

    /**
     * 解析 IP 和 地址
     * @param pojo
     */
    public void parseWarnData(String pojo) {
        if (TextUtils.isEmpty(pojo)) {
            return;
        }

        if (pojo.contains("ip") && pojo.contains("address")){
            CheckWarnRestrict checkWarnRestrict = new Gson().fromJson(pojo, CheckWarnRestrict.class);
            MMKVUtil.put(LOCATION_KEY, checkWarnRestrict.getIp());
            MMKVUtil.put(LOCATION_ADDRESS, checkWarnRestrict.getAddress());
        }

    }
}