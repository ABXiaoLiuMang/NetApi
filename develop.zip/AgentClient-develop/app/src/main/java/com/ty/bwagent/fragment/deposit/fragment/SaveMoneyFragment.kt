package com.ty.bwagent.fragment.deposit.fragment

import android.text.Editable
import android.text.InputFilter
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.lxj.xpopup.interfaces.OnCancelListener
import com.lxj.xpopup.interfaces.OnConfirmListener
import com.ty.bwagent.R
import com.ty.bwagent.bean.*
import com.ty.bwagent.fragment.deposit.viewmodel.SaveViewModel
import com.ty.bwagent.fragment.deposit.viewmodel.TurnConfigViewModel
import com.ty.bwagent.fragment.login.PayPassWordSetFragment
import com.ty.bwagent.utils.*
import com.ty.bwagent.viewmodel.MoneyViewModel
import com.ty.common.ui.ABBaseFragment
import com.ty.net.callback.NetObserver
import com.ty.net.callback.SimpleObserver
import com.ty.utils.*
import kotlinx.android.synthetic.main.fragment_save_layout.*
import kotlinx.android.synthetic.main.fragment_save_layout.commit_limit
import kotlinx.android.synthetic.main.fragment_save_layout.drawing_tv_warning
import kotlinx.android.synthetic.main.fragment_save_layout.et_input_account
import kotlinx.android.synthetic.main.fragment_save_layout.et_input_money
import kotlinx.android.synthetic.main.fragment_save_layout.et_input_note
import kotlinx.android.synthetic.main.fragment_save_layout.group_type
import kotlinx.android.synthetic.main.fragment_save_layout.rb_type_pass
import kotlinx.android.synthetic.main.fragment_save_layout.rb_type_phone
import kotlinx.android.synthetic.main.fragment_save_layout.rg_payType
import kotlinx.android.synthetic.main.fragment_save_layout.titleBar
import kotlinx.android.synthetic.main.fragment_save_layout.tv_limit_money
import kotlinx.android.synthetic.main.fragment_save_layout.tv_limit_tips
import kotlinx.android.synthetic.main.fragment_turn_layout.*
import kotlinx.android.synthetic.main.include_save_msg.*
import kotlinx.android.synthetic.main.include_save_password.*

/**
 * 代理代存
 */
class SaveMoneyFragment : ABBaseFragment(), View.OnClickListener {

    lateinit var turnConfigViewModel: TurnConfigViewModel
    lateinit var saveViewModel: SaveViewModel
    lateinit var moneyViewModel: MoneyViewModel
    var agentDepositSettingBean: MemberConfigEntity.AgentDepositSettingBean? = null
    var commission: Commission? = null
    var account: String? = null //代存账号
    var money: String? = null//代存金额
    var note: String? = null//备注
    var proxyType = 1
    var limitType = true//ture: 额度代存 false 佣金代存
    var saveType = true//ture: 验证码支付 false 密码支付
    private lateinit var softKeyboardHelper: SoftKeyboardHelper
    var password: String? = null//代存支付密码
    var code: String? = null//验证码
    var phone: String? = null
    var flowRatio: String? = null
    var msgEnabled = false
    var passEnabled = false
    companion object {
        fun getInstance(): SaveMoneyFragment {
            return SaveMoneyFragment()
        }
    }

    override fun getLayoutId(): Int {
        return R.layout.fragment_save_layout
    }

    override fun createProvider() {
        moneyViewModel = ViewModelProvider(requireActivity()).get(MoneyViewModel::class.java)
        saveViewModel = ViewModelProvider(this).get(SaveViewModel::class.java)
        turnConfigViewModel = ViewModelProvider(this).get(TurnConfigViewModel::class.java)

        //佣金余额
        moneyViewModel.commissLiveData.observe(this, object : NetObserver<BaseEntity<Commission>>() {
            override fun onSuccess(baseEntity: BaseEntity<Commission>) {
                commission = baseEntity.data
                initSaveMoney()
            }

            override fun onError(code: Int, errMsg: String) {}
        })

        //转账结果监听
        saveViewModel.saveLiveData.observe(this, object : NetObserver<BaseEntity<*>>() {
            override fun onSuccess(baseEntity: BaseEntity<*>) {
                ToastUtils.showLong("代存成功")
                pop()
            }

            override fun onLoading(show: Boolean) {
                if (show) showProgressDialog() else dismissProgressDialog()
            }

            override fun onError(code: Int, errMsg: String) {
                ToastUtils.showLong(errMsg)
                moneyViewModel.initMoney()//刷新一下可转账金额
                turnConfigViewModel.getAgentDepositConfig()//代理代存，代理转账，配置
            }
        })

        //代理转账-获取下级用户信息接口
        saveViewModel.saveUserInfoLiveData.observe(this, object : SimpleObserver<BaseEntity<SaveUserEntity>>() {
            override fun onSuccess(baseEntity: BaseEntity<SaveUserEntity>) {
                var userName = baseEntity.data.realName
                if (StringUtils.length(userName) > 0) {
                    userName = userName.substring(0, 1) + "**"
                }
                account = baseEntity.data.name
                val depositEntity = DepositEntity(money, account, userName, false)
                depositEntity.status = baseEntity.data.status//用户状态(0停用，1启用)
                showCommitDialog(depositEntity)
            }

            override fun onLoading(show: Boolean) {
                if (show) {
                    commit_limit.isEnabled = false
                    showProgressDialog()
                } else {
                    commit_limit.isEnabled = true
                    dismissProgressDialog()
                }
            }

        })

        //代理代存，代理转账，配置
        XLiveDataManager.getInstance().memberConfigLiveData.observe(this, object : NetObserver<BaseEntity<MemberConfigEntity>>() {
            override fun onSuccess(memberConfigEntityBaseEntity: BaseEntity<MemberConfigEntity>?) {
                memberConfigEntityBaseEntity?.data?.let {
                    agentDepositSettingBean = it.agentDepositSetting?.apply {
                        tv_limit_tips.text = StringUtils.getFormatString(ResUtils.getString(R.string.generic_deposit_save),
                                Utils.getMoney(this.min),
                                Utils.getMoney(this.max),
                                Utils.getMoney(this.stint))
                    }
                    if(it.showFlowRatio == 0){
                        group_water.visibility = View.VISIBLE
                    }else{
                        group_water.visibility = View.GONE
                    }

                }
            }

            override fun onError(code: Int, errMsg: String) {}
        })

        //监听验证码
        saveViewModel.codeLivedata.observe(this, object : NetObserver<BaseEntity<*>>() {
            override fun onSuccess(baseEntity: BaseEntity<*>?) {
                if (baseEntity == null) {
                    return
                }
                //保存获取成功验证码时间，60秒能不能重复获取
                MMKVUtil.put(SaveMoneyFragment::class.java.simpleName, System.currentTimeMillis())
                ToastUtils.showLong("验证码已发送")
                saveViewModel.startTimer(lifecycle)
            }

            override fun onLoading(show: Boolean) {
                if (show) {
                    showProgressDialog()
                } else {
                    dismissProgressDialog()
                }
            }

            override fun onError(code: Int, errMsg: String) {
                ToastUtils.showLong(errMsg)
                tv_save_code.isEnabled = true
                Utils.isClickedReset60S(errMsg, lifecycle, saveViewModel, tv_save_code)
            }
        })

        //验证码倒计时
        saveViewModel.timerLiveData.observe(this, androidx.lifecycle.Observer {
            if (it.toLong() == 0L) {
                tv_save_code.text = ResUtils.getString(R.string.generic_reset_code)
                tv_save_code.isEnabled = true
            } else {
                tv_save_code.text = StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time), it)
                tv_save_code.isEnabled = false
            }
        })

    }


    override fun initViewsAndEvents() {
        et_input_water.addTextChangedListener(object : SimpleTextWatcher(){
            override fun afterTextChanged(s: Editable) {
                s.toString().run {
                    if(s.length == 1 && StringUtils.equals("0",this)){
                        s?.clear()
                    }
                }
            }
        })

        Utils.isClicked60S(SaveMoneyFragment::class.java.simpleName, lifecycle, saveViewModel, tv_save_code)

        InputResultCalculator(listOf(et_input_account, et_input_money,et_input_water, et_input_code)) { ok ->
                commit_limit.isEnabled = ok
                msgEnabled = ok
        }

        commit_limit.setOnClickListener(this)
        tv_save_code.setOnClickListener(this)
        iv_eye_pass.setOnClickListener(this)
        mainLayout.setOnClickListener(this)
        val userInfo = UserInfoCache.getInstance().userInfo
        rg_saveType.setOnCheckedChangeListener { _, checkedId ->
            when(checkedId){
                R.id.rb_save_limit ->{
                    proxyType = 1
                    limitType = true
                    initSaveMoney()
                }
                R.id.rb_save_money ->{
                    proxyType = 0
                    limitType = false
                    initSaveMoney()
                }
            }
            checkRefreshWarning()
        }

        rg_payType.setOnCheckedChangeListener { _, checkedId ->
            when(checkedId){
                R.id.rb_type_phone ->{
                    group_pass.visibility = View.GONE
                    group_msg.visibility = View.VISIBLE
                    commit_limit.isEnabled = msgEnabled
                    InputResultCalculator(listOf(et_input_account, et_input_money, et_input_code)) { ok ->
                        commit_limit.isEnabled = ok
                        msgEnabled = ok
                    }
                    saveType = true
                }
                R.id.rb_type_pass ->{
                    if (StringUtils.isEmpty(userInfo.paymentPassword) || "0" == userInfo.paymentPassword) {
                        DialogUtil.confirmPayPassWordDailog(mContext){
                            start(PayPassWordSetFragment.getInstance())
                        }
                        rb_type_phone.isChecked = true
                        return@setOnCheckedChangeListener
                    }
                    group_pass.visibility = View.VISIBLE
                    group_msg.visibility = View.GONE
                    commit_limit.isEnabled = passEnabled
                    InputResultCalculator(listOf(et_input_account, et_input_money, et_input_password)) { ok ->
                        commit_limit.isEnabled = ok
                        passEnabled = ok
                    }
                    saveType = false
                }
            }
        }

        if (userInfo.sysType == 1) {//管代
            rb_type_pass.isChecked = true
            rb_type_phone.isChecked = false
            group_type.visibility = View.GONE
        }


        titleBar.setRightOnClickListener {
            KeyboardUtils.hideSoftInput(requireActivity())
            start(SaveRecordFragment.getInstance())
        }
        titleBar.setTitleRightDrawable(R.mipmap.member_ask_bg)
        //顶部提示弹窗
        titleBar.setTitleOnClickListener { DialogUtil.showDepositTipsDialog(mContext) }


        phone = UserInfoCache.getInstance().userInfo?.phone
        tv_phone.text = Utils.getHidePhone(phone)

        et_input_money.filters = arrayOf(MoneyValueFilter(), InputFilter.LengthFilter(12))
        et_input_money.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {//获的焦点
                drawing_tv_warning.text = ""
            } else {//失去焦点
                if (et_input_money == null) {
                    return@setOnFocusChangeListener
                }
                checkRefreshWarning()
            }
        }
        moneyViewModel.initMoney()//获取可转账金额
        turnConfigViewModel.getAgentDepositConfig()//代理代存，代理转账，配置
        registerKeyboardListener()
    }


    /**
     * 软键盘输入框管理
     */
    private fun registerKeyboardListener() {
        // 键盘弹出密码输入框需要更新位置，整体布局上移
        softKeyboardHelper = SoftKeyboardHelper()
                .registerFragment(this)
                .setOnSoftKeyboardChangeListener(object : SoftKeyboardHelper.OnSoftKeyboardChangeListener {
                    override fun onSoftKeyboardChanged(keyboardHeightInPx: Int) {}

                    override fun onSoftKeyboardOpened(keyboardHeightInPx: Int) {
                        rootView.scrollTo(0, SizeUtils.dp2px(50f) + StatusBarUtil.getNavBarHeight())
                    }

                    override fun onSoftKeyboardClosed() {
                        rootView.scrollTo(0, 0)
                    }
                })

    }


    override fun onClick(v: View?) {
        if (DoubleClickUtils.isLongDoubleClick()) {
            return
        }
        when (v?.id) {
            R.id.commit_limit -> {//提交
              commitClick()
            }
            R.id.iv_eye_pass -> {
                showHidePassWord()
            }
            R.id.tv_save_code -> {
                tv_save_code.isEnabled = false
                saveViewModel.getPhoneCode(phone)
            }
            R.id.mainLayout -> {
               KeyboardUtils.hideSoftInput(requireActivity())
            }
        }
    }

    /**
     * 提交按钮事件
     */
    private fun commitClick(){
        account = et_input_account.text?.toString()
        money = et_input_money.text?.toString()
        password = et_input_password.text?.toString()
        note = et_input_note.text?.toString()
        code = et_input_code.text?.toString()
        flowRatio = et_input_water.text?.toString()

        if (StringUtils.length(account) < 4) {
            ToastUtils.showLong(ResUtils.getString(R.string.generic_username_warn))
            return
        }

        if (StringUtils.isEmpty(flowRatio)) {
            ToastUtils.showLong(ResUtils.getString(R.string.generic_save_water))
            return
        }

        if (saveType) {
            if (!VerifyUtils.isCode(code)) {
                ToastUtils.showLong(ResUtils.getString(R.string.generic_code_warn))
                return
            }
        } else {
            if (StringUtils.length(password) < 6) {
                ToastUtils.showLong("请输入支付密码（6位字母或数字）")
                return
            }
        }

        agentDepositSettingBean?.let {
            if (StringUtils.parseDouble(money) < it.min || StringUtils.parseDouble(money) > it.max) {
                ToastUtils.showLong(StringUtils.getFormatString(ResUtils.getString(R.string.generic_save_tips), Utils.getMoney(it.min), Utils.getMoney(it.max)))
                return
            }
        }
        saveViewModel.agentDepositInfo(account)
    }

    private fun showCommitDialog(depositEntity: DepositEntity) {
        KeyboardUtils.hideSoftInput(requireActivity())
        DialogUtil.depositPopupDailog(mContext, depositEntity)
                .setListener({
                    //提款确认按钮
                    KeyboardUtils.hideSoftInput(requireActivity())
                    if (saveType) {
                        saveViewModel.commitMoneySave(proxyType, account, money, code, note,flowRatio)
                    } else {
                        saveViewModel.commitLimitSave(proxyType, account, money, password, note,flowRatio)
                    }

                }, null)
                .setCancelTextColor(R.color.generic_heise)
                .setConfirmTextColor(R.color.site_style_color)
                .setTitleContent("提示", "是否确定为下列账号进行代存：", null)
    }


    /**
     * 更新提示语
     */
    private fun checkRefreshWarning(){
        val money = StringUtils.parseDouble(et_input_money.text?.toString()?.trim { it <= ' ' })
        if(money == 0.00) return
        agentDepositSettingBean?.let {
            if (money > it.max || money < it.min) {
                drawing_tv_warning.text = StringUtils.getFormatString(ResUtils.getString(R.string.generic_deposit_tips), Utils.getMoney(it.min), Utils.getMoney(it.max))
                return@checkRefreshWarning
            }
        }

        commission?.let {
            val commissionMoney = if (limitType) it.valetMoney else it.agentMoney - it.agentFreezedMoney
            if (money > commissionMoney) drawing_tv_warning.text = "不能超过可代存金额" else  drawing_tv_warning.text = ""
        }
    }

    /**
     * 初始化金额
     */
    private fun initSaveMoney() {
        //佣金余额
        commission?.let {
            val money = if (limitType) it.valetMoney else it.agentMoney - it.agentFreezedMoney
            if (money >= 10000000000.0) {
                tv_limit_money.text = "9,999,999,999.99"
            } else {
                tv_limit_money.text = Utils.roundDownMoney(money)
            }
        }
    }


    private fun showHidePassWord() {
        val type = et_input_password.transformationMethod
        if (PasswordTransformationMethod.getInstance() == type) {
            et_input_password.transformationMethod = HideReturnsTransformationMethod.getInstance()
            iv_eye_pass.setImageResource(R.mipmap.login_eye_show_bg)
        } else {
            et_input_password.transformationMethod = PasswordTransformationMethod.getInstance()
            iv_eye_pass.setImageResource(R.mipmap.login_eye_hide_bg)
        }
        et_input_password.setSelection(et_input_password.text.toString().length)
    }

    override fun onDestroy() {
        super.onDestroy()
        XLiveDataManager.getInstance().getUserInfo()//请求个人信息
        turnConfigViewModel.getAgentDepositConfig()
        KeyboardUtils.hideSoftInput(requireActivity())
        softKeyboardHelper?.unregisterView()
    }

}
