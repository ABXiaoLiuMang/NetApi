package com.ty.bwagent.dialog;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.core.ImageViewerPopupView;
import com.ty.bwagent.R;

public class ImagePopupView extends ImageViewerPopupView {

    TextView backView;

    public ImagePopupView(@NonNull Context context) {
        super(context);
    }

    @Override
    protected int getPopupLayoutId() {
        return R.layout.custom_dialog_big_pic;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        backView = findViewById(R.id.backView);
        backView.setOnClickListener(v -> dismiss());
    }
}
