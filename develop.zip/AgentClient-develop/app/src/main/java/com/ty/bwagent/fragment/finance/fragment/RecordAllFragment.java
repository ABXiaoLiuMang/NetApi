package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import com.ty.bwagent.bean.RecordFilterEntity;
import com.ty.common.util.ABConfig;

/**
 * 提款记录界面(全部)
 */
public class RecordAllFragment extends RecordFragment {

    public static RecordAllFragment getInstance(int index) {
        RecordAllFragment fragment = new RecordAllFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ABConfig.KEY_TAG,index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void createProvider() {
        super.createProvider();
        Fragment fragment = getParentFragment();
        if(fragment != null && fragment instanceof RecordTabFragment){
            RecordTabFragment tabFragment = (RecordTabFragment) fragment;
            tabFragment.filterLiveData.observe(this, recordFilterEntity -> refreshFilter(recordFilterEntity));
        }
    }

    private void refreshFilter(RecordFilterEntity entity){
        pageNum = 1;
        pageSize = 10;
        status = entity.getStatus();
        startDate = entity.getStartDate();
        endDate = entity.getEndDate();
        mRecordViewModel.withdrawalListFilter(startDate,endDate,status,pageNum,pageSize);
    }

}
