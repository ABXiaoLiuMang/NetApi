package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MemberDetailsEntity;
import com.ty.bwagent.bean.MemberGameEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

public class MemberDetailsViewModel extends ViewModel {

    //游戏列表
    public NetLiveData<BaseEntity<MemberGameEntity>> memberGameLiveData = new NetLiveData<>();

    //下级会员详情
    public NetLiveData<BaseEntity<MemberDetailsEntity>> memberDetailsLiveData = new NetLiveData<>();


    /**
     * 游戏列表
     * @param memberId 会员ID
     * @param startDate
     * @param endDate
     * @param pageNum
     * @param pageSize
     */
    public void queryLowerMember(String memberId,String startDate,String endDate,int pageNum,int pageSize){
        NetSdk.create(Api.class)
                .queryGameInfo()
                .params("memberId", memberId)
                .params("startDate",startDate)
                .params("endDate",endDate)
                .params("pageNum",pageNum)
                .params("pageSize",pageSize)
                .asJSONType()
                .send(memberGameLiveData);
    }
    /**
     * 游戏详情
     * @param memberId 会员ID
     */
    public void queryLowerMemberDetail(String memberId){
        NetSdk.create(Api.class)
                .queryLowerMemberDetail()
                .params("memberId", memberId)
                .asJSONType()
                .send(memberDetailsLiveData);
    }

}
