package com.ty.bwagent.fragment.finance.fragment;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.FinanceEntity;
import com.ty.bwagent.fragment.finance.adapter.FinanceDetailsAdapter;
import com.ty.bwagent.fragment.finance.bean.FinanceDetails;
import com.ty.bwagent.fragment.finance.viewmodel.FinanceDetailsViewModel;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.Utils;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.ui.Mode;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.ResUtils;

import java.util.List;

/**
 * 月度详细 三个共用界面
 * 1.佣金
 * 2.净输赢
 * 3.冲正后净输赢
 */
public abstract class FinanceDetailsFragment extends ABRefreshFragment<FinanceDetails> {

    protected FinanceDetailsViewModel mFinanceDetailsViewModel;

    protected FinanceEntity financeEntity;//佣金明细对象

    LinearLayout title_layout;//标题布局
    TextView tv_service;//联系客服

    LinearLayout ll_net;
    TextView bnt_nonet;

    @Override
    protected void createProvider() {
        mFinanceDetailsViewModel = new ViewModelProvider(this).get(FinanceDetailsViewModel.class);

        //监听数据
        mFinanceDetailsViewModel.financeNetLiveData.observe(this,new SimpleObserver<BaseEntity<List<FinanceDetails>>>(){
            @Override
            protected void onSuccess(BaseEntity<List<FinanceDetails>> listBaseEntity) {
                List<FinanceDetails> details = listBaseEntity.getData();
                if(details.size() > 0){
                    title_layout.setVisibility(View.VISIBLE);
                }else {
                    title_layout.setVisibility(View.GONE);
                }
                listAdapter.setNewData(details);

                if (ll_net != null) {
                    ll_net.setVisibility(View.GONE);
                }
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                if (ll_net != null) {
                    ll_net.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        financeEntity = bundle.getParcelable(ABConfig.KEY_OBJECT);
//        mFinanceDetailsViewModel.getGameFanshuiHighLow();
        title_layout = rootView.findViewById(R.id.title_layout);
        tv_service = rootView.findViewById(R.id.tv_service);
        tv_service.setOnClickListener(v -> goActivity(OnlineActivity.class));
        Utils.setTextViewLine(tv_service, ResUtils.getString(R.string.generic_service));

        if (bnt_nonet != null) {
            bnt_nonet.setOnClickListener(v -> mFinanceDetailsViewModel.getGameFanshuiHighLow());
        }

        recyclerView.setVisibility(View.GONE);
        title_layout.setVisibility(View.GONE);
    }



    @Override
    public int getMode() {
        return Mode.DISABLED;
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }


    @Override
    public BaseQuickAdapter<FinanceDetails, BaseViewHolder> getListAdapter() {
        return new FinanceDetailsAdapter();
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
    }
}
