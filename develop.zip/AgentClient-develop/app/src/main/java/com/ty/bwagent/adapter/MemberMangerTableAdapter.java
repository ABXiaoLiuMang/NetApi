package com.ty.bwagent.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.TeamMenberInfoEntity;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.view.XTextView;
import com.ty.bwagent.view.table.TableAdapter;
import com.ty.tysite.utils.ImageResoureSiteUtils;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ScreenUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

//团队财务
public class MemberMangerTableAdapter extends TableAdapter<TeamMenberInfoEntity.ListBean> {

    List<TeamMenberInfoEntity.ListBean> arrayList = new ArrayList<>();
    RecyclerView.Adapter adapter;
    private Context context;
    public boolean isAddNoDate;
    ViewGroup.LayoutParams layoutParams;
    private final int endColumnWidth;

    public MemberMangerTableAdapter(Context context, List<TeamMenberInfoEntity.ListBean> listBeans) {
        this.context = context;
        this.arrayList.addAll(listBeans);
        layoutParams = new ViewGroup.LayoutParams(SizeUtils.dp2px(100), SizeUtils.dp2px(40));
        endColumnWidth = ScreenUtils.getAppScreenWidth() - SizeUtils.dp2px(100) - SizeUtils.dp2px(100) - SizeUtils.dp2px(28);
        int appScreenHeight = ScreenUtils.getAppScreenHeight();
        int height = appScreenHeight - SizeUtils.dp2px(40) * getRowCount() - SizeUtils.dp2px(170 + 140);
        if (arrayList.size() > 1 && height > 0) {
            isAddNoDate = true;
        } else {
            isAddNoDate = false;
        }
    }

    @Override
    public int getRowCount() {
        return isAddNoDate ? arrayList.size() + 1 : arrayList.size();
    }

    @Override
    public void setRecyclerAdapter(RecyclerView.Adapter adapter) {
        this.adapter = adapter;
    }

    @Override
    public void addDatas(List<TeamMenberInfoEntity.ListBean> datas) {
        arrayList.addAll(datas);
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void setNewDatas(List<TeamMenberInfoEntity.ListBean> datas) {
        arrayList.clear();
        arrayList.addAll(datas);
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    //没有数据 只显示头
    public void setNoDate() {
        List<TeamMenberInfoEntity.ListBean> listBeans1 = new ArrayList<>();
        TeamMenberInfoEntity.ListBean listBean = new TeamMenberInfoEntity.ListBean();
        listBeans1.add(listBean);
        setNewDatas(listBeans1);
    }


    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int row, int column) {
        if (holder instanceof VH) {
            TeamMenberInfoEntity.ListBean listBean = arrayList.get(row);
            VH vhHolder = (VH) holder;
            vhHolder.t.setCompoundDrawables(null, null, null, null);
            if (row == 0) {
                vhHolder.t.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                switch (column) {
                    case 0:
                        vhHolder.t.setCompoundDrawables(null, null, null, null);
                        vhHolder.t.setText("代理账号");
                        break;
                    case 1:
                        vhHolder.t.setText("下级人数");
                        break;
                    case 2:
                        vhHolder.t.setText("加入团队时间");
                        break;
                }
            } else {
                if (listBean == null) {
                    return;
                }
                vhHolder.t.setCompoundDrawables(null, null, null, null);
                vhHolder.t.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
                switch (column) {
                    case 0://团队代理
                        vhHolder.t.setText(listBean.getAgentName());
                        if (listBean.getIsCaptain() == 1) {
                            vhHolder.t.setCompoundDrawables(null, null, null, null);
                            Drawable nav_up = context.getResources().getDrawable(ImageResoureSiteUtils.teamIconFlagBg());
                            nav_up.setBounds(0, 0, nav_up.getMinimumWidth(), nav_up.getMinimumHeight());
                            vhHolder.t.setCompoundDrawablePadding(3);
                            vhHolder.t.setCompoundDrawables(null, null, nav_up, null);
                        }
                        break;
                    case 1://下级人数
                        vhHolder.t.setText(Utils.fmtMicrometer(listBean.getSubMemberNum() + ""));
                        break;
                    case 2://加入团队时间
                        vhHolder.t.setText(listBean.getCreatedAt() + "");
                        break;
                }
            }

            if (column == 0) {
                vhHolder.fl.setLayoutParams(layoutParams);
                vhHolder.fl.setGravity(Gravity.CENTER_VERTICAL);
                vhHolder.fl.setPadding(SizeUtils.dp2px(10), 0, 0, 0);
            } else if (column == 1) {
                vhHolder.fl.setLayoutParams(layoutParams);
                vhHolder.fl.setGravity(Gravity.CENTER);
                vhHolder.fl.setPadding(0, 0, 0, 0);
            } else if (column == 2) {
                vhHolder.fl.setLayoutParams(new ViewGroup.LayoutParams(endColumnWidth, SizeUtils.dp2px(40)));
                vhHolder.fl.setGravity(Gravity.CENTER_VERTICAL);
                vhHolder.fl.setPadding(0, 0, 0, 0);
            }

            if (row % 2 == 1) {
                vhHolder.fl.setBackgroundColor(ResUtils.getColor(R.color.generic_forget_setp_color));
            } else {
                vhHolder.fl.setBackgroundColor(ResUtils.getColor(android.R.color.white));
            }

            vhHolder.fl.setOnClickListener(v -> KeyboardUtils.hideSoftInput(vhHolder.fl));
        } else {
            holder.itemView.setOnClickListener(v -> KeyboardUtils.hideSoftInput(holder.itemView));
        }
    }


    public int TYPE_NODATE = 0;
    public int TYPE_CONTENT = 1;

    @Override
    public int getItemViewType(int row, int column) {
        if (isAddNoDate && row == getRowCount() - 1) {
            return TYPE_NODATE;
        } else {
            return TYPE_CONTENT;
        }
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if (viewType == TYPE_NODATE) {
            FrameLayout relativeLayout = new FrameLayout(parent.getContext());
            onLastItemLayout(relativeLayout);
            return new NoDateHolder(relativeLayout);
        } else {
            RelativeLayout relativeLayout = new RelativeLayout(parent.getContext());
            XTextView tv = new XTextView(parent.getContext());
            tv.setSingleLine(true);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, context.getResources().getDimensionPixelSize(R.dimen.dp_12));

            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setTextColor(context.getResources().getColor(R.color.generic_heise));
            relativeLayout.addView(tv);
            return new VH(relativeLayout);
        }

    }

    public void onLastItemLayout(View itemView) {
        //170dp
        int appScreenHeight = ScreenUtils.getAppScreenHeight();
        int height = appScreenHeight - SizeUtils.dp2px(40) * getRowCount() - SizeUtils.dp2px(170 + 130+20);
        if (height > 0) {
            itemView.setLayoutParams(new ViewGroup.LayoutParams(SizeUtils.dp2px(100), height));
            itemView.requestLayout();
        }
    }

    static class VH extends RecyclerView.ViewHolder {
        XTextView t;
        RelativeLayout fl;

        public VH(RelativeLayout itemView) {
            super(itemView);
            t = (XTextView) itemView.getChildAt(0);
            fl = itemView;
        }
    }

    static class NoDateHolder extends RecyclerView.ViewHolder {

        public NoDateHolder(FrameLayout itemView) {
            super(itemView);
        }
    }
}
