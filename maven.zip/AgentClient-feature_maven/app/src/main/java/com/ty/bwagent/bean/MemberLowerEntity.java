package com.ty.bwagent.bean;

/**
 * 查询下级会员和新增下级会员数量
 */
public class MemberLowerEntity {

    /**
     * addNewLowerMember : 0
     * lowerMemberTotal : 0
     */

    private int addNewLowerMember;//新增下级会员
    private int lowerMemberTotal;//下级会员总数

    public int getAddNewLowerMember() {
        return addNewLowerMember;
    }

    public void setAddNewLowerMember(int addNewLowerMember) {
        this.addNewLowerMember = addNewLowerMember;
    }

    public int getLowerMemberTotal() {
        return lowerMemberTotal;
    }

    public void setLowerMemberTotal(int lowerMemberTotal) {
        this.lowerMemberTotal = lowerMemberTotal;
    }
}
