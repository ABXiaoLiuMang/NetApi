package com.ty.bwagent.fragment.schemeset;

import android.content.Context;
import android.os.Bundle;

import com.ty.bwagent.R;
import com.ty.bwagent.adapter.ViewPagerFragmentAdapter;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.ABConfig;
import com.ty.common.view.magicindicator.MagicIndicator;
import com.ty.common.view.magicindicator.ViewPagerHelper;
import com.ty.common.view.magicindicator.buildins.commonnavigator.CommonNavigator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.badge.BadgePagerTitleView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;

import androidx.viewpager.widget.ViewPager;
import butterknife.BindView;

/**
 * 返佣方案设置
 */
public class SchemeSetTabFragment extends ABBaseFragment {

    @BindView(R.id.magicIndicator)
    protected MagicIndicator magicIndicator;
    @BindView(R.id.viewPager)
    public ViewPager mViewPager;

    String[] tabTitles = new String[]{"我的", "直属下级"};
    ArrayList<ABBaseFragment> fragments = new ArrayList<>();
    private OnChildFragListener onChildFragListener;
    private int pagePositon;

    public static SchemeSetTabFragment getInstance(int pagePositon) {
        SchemeSetTabFragment fragment = new SchemeSetTabFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ABConfig.KEY_TAG, pagePositon);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.frag_set_scheme;
    }

    @Override
    protected void createProvider() {
    }

    @Override
    protected void initViewsAndEvents() {
        initDate();
        initListener();
    }

    private void initDate() {

        pagePositon = getArguments().getInt(ABConfig.KEY_TAG, 0);
        fragments.clear();
        if (pagePositon == 0) {
            fragments.add(SchemeCommissionFragment.getInstance(0));
            fragments.add(SchemeCommissionFragment.getInstance(1));
        } else {
            fragments.add(SchemeRebateFragment.getInstance(0));
            fragments.add(SchemeRebateFragment.getInstance(1));
        }

        ViewPagerFragmentAdapter adapter = new ViewPagerFragmentAdapter(getChildFragmentManager(), fragments);
        mViewPager.setAdapter(adapter);
        CommonNavigator commonNavigator = new CommonNavigator(mContext);
        commonNavigator.setAdapter(mAdapter);
        commonNavigator.setAdjustMode(false);
        magicIndicator.setNavigator(commonNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }

    //监听
    private void initListener() {
        mViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                KeyboardUtils.hideSoftInput(rootView);
                if (onChildFragListener != null) {
                    onChildFragListener.onChildViewPagerChange(pagePositon, position);
                }
                if (pagePositon == 0) {
                    if (position == 1) {//返佣方案 第一次加载
                        ((SchemeCommissionFragment) fragments.get(1)).myLowerCommission();
                    }
                } else {
                    if (position == 1) {//返水方案 第一次加载
                        ((SchemeRebateFragment) fragments.get(1)).loadDate();
                    }
                }
            }
        });

        //子页面增加监听
        if (pagePositon == 0) {
            ((SchemeCommissionFragment) fragments.get(0)).setOnChildFragListener(onChildFragListener);
            ((SchemeCommissionFragment) fragments.get(1)).setOnChildFragListener(onChildFragListener);
        } else {
            ((SchemeRebateFragment) fragments.get(0)).setOnChildFragListener(onChildFragListener);
            ((SchemeRebateFragment) fragments.get(1)).setOnChildFragListener(onChildFragListener);
        }
    }

    //返水方案 我的第一次加载
    public void loadSchemeRebateDate() {
        if (pagePositon == 1 && mViewPager.getCurrentItem() == 0) {
            ((SchemeRebateFragment) fragments.get(0)).loadDate();
        }
    }

    /**
     * 设置右标题编辑状态显示
     */
    public void setIsEditeState(boolean isEditeState, boolean isInsertOrUpdate) {
        if (pagePositon == 0) {//返佣
            ((SchemeCommissionFragment) fragments.get(1)).setIsEditeState(isEditeState, isInsertOrUpdate);
        } else {//返水
            ((SchemeRebateFragment) fragments.get(1)).setIsEditeState(isEditeState, isInsertOrUpdate);
        }
    }

    /**
     * 设置子页面监听
     *
     * @param onChildFragListener
     */
    public void setOnChildFragListener(OnChildFragListener onChildFragListener) {
        this.onChildFragListener = onChildFragListener;
    }


    CommonNavigatorAdapter mAdapter = new CommonNavigatorAdapter() {
        @Override
        public int getCount() {
            return tabTitles.length;
        }

        @Override
        public IPagerTitleView getTitleView(Context context, final int position) {
            BadgePagerTitleView badgePagerTitleView = new BadgePagerTitleView(context);
            SimplePagerTitleView tabView = new SimplePagerTitleView(context);
            tabView.setPadding(SizeUtils.dp2px(15), 0, SizeUtils.dp2px(15), 0);
            tabView.setNormalColor(ResUtils.getColor(R.color.generic_huise));
            tabView.setSelectedColor(ResUtils.getColor(R.color.black));
            tabView.setText(tabTitles[position]);
            tabView.setOnClickListener(v -> mViewPager.setCurrentItem(position));
            if (position == 1 && onChildFragListener != null) {//只有直属下属才有右边的标题显示
                onChildFragListener.onBagePagerViewListener(pagePositon, badgePagerTitleView);
            }
            badgePagerTitleView.setInnerPagerTitleView(tabView);
            return badgePagerTitleView;
        }

        @Override
        public IPagerIndicator getIndicator(Context context) {
            LinePagerIndicator linePagerIndicator = new LinePagerIndicator(context);
            linePagerIndicator.setMode(LinePagerIndicator.MODE_EXACTLY);
            linePagerIndicator.setLineHeight(SizeUtils.dp2px(2));
            linePagerIndicator.setLineWidth(SizeUtils.dp2px(44));
            linePagerIndicator.setRoundRadius(SizeUtils.dp2px(1));
            linePagerIndicator.setColors(ResUtils.getColor(SiteSdk.ins().styleColor()));
            return linePagerIndicator;
        }
    };


    public interface OnChildFragListener {
        //页面滑动监听
        void onChildViewPagerChange(int parentPager, int childPage);

        //右标题显示监听
        void onTitleRightShow(int parentPager, int childPage, boolean isShow);

        //右标题是否是编辑状态
        void onTitleEditeShow(int parentPager, int childPage, boolean isEditeShow);

        //是否展示红点
        void onTitleRedDotShow(int parentPager, int childPage, boolean isShowRedDot);

        //红点View
        void onBagePagerViewListener(int pagePositon, BadgePagerTitleView pagerTitleView);

        //键盘的滑动
        void onSoftKeyboardScroll(int keybordUp);
    }
}
