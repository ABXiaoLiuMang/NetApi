package com.ty.bwagent.utils;

public interface CacheKey {
    String GUSTURE_PASSWORD        = "gusture_password";

    String REMEMBER_PASSWORD = "remember_password";// 记住密码
    String USER_NAME = "user_name";// 用户名
    String USER_PASSWORD = "user_password";// 密码
    String USER_LOGIN_TIME = "user_login_time";// 保存登录数据（14天内免登陆）

    String ACCOUNT_INFO            = "account_info";
    String USER_SHOW_MONEY            = "user_show_money";
    String CUSTOMER_SERVICE            = "customerService";
    String H5_DOMAIN            = "h5_domain";
    String SYSTEM_MAIN_PROINFO            = "system_proinfo";//区域限制拉取

}
