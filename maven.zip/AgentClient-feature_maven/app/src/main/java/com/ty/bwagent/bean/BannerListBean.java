package com.ty.bwagent.bean;

import com.ty.view.viewpager.entity.SimpleBannerInfo;

public class BannerListBean extends SimpleBannerInfo {

    /**
     * activityName : 804
     * carouselEquipmentType : 3
     * carouselInfoUrl :
     * carouselTitle : 测试2
     * carouselType : 1
     * carouselUrl : http://web.r5at08.com/1581667571509084.jpg?auth_key=1581669443-0-0-c44554635647948c2e78546f7190363f
     * createdAt : 2020-02-14 16:06:12
     * createdBy : admin
     * id : 441
     * isDelete : 0
     * showEndTime : 9999-12-31 23:59:59
     * showStartTime : 2020-02-02 00:00:00
     * sort : 2
     * status : 0
     * updatedAt : 2020-02-14 16:07:31
     * updatedBy : admin
     * urlType : -1
     */

    private int activityName;
    private int carouselEquipmentType;
    private String carouselInfoUrl;
    private String carouselTitle;
    private int carouselType;
    private String carouselUrl;
    private String createdAt;
    private String createdBy;
    private int id;
    private int isDelete;
    private String showEndTime;
    private String showStartTime;
    private int sort;
    private int status;
    private String updatedAt;
    private String updatedBy;
    private int urlType;

    @Override
    public String getXBannerUrl() {
        return carouselUrl;
    }

    public int getActivityName() {
        return activityName;
    }

    public void setActivityName(int activityName) {
        this.activityName = activityName;
    }

    public int getCarouselEquipmentType() {
        return carouselEquipmentType;
    }

    public void setCarouselEquipmentType(int carouselEquipmentType) {
        this.carouselEquipmentType = carouselEquipmentType;
    }

    public String getCarouselInfoUrl() {
        return carouselInfoUrl;
    }

    public void setCarouselInfoUrl(String carouselInfoUrl) {
        this.carouselInfoUrl = carouselInfoUrl;
    }

    public String getCarouselTitle() {
        return carouselTitle;
    }

    public void setCarouselTitle(String carouselTitle) {
        this.carouselTitle = carouselTitle;
    }

    public int getCarouselType() {
        return carouselType;
    }

    public void setCarouselType(int carouselType) {
        this.carouselType = carouselType;
    }

    public String getCarouselUrl() {
        return carouselUrl;
    }

    public void setCarouselUrl(String carouselUrl) {
        this.carouselUrl = carouselUrl;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }

    public String getShowEndTime() {
        return showEndTime;
    }

    public void setShowEndTime(String showEndTime) {
        this.showEndTime = showEndTime;
    }

    public String getShowStartTime() {
        return showStartTime;
    }

    public void setShowStartTime(String showStartTime) {
        this.showStartTime = showStartTime;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public int getUrlType() {
        return urlType;
    }

    public void setUrlType(int urlType) {
        this.urlType = urlType;
    }
}

