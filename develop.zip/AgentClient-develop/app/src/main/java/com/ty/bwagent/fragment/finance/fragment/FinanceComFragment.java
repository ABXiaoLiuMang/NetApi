package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.common.util.ABConfig;
import com.ty.utils.MathUtil;

import androidx.constraintlayout.widget.ConstraintLayout;

/**
 * 佣金界面
 */
public class FinanceComFragment extends FinanceDetailsFragment {


    TextView tv_month;//查询月份
    TextView tv_money;//佣金金额
    TextView account_total;//佣金比例
    private TextView tv_total;
    private ConstraintLayout consInfinlite; //无限极显示
    private ConstraintLayout consNomal; //一级代理显示
    private ConstraintLayout footer_bar; //一级代理显示

    public static FinanceComFragment getInstance(Bundle bundle) {
        FinanceComFragment fragment = new FinanceComFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void createProvider() {
        super.createProvider();
        bnt_nonet = rootView.findViewById(R.id.bnt_nonet);//这个要在initViewsAndEvents()之前获取
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_com;
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        tv_month = rootView.findViewById(R.id.tv_month);
        tv_money = rootView.findViewById(R.id.tv_monty);
        account_total = rootView.findViewById(R.id.account_total);
        tv_total = rootView.findViewById(R.id.tv_total);
        consInfinlite = rootView.findViewById(R.id.cons_infinlite);
        consNomal = rootView.findViewById(R.id.cons_nomal);
        footer_bar = rootView.findViewById(R.id.footer_bar);

        ll_net = rootView.findViewById(R.id.ll_net);

        String startData = bundle.getString(ABConfig.KEY_TAG);
        tv_month.setText(startData);
        tv_money.setText(Utils.roundDownMoney(financeEntity.getCommission()));

        UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
        if (userInfo.getAgentModel() == 0) {//不是无限极
            consInfinlite.setVisibility(View.GONE);
            consNomal.setVisibility(View.VISIBLE);
            footer_bar.setVisibility(View.VISIBLE);
            if (financeEntity.getShowCommissionRate() == 0) {//是否显示佣金比例 0展示 1隐藏
                account_total.setText(MathUtil.twoNumber(financeEntity.getRate() * 100) + "%");//佣金比例
                account_total.setTextColor(getResources().getColor(R.color.site_style_color));
            } else {
                account_total.setText("--");//佣金比例
                account_total.setTextColor(getResources().getColor(R.color.generic_heise));
            }
        } else {//无极限
            consInfinlite.setVisibility(View.VISIBLE);
            consNomal.setVisibility(View.GONE);
            footer_bar.setVisibility(View.GONE);
            account_total.setVisibility(View.INVISIBLE);
            tv_total.setVisibility(View.INVISIBLE);
        }

    }
}
