package com.ty.bwagent.fragment;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.lxj.xpopup.XPopup;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.ty.bwagent.R;
import com.ty.bwagent.adapter.GameRecordAdapter;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.GameRecordEntity;
import com.ty.bwagent.bean.MemberGameRecordEntity;
import com.ty.bwagent.dialog.GameRecordPopup;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.GameRecordModel;
import com.ty.common.ui.ABRefreshFragment;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.NetObserver;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;

import java.util.Date;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;

public class GameRecordFragment extends ABRefreshFragment {

    @BindView(R.id.titleBar)
    TitleBar titleBar;
    int pageNum = 1;
    int pageSize = 10;
    private GameRecordModel gameRecordModel;
    private GameRecordEntity gameRecordEntity;
    private ImageView iv_logo;
    private TextView tv_tips;

    public static GameRecordFragment getInstance() {
        GameRecordFragment fragment = new GameRecordFragment();
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.layout_frag_game_record;
    }

    @Override
    protected void createProvider() {
        gameRecordModel = new ViewModelProvider(this).get(GameRecordModel.class);

        //游戏列表
        gameRecordModel.memberGameLiveData.observe(this, new NetObserver<BaseEntity<MemberGameRecordEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<MemberGameRecordEntity> listBaseEntity) {
                dismissProgressDialog();
                List<MemberGameRecordEntity.ListBean> entityList = listBaseEntity.getData().getList();
                if (pageNum == 1) {
                    listAdapter.setNewData(entityList);
                    refreshLayout.finishRefresh();
                } else {
                    listAdapter.addData(entityList);
                    refreshLayout.finishLoadMore();
                }
                if (entityList.size() < pageSize) {
                    refreshLayout.finishLoadMoreWithNoMoreData();
                }
                if (tv_tips != null) {
                    iv_logo.setImageResource(R.mipmap.message_empty_bg);
                    tv_tips.setText("暂无数据");
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                ToastUtils.showLong(errMsg);
                if (pageNum == 1) {
                    refreshLayout.finishRefresh();
                } else {
                    refreshLayout.finishLoadMore();
                }
                if (iv_logo != null && code != 26308) {
                    iv_logo.setImageResource(R.mipmap.generic_ic_no_network_no_data);
                    tv_tips.setText("网络不给力");
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        titleBar.setRightOnClickListener(view -> {
            if (DoubleClickUtils.isLongDoubleClick()) {
                return;
            }
            showFilterDialog();
        });

        gameRecordModel.filterLiveData.observe(this, gameRecordEntity -> {
            showProgressDialog();
            GameRecordFragment.this.gameRecordEntity = gameRecordEntity;
            pageNum = 1;
            gameRecordModel.queryGameRecodeList(gameRecordEntity.getMemberName(), gameRecordEntity.getVenueId(), gameRecordEntity.getFlag(), gameRecordEntity.getStartDate(), gameRecordEntity.getEndDate(), pageNum, pageSize);
        });

        String time = TimeUtils.toString(new Date(), "yyyy-MM-dd");
        gameRecordModel.queryGameRecodeList("", "", "", time, time, pageNum, pageSize);

        XLiveDataManager.getInstance().netChangeLiveData.observe(this, aBoolean -> {
            if (aBoolean) {
                gameRecordModel.getAllGameVenue();
            }
        });

    }

    @Override
    public BaseQuickAdapter<MemberGameRecordEntity.ListBean, BaseViewHolder> getListAdapter() {
        return new GameRecordAdapter();
    }

    @Override
    public RecyclerView.ItemDecoration getItemDecoration() {
        return null;
    }


    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {

    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        if (gameRecordEntity != null) {
            pageNum++;
            gameRecordModel.queryGameRecodeList(gameRecordEntity.getMemberName(), gameRecordEntity.getVenueId(), gameRecordEntity.getFlag(), gameRecordEntity.getStartDate(), gameRecordEntity.getEndDate(), pageNum, pageSize);
        } else {
            pageNum++;
            String time = TimeUtils.toString(new Date(), "yyyy-MM-dd");
            gameRecordModel.queryGameRecodeList("", "", "", time, time, pageNum, pageSize);
        }
    }

    @Override
    public View getEmptyView() {
        View empty = View.inflate(mContext, R.layout.empty_message, null);
        iv_logo = empty.findViewById(R.id.iv_image);
        tv_tips = empty.findViewById(R.id.tv_message);
        return empty;
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        if (gameRecordEntity != null) {
            pageNum = 1;
            gameRecordModel.queryGameRecodeList(gameRecordEntity.getMemberName(), gameRecordEntity.getVenueId(), gameRecordEntity.getFlag(), gameRecordEntity.getStartDate(), gameRecordEntity.getEndDate(), pageNum, pageSize);
        } else {
            pageNum = 1;
            String time = TimeUtils.toString(new Date(), "yyyy-MM-dd");
            gameRecordModel.queryGameRecodeList("", "", "", time, time, pageNum, pageSize);
        }
    }

    @Override
    public boolean onBackPressedSupport() {
        if (gameReCordPopup != null && gameReCordPopup.isShow()) {
            gameReCordPopup.dismiss();
            return true;
        }
        return super.onBackPressedSupport();
    }


    /**
     * 筛选对话框
     */
    GameRecordPopup gameReCordPopup;

    private void showFilterDialog() {
        if (gameReCordPopup == null) {
            gameReCordPopup = new GameRecordPopup(this, gameRecordModel);
            new XPopup.Builder(mContext)
                    .atView(titleBar)
                    .asCustom(gameReCordPopup);
        }
        if (gameReCordPopup.isShow()) {
            gameReCordPopup.dismiss();
        } else {
            gameReCordPopup.show();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (gameReCordPopup != null) {
            gameReCordPopup.onDesoty();
        }
    }
}
