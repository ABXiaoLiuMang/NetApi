package com.ty.bwagent.ui;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.config.PictureConfig;
import com.luck.picture.lib.config.PictureMimeType;
import com.luck.picture.lib.entity.LocalMedia;
import com.ty.bwagent.App;
import com.ty.bwagent.R;
import com.ty.bwagent.utils.GlideEngine;
import com.ty.bwagent.utils.Keyboard;
import com.ty.common.ui.ABBaseActivity;
import com.ty.common.view.TitleBar;
import com.ty.constant.PermissionConstants;
import com.ty.tysite.view.XLoadingView;
import com.ty.utils.PermissionUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;
import com.ty.webview.AgentWeb;
import com.ty.webview.AgentWebSettingsImpl;
import com.ty.webview.AgentWebUIControllerImplBase;
import com.ty.webview.DefaultWebClient;
import com.ty.webview.IAgentWebSettings;
import com.ty.webview.IWebLayout;
import com.ty.webview.MiddlewareWebChromeBase;
import com.ty.webview.MiddlewareWebClientBase;
import com.ty.webview.PermissionInterceptor;
import com.ty.webview.WebChromeClient;
import com.ty.webview.WebViewClient;

import java.io.File;
import java.util.List;


public abstract class BaseAgentWebActivity extends ABBaseActivity {

    protected AgentWeb mAgentWeb;
    protected XLoadingView xLoadingView;
    private ErrorLayoutEntity mErrorLayoutEntity;
    protected TitleBar titleBar;

    protected abstract @Nullable String getUrl();

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_h5;
    }

    @Override
    protected void createProvider() {
    }


    @Override
    protected void initViewsAndEvents() {
        Keyboard.assistActivity(this);
        xLoadingView = getLoadingView();
        xLoadingView.bindLifecycle(this);
        titleBar = findViewById(R.id.titleBar);
        titleBar.setLeftOnClickListener(view -> finish());
        buildAgentWeb();
    }

    protected void buildAgentWeb() {
        mErrorLayoutEntity = getErrorLayoutEntity();
        mAgentWeb = AgentWeb.with(this)
                .setAgentWebParent(getAgentWebParent(), new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                .closeIndicator()
                .setWebChromeClient(mWebChromeClient)
                .setWebViewClient(mWebViewClient)
                .setPermissionInterceptor(getPermissionInterceptor())
                .setWebLayout(getWebLayout())
                .setAgentWebUIController(getAgentWebUIController())
                .interceptUnkownUrl()//拦截找不到相关页面的Scheme
                .setOpenOtherPageWays(getOpenOtherAppWay())
                .useMiddlewareWebChrome(getMiddleWareWebChrome())
                .useMiddlewareWebClient(getMiddleWareWebClient())
                .setAgentWebWebSettings(getAgentWebSettings())
                .setMainFrameErrorView(mErrorLayoutEntity.layoutRes, mErrorLayoutEntity.reloadId)
                .setSecurityType(AgentWeb.SecurityType.STRICT_CHECK)
                .createAgentWeb()
                .ready()
                .go(getUrl());
    }

    @NonNull
    protected ViewGroup getAgentWebParent() {
        return findViewById(R.id.layout);
    }

    @NonNull
    protected XLoadingView getLoadingView() {
        return findViewById(R.id.loadingView);
    }

    protected @NonNull
    ErrorLayoutEntity getErrorLayoutEntity() {
        if (this.mErrorLayoutEntity == null) {
            this.mErrorLayoutEntity = new ErrorLayoutEntity();
        }
        return mErrorLayoutEntity;
    }


    protected static class ErrorLayoutEntity {
        private int layoutRes = R.layout.web_error_page;
        private int reloadId = R.id.tvRefresh;

        public void setLayoutRes(int layoutRes) {
            this.layoutRes = layoutRes;
        }

        public void setReloadId(int reloadId) {
            this.reloadId = reloadId;
        }
    }

    @Override
    public void onPause() {
        if (mAgentWeb != null) {
            mAgentWeb.getWebLifeCycle().onPause();
        }
        super.onPause();

    }

    @Override
    public void onResume() {
        if (mAgentWeb != null) {
            mAgentWeb.getWebLifeCycle().onResume();
        }
        super.onResume();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (null == mUploadMessage && null == mUploadMessageLollipop) {
            return;
        }
        if (requestCode != CHANGE_SELECT_HEAD || data == null) {
            cancleUpload();
            return;
        }
        List<LocalMedia> selectList = PictureSelector.obtainMultipleResult(data);
        if (selectList.size() == 0) {
            cancleUpload();
            return;
        }
        String path = selectList.get(0).getCompressPath();
        if (TextUtils.isEmpty(path)) {
            cancleUpload();
            return;
        }
        Uri uri = Uri.fromFile(new File(path));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mUploadMessageLollipop.onReceiveValue(new Uri[]{uri});
            mUploadMessage = null;
            mUploadMessageLollipop = null;
        } else {
            mUploadMessage.onReceiveValue(uri);
            mUploadMessage = null;
        }

    }

    private void cancleUpload() {
        if (mUploadMessage != null) {
            mUploadMessage.onReceiveValue(null);
        }
        mUploadMessage = null;
        if (mUploadMessageLollipop != null) {
            mUploadMessageLollipop.onReceiveValue(null);
        }
        mUploadMessageLollipop = null;
    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (mAgentWeb != null && mAgentWeb.handleKeyEvent(keyCode, event)) {
            return true;
        }
        xLoadingView.stop();
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onDestroy() {
        App.goPhoto = false;
        if (mAgentWeb != null) {
            mAgentWeb.getWebCreator().getWebView().removeCallbacks(timeOutRunnable);
            mAgentWeb.getWebLifeCycle().onDestroy();
        }
        super.onDestroy();
    }

    public @Nullable
    IAgentWebSettings getAgentWebSettings() {
        return AgentWebSettingsImpl.getInstance();
    }

    private com.ty.webview.WebChromeClient mWebChromeClient = new WebChromeClient() {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            if (newProgress > 90) {
                mWebViewClient.onPageFinished(view, view.getUrl());
                xLoadingView.stop();
            }
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            //设置标题
        }
    };


    //开始超时计时
    private boolean isStarted = false;

    private void startTimeOutCount() {
        if (!isStarted) {
            isStarted = true;
            mAgentWeb.getWebCreator().getWebView().postDelayed(timeOutRunnable, 15 * 1000);
        }
    }

    private Runnable timeOutRunnable = () -> {
        if (isStarted) {
            xLoadingView.stop();
            isStarted = false;
        }
    };


    private com.ty.webview.WebViewClient mWebViewClient = new WebViewClient() {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            xLoadingView.start();
            startTimeOutCount();
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            isStarted = false;
            xLoadingView.stop();
            super.onPageFinished(view, url);
        }


        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            WebResourceResponse webResourceResponse = null;
            if (webResourceResponse == null) {
                webResourceResponse = super.shouldInterceptRequest(view, url);
            }
            return webResourceResponse;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            WebResourceResponse webResourceResponse = null;
            if (webResourceResponse == null) {
                webResourceResponse = super.shouldInterceptRequest(view, request);
            }
            return webResourceResponse;
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            super.onReceivedSslError(view, handler, error);
            handler.proceed();
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!detail.didCrash()) {
                    if (view != null) {
                        view.post(() -> Log.e("网页", "System killed the WebView rendering process " +
                                "to reclaim memory. Recreating..."));
                        ((ViewGroup) view.getParent()).removeView(view);
                        view.destroy();
                        view = null;
                    }
                    return true;
                }
                return false;
            } else {
                return super.onRenderProcessGone(view, detail);
            }
        }

    };

    protected @Nullable
    IWebLayout getWebLayout() {
        return null;
    }

    protected @Nullable
    PermissionInterceptor getPermissionInterceptor() {
        return null;
    }

    public @Nullable
    AgentWebUIControllerImplBase getAgentWebUIController() {
        return null;
    }

    public @Nullable
    DefaultWebClient.OpenOtherPageWays getOpenOtherAppWay() {
        return null;
    }


    private ValueCallback<Uri> mUploadMessage = null;
    private ValueCallback<Uri[]> mUploadMessageLollipop = null;

    protected @NonNull
    MiddlewareWebChromeBase getMiddleWareWebChrome() {
        return new MiddlewareWebChromeBase() {
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                setTitle(view, title);
            }

            @Override
            public void openFileChooser(ValueCallback<Uri> uploadFile, String acceptType, String capture) {
                mUploadMessage = uploadFile;
                obtainPermission();
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                mUploadMessageLollipop = filePathCallback;
                obtainPermission();
                return true;
            }
        };
    }

    protected void setTitle(WebView view, String title) {

    }

    protected @NonNull
    MiddlewareWebClientBase getMiddleWareWebClient() {
        return new MiddlewareWebClientBase() {
        };
    }

    private void obtainPermission() {
        PermissionUtils.permission(PermissionConstants.STORAGE, PermissionConstants.CAMERA)
                .callback(new PermissionUtils.SimpleCallback() {
                    @Override
                    public void onGranted() {
                        openCamera();
                    }

                    @Override
                    public void onDenied() {
                        App.goPhoto = true;
                        ToastUtils.showLong(ResUtils.getString(R.string.generic_open_permisson_warn));
                    }
                }).request();
    }

    public static int CHANGE_SELECT_HEAD = 100;

    private void openCamera() {
        App.goPhoto = true;
        PictureSelector.create(this)
                .openGallery(PictureMimeType.ofImage())
                .theme(R.style.picture_default_style)
                .minSelectNum(1)// 最小选择数量
                .setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)// 设置相册Activity方向，不设置默认使用系统
                .isCamera(true)
                .selectionMode(PictureConfig.SINGLE)
                .compress(true)// 是否压缩
                .isGif(false)
                .enablePreviewAudio(false)
                .isGif(false)
                .previewVideo(false)
                .loadImageEngine(GlideEngine.createGlideEngine()) // 请参考Demo GlideEngine.java
                .forResult(CHANGE_SELECT_HEAD);
    }


}
