package com.ty.bwagent.fragment.finance.fragment;

import android.os.Bundle;
import android.widget.TextView;

import com.ty.bwagent.R;
import com.ty.bwagent.view.XTextView;
import com.ty.common.util.ABConfig;

/**
 * 净输赢界面
 */
public class FinanceWinFragment extends FinanceDetailsFragment{


    TextView tv_month;//查询月份
    XTextView account_total;//净输赢

    public static FinanceWinFragment getInstance(Bundle bundle) {
        FinanceWinFragment fragment = new FinanceWinFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_finance_win;
    }

    @Override
    protected void initViewsAndEvents() {
        super.initViewsAndEvents();
        tv_month = rootView.findViewById(R.id.tv_month);
        account_total = rootView.findViewById(R.id.account_total);
        String startData = bundle.getString(ABConfig.KEY_TAG);
        tv_month.setText(startData);
        account_total.setMontyText(financeEntity.getNetProfit());
    }
}
