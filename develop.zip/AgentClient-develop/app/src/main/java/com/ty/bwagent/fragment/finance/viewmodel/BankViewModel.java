package com.ty.bwagent.fragment.finance.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.ty.bwagent.bean.BankEntity;

public class BankViewModel extends ViewModel {
    //绑定银行卡后卡号
    public MutableLiveData<BankEntity> bankNumberLiveData = new MutableLiveData<>();
}
