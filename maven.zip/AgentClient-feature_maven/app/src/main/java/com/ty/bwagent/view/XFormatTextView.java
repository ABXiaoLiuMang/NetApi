package com.ty.bwagent.view;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;

import com.ty.bwagent.R;
import com.ty.bwagent.utils.TypefaceUtils;
import com.ty.bwagent.utils.Utils;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

/**
 * 金额显示View
 * 1.所有金额保留两位小数显示
 * 2.格式化金额
 */
public class XFormatTextView extends AppCompatTextView {
    public XFormatTextView(Context context) {
        super(context);
    }

    public XFormatTextView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public XFormatTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setMontyText(double money) {
        String text ;
        if(money <= -9999999999.99D ){//小于10亿
            text = "-9,999,999,999.99";
        }else if(money >= 9999999999.99D){//大于10亿
            text = "9,999,999,999.99";
        }else {
            text = Utils.roundDownMoney(money);
        }

        setTypeface(TypefaceUtils.DIN_MEDIUM);
        super.setText(text);

        if(money < 0){
            setTextColor(ResUtils.getColor(R.color.color_f4333c));
        }else if(money > 0) {
            setTextColor(ResUtils.getColor(R.color.generic_lvse));
        }else {
            setTextColor(ResUtils.getColor(R.color.generic_heise));
        }
    }


    public void setMontyText(String money) {
        double mMoney = StringUtils.parseDouble(money);
        this.setMontyText(mMoney);
    }
}
