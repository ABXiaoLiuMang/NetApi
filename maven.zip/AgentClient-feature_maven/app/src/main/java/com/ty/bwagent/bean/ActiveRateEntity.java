package com.ty.bwagent.bean;

/**
 * 查询活跃占比（当月，当天）
 */
public class ActiveRateEntity {

    /**
     * dayActiveRate : 0.0
     * dayNotActiveRate : 1.0
     * monthActiveRate : 0.999
     * monthNotActiveRate : 0
     */

    private double dayActiveRate; //日活跃比例（0.000）
    private double dayNotActiveRate;//日菲活跃比例（0.000）
    private double monthActiveRate;//月活跃比例（0.000）
    private double monthNotActiveRate;//月非活跃比例（0.000）

    public double getDayActiveRate() {
        return dayActiveRate;
    }

    public void setDayActiveRate(double dayActiveRate) {
        this.dayActiveRate = dayActiveRate;
    }

    public double getDayNotActiveRate() {
        return dayNotActiveRate;
    }

    public void setDayNotActiveRate(double dayNotActiveRate) {
        this.dayNotActiveRate = dayNotActiveRate;
    }

    public double getMonthActiveRate() {
        return monthActiveRate;
    }

    public void setMonthActiveRate(double monthActiveRate) {
        this.monthActiveRate = monthActiveRate;
    }

    public double getMonthNotActiveRate() {
        return monthNotActiveRate;
    }

    public void setMonthNotActiveRate(double monthNotActiveRate) {
        this.monthNotActiveRate = monthNotActiveRate;
    }
}
