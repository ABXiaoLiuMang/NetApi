package com.ty.bwagent.fragment.finance.bean;

public class FinanceDeposit {


    /**
     * category : 财务手动上分
     * money : 0
     */

    private String category;
    private double money;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
}
