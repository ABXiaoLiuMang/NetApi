package com.ty.bwagent.viewmodel;

public class NewMemberCenterViewModel extends TeamViewModel {


}
