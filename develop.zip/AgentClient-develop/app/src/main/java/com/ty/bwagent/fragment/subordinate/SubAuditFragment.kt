package com.ty.bwagent.fragment.subordinate

import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.lxj.xpopup.XPopup
import com.scwang.smartrefresh.layout.api.RefreshLayout
import com.ty.bwagent.R
import com.ty.bwagent.adapter.SubordinateAuditAdapter
import com.ty.bwagent.bean.BaseEntity
import com.ty.bwagent.bean.ReviewListEntity
import com.ty.bwagent.dialog.CommonDialogPopView
import com.ty.bwagent.dialog.SubordinateAuditFilterPopup
import com.ty.bwagent.fragment.schemeset.SchemeSetTabFragment
import com.ty.bwagent.utils.DialogUtil
import com.ty.bwagent.viewmodel.SubordinateAuditViewModle
import com.ty.common.ui.ABRefreshFragment
import com.ty.net.callback.NetObserver
import com.ty.utils.KeyboardUtils
import com.ty.utils.ToastUtils
import kotlinx.android.synthetic.main.layout_sub_audit.*

/**
 * 下级审核
 */
class SubAuditFragment : ABRefreshFragment<ReviewListEntity.ListBean>() {

    private lateinit var subordinateAuditViewModle: SubordinateAuditViewModle
    private var auditFilterPopup: SubordinateAuditFilterPopup? = null

    var startTime: String? = ""
    var endTime: String? = ""
    var name: String? = ""
    var state: String? = ""

    var pageNum = 1;
    var pageSize = 10;

    var ivLogo: ImageView? = null
    var tvTips: TextView? = null


    companion object {
        fun getInstance(): SubAuditFragment {
            return SubAuditFragment()
        }
    }

    override fun getLayoutId(): Int {
        return R.layout.layout_sub_audit
    }

    override fun createProvider() {
        subordinateAuditViewModle = ViewModelProvider(this).get(SubordinateAuditViewModle::class.java)
        subordinateAuditViewModle.reviewListLiveData.observe(this, object : NetObserver<BaseEntity<ReviewListEntity>>() {

            override fun onSuccess(listEntityBaseEntity: BaseEntity<ReviewListEntity>?) {
                dismissProgressDialog()
                listEntityBaseEntity?.data?.apply {
                    if (pageNum == 1) {
                        listAdapter.setNewData(this.list)
                        refreshLayout.finishRefresh()
                    } else {
                        listAdapter.addData(this.list)
                        refreshLayout.finishLoadMore()
                    }
                    if (pageNum == pages) {
                        refreshLayout.finishLoadMoreWithNoMoreData()
                    }
                }
                ivLogo?.setImageResource(R.mipmap.message_empty_bg)
                tvTips?.text = "暂无数据"
            }

            override fun onError(code: Int, errMsg: String?) {
                dismissProgressDialog()
                refreshLayout.visibility = View.VISIBLE
                if (pageNum == 1) {
                    refreshLayout.finishRefresh(false)
                } else {
                    refreshLayout.finishLoadMore(false)
                }
                ToastUtils.showToast(errMsg)
                ivLogo?.setImageResource(R.mipmap.generic_ic_no_network_no_data)
                tvTips?.text = "网络不给力"

            }
        });

        subordinateAuditViewModle.updateReviewLiveData.observe(this, object : NetObserver<BaseEntity<*>>() {
            override fun onSuccess(t: BaseEntity<*>?) {
                subordinateAuditViewModle.reviewList(name, state, startTime, endTime, pageNum, pageSize)
            }

            override fun onError(code: Int, errMsg: String?) {
                ToastUtils.showToast(errMsg)
            }

        });

    }


    override fun initViewsAndEvents() {
        super.initViewsAndEvents()

        titleBar.setRightOnClickListener { showAuditFilterPopup() }
        listAdapter?.setOnItemChildClickListener { adapter, view, position -> onItemChildClick(adapter, view, position) }

        showProgressDialog()
        subordinateAuditViewModle.reviewList(name, state, startTime, endTime, pageNum, pageSize)
    }

    override fun getListAdapter(): BaseQuickAdapter<ReviewListEntity.ListBean, BaseViewHolder>? {
        return SubordinateAuditAdapter();
    }

    //按钮点击事件
    private fun onItemChildClick(adapter: BaseQuickAdapter<*, *>?, view: View?, position: Int) {
        val listBean = adapter?.getItem(position) as ReviewListEntity.ListBean?
        listBean?.apply {
            when (view?.id) {
                R.id.tv_key_top//   //审核状态0待审核1审核拒绝2审批通过
                -> if (this.reviewStatus == 0) {//按钮：待审核 通过
                    DialogUtil.commonDialogShow(activity, "温馨提示",
                            "审核通过后，会员将升级为代理，并继承您的代理模式、代理类型等，您确定审核通过？", "确定", true) {
                        subordinateAuditViewModle.updateReview("2", this.id.toString(), "审核通过")
                    }
                } else if (this.reviewStatus == 1 || this.reviewStatus == 2) {//按钮：查看   审核拒绝 审批通过的
                    val bundle = Bundle()
                    bundle.putParcelable("listBean", this)
                    start(SubAuditDetailFragment.Companion.getInstant(bundle))
                }
                R.id.tv_key_bottom////按钮：待审核 拒绝
                -> {
                    DialogUtil.subAuditRefuse(this@SubAuditFragment, listBean?.id.toString());
                }
            }
        }
    }


    override fun getEmptyView(): View {
        val empty = View.inflate(mContext, R.layout.empty_message, null)
        ivLogo = empty.findViewById(R.id.iv_image)
        tvTips = empty.findViewById(R.id.tv_message)
        tvTips?.text = "暂无数据"
        return empty
    }

    override fun onLoadMore(refreshLayout: RefreshLayout) {
        pageNum++
        subordinateAuditViewModle.reviewList(name, state, startTime, endTime, pageNum, pageSize)
    }

    override fun onRefresh(refreshLayout: RefreshLayout) {
        pageNum = 1
        subordinateAuditViewModle.reviewList(name, state, startTime, endTime, pageNum, pageSize)
    }

    override fun onItemClick(adapter: BaseQuickAdapter<*, *>?, view: View?, position: Int) {
    }

    override fun onBackPressedSupport(): Boolean {
        auditFilterPopup?.let {
            if (it.isShow) {
                it.dismiss()
                return true
            }
        }
        return super.onBackPressedSupport()
    }

    override fun getItemDecoration(): RecyclerView.ItemDecoration? {
        return null
    }

    /**
     * 筛选框
     */
    private fun showAuditFilterPopup() {
        if (auditFilterPopup == null) {
            auditFilterPopup = SubordinateAuditFilterPopup(mContext) { startTime, endTime, name, state ->
                this.startTime = startTime
                this.endTime = endTime
                this.name = name
                this.state = state
                subordinateAuditViewModle.reviewList(name, state, startTime, endTime, pageNum, pageSize)
            }
            XPopup.Builder(mContext)
                    .atView(titleBar)
                    .dismissOnBackPressed(true)
                    .dismissOnTouchOutside(true)
                    .asCustom(auditFilterPopup)
                    .show()
        }

        auditFilterPopup?.apply {
            if (isShow) dismiss() else show()
        }
    }


    override fun onStop() {
        super.onStop()
        KeyboardUtils.hideSoftInput(rootView)
    }


}