package com.ty.bwagent.exchange;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.ty.utils.SpanBuilder;
import com.ty.utils.StringUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class StringUtil {
    /**
     * desc: 安全忽略大小写对比
     *
     * @author Jeff created on 2018/9/12 14:30
     */
    @SuppressWarnings("unused")
    public static boolean equalsIgnoreCase(CharSequence a, CharSequence b) {
        try {
            if (a == b) {
                return true;
            }
            int length;
            if (a != null && b != null && (length = a.length()) == b.length()) {
                if (a instanceof String && b instanceof String) {
                    return ((String) a).equalsIgnoreCase((String) b);
                } else {
                    for (int i = 0; i < length; i++) {
                        if (a.charAt(i) != b.charAt(i)) {
                            return false;
                        }
                    }
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
        }
        return false;
    }

    /**
     * desc: 安全转换int类型
     *
     * @author Jeff created on 2018/9/12 14:21
     */
    @SuppressWarnings("unused")
    public static int parseInt(String value) {
        if (TextUtils.isEmpty(value)) {
            return 0;
        }
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * desc: 安全转换long类型
     *
     * @author Jeff created on 2018/9/12 14:21
     */
    @SuppressWarnings("unused")
    public static long parseLong(String value) {
        if (TextUtils.isEmpty(value)) {
            return 0;
        }
        try {
            return Long.parseLong(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * desc: 安全转换float类型
     *
     * @author Jeff created on 2018/9/12 14:21
     */
    @SuppressWarnings("unused")
    public static float parseFloat(String value) {
        if (TextUtils.isEmpty(value)) {
            return 0;
        }
        try {
            return Float.parseFloat(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * desc: 安全转换double类型
     *
     * @author Jeff created on 2018/9/12 14:21
     */
    @SuppressWarnings("unused")
    public static double parseDouble(String value) {
        if (TextUtils.isEmpty(value)) {
            return 0;
        }
        try {
            return Double.parseDouble(value);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * desc: 安全转换boolean类型 解析失败返回false
     *
     * @author Jeff created on 2018/9/12 14:21
     */
    @SuppressWarnings("unused")
    public static boolean parseBoolean(String value) {
        if (TextUtils.isEmpty(value)) {
            return false;
        }
        try {
            return Boolean.parseBoolean(value);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * desc: 字符串拼接,线程不安全,并发不可用
     *
     * @author Jeff created on 2018/8/26 15:11
     */
    @NonNull
    @SuppressWarnings("unused")
    public static String builder(Object... params) {
        StringBuilder buffer = new StringBuilder();
        for (Object o :
                params) {
            buffer.append(o);
        }
        return buffer.toString();
    }

    /**
     * desc: 字符串拼接,线程安全
     *
     * @author Jeff created on 2018/8/26 15:11
     */
    @NonNull
    @SuppressWarnings("unused")
    public static String buffer(Object... params) {
        StringBuffer buffer = new StringBuffer();
        for (Object o : params) {
            buffer.append(o);
        }
        return buffer.toString();
    }

    /**
     * 字符串拼接器
     *
     * @return {@link SpanBuilder}
     */
    @NonNull
    public static SpanBuilder getSpanBuilder() {
        return new SpanBuilder();
    }

    //data:2020-15
    public static String getLastDayOfMonth(String time) {
        try {
            if (StringUtils.isEmpty(time)) {
                return "";
            }
            String[] split = time.split("-");
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, Integer.parseInt(split[0]));
            calendar.set(Calendar.MONTH, Integer.parseInt(split[1]) - 1);
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            return format.format(calendar.getTime());
        } catch (Exception e) {

        }
        return "";
    }

    //2010-10 转data
    public static Date getYMToDate(String time) {
        try {
            if (StringUtils.isEmpty(time)) {
                return null;
            }
            SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM");
            Date parse = simpleDateFormat.parse(time);
            return parse;
        } catch (Exception e) {

        }
        return null;
    }


}
