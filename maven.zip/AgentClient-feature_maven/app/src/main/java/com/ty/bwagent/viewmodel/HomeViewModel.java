package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BannerListBean;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.MessageSys;
import com.ty.bwagent.bean.MonthOverEntity;
import com.ty.bwagent.bean.SpecialNoticeEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class HomeViewModel extends AboutViewModel {

    boolean isFirst = false;

    //普通通知（跑马灯数据）
   public NetLiveData<BaseEntity<List<SpecialNoticeEntity>>> noticeLiveData = new NetLiveData<>();

   //重要通告，弹窗数据
   public NetLiveData<BaseEntity<List<SpecialNoticeEntity>>> specialLiveData = new NetLiveData<>();

   //本月概览
   public NetLiveData<BaseEntity<MonthOverEntity>> monthOverLiveData = new NetLiveData<>();

   //轮播图
   public NetLiveData<BaseEntity<List<BannerListBean>>> bannerLiveData = new NetLiveData<>();

   //跑马灯通知
    public void queryNotice(){
        NetSdk.create(Api.class)
                .queryNotice()
                .params("category","1")//类型1-普通,2-特殊,3-财务
                .asJSONType()
                .send(noticeLiveData);
    }
   //特殊弹窗公告
    public void querySpecialNotice(){
        if(isFirst){
            return;
        }
        isFirst = true;
        NetSdk.create(Api.class)
                .queryNotice()
                .params("category","2")//类型1-普通,2-特殊,3-财务
                .asJSONType()
                .send(specialLiveData);
    }
   //本月概览
    public void queryMonthOverview(){
        NetSdk.create(Api.class)
                .queryMonthOverview()
                .asJSONType()
                .send(monthOverLiveData);
    }
   //轮播图
    public void queryBannerList(){
        NetSdk.create(Api.class)
                .queryBannerList()
                .asJSONType()
                .send(bannerLiveData);
    }

}
