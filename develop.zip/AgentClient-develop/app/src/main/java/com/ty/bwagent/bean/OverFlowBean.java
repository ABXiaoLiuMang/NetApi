package com.ty.bwagent.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class OverFlowBean {


    /**
     * endRow : 6
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : true
     * isLastPage : true
     * list : [{"agentId":2019139800,"applicationTime":"","applyImg":"","applyName":"","applyReason":"","applyStatus":0,"applyTime":"","createAt":"2020-04-24 17:42:12","createBy":0,"id":76,"memberId":2019139744,"memberName":"mmmnnn33","promoteDevice":0,"promoteUrl":"","remark":"该会员的注册时间在三天以上","updateAt":"2020-04-24 17:42:11","updateBy":0},{"agentId":2019139800,"applicationTime":"2020-04-24 17:38:02","applyImg":"https://bwstatic.oss-cn-hongkong.aliyuncs.com/agentWeb/1587721082289071.png","applyName":"vincent","applyReason":"jhj","applyStatus":3,"applyTime":"2020-04-24 17:39:10","createAt":"2020-04-24 17:36:42","createBy":0,"id":75,"memberId":2019139922,"memberName":"mmmnnn54","promoteDevice":1,"promoteUrl":"http://www.baidu.com","remark":"","updateAt":"2020-04-24 17:39:10","updateBy":0},{"agentId":2019139800,"applicationTime":"","applyImg":"","applyName":"","applyReason":"","applyStatus":0,"applyTime":"","createAt":"2020-04-24 17:31:33","createBy":0,"id":74,"memberId":2019139816,"memberName":"mmmnnn38","promoteDevice":0,"promoteUrl":"","remark":"该会员已存在上级","updateAt":"2020-04-24 17:31:32","updateBy":0},{"agentId":2019139800,"applicationTime":"","applyImg":"","applyName":"","applyReason":"","applyStatus":0,"applyTime":"","createAt":"2020-04-24 17:31:28","createBy":0,"id":73,"memberId":2019139803,"memberName":"mmmnnn37","promoteDevice":0,"promoteUrl":"","remark":"该会员的注册时间在三天以上","updateAt":"2020-04-24 17:31:28","updateBy":0},{"agentId":2019139800,"applicationTime":"","applyImg":"","applyName":"","applyReason":"","applyStatus":0,"applyTime":"","createAt":"2020-04-24 17:30:51","createBy":0,"id":72,"memberId":2019139662,"memberName":"mmmnnn16","promoteDevice":0,"promoteUrl":"","remark":"该会员已存在上级","updateAt":"2020-04-24 17:30:50","updateBy":0},{"agentId":2019139800,"applicationTime":"","applyImg":"","applyName":"","applyReason":"","applyStatus":0,"applyTime":"","createAt":"2020-04-24 17:30:45","createBy":0,"id":71,"memberId":2019139661,"memberName":"mmmnnn15","promoteDevice":0,"promoteUrl":"","remark":"该会员已存在上级","updateAt":"2020-04-24 17:30:44","updateBy":0}]
     * navigateFirstPage : 1
     * navigateLastPage : 1
     * navigatePages : 8
     * navigatepageNums : [1]
     * nextPage : 0
     * pageNum : 1
     * pageSize : 15
     * pages : 1
     * prePage : 0
     * size : 6
     * startRow : 1
     * total : 6
     */

    private int endRow;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private int navigateFirstPage;
    private int navigateLastPage;
    private int navigatePages;
    private int nextPage;
    private int pageNum;
    private int pageSize;
    private int pages;
    private int prePage;
    private int size;
    private int startRow;
    private int total;
    private List<ListBean> list;
    private List<Integer> navigatepageNums;

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public List<Integer> getNavigatepageNums() {
        return navigatepageNums;
    }

    public void setNavigatepageNums(List<Integer> navigatepageNums) {
        this.navigatepageNums = navigatepageNums;
    }

    public static class ListBean implements Parcelable {
        /**
         * agentId : 2019139800
         * applicationTime :
         * applyImg :
         * applyName :
         * applyReason :
         * applyStatus : 0
         * applyTime :
         * createAt : 2020-04-24 17:42:12
         * createBy : 0
         * id : 76
         * memberId : 2019139744
         * memberName : mmmnnn33
         * promoteDevice : 0
         * promoteUrl :
         * remark : 该会员的注册时间在三天以上
         * updateAt : 2020-04-24 17:42:11
         * updateBy : 0
         */

        private int agentId;
        private String applicationTime;
        private String applyImg;
        private String applyName;
        private String applyReason;
        private int applyStatus;
        private String applyTime;
        private String createAt;
        private int createBy;
        private int id;
        private int memberId;
        private String memberName;
        private int promoteDevice;
        private String promoteUrl;
        private String remark;
        private String updateAt;
        private int updateBy;

        protected ListBean(Parcel in) {
            agentId = in.readInt();
            applicationTime = in.readString();
            applyImg = in.readString();
            applyName = in.readString();
            applyReason = in.readString();
            applyStatus = in.readInt();
            applyTime = in.readString();
            createAt = in.readString();
            createBy = in.readInt();
            id = in.readInt();
            memberId = in.readInt();
            memberName = in.readString();
            promoteDevice = in.readInt();
            promoteUrl = in.readString();
            remark = in.readString();
            updateAt = in.readString();
            updateBy = in.readInt();
        }

        public static final Creator<ListBean> CREATOR = new Creator<ListBean>() {
            @Override
            public ListBean createFromParcel(Parcel in) {
                return new ListBean(in);
            }

            @Override
            public ListBean[] newArray(int size) {
                return new ListBean[size];
            }
        };

        public int getAgentId() {
            return agentId;
        }

        public void setAgentId(int agentId) {
            this.agentId = agentId;
        }

        public String getApplicationTime() {
            return applicationTime;
        }

        public void setApplicationTime(String applicationTime) {
            this.applicationTime = applicationTime;
        }

        public String getApplyImg() {
            return applyImg;
        }

        public void setApplyImg(String applyImg) {
            this.applyImg = applyImg;
        }

        public String getApplyName() {
            return applyName;
        }

        public void setApplyName(String applyName) {
            this.applyName = applyName;
        }

        public String getApplyReason() {
            return applyReason;
        }

        public void setApplyReason(String applyReason) {
            this.applyReason = applyReason;
        }

        public int getApplyStatus() {
            return applyStatus;
        }

        public void setApplyStatus(int applyStatus) {
            this.applyStatus = applyStatus;
        }

        public String getApplyTime() {
            return applyTime;
        }

        public void setApplyTime(String applyTime) {
            this.applyTime = applyTime;
        }

        public String getCreateAt() {
            return createAt;
        }

        public void setCreateAt(String createAt) {
            this.createAt = createAt;
        }

        public int getCreateBy() {
            return createBy;
        }

        public void setCreateBy(int createBy) {
            this.createBy = createBy;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMemberId() {
            return memberId;
        }

        public void setMemberId(int memberId) {
            this.memberId = memberId;
        }

        public String getMemberName() {
            return memberName;
        }

        public void setMemberName(String memberName) {
            this.memberName = memberName;
        }

        public int getPromoteDevice() {
            return promoteDevice;
        }

        public void setPromoteDevice(int promoteDevice) {
            this.promoteDevice = promoteDevice;
        }

        public String getPromoteUrl() {
            return promoteUrl;
        }

        public void setPromoteUrl(String promoteUrl) {
            this.promoteUrl = promoteUrl;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getUpdateAt() {
            return updateAt;
        }

        public void setUpdateAt(String updateAt) {
            this.updateAt = updateAt;
        }

        public int getUpdateBy() {
            return updateBy;
        }

        public void setUpdateBy(int updateBy) {
            this.updateBy = updateBy;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(agentId);
            dest.writeString(applicationTime);
            dest.writeString(applyImg);
            dest.writeString(applyName);
            dest.writeString(applyReason);
            dest.writeInt(applyStatus);
            dest.writeString(applyTime);
            dest.writeString(createAt);
            dest.writeInt(createBy);
            dest.writeInt(id);
            dest.writeInt(memberId);
            dest.writeString(memberName);
            dest.writeInt(promoteDevice);
            dest.writeString(promoteUrl);
            dest.writeString(remark);
            dest.writeString(updateAt);
            dest.writeInt(updateBy);
        }
    }
}
