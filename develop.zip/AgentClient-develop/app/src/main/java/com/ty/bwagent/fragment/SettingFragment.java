package com.ty.bwagent.fragment;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.bugly.crashreport.CrashReport;
import com.tianyu.updater.entity.UpdateEntity;
import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.update.XUpdateManager;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.GlideUtil;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.SettingViewModel;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.ValueView;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.AppUtil;
import com.ty.utils.DoubleClickUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;

import androidx.lifecycle.ViewModelProvider;
import butterknife.BindView;
import butterknife.OnClick;


public class SettingFragment extends ABBaseFragment {

    SettingViewModel mSettingViewModel;
    @BindView(R.id.valueview_about)
    ValueView valueviewAbout;
    @BindView(R.id.valueview_devices)
    ValueView valueviewDevices;
    @BindView(R.id.valueview_cache)
    ValueView valueviewCache;
    @BindView(R.id.valueview_update)
    ValueView valueviewUpdate;
    @BindView(R.id.setting_exit)
    TextView settingExit;
    @BindView(R.id.center_update_point)
    ImageView center_update_point;

    UpdateEntity updateEntity = null;

    public static SettingFragment getInstance() {
        SettingFragment fragment = new SettingFragment();
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_setting;
    }

    @Override
    protected void createProvider() {

        mSettingViewModel = new ViewModelProvider(this).get(SettingViewModel.class);

        //退出登录监听
        mSettingViewModel.logOutLivaData.observe(this, new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if (!MMKVUtil.getBoolean(CacheKey.REMEMBER_PASSWORD, true)) {
                    MMKVUtil.removeValueForKey(CacheKey.USER_PASSWORD);
                }
                SystemModel.loginOut.postValue(true);
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                ToastUtils.showLong(errMsg);
            }
        });

        //检查更新监听
        mSettingViewModel.updateResult.observe(this, new NetObserver<UpdateEntity>() {


            @Override
            protected void onSuccess(UpdateEntity entity) {
                dismissProgressDialog();
                updateEntity = entity;
                if (!StringUtils.isEmpty(updateEntity.getUpdateInfo().getVersion()) && updateEntity.getUpdateInfo().getCode() > BuildConfig.VERSION_CODE) {
                    center_update_point.setVisibility(View.VISIBLE);
                    valueviewUpdate.getTv_value().setHint(ResUtils.getString(R.string.generic_version_new, updateEntity.getUpdateInfo().getVersion()));
                    XUpdateManager.showUpdateDialog(getActivity(), null, updateEntity, null);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                dismissProgressDialog();
                if (code == 10102112) {//已经是最新版本
                    ToastUtils.showLong(errMsg);
                } else {
                    ToastUtils.showLong(errMsg);
                }
            }
        });


    }

    @Override
    protected void initViewsAndEvents() {
        valueviewUpdate.getTv_value().setHint(StringUtils.getFormatString(ResUtils.getString(R.string.generic_version), AppUtil.getVersionName()));
        setCacheData();
        registerUpdate();
    }

    @OnClick({R.id.valueview_about, R.id.valueview_devices, R.id.valueview_cache, R.id.valueview_update, R.id.setting_exit})
    public void onViewClicked(View view) {
        if (DoubleClickUtils.isLongDoubleClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.valueview_about:
                start(AboutFragment.getInstance());
                break;
            case R.id.valueview_devices:
                start(DevicesFragment.getInstance());
                break;
            case R.id.valueview_cache:
                clearCache();
                break;
            case R.id.valueview_update:
                if (updateEntity == null) {
                    showProgressDialog();
                    mSettingViewModel.checkUpdate();
                } else {
                    if (!StringUtils.isEmpty(updateEntity.getUpdateInfo().getVersion()) && updateEntity.getUpdateInfo().getCode() > BuildConfig.VERSION_CODE) {
                        XUpdateManager.showUpdateDialog(getActivity(), null, updateEntity, null);
                        return;
                    } else {
                        ToastUtils.showLong(ResUtils.getString(R.string.generic_latest_version));
                    }
                }
                break;
            case R.id.setting_exit:
                mSettingViewModel.logout();
                break;
        }
    }


    private void setCacheData() {
        String appClearSize = GlideUtil.getCacheSize(mContext);
        valueviewCache.setTextValue(appClearSize);
    }

    private void clearCache() {
        GlideUtil.clearImageAllCache(mContext);
        ToastUtils.showLong("清除缓存成功");
        valueviewCache.setTextValue("0MB");
        valueviewCache.setTextValueImg(null);
    }

    /**
     * 更新提示
     */
    private void registerUpdate() {
        XLiveDataManager.getInstance().updateResult.observe(this, new SimpleObserver<UpdateEntity>() {
            @Override
            protected void onSuccess(UpdateEntity entity) {
                updateEntity = entity;
                if (entity != null && !StringUtils.isEmpty(updateEntity.getUpdateInfo().getVersion()) && updateEntity.getUpdateInfo().getCode() > BuildConfig.VERSION_CODE) {
                    center_update_point.setVisibility(View.VISIBLE);
                    valueviewUpdate.getTv_value().setHint(ResUtils.getString(R.string.generic_version_new, updateEntity.getUpdateInfo().getVersion()));
                }
            }

            @Override
            protected void onError(int code, String errMsg) {

            }
        });
    }
}
