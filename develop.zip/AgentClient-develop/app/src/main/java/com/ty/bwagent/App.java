package com.ty.bwagent;


import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Process;

import androidx.lifecycle.Observer;
import androidx.multidex.MultiDex;

import com.bw.tmapmanager.domains.TmapDomainsManager;
import com.bw.tmapmanager.network.inter.TmapStrategy;
import com.bw.tmapmanager.network.sign.TmapChuangYuStrategy;
import com.bw.tmapmanager.network.sign.TmapSCDNStrategy;
import com.bw.tmapmanager.network.sign.TmapYunDunStrategy;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.squareup.leakcanary.LeakCanary;
import com.tencent.bugly.Bugly;
import com.tencent.bugly.beta.Beta;
import com.tianyu.updater.TYUpdater;
import com.ty.bwagent.api.BaseRetryInterceptor;
import com.ty.bwagent.api.BaseUrlManager;
import com.ty.bwagent.api.HttpSignUtils;
import com.ty.bwagent.api.NetSignInterceptor;
import com.ty.bwagent.header.MyClassicsRefreshFooter;
import com.ty.bwagent.header.MyClassicsRefreshHeader;
import com.ty.bwagent.ui.GestureActivity;
import com.ty.bwagent.ui.LoginActivity;
import com.ty.bwagent.ui.SystemMaintainActivity;
import com.ty.bwagent.update.XUpdateManager;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.Key;
import com.ty.bwagent.utils.NetChangedReceiver;
import com.ty.bwagent.utils.ParameIntercept;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.util.ABApplication;
import com.ty.common.util.ABConfig;
import com.ty.net.NetSdk;
import com.ty.net.manager.NetConfig;
import com.ty.tysite.SiteSdk;
import com.ty.utils.AppConfig;
import com.ty.utils.LogUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.NetworkUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TopActivityManager;
import com.yabo.tymonitor.TYTingyunMonitor;

import java.util.HashSet;
import java.util.Set;

import me.yokeyword.fragmentation.Fragmentation;


public class App extends ABApplication {

    public static int height;

    /**
     * 上传头像拍照设置为ture,回来不回调锁屏
     */
    public static boolean goPhoto = false;

    /**
     * 是否显示过更新对话框 false 没有
     */
    public static boolean is_showing_update_dialog = false;

    static {
        //设置全局的Header构建器
        SmartRefreshLayout.setDefaultRefreshHeaderCreator((context, layout) -> new MyClassicsRefreshHeader(context));
        //设置全局的Footer构建器
        SmartRefreshLayout.setDefaultRefreshFooterCreator((context, layout) -> new MyClassicsRefreshFooter(context));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        LogUtils.isDebug(BuildConfig.DEBUG);
        MMKVUtil.put(Key.SITEIDKEY, BuildConfig.appType);
        MMKVUtil.put(CacheKey.SYSTEM_MAIN_PROINFO, false);
        SiteSdk.ins().initSDK(this).setSiteId(BuildConfig.appType);

        if (isMainProcess()) {
            initNetSdk();
            updateCDNmainHost();
            initXUpdate();
//            initBugly();
            initTingYun();
            systemMaintain();
            registerNetChangedReceiver();
        }

        addForegroundListener();
        if (StringUtils.equals("developDebug", BuildConfig.FLAVOR) && BuildConfig.DEBUG) {
            Fragmentation.builder()
                    .stackViewMode(Fragmentation.BUBBLE)
                    .debug(true)
                    .handleException(e -> LogUtils.d("err:" + e.getMessage()))
                    .install();

            //检查内存泄漏
            if (LeakCanary.isInAnalyzerProcess(this)) {
                return;
            }
            LeakCanary.install(this);
        }
    }


    /**
     * 注册网络监听广播
     */
    NetChangedReceiver netChangedReceiver;

    private void registerNetChangedReceiver() {
        netChangedReceiver = new NetChangedReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(netChangedReceiver, filter);
    }

    private void initNetSdk() {
        String baseUrl = BaseUrlManager.ins().currentDomain().getHost();
        //必须先初始化
        NetConfig netConfig = NetSdk.config(this)
                .baseUrl(baseUrl)
                .connectTimeout(30_1000)
                .readTimeout(10_000)
                .writeTimeout(10_000)
                .addHeaders(HttpSignUtils::getBaseHeader)
                .addInterceptor(new ParameIntercept())
                .needLog(BuildConfig.DEBUG);
        //正式环境才加签
        if (BuildConfig.appEnv == Key.HTTPS_RELEASE || BuildConfig.appEnv == Key.RELEASE) {
            netConfig.addInterceptor(new NetSignInterceptor())
                    .addInterceptor(new BaseRetryInterceptor());
        }
    }

    /**
     * 初始化更新
     * http://jira.hnxmny.com:8090/pages/viewpage.action?pageId=26692106 集成文档
     */
    private void initXUpdate() {
        XUpdateManager.getInstance();
        Set<String> setActivities = new HashSet<>();
        setActivities.add("LoginActivity");
        setActivities.add("MainActivity");
        try {
            TYUpdater tyUpdater = TYUpdater.get().setDebug(BuildConfig.DEBUG)
                    .setAppEnv(Key.RELEASE)
                    .setIsRetry(true)
                    .addShowActivities(setActivities)
                    .initUpdate(this, BuildConfig.appKey);
            if (NetworkUtils.isAvailable()) {
                tyUpdater.checkVersion();
            }
        } catch (Exception e) {
        }
    }

    /**
     * 初始化加签
     */
    private void updateCDNmainHost() {
        TmapSCDNStrategy alscdn = new TmapSCDNStrategy();
        TmapYunDunStrategy yundun = new TmapYunDunStrategy();
        TmapChuangYuStrategy chuangyu = new TmapChuangYuStrategy();
        TmapStrategy[] tmapStrategies = new TmapStrategy[]{alscdn, yundun, chuangyu};
        long currentTime = System.currentTimeMillis() / 1000;
        TmapDomainsManager.getInstance().init(tmapStrategies, currentTime, 1800).initLogInfo(true);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
        Beta.installTinker();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        unregisterReceiver(netChangedReceiver);
        SystemModel.areaWarnResult.removeObserver(sysObserver);
        SystemModel.loginOut.removeObserver(loginOut);

    }

    //是否是主进程
    private boolean isMainProcess() {
        int pid = Process.myPid();
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningAppProcessInfo appProcess : activityManager.getRunningAppProcesses()) {
            if (appProcess.pid == pid) {
                LogUtils.d(String.format("当前进程：%s", appProcess.processName));
                return getApplicationInfo().packageName.equals(appProcess.processName);
            }
        }
        return false;
    }


    /**
     * 初始化Bugly
     */
    private void initBugly() {
        Bugly.setIsDevelopmentDevice(this, BuildConfig.DEBUG);
        //context 一定要传入this(当前项目的Application)，否则不能进行上报tinkerid
        if ((BuildConfig.appEnv == Key.HTTPS_RELEASE || BuildConfig.appEnv == Key.RELEASE) && !BuildConfig.DEBUG) {
            Bugly.init(this, Key.BUGLY_ID_PRODUCT, BuildConfig.DEBUG);
        } else {
            Bugly.init(this, Key.BUGLY_ID_DEBUG, BuildConfig.DEBUG);
        }
    }

    private void initTingYun() {
        TYTingyunMonitor.init(this);
        if ((BuildConfig.appEnv == Key.HTTPS_RELEASE || BuildConfig.appEnv == Key.RELEASE) && !BuildConfig.DEBUG) {
            TYTingyunMonitor.startAppMonitorEnv(SiteSdk.ins().getTingyunKey(), "0000", true);
        } else {
            TYTingyunMonitor.startAppMonitorEnv(Key.TING_YUN_KEY_DEBUG, "0000", true);
        }
    }

    /**
     * 全局系统级别回调监听
     */
    private void systemMaintain() {
        SystemModel.areaWarnResult.observeForever(sysObserver);
        SystemModel.loginOut.observeForever(loginOut);
    }

    Observer<Integer> sysObserver = code -> {
        Activity activity = TopActivityManager.getInstance().getCurActivity();
        if (activity != null) {
            if (StringUtils.equals("SystemMaintainActivity", activity.getClass().getSimpleName())) {
                return;
            } else if (!activity.isFinishing()) {
                if (!MMKVUtil.getBoolean(CacheKey.SYSTEM_MAIN_PROINFO, false)) {
                    MMKVUtil.put(CacheKey.SYSTEM_MAIN_PROINFO, true);
                    XLiveDataManager.getInstance().getPerInfo();
                }
                Intent intent = new Intent(new Intent(activity, SystemMaintainActivity.class));
                Bundle bundle = new Bundle();
                bundle.putInt(ABConfig.KEY_TAG, code);
                intent.putExtras(bundle);
                activity.startActivity(intent);
                activity.finish();
            }
        }
    };

    Observer<Boolean> loginOut = aBoolean -> {
        Activity activity = com.ty.utils.TopActivityManager.getInstance().getCurActivity();
        if (activity != null && !activity.isFinishing()) {
            if (!(activity instanceof LoginActivity)) {
                XLiveDataManager.getInstance().loginOut();
                LoginActivity.startLoginActivity(activity,false);
                activity.finish();
                XLiveDataManager.getInstance().getPerInfo();
            }
        }
    };


    /**
     * app启动，第一次不跳转锁屏
     */
    boolean isStartAlive = false;

    private String backActivityName = "";

    private void addForegroundListener() {
        TopActivityManager.getInstance().addListener(new TopActivityManager.OnAppStatusChangedListener() {
            @Override
            public void onForeground() {
                if (App.goPhoto) {
                    App.goPhoto = false;
                    return;
                }

                Activity activity = TopActivityManager.getInstance().getCurActivity();
                if (StringUtils.equals("PermissionActivity", backActivityName) || StringUtils.equals("PictureSelectorCameraEmptyActivity", backActivityName)) {//拍照权限
                    return;
                }

                if (isStartAlive) {
                    if (AppConfig.isStartActivity(activity)) {
                        GestureActivity.startGestureActivity(false,false);
                    } else {
                        GestureActivity.startGestureActivity(true,false);
                    }
                }
                isStartAlive = true;

            }

            @Override
            public void onBackground() {
                Activity activity = TopActivityManager.getInstance().getCurActivity();
                if (activity == null) {
                    return;
                }
                backActivityName = activity.getClass().getSimpleName();
                if (!activity.isFinishing()) {
                    if (AppConfig.isBackgroundActivity(activity)) {//照相选择满足条件销毁
                        activity.finish();
                    }
                }
            }
        });
    }
}


