package com.ty.bwagent.dialog;

import android.view.View;
import android.view.inputmethod.EditorInfo;

import androidx.fragment.app.Fragment;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupAnimation;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.SimpleTextWatcher;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.viewmodel.OverFlowViewModle;
import com.ty.common.util.AlphaAnimator;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

/**
 * 溢出查询
 */
public class OverFlowFindPopup extends ConfirmPopupView {

    ClearEditText et_input;
    OverFlowViewModle overFlowViewModle;
    Fragment fragment;
    private OnFindClickListener onFindClickListener;
    BasePopupView progressDialog;

    public OverFlowFindPopup(Fragment fragment, OnFindClickListener onFindClickListener) {
        super(fragment.getContext());
        this.fragment = fragment;
        this.onFindClickListener = onFindClickListener;
        this.title = "溢出查询";
        overFlowViewModle = new OverFlowViewModle();
    }


    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_overflow_find;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();

        et_input = findViewById(R.id.et_input);
        tv_content = findViewById(R.id.tv_content);

        et_input.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tv_content.setText("");
            }
        });
        setListener(() -> {
            if (StringUtils.isEmpty(et_input.getText().toString().trim())) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText("会员账号不能为空");
                return;
            }
            if (StringUtils.length(et_input.getText().toString().trim()) < 4 && StringUtils.length(et_input.getText().toString().trim()) > 0) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText("请输入4-12位会员账号");
                return;
            }
            UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
            if (et_input.getText().toString().trim().equals(userInfo.getName())) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText("会员账号不能为代理自身账号");
                return;
            }
            KeyboardUtils.hideSoftInput(et_input);
            overFlowViewModle.revisionQueryList(et_input.getText().toString().trim(), 1, 15);
        }, null);

        et_input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                if (StringUtils.isEmpty(et_input.getText().toString().trim())) {
                    tv_content.setVisibility(View.VISIBLE);
                    tv_content.setText("请输入会员账号");
                    return false;
                }
                if (StringUtils.length(et_input.getText().toString().trim()) < 4 && StringUtils.length(et_input.getText().toString().trim()) > 0) {
                    tv_content.setVisibility(View.VISIBLE);
                    tv_content.setText("请输入4-12位会员账号");
                    return false;
                }
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                if (et_input.getText().toString().trim().equals(userInfo.getName())) {
                    tv_content.setVisibility(View.VISIBLE);
                    tv_content.setText("会员账号不能为代理自身账号");
                    return false;
                }
                KeyboardUtils.hideSoftInput(et_input);
                overFlowViewModle.revisionQueryList(et_input.getText().toString().trim(), 1, 15);
                return true;
            }
            return false;
        });


        initViewsAndEvents();
    }

    /**
     * 一系列监听回调
     */
    private void initViewsAndEvents() {

        //监听绑定结果
        overFlowViewModle.revisionQueryNetLiveData.observeForever(new NetObserver<BaseEntity>() {
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                onFindClickListener.OnFindClick();
                dismiss();
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                tv_content.setVisibility(View.VISIBLE);
                tv_content.setText(errMsg);
            }

        });

    }

    @Override
    public void dismiss() {
        overFlowViewModle.revisionQueryNetLiveData.removeObservers(fragment);
        super.dismiss();
    }


    @Override
    protected void doAfterShow() {
        super.doAfterShow();
        KeyboardUtils.showSoftInput(et_input);
    }


    @Override
    protected void doAfterDismiss() {
        super.doAfterDismiss();
        KeyboardUtils.hideSoftInput(et_input);
    }

    private void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(fragment.getContext(),fragment);
            progressDialog = new XPopup.Builder(fragment.getContext())
                    .isRequestFocus(false)  //loading不要焦点
                    .hasShadowBg(false)
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        progressDialog.show();
    }

    private void dismissProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    public interface OnFindClickListener {
        void OnFindClick();
    }

}