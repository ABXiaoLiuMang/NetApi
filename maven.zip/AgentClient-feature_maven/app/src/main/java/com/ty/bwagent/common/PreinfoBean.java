package com.ty.bwagent.common;

public class PreinfoBean {


    private String address;
    private String ip;
    private MainConfig maintainConfig;
    private SiteBaseConfig SiteBaseConfigVo;

    public SiteBaseConfig getSiteBaseConfigVo() {
        return SiteBaseConfigVo;
    }

    public void setSiteBaseConfigVo(SiteBaseConfig siteBaseConfigVo) {
        SiteBaseConfigVo = siteBaseConfigVo;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public MainConfig getMaintainConfig() {
        return maintainConfig;
    }

    public void setMaintainConfig(MainConfig maintainConfig) {
        this.maintainConfig = maintainConfig;
    }

    public static class MainConfig {
        private String maintainEndAt;
        private String maintainStartAt;
        private String platformChName;
        private String platformEnName;
        private String platformType;
        private String remark;
        private String status;

        public MainConfig() {
        }

        public String getMaintainEndAt() {
            return maintainEndAt;
        }

        public void setMaintainEndAt(String maintainEndAt) {
            this.maintainEndAt = maintainEndAt;
        }

        public String getMaintainStartAt() {
            return maintainStartAt;
        }

        public void setMaintainStartAt(String maintainStartAt) {
            this.maintainStartAt = maintainStartAt;
        }

        public String getPlatformChName() {
            return platformChName;
        }

        public void setPlatformChName(String platformChName) {
            this.platformChName = platformChName;
        }

        public String getPlatformEnName() {
            return platformEnName;
        }

        public void setPlatformEnName(String platformEnName) {
            this.platformEnName = platformEnName;
        }

        public String getPlatformType() {
            return platformType;
        }

        public void setPlatformType(String platformType) {
            this.platformType = platformType;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }

}
