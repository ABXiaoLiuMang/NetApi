package com.ty.bwagent.fragment.finance.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.viewmodel.CodeViewModel;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

public class DrawWalletViewModel extends CodeViewModel {

    //提款至中心钱包
    public NetLiveData<BaseEntity> withdrawNetLiveData = new NetLiveData<>();

    /**
     * 提款至中心钱包
     * @param withdrawWallet 金额
     * @param code 手机验证码
     */
    public void withdrawToCentralWallet(String withdrawWallet,String code){
        NetSdk.create(Api.class)
                .withdrawToCentralWallet()
                .params("withdrawWallet",withdrawWallet)
                .params("code",code)
                .asJSONType()
                .send(withdrawNetLiveData);
    }
}
