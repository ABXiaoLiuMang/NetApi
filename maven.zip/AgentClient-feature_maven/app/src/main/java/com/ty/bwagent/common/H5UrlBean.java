package com.ty.bwagent.common;

public class H5UrlBean {
    private String intro;
    private String name;
    private String url;
    /**
     * 类型 web 还是phone
     */
    private String type;

    public String getType() {
        return type;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}

