package com.ty.bwagent.fragment;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.CenterPopupView;
import com.lxj.xpopup.interfaces.XPopupImageLoader;
import com.lzy.imagepicker.ImagePicker;
import com.lzy.imagepicker.bean.ImageItem;
import com.lzy.imagepicker.loader.ImageLoader;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tianyu.updater.entity.UpdateEntity;
import com.ty.bwagent.BuildConfig;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.Commission;
import com.ty.bwagent.bean.UnRendTypeEntity;
import com.ty.bwagent.bean.UpFileEntity;
import com.ty.bwagent.bean.UserEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.common.Key;
import com.ty.bwagent.dialog.BindEmailPopup;
import com.ty.bwagent.dialog.BindPhonePopup;
import com.ty.bwagent.dialog.UpHeadPopup;
import com.ty.bwagent.fragment.finance.fragment.DrawingTabFragment;
import com.ty.bwagent.fragment.finance.fragment.RecordTabFragment;
import com.ty.bwagent.fragment.login.ChangePassWordFragment;
import com.ty.bwagent.fragment.news.MessageTabFragment;
import com.ty.bwagent.ui.OnlineActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.Utils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.MoneyViewModel;
import com.ty.bwagent.viewmodel.MyCenterViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.util.SingleOnClickListener;
import com.ty.common.view.TitleBar;
import com.ty.common.view.ValueView;
import com.ty.net.callback.NetObserver;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteSdk;
import com.ty.utils.FileUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.MathUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.CircleImageView;

import java.io.File;
import java.util.ArrayList;

import butterknife.BindView;
import me.yokeyword.fragmentation.ISupportFragment;

import static com.ty.bwagent.dialog.UpHeadPopup.CHANGE_SELECT_HEAD;

/**
 * 我的
 */
public class MyCenterFragment extends ABBaseFragment implements OnRefreshListener {

    MyCenterViewModel mMyCenterViewModel;
    MoneyViewModel moneyViewModel;
    @BindView(R.id.titleBar)
    TitleBar titleBar;
    @BindView(R.id.center_userHead)
    CircleImageView centerUserHead;
    @BindView(R.id.center_userName)
    TextView centerUserName;
    @BindView(R.id.center_join_days)
    TextView centerJoinDays;
    @BindView(R.id.center_iv_commmiss)
    ImageView centerIvCommmiss;
    @BindView(R.id.center_commiss_money)
    TextView centerCommissMoney;
    @BindView(R.id.center_eye_commiss)
    ImageView centerEyeCommiss;
    @BindView(R.id.center_drawing)
    TextView centerDrawing;
    @BindView(R.id.valueview_notice)
    ValueView valueviewNotice;
    @BindView(R.id.valueview_drawing)
    ValueView valueviewDrawing;
    @BindView(R.id.valueview_phone)
    ValueView valueviewPhone;
    @BindView(R.id.valueview_email)
    ValueView valueviewEmail;
    @BindView(R.id.valueview_password)
    ValueView valueviewPassword;
    @BindView(R.id.valueview_vip)
    ValueView valueviewVip;
    @BindView(R.id.valueview_setting)
    ValueView valueviewSetting;
    @BindView(R.id.center_msg_point)
    ImageView centerMsgPoint;
    @BindView(R.id.center_setting_point)
    ImageView centerSettingPoint;
    @BindView(R.id.tv_inviteCode)
    TextView tv_inviteCode;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    Commission commission;//佣金余额和冻结金额

    boolean hideMoney;//true 隐藏金额
    double money = 0.00;//佣金余额

    public static MyCenterFragment getInstance() {
        MyCenterFragment fragment = new MyCenterFragment();
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_my_center;
    }

    @Override
    protected void createProvider() {
        mMyCenterViewModel =  new ViewModelProvider(this).get(MyCenterViewModel.class);
        moneyViewModel =  new ViewModelProvider(getActivity()).get(MoneyViewModel.class);

        //未读消息数量
        XLiveDataManager.getInstance().unreadTypeLiveData.observe(this,new SimpleObserver<BaseEntity<UnRendTypeEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<UnRendTypeEntity> baseEntity) {
                UnRendTypeEntity unRendTypeEntity = baseEntity.getData();
                int unRead = unRendTypeEntity.getActivityCount() + unRendTypeEntity.getNoticeCount();
                if(unRead > 0){//有未读消息数量
                    centerMsgPoint.setVisibility(View.VISIBLE);//显示消息通知
                }else {
                    centerMsgPoint.setVisibility(View.GONE);//显示消息通知
                }
            }
        });

        //检查更新监听
        XLiveDataManager.getInstance().updateResult.observe(this,new NetObserver<UpdateEntity>(){
            @Override
            protected void onSuccess(UpdateEntity updateEntity) {
                if (updateEntity != null && !StringUtils.isEmpty(updateEntity.getUpdateInfo().getVersion()) && updateEntity.getUpdateInfo().getCode() > BuildConfig.VERSION_CODE) {
                    centerSettingPoint.setVisibility(View.VISIBLE);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //监听个人信息(加入天数等)
        XLiveDataManager.getInstance().userLiveData.observe(this,new SimpleObserver<BaseEntity<UserEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<UserEntity> baseEntity) {
                UserEntity userEntity = baseEntity.getData();
                centerUserName.setText(userEntity.getName());

                centerJoinDays.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_center_joins), SiteSdk.ins().getSiteName(),userEntity.getJoinedDays()));

                if(!StringUtils.isEmpty(userEntity.getEmail())){
                    valueviewEmail.setTextValue(Utils.getHideEmail(userEntity.getEmail()));
                    valueviewEmail.setTextValueImg(null);
                    valueviewEmail.setEnabled(false);
                }
                if(!StringUtils.isEmpty(userEntity.getPhone())){
                    valueviewPhone.setTextValue(Utils.getHidePhone(userEntity.getPhone()));
                    valueviewPhone.setTextValueImg(null);
                    valueviewPhone.setEnabled(false);
                }

                Glide.with(mContext).load(userEntity.getAvatar()).into(centerUserHead);

                /**
                 * 可能绑定了用户真实姓名，刷新保存
                 */
                if(!StringUtils.isEmpty(userEntity.getRealName())){
                    UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                    userInfo.setRealName(userEntity.getRealName());
                    UserInfoCache.getInstance().saveUserInfo(userInfo);
                }
            }
        });

        //监听（全局）个人信息
        XLiveDataManager.getInstance().userInfo.observe(this,new NetObserver<UserInfo>(){
            @Override
            protected void onSuccess(UserInfo userInfo) {
                if(!StringUtils.isEmpty(userInfo.getEmail())){
                    valueviewEmail.setTextValue(Utils.getHideEmail(userInfo.getEmail()));
                    valueviewEmail.setTextValueImg(null);
                    valueviewEmail.setEnabled(false);
                }
                if(!StringUtils.isEmpty(userInfo.getPhone())){
                    valueviewPhone.setTextValue(userInfo.getPhone());
                    valueviewPhone.setTextValueImg(null);
                    valueviewPhone.setEnabled(false);
                }
                Glide.with(mContext).load(userInfo.getAvatar()).into(centerUserHead);

                /**
                 * 可能绑定了用户真实姓名，刷新保存
                 */
                if(!StringUtils.isEmpty(userInfo.getRealName())){
                    UserInfo mUserInfo = UserInfoCache.getInstance().getUserInfo();
                    mUserInfo.setRealName(userInfo.getRealName());
                    UserInfoCache.getInstance().saveUserInfo(mUserInfo);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
            }
        });

        //佣金余额
        moneyViewModel.commissLiveData.observe(this,new SimpleObserver<BaseEntity<Commission>>(){
            @Override
            protected void onSuccess(BaseEntity<Commission> baseEntity) {
                refreshLayout.finishRefresh();
                commission = baseEntity.getData();
                money = commission.getAgentMoney();
                showHidePassWord();
            }

            @Override
            protected void onError(int code, String errMsg) {
                super.onError(code, errMsg);
                refreshLayout.finishRefresh(false);
            }
        });

        //修改头像（上传文件）
        mMyCenterViewModel.uploadLiveData.observe(this,new SimpleObserver<BaseEntity<UpFileEntity>>(){
            @Override
            protected void onSuccess(BaseEntity<UpFileEntity> baseEntity) {
                UpFileEntity upFileEntity = baseEntity.getData();
                mMyCenterViewModel.insertMemberAvatar(upFileEntity.getFileUrl());
                Glide.with(mContext).load(upFileEntity.getFileUrl()).into(centerUserHead);
                UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                userInfo.setAvatar(upFileEntity.getFileUrl());
                UserInfoCache.getInstance().saveUserInfo(userInfo);
                XLiveDataManager.getInstance().userInfo.postNext(userInfo);
            }

            @Override
            protected void onError(int code, String errMsg) {
               dismissProgressDialog();
               ToastUtils.showLong(errMsg);
            }
        });

        //上传头像(第二步)
        mMyCenterViewModel.insertAvatarLiveData.observe(this,new SimpleObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                dismissProgressDialog();
                if(upHeadPopup != null){
                    upHeadPopup.dismiss();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
               dismissProgressDialog();
               ToastUtils.showLong(errMsg);
            }
        });
    }


    @Override
    protected void initViewsAndEvents() {
        mMyCenterViewModel.getUnreadForType();//获取未读消息数量（总数）
        hideMoney = MMKVUtil.getBoolean(CacheKey.USER_SHOW_MONEY,true);
        showHidePassWord();
        String inviteCode = MMKVUtil.getString(Key.INVITE_CODE);
        tv_inviteCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_invitecode),inviteCode));
        centerDrawing.setOnClickListener(singleOnClickListener);
        centerUserHead.setOnClickListener(singleOnClickListener);
        centerEyeCommiss.setOnClickListener(singleOnClickListener);
        valueviewNotice.setOnClickListener(singleOnClickListener);
        valueviewDrawing.setOnClickListener(singleOnClickListener);
        valueviewPhone.setOnClickListener(singleOnClickListener);
        valueviewEmail.setOnClickListener(singleOnClickListener);
        valueviewPassword.setOnClickListener(singleOnClickListener);
        valueviewVip.setOnClickListener(singleOnClickListener);
        valueviewSetting.setOnClickListener(singleOnClickListener);
        titleBar.setRightOnClickListener(view -> goActivity(OnlineActivity.class));

        refreshLayout.setOnRefreshListener(this);
        refreshLayout.setEnableRefresh(true);
        refreshLayout.setEnableLoadMore(false);
    }

    SingleOnClickListener singleOnClickListener = new SingleOnClickListener() {
        @Override
        public void onSingleClick(View view) {
            switch (view.getId()) {
                case R.id.center_drawing://提款按钮
                    drawingMoney();
                    break;
                case R.id.center_userHead:
                    new XPopup.Builder(getActivity())
                            .asImageViewer(centerUserHead, "http://t8.baidu.com/it/u=3571592872,3353494284&fm=79&app=86&size=h300&n=0&g=4n&f=jpeg?sec=1589298414&t=85a730d20c1c9532dfcdb9a07430bae4", new ImageLoader())
                            .show();
//                    showHeadDialog();
                    break;
                case R.id.center_eye_commiss:
                    hideMoney = !hideMoney;
                    showHidePassWord();
                    break;
                case R.id.valueview_notice:
                    goFragment(MessageTabFragment.getInstance(0));
                    break;
                case R.id.valueview_drawing://提款记录
                    goFragment(RecordTabFragment.getInstance());
                    break;
                case R.id.valueview_phone:
                    showBindDialog(true);
                    break;
                case R.id.valueview_email:
                    showBindDialog(false);
                    break;
                case R.id.valueview_password:
                    goFragment(ChangePassWordFragment.getInstance());
                    break;
                case R.id.valueview_vip:
                    ToastUtils.showLong(ResUtils.getString(R.string.generic_open));
                    break;
                case R.id.valueview_setting:
                    goFragment(SettingFragment.getInstance());
                    break;
            }
        }
    };


    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        mMyCenterViewModel.getUnreadForType();//获取未读消息数量（总数）
        moneyViewModel.initMoney();//获取佣金余额
        XLiveDataManager.getInstance().checkUpdate();//检查更新
    }

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        moneyViewModel.initMoney();//获取佣金余额
        XLiveDataManager.getInstance().getUserInfo();//刷新用户信息
    }

    private void drawingMoney(){
        UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
        String phone = userInfo.getPhone();
        if(StringUtils.isEmpty(phone)){
            ToastUtils.showLong("请绑定手机号后操作");
            return;
        }
        if(commission == null){
            return;
        }

        double hasMoney = MathUtil.subtract(commission.getAgentMoney(),commission.getAgentFreezedMoney());
        if(hasMoney < 100d){
            ToastUtils.showLong(ResUtils.getString(R.string.generic_money_small));
        }else {
            goFragment(DrawingTabFragment.getInstance());
        }
    }


    private void showHidePassWord(){
        String hideMoney = MathUtil.parseNumber(money);
        if (this.hideMoney){
            centerEyeCommiss.setImageResource(R.mipmap.center_eyes_close);
            centerCommissMoney.setText(Utils.getHideMoney(hideMoney));
        }else {
            centerCommissMoney.setText(hideMoney);
            centerEyeCommiss.setImageResource(R.mipmap.center_eye_open);
        }
        MMKVUtil.put(CacheKey.USER_SHOW_MONEY, this.hideMoney);
    }

    /**
     * 绑定电话或邮箱弹窗
     * @param bindType true 电话 ，false 邮箱
     */
    private void showBindDialog(boolean bindType){
        CenterPopupView centerBindPopup;
        if(bindType){
            centerBindPopup = new BindPhonePopup(this)
            .setConfirmTextColor(SiteSdk.ins().styleColor());
        }else {
            centerBindPopup = new BindEmailPopup(this)
            .setConfirmTextColor(SiteSdk.ins().styleColor());
        }

        new XPopup.Builder(getContext())
                .moveUpToKeyboard(true)
                .autoDismiss(false)
                .dismissOnBackPressed(false)
                .asCustom(centerBindPopup)
                .show();
    }

    /**
     * 用户选择头像弹窗
     */
    UpHeadPopup upHeadPopup;
    private void showHeadDialog(){
        upHeadPopup = new UpHeadPopup(this);
        new XPopup.Builder(getContext())
                .asCustom(upHeadPopup)
                .show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CHANGE_SELECT_HEAD && data != null){
            ArrayList<ImageItem> images = (ArrayList<ImageItem>) data.getSerializableExtra(ImagePicker.EXTRA_RESULT_ITEMS);
            String path = images.get(0).path;
            File file = new File(path);
            FileUtils.createOrExistsFile(file);
            showProgressDialog();
            mMyCenterViewModel.uploadFile(file);
        }
    }

    private void goFragment(ISupportFragment supportFragment){
        ((ABBaseFragment)getParentFragment()).start(supportFragment);
    }

    public static class ImageLoader implements XPopupImageLoader {
        @Override
        public void loadImage(int position, @NonNull Object url, @NonNull ImageView imageView) {
            //必须指定Target.SIZE_ORIGINAL，否则无法拿到原图，就无法享用天衣无缝的动画
            Glide.with(imageView).load(url).apply(new RequestOptions().placeholder(R.mipmap.ic_launcher).override(0x80000000)).into(imageView);
        }

        @Override
        public File getImageFile(@NonNull Context context, @NonNull Object uri) {
            try {
                return Glide.with(context).downloadOnly().load(uri).submit().get();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

}
