package com.ty.bwagent.adapter

import android.view.View
import android.widget.ImageView
import androidx.core.content.ContextCompat

import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.ty.bwagent.R
import com.ty.bwagent.bean.ContactUsEntity
import com.ty.bwagent.bean.SchemeSetCommissionEntity


/**
 * 描述:下级详情佣金比例
 */
class CommissionRatioAdapter : BaseQuickAdapter<SchemeSetCommissionEntity.RebateDetailBean, BaseViewHolder>(R.layout.recycle_item_commission_ratio) {

    private var selectPositon = 0

    override fun convert(helper: BaseViewHolder, item: SchemeSetCommissionEntity.RebateDetailBean) {

        item.let {
            helper.setText(R.id.tv_text, it.name)
            if (selectPositon == helper.adapterPosition) {
                helper.getView<View>(R.id.tv_text).background = ContextCompat.getDrawable(mContext, R.drawable.site_bnt_solid_bg)
                helper.setTextColor(R.id.tv_text, ContextCompat.getColor(mContext, R.color.white))
            } else {
                helper.getView<View>(R.id.tv_text).background = ContextCompat.getDrawable(mContext, R.drawable.sec_team_title_bg)
                helper.setTextColor(R.id.tv_text, ContextCompat.getColor(mContext, R.color.color_cbced8))
            }
        }

    }


    fun setSelect(selectPositon: Int) {
        if (this.selectPositon != selectPositon) {
            this.selectPositon = selectPositon
            notifyDataSetChanged()
        }
    }

}
