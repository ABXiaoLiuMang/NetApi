package com.ty.bwagent.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.GameVenueEntity;
import com.ty.bwagent.bean.TeamCommissionEntity;
import com.ty.bwagent.bean.TeamMenberInfoEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class TeamViewModel extends ViewModel {

    public NetLiveData<BaseEntity<String>> teamInfoLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity<TeamMenberInfoEntity>> teamMenberInfoLiveData = new NetLiveData<>();
    public NetLiveData<BaseEntity<TeamCommissionEntity>> teamCommissionListLiveData = new NetLiveData<>();

    //类型
    public NetLiveData<BaseEntity<List<GameVenueEntity>>> allGameVenueLiveData = new NetLiveData<>();

    //查询代理团队信息
    public void getTeamInfo() {
        NetSdk.create(Api.class)
                .getTeamId()
                .asJSONType()
                .send(teamInfoLiveData);
    }

    //查询代理团队信息
    public void getTeamMenberList(String data, int pageNum, int pageSize) {
        NetSdk.create(Api.class)
                .getTeamMenberList()
                .params("agentName", data)
                .params("pageNum", pageNum)
                .params("pageSize", pageSize)
                .asJSONType()
                .send(teamMenberInfoLiveData);
    }

    //团队佣金&团队财务列表   commissionDate：佣金月份(格式2019-11）
    public void commissionList(String agentName, String commissionDate, int pageNum, int pageSize) {
        NetSdk.create(Api.class)
                .commissionList()
                .params("agentName", agentName)
                .params("commissionDate", commissionDate)
                .params("pageNum", pageNum)
                .params("pageSize", pageSize)
                .asJSONType()
                .send(teamCommissionListLiveData);
    }
}
