package com.ty.bwagent.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.ty.bwagent.R;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.utils.InputResultCalculator;
import com.ty.view.ClearEditText;
import java.util.Arrays;

public class XCodeView extends ConstraintLayout {

    Context mContext;
    int maxLength;
    String hint_text;
    String commit_text;
    ClearEditText x_et_code;
    TextView x_tv_code;

    public XCodeView(Context context) {
        this(context, null);
    }

    public XCodeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public XCodeView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        TypedArray mTypedArray = mContext.obtainStyledAttributes(attrs, R.styleable.XCodeView);
        maxLength = mTypedArray.getInt(R.styleable.XCodeView_maxLength,6);
        hint_text = mTypedArray.getString(R.styleable.XCodeView_hint_text);
        commit_text = mTypedArray.getString(R.styleable.XCodeView_commit_text);
        mTypedArray.recycle();
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        View view = LayoutInflater.from(mContext).inflate(R.layout.x_codeview, this, true);
        x_et_code = view.findViewById(R.id.x_et_code);
        x_tv_code = view.findViewById(R.id.x_tv_code);

        if(!TextUtils.isEmpty(hint_text)){
            x_et_code.setHint(hint_text);
        }
        x_et_code.setFilters(new InputFilter[] { new InputFilter.LengthFilter(maxLength) });
        if(!TextUtils.isEmpty(commit_text)){
            x_tv_code.setText(commit_text);
        }
    }

    /**
     * @return 获取确定按钮
     */
    public TextView getCommitBtn() {
        return x_tv_code;
    }

    /**
     * 获取输入框
     * @return
     */
    public ClearEditText getEditText() {
        return x_et_code;
    }

    /**
     * 获取输入框
     * @return
     */
    public String getInputString() {
        return x_et_code.getText().toString().trim();
    }
}
