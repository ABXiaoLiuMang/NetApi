package com.ty.bwagent.adapter;


import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.MessageSys;
import com.ty.bwagent.bean.SpecialNoticeEntity;
import com.ty.utils.ScreenUtils;

import java.util.ArrayList;
import java.util.List;

public class MarqueAdapter extends BaseQuickAdapter<SpecialNoticeEntity, BaseViewHolder> {
    private List<SpecialNoticeEntity> originList = null;

    public MarqueAdapter() {
        super(R.layout.recycle_item_marque);
    }

    @Override
    protected void convert(BaseViewHolder helper, SpecialNoticeEntity item) {
        TextView scrollView = helper.getView(R.id.tv_scroll_content);
        String content = item.getContent().replace("\n"," ");
        scrollView.setText(content);
        scrollView.setPadding(ScreenUtils.getScreenWidth()/3, 0, 0, 0);
    }

    @Override
    public void setNewData(@Nullable List<SpecialNoticeEntity> data) {
        if (data != null){
            originList = new ArrayList<>(data);
        }
        super.setNewData(data);
    }

    public void reload() {
        List<SpecialNoticeEntity> stringList = new ArrayList<>(originList);
        addData(stringList);
    }
}

