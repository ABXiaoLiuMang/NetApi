package com.ty.bwagent.ui;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.Data;
import com.ty.bwagent.bean.ProInfoEntity;
import com.ty.bwagent.fragment.login.LoginAndRegisterFragment;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.ui.ABBaseActivity;
import com.ty.common.util.ABConfig;
import com.ty.net.callback.SimpleObserver;
import com.ty.net.utils.JsonUtils;
import com.ty.utils.ExitUtils;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.TopActivityManager;

import butterknife.BindView;


public class LoginActivity extends ABBaseActivity {

    @BindView(R.id.fl_container)
    View rootView;

    /** processFirst
     * 1.ture：需要判断第一次挂警告的处理，false:忽略警告处理
     * 2.ture:第一次闪屏到解锁后进入  false:退出登录，修改密码等跳入
     */
    boolean processFirst = false;//

    /**
     * processFirst
     * 1.ture：需要判断第一次挂警告的处理，false:忽略警告处理
     * 2.ture:第一次闪屏到解锁后进入  false:退出登录，修改密码等跳入
     */
    public static void startLoginActivity(Activity activity,boolean processFirst){
        Bundle bundle = new Bundle();
        bundle.putBoolean(ABConfig.KEY_TAG,processFirst);
        Intent intent = new Intent();
        intent.setClass(activity, LoginActivity.class);
        intent.putExtras(bundle);
        activity.startActivity(intent);
        activity.overridePendingTransition(com.ty.common.R.anim.x_push_left_in, com.ty.common.R.anim.x_push_left_out);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_root;
    }

    @Override
    protected void createProvider() {
        processFirst = bundle.getBoolean(ABConfig.KEY_TAG,false);
        findViewById(android.R.id.content).setOnClickListener(v -> KeyboardUtils.hideSoftInput(LoginActivity.this));
        XLiveDataManager.getInstance().proInfoLiveData.observe(this,new SimpleObserver<ProInfoEntity>(){
            @Override
            protected void onSuccess(ProInfoEntity proInfoEntity) {
                int code = -1;
                if(proInfoEntity != null && proInfoEntity.getData() != null){
                    Data dataBean =  proInfoEntity.getData();
                    if(dataBean.getMaintainConfig().getStatus() == 0){
                        code = 10401;
                    }else if(proInfoEntity.getCode() == 10402){
                        code = 10402;
                    }else if(proInfoEntity.getCode() == 10403 && processFirst){
                        code = 10403;
                    }

                    if(code != -1){//维护状态
                        SystemModel.areaWarnResult.postValue(code);
                    }
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        if (findFragment(LoginAndRegisterFragment.class) == null) {
            loadRootFragment(R.id.fl_container, LoginAndRegisterFragment.getInstance());
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            exit();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void exit() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if (count > 1) {
            pop();
        } else {
            ExitUtils.getInstance().finishAll();
        }
    }
}
