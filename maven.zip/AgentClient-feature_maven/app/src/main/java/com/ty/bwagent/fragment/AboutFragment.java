package com.ty.bwagent.fragment;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.ContactUsEntity;
import com.ty.bwagent.viewmodel.AboutViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.SimpleObserver;
import com.ty.tysite.SiteConfig;
import com.ty.tysite.SiteSdk;
import com.ty.utils.AppUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

import butterknife.BindView;


public class AboutFragment extends ABBaseFragment {

    AboutViewModel mAboutViewModel;
    @BindView(R.id.ivLogo)
    ImageView ivLogo;
    @BindView(R.id.tvAppName)
    TextView tvAppName;
    @BindView(R.id.about_tv_qq)
    TextView aboutTvQq;
    @BindView(R.id.about_tv_sugram)
    TextView aboutTvSugram;
    @BindView(R.id.about_tv_skype)
    TextView aboutTvSkype;
    @BindView(R.id.tv_QQ_logo)
    TextView tvQQLogo;
    @BindView(R.id.tv_sugram_logo)
    TextView tvSugramLogo;
    @BindView(R.id.tv_skype_logo)
    TextView tvSkypeLogo;

    public static AboutFragment getInstance() {
        AboutFragment fragment = new AboutFragment();
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_about;
    }

    @Override
    protected void createProvider() {
        mAboutViewModel = new ViewModelProvider(this).get(AboutViewModel.class);
        mAboutViewModel.contactUsLiveData.observe(this, new SimpleObserver<BaseEntity<ContactUsEntity>>() {
            @Override
            protected void onSuccess(BaseEntity<ContactUsEntity> baseEntity) {
                refreshUI(baseEntity.getData());
            }

            @Override
            protected void onLoading(boolean show) {
                if (show) {
                    showProgressDialog();
                } else {
                    dismissProgressDialog();
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        mAboutViewModel.contactUs();
        tvAppName.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_app_version), AppUtil.getVersionName()));
    }

    private void refreshUI(ContactUsEntity contactUsEntity) {
        SiteConfig siteConfig = (SiteConfig) SiteSdk.ins();
        switch (siteConfig.getSiteId()) {
            case 4://火狐
              Drawable telegramLogo = ResUtils.getDrawable(R.mipmap.about_telegram);
                telegramLogo.setBounds(0, 0, telegramLogo.getMinimumWidth(), telegramLogo.getMinimumHeight());
                tvSugramLogo.setCompoundDrawables(null, telegramLogo, null, null);
                tvSugramLogo.setText("合营部Telegram");
                aboutTvSugram.setText(contactUsEntity.getAgentSugram());

                aboutTvQq.setText(contactUsEntity.getAgentQq());
                aboutTvSkype.setText(contactUsEntity.getAgentSkype());
                break;
            case 8://环球
            case 6://亿博
                Drawable flygram = ResUtils.getDrawable(R.mipmap.about_flygram);
                flygram.setBounds(0, 0, flygram.getMinimumWidth(), flygram.getMinimumHeight());
                tvSugramLogo.setCompoundDrawables(null, flygram, null, null);
                tvSugramLogo.setText("合营部Flygram");
                aboutTvSugram.setText(contactUsEntity.getAgentSugram());

                aboutTvQq.setText(contactUsEntity.getAgentQq());
                aboutTvSkype.setText(contactUsEntity.getAgentSkype());
                break;
            case 7://AOA
            case 5://KOK
            default:
                aboutTvQq.setText(contactUsEntity.getAgentQq());
                aboutTvSugram.setText(contactUsEntity.getAgentSugram());
                aboutTvSkype.setText(contactUsEntity.getAgentSkype());
                break;
        }
    }
}
