package com.ty.bwagent.fragment.deposit.bean;

import java.util.List;

/**
 * 描述:代理转账记录
 * <p>
 * author:Dale
 */
public class DepositRecord {
    /**
     * navigatepageNums : [1]
     * startRow : 1
     * hasNextPage : false
     * prePage : 0
     * nextPage : 0
     * endRow : 2
     * pageSize : 10
     * list : [{"confirmAt":"2020-03-21 21:43:32","bankCard":"","topId":0,"transferMemberId":2019138343,"withdrawType":null,"payAdminId":0,"remark":"","createdAt":"2020-03-21 21:43:32","clientType":4,"memberUsername":"boby","id":350,"typayOrderId":"","billNo":"DD1241359791448788992","memberId":201095,"updatedAt":"2020-03-21 21:43:32","bankCode":"","amount":100,"drawStatus":403,"riskAdminId":0,"payAssignerId":0,"riskConfirmAt":"2020-03-21 21:43:32","bankAddress":"","bankRealname":"","memberGrade":0,"clientIp":"202.186.228.135","drawComment":"","category":3,"transferMemberName":"ouou6"},{"confirmAt":"2020-03-08 20:39:42","bankCard":"","topId":0,"transferMemberId":0,"withdrawType":null,"payAdminId":0,"remark":"","createdAt":"2020-03-08 20:39:42","clientType":1,"memberUsername":"boby","id":87,"typayOrderId":"","billNo":"DD1236632684269277184","memberId":201095,"updatedAt":"2020-03-08 20:39:42","bankCode":"","amount":100,"drawStatus":403,"riskAdminId":0,"payAssignerId":0,"riskConfirmAt":"2020-03-08 20:39:42","bankAddress":"","bankRealname":"","memberGrade":0,"clientIp":"103.113.60.166","drawComment":"234w34dgdfgsdf#$%#$%","category":3,"transferMemberName":""}]
     * pageNum : 1
     * navigatePages : 8
     * navigateFirstPage : 1
     * total : 2
     * pages : 1
     * size : 2
     * isLastPage : true
     * hasPreviousPage : false
     * navigateLastPage : 1
     * isFirstPage : true
     */

    private int startRow;
    private boolean hasNextPage;
    private int prePage;
    private int nextPage;
    private int endRow;
    private int pageSize;
    private int pageNum;
    private int navigatePages;
    private int navigateFirstPage;
    private int total;
    private int pages;
    private int size;
    private boolean isLastPage;
    private boolean hasPreviousPage;
    private int navigateLastPage;
    private boolean isFirstPage;
    private List<ListBean> list;

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public int getPrePage() {
        return prePage;
    }

    public void setPrePage(int prePage) {
        this.prePage = prePage;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getNavigatePages() {
        return navigatePages;
    }

    public void setNavigatePages(int navigatePages) {
        this.navigatePages = navigatePages;
    }

    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    public void setNavigateFirstPage(int navigateFirstPage) {
        this.navigateFirstPage = navigateFirstPage;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean isIsLastPage() {
        return isLastPage;
    }

    public void setIsLastPage(boolean isLastPage) {
        this.isLastPage = isLastPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    public void setNavigateLastPage(int navigateLastPage) {
        this.navigateLastPage = navigateLastPage;
    }

    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    public void setIsFirstPage(boolean isFirstPage) {
        this.isFirstPage = isFirstPage;
    }


    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {

        /**
         * amount : 100.0
         * billNo : PR1252209027211988992
         * category : 20204
         * clientIp : 218.189.125.130
         * clientType : 1
         * createdAt : 2020-04-20 20:14:31
         * drawStatus : 403
         * id : 999999602988995323
         * memberId : 2019126041
         * memberUsername : testouou
         * remark : 啊啊
         * topId : 2019138606
         * transferMemberId : 2019139752
         * transferMemberName : ououou8
         * updatedAt : 2020-04-20 20:14:31
         * withdrawType : 1
         */

        private double amount;
        private String billNo;
        private int category;
        private String clientIp;
        private int clientType;
        private String createdAt;
        private int drawStatus;
        private String id;
        private String memberId;
        private String memberUsername;
        private String remark;
        private String topId;
        private String transferMemberId;
        private String transferMemberName;
        private String updatedAt;
        private String drawComment;
        private int withdrawType;//代存类型 20206 佣金代存 20205额度代存

        public double getAmount() {
            return amount;
        }

        public void setAmount(double amount) {
            this.amount = amount;
        }

        public String getBillNo() {
            return billNo;
        }

        public void setBillNo(String billNo) {
            this.billNo = billNo;
        }

        public int getCategory() {
            return category;
        }

        public void setCategory(int category) {
            this.category = category;
        }

        public String getClientIp() {
            return clientIp;
        }

        public void setClientIp(String clientIp) {
            this.clientIp = clientIp;
        }

        public int getClientType() {
            return clientType;
        }

        public void setClientType(int clientType) {
            this.clientType = clientType;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public int getDrawStatus() {
            return drawStatus;
        }

        public void setDrawStatus(int drawStatus) {
            this.drawStatus = drawStatus;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getMemberId() {
            return memberId;
        }

        public void setMemberId(String memberId) {
            this.memberId = memberId;
        }

        public String getMemberUsername() {
            return memberUsername;
        }

        public void setMemberUsername(String memberUsername) {
            this.memberUsername = memberUsername;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getTopId() {
            return topId;
        }

        public void setTopId(String topId) {
            this.topId = topId;
        }

        public String getTransferMemberId() {
            return transferMemberId;
        }

        public void setTransferMemberId(String transferMemberId) {
            this.transferMemberId = transferMemberId;
        }

        public String getTransferMemberName() {
            return transferMemberName;
        }

        public void setTransferMemberName(String transferMemberName) {
            this.transferMemberName = transferMemberName;
        }

        public String getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
        }

        public int getWithdrawType() {
            return withdrawType;
        }

        public void setWithdrawType(int withdrawType) {
            this.withdrawType = withdrawType;
        }

        public String getDrawComment() {
            return drawComment;
        }

        public void setDrawComment(String drawComment) {
            this.drawComment = drawComment;
        }
    }
}
