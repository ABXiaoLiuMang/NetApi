package com.ty.bwagent.ui

import com.ty.bwagent.R
import com.ty.bwagent.bean.ProInfoEntity
import com.ty.bwagent.utils.CacheKey
import com.ty.bwagent.utils.GoUtils
import com.ty.bwagent.utils.XLiveDataManager
import com.ty.bwagent.view.XMaintainView
import com.ty.common.ui.ABBaseActivity
import com.ty.common.util.ABConfig
import com.ty.net.callback.SimpleObserver
import com.ty.utils.MMKVUtil
import com.ty.utils.StringUtils
import kotlinx.android.synthetic.main.activity_system_maintain.*

/**
 * 1.暂时没有此功能
 * 1.区域限制
 * 2.维护限制
 */
class SystemMaintainActivity : ABBaseActivity() {

    internal var code: Int = 0

    override fun getLayoutId(): Int {
        return R.layout.activity_system_maintain
    }

    override fun createProvider() {
        code = bundle.getInt(ABConfig.KEY_TAG, 10402)
        XLiveDataManager.getInstance().proInfoLiveData.observe(this, object : SimpleObserver<ProInfoEntity>() {
            override fun onSuccess(proInfoEntity: ProInfoEntity) {
                initViews(proInfoEntity)
            }
        })
    }

    override fun initViewsAndEvents() {
        xMaintainView.callService.setOnClickListener { goActivity(OnlineActivity::class.java) }
        xMaintainView.tvContinue.setOnClickListener { GoUtils.checkSwitch(this,false) }
        when (code) {
            10401 -> xMaintainView.setSpecialType(XMaintainView.SpecialType.system_maintain)
            10402 -> xMaintainView.setSpecialType(XMaintainView.SpecialType.access_limit)
            else -> xMaintainView.setSpecialType(XMaintainView.SpecialType.area_forbid)
        }
    }


    private fun initViews(proInfoEntity: ProInfoEntity) {
        proInfoEntity?.data?.let {
            MMKVUtil.put(CacheKey.CUSTOMER_SERVICE, it.SiteBaseConfigVo?.customerService)
            when (code) {
                10401 -> {//维护A
                    xMaintainView.tv_tag_tips.text = getString(R.string.generic_system_time)
                    var startTime = it.maintainConfig?.maintainStartAt
                    var endTime = it.maintainConfig?.maintainEndAt
                    if(!StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)){
                        if(startTime?.length > 5) startTime = startTime.substring(5,startTime.length)
                        if(endTime?.length > 5) endTime = endTime.substring(5,endTime.length)
                        xMaintainView.tv_ip.text = StringUtils.getFormatString(getString(R.string.generic_system_tips), startTime, endTime)
                    }
                    xMaintainView.setSpecialType(XMaintainView.SpecialType.system_maintain)
                }
                10402 -> {//ip禁止
                    xMaintainView.tv_tag_tips.text = getString(R.string.generic_system_ip)
                    xMaintainView.tv_ip.text = StringUtils.getFormatString(getString(R.string.generic_system_addres), it.ip, it.address)
                    xMaintainView.setSpecialType(XMaintainView.SpecialType.access_limit)
                }
                else ->{ //警告
                    xMaintainView.tv_tag_tips.text = getString(R.string.generic_system_ip)
                    xMaintainView.tv_ip.text = StringUtils.getFormatString(getString(R.string.generic_system_addres), it.ip, it.address)
                    xMaintainView.setSpecialType(XMaintainView.SpecialType.area_forbid)
                }
            }
        }

    }

}
