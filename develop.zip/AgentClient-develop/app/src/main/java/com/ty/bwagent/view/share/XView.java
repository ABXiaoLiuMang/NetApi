package com.ty.bwagent.view.share;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.ty.utils.ScreenUtils;

public class XView extends View {
    public XView(Context context) {
        super(context);
    }

    public XView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public XView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(ScreenUtils.getScreenWidth(),heightMeasureSpec);
    }
}
