package com.ty.bwagent.adapter

import android.widget.TextView
import androidx.core.content.ContextCompat

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.ty.bwagent.R
import com.ty.bwagent.bean.ReviewListEntity
import com.ty.utils.StringUtils


/**
 * 下级审核显示
 */
class SubordinateAuditAdapter : BaseQuickAdapter<ReviewListEntity.ListBean, BaseViewHolder>(R.layout.recycle_item_sub_audit) {

    override fun convert(helper: BaseViewHolder, item: ReviewListEntity.ListBean) {

        item?.let {

            helper.setText(R.id.tv_name, it.memberName)//
            helper.setText(R.id.tv_real_name, "真实姓名：" + if (StringUtils.isEmpty(it.realName)) "" else it.realName)//
            helper.setText(R.id.tv_phone, "手机号码：" + if (StringUtils.isEmpty(it.phone)) "" else it.phone)//
            helper.setText(R.id.apply_time, if (StringUtils.isEmpty(it.createdAt)) "" else it.createdAt + "")//申请时间
            helper.setText(R.id.audio_time, if (StringUtils.isEmpty(it.reviewAt)) "" else it.reviewAt + "")//审核时间

            val tvState = helper.getView<TextView>(R.id.tv_state)//审核状态

            //审核状态0待审核1审核拒绝2审批通过
            when (it.reviewStatus) {
                0//待审核
                -> {
                    helper.setVisible(R.id.tv_key_top, true)
                    helper.setVisible(R.id.tv_key_bottom, true)
                    helper.setText(R.id.tv_key_top, "通过")
                    helper.setText(R.id.tv_key_bottom, "拒绝")
                    tvState.text = "待审核"
                    tvState.setTextColor(ContextCompat.getColor(mContext,R.color.generic_heise))
                }
                1//审核拒绝
                -> {
                    tvState.setTextColor(ContextCompat.getColor(mContext,R.color.generic_warning))
                    helper.setVisible(R.id.tv_key_top, true)
                    helper.setVisible(R.id.tv_key_bottom, false)
                    helper.setText(R.id.tv_key_top, "查看")
                    tvState.text = "审核拒绝"
                }
                2//审批通过
                -> {
                    tvState.setTextColor(ContextCompat.getColor(mContext,R.color.generic_lvse_a))
                    tvState.text = "审核通过"
                    helper.setVisible(R.id.tv_key_top, true)
                    helper.setVisible(R.id.tv_key_bottom, false)
                    helper.setText(R.id.tv_key_top, "查看")
                }
            }
            helper.addOnClickListener(R.id.tv_key_top, R.id.tv_key_bottom)
        }

    }


}
