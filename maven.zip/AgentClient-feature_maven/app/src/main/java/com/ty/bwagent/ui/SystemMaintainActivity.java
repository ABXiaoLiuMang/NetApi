package com.ty.bwagent.ui;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.view.XMaintainView;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.ui.ABBaseActivity;
import com.ty.net.callback.NetObserver;
import com.ty.net.exception.ErrorMessage;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ToastUtils;

import butterknife.BindView;

public class SystemMaintainActivity extends ABBaseActivity {

    @BindView(R.id.xMaintainView)
    XMaintainView xMaintainView;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_system_maintain;
    }

    @Override
    protected void createProvider() {
    }

    @Override
    protected void initViewsAndEvents() {
        xMaintainView.getvCallService().setOnClickListener(v -> {
            ToastUtils.showLong("跳转客服");
        });

        xMaintainView.getTv_tag_tips().setText("预计维护时间:");
        xMaintainView.getTv_ip().setText("11-12 4:30-11-12 9:30");

        SystemModel.sMaintainInfo.observe(this,new NetObserver<BaseEntity>(){

            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                boolean type = MMKVUtil.getBoolean("testtype",false);
                if (type){
                    xMaintainView.getTv_tag_tips().setText("您的IP来自于:");
                    xMaintainView.getTv_ip().setText("*** *** ***(马来西亚)");
                    xMaintainView.setSpecialType(XMaintainView.SpecialType.access_limit);
                    MMKVUtil.put("testtype",false);
                }else {
                    xMaintainView.getTv_tag_tips().setText("预计维护时间:");
                    xMaintainView.getTv_ip().setText("11-12 4:30-11-12 9:30");
                    xMaintainView.setSpecialType(XMaintainView.SpecialType.system_maintain);
                    MMKVUtil.put("testtype",true);
                }
            }

            @Override
            protected void onError(int code, String errMsg) {

            }


        });
    }

}
