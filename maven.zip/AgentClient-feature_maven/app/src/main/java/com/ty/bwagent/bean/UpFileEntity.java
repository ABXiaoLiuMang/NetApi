package com.ty.bwagent.bean;

/**
 * 上传图片返回模型
 */
public class UpFileEntity {

    /**
     * contentType : image/png
     * fileId : 1581906758381685.png
     * fileName : IMG_20200217_103241.png
     * fileUri : //img.bwhou2020.com/1581906758381685.png
     * fileUrl : https://img.bwhou2020.com/1581906758381685.png
     * lastModified : 0
     * size : 143825
     */

    private String contentType;
    private String fileId;
    private String fileName;
    private String fileUri;
    private String fileUrl;
    private int lastModified;
    private int size;

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileUri() {
        return fileUri;
    }

    public void setFileUri(String fileUri) {
        this.fileUri = fileUri;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public int getLastModified() {
        return lastModified;
    }

    public void setLastModified(int lastModified) {
        this.lastModified = lastModified;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
