package com.ty.bwagent.fragment.deposit.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.fragment.deposit.bean.DepositRecord;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

public class DepositViewModel extends ViewModel {

    //代理转账记录
    public NetLiveData<BaseEntity<DepositRecord>> depositNetLiveData = new NetLiveData<>();

    /**
     * 查询代理转账记录
     * @param startDate
     * @param endDate
     * @param status
     * @param pageNum
     * @param pageSize
     */
    public void getDepositRecordList(String startDate, String endDate, int status, int pageNum, int pageSize){
        NetSdk.create(Api.class)
                .transferRecordList()
                .params("pageNum",pageNum)
                .params("pageSize",pageSize)
                .params("status",status == 0 ? "" : status + "")
                .params("startDate",startDate)
                .params("endDate",endDate)
                .asJSONType()
                .send(depositNetLiveData);
    }

    /**
     * 查询代理代存记录
     * @param startDate
     * @param endDate
     * @param status
     * @param pageNum
     * @param pageSize
     */
    public void agentDepositRecordList(String startDate, String endDate, int status, int pageNum, int pageSize){
        NetSdk.create(Api.class)
                .agentDepositRecordList()
                .params("pageNum",pageNum)
                .params("pageSize",pageSize)
                .params("status",status == 0 ? "" : status + "")
                .params("startDate",startDate)
                .params("endDate",endDate)
                .asJSONType()
                .send(depositNetLiveData);
    }
}
