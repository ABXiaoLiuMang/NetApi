package com.ty.bwagent.fragment.finance.viewmodel;

import androidx.lifecycle.ViewModel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.fragment.finance.bean.FinanceDetails;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

public class FinanceDetailsViewModel extends ViewModel {


    //佣金/场馆费月度明细
    public NetLiveData<BaseEntity<List<FinanceDetails>>> financeNetLiveData = new NetLiveData<>();

    /**
     * 账户调整月度明细
     */
    public void getGameFanshuiHighLow(){
        NetSdk.create(Api.class)
                .getGameFanshuiHighLow()
                .asJSONType()
                .send(financeNetLiveData);
    }

}
