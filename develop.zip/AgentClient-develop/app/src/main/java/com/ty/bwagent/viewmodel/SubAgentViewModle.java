package com.ty.bwagent.viewmodel;

import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.AgentLowerListBean;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.TeamCountEntity;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;

import java.util.List;

import androidx.lifecycle.ViewModel;

/**
 * 下级代理
 */
public class SubAgentViewModle extends ViewModel {

    //列表查询
    public NetLiveData<BaseEntity<AgentLowerListBean>> reviewListLiveData = new NetLiveData<>();

    //无限代web-下级-新增代理
    public NetLiveData<BaseEntity> insertLowerLiveData = new NetLiveData<>();
    //新增下级权限 团队总人数和团队代理人数
    public NetLiveData<BaseEntity<TeamCountEntity>> getTeamCountLiveData = new NetLiveData<>();

    /**
     * 无限代web-下级-下级代理
     *
     * @param pageNum
     * @param pageSize
     */
    public void agentLowerList(String agentName, String commissionDate, int pageNum, int pageSize) {
        NetSdk.create(Api.class)
                .agentLowerList()
                .params("agentName", agentName)
                .params("commissionDate", commissionDate)
                .params("pageNum", pageNum)
                .params("pageSize", pageSize)
                .asJSONType()
                .send(reviewListLiveData);
    }

    /**
     * 无限代web-下级-下级代理
     */
    public void insertLower(String agentName) {
        NetSdk.create(Api.class)
                .insertLower()
                .params("agentName", agentName)
                .asJSONType()
                .send(insertLowerLiveData);
    }


    /**
     * //新增下级权限 团队总人数和团队代理人数
     */
    public void getTeamCount() {
        NetSdk.create(Api.class)
                .getTeamCount()
                .asJSONType()
                .send(getTeamCountLiveData);
    }

}
