package com.ty.bwagent.fragment.login;

import android.widget.TextView;

import androidx.lifecycle.ViewModelProvider;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.ui.LoginActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.view.XPassWordView;
import com.ty.bwagent.viewmodel.ChangePassWordViewModel;
import com.ty.common.ui.ABBaseFragment;
import com.ty.net.callback.SimpleObserver;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.KeyboardUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.OnClick;


public class ChangePassWordFragment extends ABBaseFragment{

    ChangePassWordViewModel mChangePassWordViewModel;
    @BindView(R.id.change_tv_warning)
    TextView changeTvWarning;
    @BindView(R.id.x_oldPass)
    XPassWordView xOldPass;
    @BindView(R.id.x_newPass)
    XPassWordView xNewPass;
    @BindView(R.id.x_confirmPass)
    XPassWordView xConfirmPass;
    @BindView(R.id.changer_commit)
    TextView changerCommit;
    String oldPassWord;
    String passWord;
    String confirmPassword;


    public static ChangePassWordFragment getInstance() {
        return new ChangePassWordFragment();
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_change_password;
    }

    @Override
    protected void createProvider() {
        mChangePassWordViewModel = new ViewModelProvider(this).get(ChangePassWordViewModel.class);
        mChangePassWordViewModel.changePassLiveData.observe(this,new SimpleObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                ToastUtils.showLong(ResUtils.getString(R.string.generic_passchange_login));
                MMKVUtil.removeValueForKey(CacheKey.USER_PASSWORD);
                XLiveDataManager.getInstance().loginOut();
                goActivity(LoginActivity.class);
                getActivity().finish();
            }

            @Override
            protected void onError(int code, String errMsg) {
                changeTvWarning.setText(errMsg);
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        new InputResultCalculator(Arrays.asList(xOldPass.getPassEditText(),xNewPass.getPassEditText(),xConfirmPass.getPassEditText()), ok ->{
            changerCommit.setEnabled(ok);
        });


    }




    @OnClick(R.id.changer_commit)
    public void onViewClicked() {
         oldPassWord = xOldPass.getPassText();
         passWord = xNewPass.getPassText();
         confirmPassword = xConfirmPass.getPassText();
         mChangePassWordViewModel.changePassWord(oldPassWord,passWord,confirmPassword);
         KeyboardUtils.hideSoftInput(changerCommit);
    }

    @Override
    public void onStop() {
        super.onStop();
        KeyboardUtils.hideSoftInput(changerCommit);
    }
}
