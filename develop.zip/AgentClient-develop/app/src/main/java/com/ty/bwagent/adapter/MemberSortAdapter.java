package com.ty.bwagent.adapter;

import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.ty.bwagent.R;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;


/**
 * 描述
 * <p> 成员时间排序筛选对话框列表适配器
 * author:Dale
 */
public class MemberSortAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    int postion = 0;

    public MemberSortAdapter() {
        super(R.layout.recycle_item_member_sort);
        ArrayList<String> strings = new ArrayList<>();
        strings.add("按最后登录时间排序");
        strings.add("按钱包余额排序");
        strings.add("按注册时间排序");
        setNewData(strings);
    }

    @Override
    protected void convert(BaseViewHolder helper, String title) {

        TextView textView =  helper.getView(R.id.sort_member_tv_title);

        textView.setText(title);
         if(postion == helper.getAdapterPosition()){
             int normalColor = SiteSdk.ins().styleColor();
             GradientDrawable normalDrawable = new GradientDrawable();
             normalDrawable.setCornerRadius(SizeUtils.sp2px(4));
             normalDrawable.setShape(GradientDrawable.RECTANGLE);
             normalDrawable.setColor(ResUtils.getColor(normalColor));
             textView.setBackground(normalDrawable);
             helper.setTextColor(R.id.sort_member_tv_title,ResUtils.getColor(R.color.white));
         }else {
             helper.setTextColor(R.id.sort_member_tv_title,ResUtils.getColor(R.color.generic_huise));
             helper.setBackgroundRes(R.id.sort_member_tv_title,R.drawable.etittext_select_bg);
         }
    }

    public void setPostion(int postion) {
        this.postion = postion;
        notifyDataSetChanged();
    }
}
