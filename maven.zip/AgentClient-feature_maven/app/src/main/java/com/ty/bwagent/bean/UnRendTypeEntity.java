package com.ty.bwagent.bean;

/**
 * 各类消息具体未读数量
 */
public class UnRendTypeEntity {

    /**
     * activityCount : 0
     * bulletinCount : 0
     * matchCount : 0
     * noticeCount : 1
     */

    private int activityCount;
    private int bulletinCount;
    private int matchCount;
    private int noticeCount;

    public int getActivityCount() {
        return activityCount;
    }

    public void setActivityCount(int activityCount) {
        this.activityCount = activityCount;
    }

    public int getBulletinCount() {
        return bulletinCount;
    }

    public void setBulletinCount(int bulletinCount) {
        this.bulletinCount = bulletinCount;
    }

    public int getMatchCount() {
        return matchCount;
    }

    public void setMatchCount(int matchCount) {
        this.matchCount = matchCount;
    }

    public int getNoticeCount() {
        return noticeCount;
    }

    public void setNoticeCount(int noticeCount) {
        this.noticeCount = noticeCount;
    }
}
