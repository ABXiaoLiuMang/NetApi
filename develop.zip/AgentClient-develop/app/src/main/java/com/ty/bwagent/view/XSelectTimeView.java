package com.ty.bwagent.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.ty.bwagent.R;
import com.ty.pickerview.builder.TimePickerBuilder;
import com.ty.pickerview.view.TimePickerView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.TimeUtils;
import com.ty.utils.ToastUtils;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

/**
 * 成员中（年月日）时间选择封装
 */
public class XSelectTimeView extends LinearLayout implements View.OnClickListener {

    Context mContext;
    TextView start_time;
    TextView end_time;
    TextView search;
    String startTime;
    String endTime;
    OnSearchListener onSearchListener;
    int interval;//初始化间隔天数(默认30天)

    public XSelectTimeView(Context context) {
        this(context, null);
    }

    public XSelectTimeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public XSelectTimeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        TypedArray mTypedArray = mContext.obtainStyledAttributes(attrs, R.styleable.selectTimeView);
        interval = mTypedArray.getInt(R.styleable.selectTimeView_interval,30);
        mTypedArray.recycle();
    }


    public void setOnSearchListener(OnSearchListener onSearchListener) {
        this.onSearchListener = onSearchListener;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        setOrientation(LinearLayout.HORIZONTAL);
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.x_selecttime_layout, this, true);
        start_time = rootView.findViewById(R.id.start_time);
        end_time = rootView.findViewById(R.id.end_time);
        search = rootView.findViewById(R.id.search);
        start_time.setOnClickListener(this);
        end_time.setOnClickListener(this);
        search.setOnClickListener(this);
        startTime = TimeUtils.getDiffDate(-interval);
        endTime = TimeUtils.getDiffDate(0);
        start_time.setText(startTime);
        end_time.setText(endTime);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search:
                if(!daysBetween(startTime, endTime)){
                    return;
                }
                if (onSearchListener != null) {
                    onSearchListener.onSearch(startTime, endTime);
                }
                break;
            case R.id.start_time:
                showStartPickerDialog();
                break;
            case R.id.end_time:
                showEndPickerDialog();
                break;
        }
    }

    public interface OnSearchListener {
        void onSearch(String startTime, String endTime);
    }
    TimePickerView timeStartPickerView;
    private void showStartPickerDialog() {
        if(timeStartPickerView == null){
            //初始化选中时间
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            calendar.add(Calendar.DAY_OF_MONTH, -interval);

            timeStartPickerView = new TimePickerBuilder(getContext(), (date, v) -> {
                String selectTime = TimeUtils.DATE_FORMAT_DATE.format(date);
                start_time.setText(selectTime);
                startTime = selectTime;

            }).setSubmitText("确定")
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setSubmitColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setDate(calendar)
                    .setTitleText("")
                    .build();
        }

        timeStartPickerView.show();
    }

    TimePickerView timeEndPickerView;
    private void showEndPickerDialog() {
        if(timeEndPickerView == null){
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            timeEndPickerView = new TimePickerBuilder(getContext(), (date, v) -> {
                String selectTime = TimeUtils.DATE_FORMAT_DATE.format(date);
                end_time.setText(selectTime);
                endTime = selectTime;

            }).setSubmitText("确定")
                    .setCancelText("取消")
                    .setCancelColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setSubmitColor(ResUtils.getColor(SiteSdk.ins().styleColor()))
                    .setDate(calendar)
                    .setTitleText("")
                    .build();
        }

        timeEndPickerView.show();
    }


    /**
     * 计算时间间隔
     * @return
     */
    private boolean daysBetween(String sTime,String eTime){
        try {
            Date smdate = TimeUtils.DATE_FORMAT_DATE.parse(sTime);
            Date bdate = TimeUtils.DATE_FORMAT_DATE.parse(eTime);
            int between_days = TimeUtils.getIntervalDays2(bdate,smdate);
            if(between_days < 0){
                ToastUtils.showLong("结束时间不能早于开始时间");
                return false;
            }else  if(between_days > 30){
                ToastUtils.showLong("时间跨度不能超过30天");
                return false;
            }else {
                return true;
            }
        }catch (ParseException e){
            return true;
        }

    }

    public void onReset(){
        start_time.setText(TimeUtils.getDiffDate(-interval));
        end_time.setText(TimeUtils.getDiffDate(0));
    }

}
