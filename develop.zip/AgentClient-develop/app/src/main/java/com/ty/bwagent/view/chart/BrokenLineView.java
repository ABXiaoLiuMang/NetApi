package com.ty.bwagent.view.chart;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Scroller;

import com.ty.bwagent.R;
import com.ty.bwagent.bean.DayLowerEntity;
import com.ty.utils.LogUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * 曲线图
 */
public class BrokenLineView extends View {

    //画笔
    private Paint mTextPaint;
    private Paint mBodyPaint;
    private Paint mHorizontalPaint;
    private Paint mBgPaint;

    private DisplayMetrics dm;
    //最大值
    private int maxValue;
    //行数
    private int mLines;
    private ArrayList<String> xRawData;
    private ArrayList<ArrayList<Integer>> mYDatas;

    //圆点半径
    private float mSpotRadius;
    private float mSpotInnerRadius;

    private int mTextHeight;
    private int mLeftTextMaxWidth;
    private int mBottomLastTextWidth;
    private float mDx;
    private float mDy;
    private float mLeftPadding;
    private float mBottomPadding;
    private float mTextSize;
    private Paint.FontMetrics mFontMetrics;

    private boolean mShowGradation;
    private float mTopPadding;
    private float mRightPadding;
    private int mTextColor;
    private int mCurveLineColor;
    private int mHorizontalLineColor;
    private int mTextBgColor;
    private float mX;
    private int mScrollX;
    private VelocityTracker mVelocityTracker;
    private Scroller mScroller;
    private int mDw;

    public BrokenLineView(Context context) {
        this(context, null);
    }

    public BrokenLineView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mScroller = new Scroller(context);
        dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        wm.getDefaultDisplay().getMetrics(dm);
        //取出自定义的属性
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.BrokenLineStyle);

        mLines = typedArray.getInteger(R.styleable.BrokenLineStyle_Lines, 4);
        mSpotRadius = typedArray.getDimension(R.styleable.BrokenLineStyle_SpotRadius, dip2px(3.5f));
        mSpotInnerRadius = typedArray.getDimension(R.styleable.BrokenLineStyle_SpotInnerRadius, dip2px(1.75f));
        mTextSize = typedArray.getDimension(R.styleable.BrokenLineStyle_TextSize, dip2px(11));
        mShowGradation = typedArray.getBoolean(R.styleable.BrokenLineStyle_ShowGradation, true);

        mLeftPadding = typedArray.getDimension(R.styleable.BrokenLineStyle_LeftPadding, dip2px(2));
        mBottomPadding = typedArray.getDimension(R.styleable.BrokenLineStyle_BottomPadding, dip2px(8));
        mTopPadding = typedArray.getDimension(R.styleable.BrokenLineStyle_TopPadding, dip2px(10));
        mRightPadding = typedArray.getDimension(R.styleable.BrokenLineStyle_RightPadding, dip2px(30));

        mTextColor = typedArray.getColor(R.styleable.BrokenLineStyle_TextColor, 0xFFA5A9B3);
        mCurveLineColor = typedArray.getColor(R.styleable.BrokenLineStyle_CurveLineColor, 0xFF158BF4);//折现和点的颜色
        mTextBgColor = typedArray.getColor(R.styleable.BrokenLineStyle_TextBgColor, 0xFF158BF4);//选中字背景颜色
        mHorizontalLineColor = typedArray.getColor(R.styleable.BrokenLineStyle_HorizontalLineColor, 0xFF158BF4);
        typedArray.recycle();

        initView();
    }

    private void initView() {
        this.mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        this.mBodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        this.mBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        this.mHorizontalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        mTextPaint.setTextSize(mTextSize);
        mTextPaint.setColor(mTextColor);
        mFontMetrics = mTextPaint.getFontMetrics();

        mBodyPaint.setStrokeWidth(dip2px(1));
        mBodyPaint.setStyle(Paint.Style.STROKE);
        mBodyPaint.setColor(mCurveLineColor);

        mHorizontalPaint.setStrokeWidth(dip2px(1));
        mHorizontalPaint.setColor(mHorizontalLineColor);

        mBgPaint.setColor(mTextBgColor);
        mBgPaint.setStyle(Paint.Style.FILL);
        mBgPaint.setMaskFilter(new BlurMaskFilter(dip2px(2), BlurMaskFilter.Blur.SOLID));
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int h = MeasureSpec.getSize(heightMeasureSpec);
        int w = (xRawData == null ? 0 : xRawData.size() * 130);
        LogUtils.d("w:" +w);
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (xRawData == null || mYDatas == null) {
            return;
        }
        //计算需要用到的数值
        initData();
        // 画直线（横向）
//        drawAllXLine(canvas);
        // 画直线（纵向）
        drawAllYLine(canvas);
        for (int i = 0; i < mYDatas.size(); i++) {
            ArrayList<Integer> yData = mYDatas.get(i);
            // 获取各个点的坐标
            Point[] points = getPoints(yData);
            if (mShowGradation) {
                //绘制渐变
                drawGradation(canvas, points);
                //绘制曲线
                drawCurve(canvas, points);
            } else {
                //绘制直线
                drawLine(canvas, points);
            }
            //绘制点和其它
            drawSpot(canvas, points, yData, i);

        }
    }

    //绘制点和其它
    private void drawSpot(Canvas canvas, Point[] points, ArrayList<Integer> yData, int index) {

        for (int i = 0; i < points.length; i++) {
//            LogUtils.d("index:" + i +"  x:" + points[i].x +"  y:" + points[i].y);
            mBodyPaint.setStyle(Paint.Style.FILL);
            if(points[i].x == 0){
                points[i].x = 24;
            }
            canvas.drawCircle(points[i].x, points[i].y, mSpotRadius, mBodyPaint);
            int finalI = i;
            float d = dip2px(5);
            Rect rect = new Rect();
            String text = getMoney(yData.get(finalI));//曲线上数字的值
            mTextPaint.getTextBounds(text, 0, text.length(), rect);
            float dx = 0;
            if (points[finalI].x + rect.width() / 2f > getWidth() - d) {
                dx = getWidth() - points[finalI].x - rect.width() / 2f - d * 2;
            }

            if (points[finalI].x - d < rect.width() / 2f) {
                dx = rect.width() / 2f - points[finalI].x + d * 2;
            }
            mTextPaint.setColor(0xff414655);
            canvas.drawText(text, points[finalI].x - rect.width() / 2f + dx, points[finalI].y - rect.height() - d, mTextPaint);
            mTextPaint.setColor(mTextColor);
            mBodyPaint.setColor(0xffffffff);
            canvas.drawCircle(points[finalI].x, points[finalI].y, mSpotInnerRadius, mBodyPaint);
            mBodyPaint.setColor(mCurveLineColor);
        }
        mBodyPaint.setStyle(Paint.Style.STROKE);
    }

    private void initData() {
        double tmp = 0;
        for (ArrayList<Integer> yData : mYDatas) {
            for (Integer aDouble : yData) {
                if (aDouble > tmp) {
                    tmp = aDouble;
                }
            }
        }

        if (tmp >= mLines) {
            int v = (int) (tmp / mLines);
            int length = (v + "").length() - 1;
            int i = (int) ((v / (int) Math.pow(10, length) + 1) * Math.pow(10, length));
            maxValue = i * mLines;
        } else {
            maxValue = mLines;
        }


        Rect rect = new Rect();
        mLeftTextMaxWidth = 0;

        for (int i = 0; i < mLines + 1; i++) {
            String text = getYText(maxValue / mLines * i);
            mTextPaint.getTextBounds(text, 0, text.length(), rect);
            if (mLeftTextMaxWidth < rect.width()) {
                mLeftTextMaxWidth = rect.width();
            }

        }
        mTextHeight = rect.height();

        String text = xRawData.get(xRawData.size() - 1);
        mTextPaint.getTextBounds(text, 0, text.length(), rect);
        mBottomLastTextWidth = rect.width();


        mDx = (getWidth() - getPaddingLeft() - getPaddingRight() - mRightPadding - mLeftPadding - mLeftTextMaxWidth - mBottomLastTextWidth / 2f) / (xRawData.size() - 1);
        mDy = (getHeight() - getPaddingTop() - getPaddingBottom() - mTopPadding - mBottomPadding - mFontMetrics.bottom - mTextHeight * 2) / mLines;
    }


    int mLastX;
    int mLastY;
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
               ViewGroup view = (ViewGroup) getParent();
                view.requestDisallowInterceptTouchEvent(false);
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                int deltaX = x - mLastX;
                int deltaY = y - mLastY;
                if (Math.abs(deltaX) > Math.abs(deltaY)) {
                    ViewGroup view = (ViewGroup) getParent();
                    view.requestDisallowInterceptTouchEvent(true);
                }
                break;
            }
            case MotionEvent.ACTION_UP: {
                break;
            }
            default:
                break;
        }

        mLastX = x;
        mLastY = y;
        return super.dispatchTouchEvent(event);
    }



    @Override
    public boolean onTouchEvent(MotionEvent event) {

        //手指位置地点
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                View parent = (View) getParent();
                mDw = getWidth() - parent.getWidth();
                if (mDw > 0) {
                    mScroller.forceFinished(true);
                    if (mVelocityTracker == null) {
                        mVelocityTracker = VelocityTracker.obtain();
                        mVelocityTracker.addMovement(event);
                    }
                    mScrollX = getScrollX();
                    mX = event.getX();
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (mDw > 0) {
                    mVelocityTracker.addMovement(event);

                    float x = event.getX();
                    int dx = (int) (mX - x + mScrollX);
                    if (dx < 0) {
                        dx = 0;
                    }
                    if (dx > mDw) {
                        dx = mDw;
                    }
                    scrollTo(dx, 0);
                }
                break;
            case MotionEvent.ACTION_UP:
                if (mDw > 0) {
                    mVelocityTracker.addMovement(event);
                    mVelocityTracker.computeCurrentVelocity(1000);
                    int velocityX = (int) mVelocityTracker.getXVelocity();
                    mScroller.fling(getScrollX(), 0, -velocityX, 0, 0, mDw, 0, 0);
                    postInvalidate();
                    if (mVelocityTracker != null) {
                        mVelocityTracker.recycle();
                        mVelocityTracker = null;
                    }
                }
                break;
        }
        return true;
    }

    @Override
    public void computeScroll() {
        // 如果返回true，表示动画还没有结束
        // 因为前面startScroll，所以只有在startScroll完成时 才会为false
        if (mScroller.computeScrollOffset()) {
            // 产生了动画效果 每次滚动一点
            scrollTo(mScroller.getCurrX(), 0);
            //刷新View 否则效果可能有误差
            postInvalidate();
        }
    }

    /**
     * 画所有横向表格，包括X轴
     */
    private void drawAllXLine(Canvas canvas) {
        for (int i = 0; i < mLines + 1; i++) {
            String text = getYText(maxValue / mLines * (mLines - i));
            Rect rect = new Rect();
            mTextPaint.getTextBounds(text, 0, text.length(), rect);

            float ty = rect.height() + mDy * i + getPaddingTop() + mTopPadding;
            canvas.drawText(text, getPaddingLeft() + mLeftTextMaxWidth - rect.width(), ty, mTextPaint);

            //不画横向表格线条
//            float y = ty - mTextHeight / 2f;
//            canvas.drawLine(getPaddingLeft() + mLeftTextMaxWidth + mLeftPadding, y, getWidth() - getPaddingRight() - mRightPadding - mBottomLastTextWidth / 2f, y, mHorizontalPaint);// Y坐标

        }
    }

    /**
     * 画所有纵向表格，包括Y轴
     */

    private void drawAllYLine(Canvas canvas) {

        Rect rect = new Rect();
        for (int i = 0; i < xRawData.size(); i++) {
            mTextPaint.getTextBounds(xRawData.get(i), 0, xRawData.get(i).length(), rect);
            canvas.drawText(xRawData.get(i), getPaddingLeft() + mLeftTextMaxWidth + mLeftPadding + mDx * i - rect.width() / 2f, getHeight() - getPaddingBottom() - mFontMetrics.bottom, mTextPaint);
        }
    }

    //得到路径
    private Path getPath(Point[] points, boolean close) {
        Path path = new Path();
        path.moveTo(points[0].x, points[0].y);

        for (int i = 0; i < points.length - 1; i++) {
            float wt = (points[i].x + points[i + 1].x) / 2f;

            path.cubicTo(wt, points[i].y, wt, points[i + 1].y, points[i + 1].x, points[i + 1].y);
        }
        if (close) {
            float y = getHeight() - mTextHeight * 1.5f - getPaddingBottom() - mFontMetrics.bottom - mBottomPadding;
            path.lineTo(points[points.length - 1].x, y);
            path.lineTo(points[0].x, y);
            path.lineTo(points[0].x, points[0].y);
        }
        return path;
    }

    //绘制曲线
    private void drawCurve(Canvas canvas, Point[] points) {
        Path path = getPath(points, false);
        canvas.drawPath(path, mBodyPaint);
    }

    //绘制渐变
    private void drawGradation(Canvas canvas, Point[] points) {
        Path path = getPath(points, true);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.FILL);
        float y = getHeight() - mTextHeight * 1.5f - getPaddingBottom() - mFontMetrics.bottom - mBottomPadding;
        LinearGradient lg = new LinearGradient(0, y, 0, mTextHeight / 2f + getPaddingTop() + mTopPadding, 0x5eFFFFFF, 0xD9158BF4, Shader.TileMode.MIRROR);
        paint.setShader(lg);
        canvas.drawPath(path, paint);
    }

    //绘制直线
    private void drawLine(Canvas canvas, Point[] points) {
        for (int i = 0; i < points.length - 1; i++) {
            canvas.drawLine(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y, mBodyPaint);
        }
    }

    private Point[] getPoints(ArrayList<Integer> yRawData) {
        Point[] points = new Point[yRawData.size()];
        for (int i = 0; i < yRawData.size(); i++) {
            points[i] = new Point((int) (getPaddingLeft() + mLeftTextMaxWidth + mLeftPadding + mDx * i + 0.5), (int) (mTextHeight / 2f + (mLines - (yRawData.get(i) / (maxValue / mLines))) * mDy + 0.5 + getPaddingTop() + mTopPadding));
        }
        return points;
    }



    public void initViewDatas(ArrayList<String> initxDatas,ArrayList<Integer> initYDatas) {
        if(xRawData == null){
            xRawData =  new ArrayList<>();
        }
        xRawData.clear();

        if(mYDatas == null){
            mYDatas = new ArrayList<>();
        }

        mYDatas.clear();
        xRawData.addAll(initxDatas);
        mYDatas.add(initYDatas);
        requestLayout();
    }


    private String getMoney(int num) {

        DecimalFormat formater = new DecimalFormat("#0");
        formater.setRoundingMode(RoundingMode.FLOOR);


        if (num >= 100000000) {
            return formater.format(num / 100000000);
        }
        if (num >= 10000) {
            return formater.format(num / 10000);
        }
        return formater.format(num);
    }

    private String getYText(int num) {

        DecimalFormat formater = new DecimalFormat("#0");
        formater.setRoundingMode(RoundingMode.FLOOR);

        if (num >= 100000000) {
            return formater.format(num / 100000000) + "E";
        }
        if (num >= 10000) {
            return formater.format(num / 10000) + "W";
        }
        if (num >= 1000) {
            return formater.format(num / 1000) + "k";
        }
        return formater.format(num);
    }

    /**
     * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    private float dip2px(float dpValue) {
        return dpValue * dm.density;
    }
}
