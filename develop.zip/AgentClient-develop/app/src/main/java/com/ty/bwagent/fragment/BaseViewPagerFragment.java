package com.ty.bwagent.fragment;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.ty.bwagent.R;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.TitleBar;
import com.ty.common.view.magicindicator.MagicIndicator;
import com.ty.common.view.magicindicator.ViewPagerHelper;
import com.ty.common.view.magicindicator.buildins.commonnavigator.CommonNavigator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.ColorTransitionPagerTitleView;
import com.ty.common.view.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;
import com.ty.utils.SizeUtils;

import java.util.ArrayList;

import butterknife.BindView;


/**
 * 封装解决viewpager滑动内存泄漏问题
 */
public abstract class BaseViewPagerFragment extends ABBaseFragment {

    @BindView(R.id.magicIndicator)
    protected MagicIndicator magicIndicator;
    @BindView(R.id.viewPager)
    protected ViewPager viewPager;
    @BindView(R.id.titleBar)
    protected TitleBar titleBar;
    protected String[] tabTitles;

    public abstract Fragment getCurrentItem(int position);

    public abstract String[] getTabTitles();



    @Override
    protected void initViewsAndEvents() {
        if(isNeedIniteIndicatoer()){
            tabTitles = getTabTitles();
            initMagicIndicator();
        }
    }

    //有的时候要请求接口返回tabTitle 就不能一进来就调用
    public boolean isNeedIniteIndicatoer(){
        return true;
    }


    protected void initMagicIndicator() {
        ViewPagerFragmentAdapter adapter = new ViewPagerFragmentAdapter(getChildFragmentManager());
        viewPager.setAdapter(adapter);
        CommonNavigator commonNavigator = new CommonNavigator(mContext);
        commonNavigator.setAdapter(getNavigatorAdapter());
        commonNavigator.setAdjustMode(getAdjustMode());
        magicIndicator.setNavigator(commonNavigator);
        ViewPagerHelper.bind(magicIndicator, viewPager);
    }

    protected boolean getAdjustMode() {
        return true;
    }


    protected CommonNavigatorAdapter getNavigatorAdapter() {
        CommonNavigatorAdapter mAdapter = new CommonNavigatorAdapter() {
            @Override
            public int getCount() {
                return tabTitles.length;
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                SimplePagerTitleView simplePagerTitleView = new ColorTransitionPagerTitleView(context);
                simplePagerTitleView.setNormalColor(ResUtils.getColor(R.color.generic_huise));
                simplePagerTitleView.setSelectedColor(ResUtils.getColor(R.color.black));
                simplePagerTitleView.setText(tabTitles[index]);
                simplePagerTitleView.setOnClickListener(v -> viewPager.setCurrentItem(index));
                return simplePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator linePagerIndicator = new LinePagerIndicator(context);
                linePagerIndicator.setMode(LinePagerIndicator.MODE_WRAP_CONTENT);
                linePagerIndicator.setLineHeight(SizeUtils.dp2px(2));
                linePagerIndicator.setLineWidth(SizeUtils.dp2px(44));
                linePagerIndicator.setRoundRadius(SizeUtils.dp2px(1));
                linePagerIndicator.setColors(ResUtils.getColor(SiteSdk.ins().styleColor()));
                return linePagerIndicator;
            }
        };
        return mAdapter;
    }


    class ViewPagerFragmentAdapter extends FragmentStatePagerAdapter {

        public ViewPagerFragmentAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int position) {
            return  getCurrentItem(position);
        }

        @Override
        public int getCount() {
            return tabTitles.length;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            return super.instantiateItem(container, position);
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            super.destroyItem(container, position, object);
        }
    }

}