package com.ty.bwagent.utils;

import com.ty.bwagent.bean.UserInfo;
import com.ty.net.utils.JsonUtils;
import com.ty.utils.MMKVUtil;

public class UserInfoCache {
    private static volatile UserInfoCache instance = null;

    UserInfo userInfo;

    public static UserInfoCache getInstance() {
        if (instance == null) {
            synchronized (UserInfoCache.class) {
                if (instance == null) {
                    instance = new UserInfoCache();
                }
            }
        }
        return instance;
    }

    private UserInfoCache() {
    }

    public UserInfo getUserInfo() {
        if (userInfo == null) {
            userInfo = JsonUtils.fromJson(MMKVUtil.getString(CacheKey.ACCOUNT_INFO), UserInfo.class);
        }
        return userInfo;
    }

    public void saveUserInfo(UserInfo userInfo) {
        String json = JsonUtils.toJson(userInfo);
        MMKVUtil.put(CacheKey.ACCOUNT_INFO, json);
    }

    public void cleanUserInfo() {
        MMKVUtil.put(CacheKey.ACCOUNT_INFO, "");
        userInfo = null;
    }

}
