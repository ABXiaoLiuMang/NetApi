package com.ty.bwagent.utils;

import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.dialog.MemberTipPopup;
import com.ty.tysite.SiteSdk;
import com.ty.utils.ResUtils;

public class DialogUtil {


    /**
     * 成员中右上角提示弹窗
     * @param mContext
     */
    public static void showMemberTipsDialog(Context mContext){
        MemberTipPopup confirmPopupView = new MemberTipPopup(mContext);
        confirmPopupView.setTitleContent("温馨提示",ResUtils.getString(R.string.generic_member_tips),"")
                .setConfirmText("我知道了")
                .hideCancelBtn()
                .setConfirmTextColor(SiteSdk.ins().styleColor());
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
    }

    /**
     * 佣金中右上角提示弹窗
     * @param mContext
     */
    public static void showFinanceTipsDialog(Context mContext){
        MemberTipPopup confirmPopupView = new MemberTipPopup(mContext);
        confirmPopupView.bindLayout(R.layout.custom_dialog_member_center)
                .setTitleContent("温馨提示",ResUtils.getString(R.string.generic_finance_tips),"")
                .setConfirmText("我知道了")
                .hideCancelBtn()
                .setConfirmTextColor(SiteSdk.ins().styleColor());
        new XPopup.Builder(mContext)
                .asCustom(confirmPopupView)
                .show();
    }
}
