package com.ty.bwagent.bean

data class ProInfoEntity(
    val code: Int,
    val `data`: Data,
    val errorSn: String,
    val msg: String
)

data class Data(
    val SiteBaseConfigVo: SiteBaseConfigVo,
    val maintainConfig: MaintainConfig,
    val address: String,
    val ip: String
)

data class SiteBaseConfigVo(
    val agentAppDomainUrl: String,
    val agentPcDomainUrl: String,
    val agentQq: String,
    val agentSkype: String,
    val agentSugram: String,
    val appChessDomailUrl: String,
    val appLotteryDomailUrl: String,
    val appPersonDomailUrl: String,
    val appSportDomailUrl: String,
    val baseInfo: List<BaseInfo>,
    val baseInfos: String,
    val categories: String,
    val customerService: String,
    val h5DomainUrl: String,
    val mobileService: String,
    val name: String,
    val pcDomainUrl: String,
    val siteDomainUrl: String,
    val siteLogoUrl: String,
    val sportAppDomainUrl: String,
    val submitMoreUnorde: Int,
    val title: String,
    val webAppUrl: String,
    val webClip: String,
    val webLogoTitleUrl: String,
    val webLogoUrl: String,
    val whiteDomain: String
)

data class MaintainConfig(
    val maintainEndAt: String,
    val maintainStartAt: String,
    val platformChName: String,
    val platformEnName: String,
    val platformType: Any,
    val remark: String,
    val siteId: Any,
    val status: Int
)

data class BaseInfo(
    val baseFlag: String,
    val deviceNum: String,
    val deviceText: String,
    val deviceType: String,
    val imageUrl: String,
    val isEnable: String,
    val linkUrl: String,
    val sort: String
)