package com.ty.bwagent.fragment.finance.fragment

import android.text.InputFilter
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.ty.bwagent.R
import com.ty.bwagent.bean.BaseEntity
import com.ty.bwagent.bean.SchemeSetCommissionEntity
import com.ty.bwagent.utils.EditRateInputFilter
import com.ty.bwagent.utils.Utils
import com.ty.bwagent.viewmodel.SchemeSetViewModle
import com.ty.common.ui.ABBaseFragment
import com.ty.net.callback.NetObserver
import com.ty.utils.ToastUtils
import kotlinx.android.synthetic.main.frag_finace_rate.*
import kotlinx.android.synthetic.main.layout_no_net.*

/**
 *佣金比例详情
 */
class FinanceRateDetailFragment : ABBaseFragment() {

    private lateinit var schemeSetViewModle: SchemeSetViewModle;

    override fun getLayoutId(): Int {
        return R.layout.frag_finace_rate;
    }

    override fun initViewsAndEvents() {
        showProgressDialog()
        schemeSetViewModle.myCommission();
        bnt_nonet.setOnClickListener {
            schemeSetViewModle.myCommission()
        }
    }

    override fun createProvider() {
        schemeSetViewModle = ViewModelProvider(this).get(SchemeSetViewModle::class.java)

        //返佣-我的方案
        schemeSetViewModle.commissionLivaData.observe(this, object : NetObserver<BaseEntity<List<SchemeSetCommissionEntity>>>() {

            override fun onLoading(show: Boolean) {
                super.onLoading(show)
                if (show) showProgressDialog() else dismissProgressDialog()
            }

            override fun onSuccess(listBaseEntity: BaseEntity<List<SchemeSetCommissionEntity>>?) {

                listBaseEntity?.data?.get(0)?.let {
                    setDate(it)
                }

                if (ll_net != null) {
                    ll_net.visibility = View.GONE
                    ll_content.visibility = View.VISIBLE
                }
            }

            override fun onError(code: Int, errMsg: String) {
                ToastUtils.showToast(errMsg)
                if (ll_net != null) {
                    ll_net.visibility = View.VISIBLE
                    ll_content.visibility = View.GONE
                }
            }
        })
    }


    //设置设置数据
    private fun setDate(commissionEntities: SchemeSetCommissionEntity) {
        if (ll_content.childCount > 1) {
            ll_content.removeViews(1, ll_content.childCount - 1)
        }
        for (i in 0 until commissionEntities.rebateDetail.size) {
            setItemView(commissionEntities, i)
        }
    }

    //列表Item的展示
    private fun setItemView(commissionEntities: SchemeSetCommissionEntity, i: Int) {
        try {
            commissionEntities.rebateDetail[i]?.let {
                val rootView = LayoutInflater.from(context).inflate(R.layout.item_commite_scheme, null)
                ll_content.addView(rootView)

                val etInput = rootView.findViewById<EditText>(R.id.et_input)
                val tvName = rootView.findViewById<TextView>(R.id.tv_name)
                val tvProfit = rootView.findViewById<TextView>(R.id.tv_profit)
                tvName.text = it.name
                tvProfit.text = "≥" + Utils.fmtMicrometer(it.profit.toString() + "")
                etInput.setText(it.rate)

                rootView.layoutParams.height = resources.getDimension(R.dimen.dp_50).toInt()

                //item背景颜色修改
                if (i == commissionEntities.rebateDetail.size - 1) {
                    if (i % 2 == 1) {
                        rootView.background = ContextCompat.getDrawable(mContext, R.drawable.finance_buttom_corners_x_bg)
                    } else {
                        rootView.background = ContextCompat.getDrawable(mContext, R.drawable.finance_buttom_corners_w_bg)
                    }
                } else if (i % 2 == 1) {
                    rootView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.x_window_color))
                } else {
                    rootView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.white))
                }
                //输入的正则匹配
                val filters = arrayOf<InputFilter>(EditRateInputFilter().setMaxValue(java.lang.Double.parseDouble(it.rate)))
                etInput.filters = filters
                etInput.isEnabled = false
                etInput.setBackgroundColor(ContextCompat.getColor(mContext, R.color.transparent))
            }
        } catch (e: Exception) {

        }

    }
}