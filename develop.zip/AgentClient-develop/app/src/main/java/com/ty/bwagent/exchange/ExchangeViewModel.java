package com.ty.bwagent.exchange;

import androidx.lifecycle.ViewModel;

import com.ty.net.bean.NetLiveData;

import java.util.Map;

public class ExchangeViewModel extends ViewModel {

    String baseUrl = "http://free.currencyconverterapi.com/";

    public NetLiveData<ExchangeEntity> exchangeLiveData = new NetLiveData<>();

//    //联系我们
//    public void getExchange(String q){
//        NetSdk.create(Api.class)
//                .getExchange()
//                .baseUrl(baseUrl)
//                .params("q", q)
//                .params("compact", "y")
//                .send(exchangeLiveData);
//    }


    public void exChange(String key, Map<String, String> rateMap,boolean isOnline) {
//        if (TextUtils.isEmpty(rateMap.get(key))) {
//            connect(key);
//        } else if (isOnline) {
//            connect(key);
//        } else{
//            onRate(key, rateMap.get(key));
//        }
    }



    private void connect(String key) {

//                NetSdk.create(Api.class)
//                .getExchange()
//                .baseUrl(baseUrl)
//                .params("q", key)
//                .params("compact", "y")
//                .send(exchangeLiveData);


//        ExchangeSource.convert(key)
//                .showLoaddingDialog("")
//                .isSingleEnable(true)
//                .send(new OnCallBack<Map<String, Object>>() {
//                    @Override
//                    public void success(Request<Map<String, Object>> request,
//                                        Map<String, Object> stringObjectMap) {
//                        try {
//                            if (stringObjectMap != null) {
//                                LogUtils.i(stringObjectMap);
//                                for (String key : stringObjectMap.keySet()) {
//                                    LinkedTreeMap value = (LinkedTreeMap) stringObjectMap.get(key);
//                                    Rate rate = JsonUtil.fromJson(JsonUtil.toJsonTree(value), Rate.class);
//                                    LogUtils.i("key : %s ,汇率: %s", key, rate.getVal());
//                                    BigDecimal decimal = new BigDecimal(rate.getVal())
//                                            .setScale(2, RoundingMode.HALF_UP);
//                                    if (getView() != null) {
//                                        getView().onRate(key, decimal.toPlainString());
//                                    }
//                                }
//                            }
//                        } catch (Exception e) {
////                            LogUtils.e(e);
//                        }
//
//                    }
//
//                    @Override
//                    public void error(Request<Map<String, Object>> request,
//                                      ErrorMessage errorMessage, Map<String, Object> stringObjectMap) {
////                        LogUtils.e(errorMessage.getError());
//                        try {
//                            if (stringObjectMap != null) {
//                                LogUtils.i(stringObjectMap);
//                                for (String key : stringObjectMap.keySet()) {
//                                    LinkedTreeMap value = (LinkedTreeMap) stringObjectMap.get(key);
//                                    Rate rate = JsonUtil.fromJson(JsonUtil.toJsonTree(value), Rate.class);
//                                    LogUtils.i("key : %s ,汇率: %s", key, rate.getVal());
//                                    BigDecimal decimal = new BigDecimal(rate.getVal())
//                                            .setScale(2, RoundingMode.HALF_UP);
//                                    if (getView() != null) {
//                                        getView().onRate(key, decimal.toPlainString());
//                                    }
//                                }
//                            }
//                        } catch (Exception e) {
////                            LogUtils.e(e);
//                        }
//                    }
//                });
    }
}
