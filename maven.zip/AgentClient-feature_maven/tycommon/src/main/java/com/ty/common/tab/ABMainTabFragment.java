package com.ty.common.tab;


import android.content.res.ColorStateList;
import android.view.View;

import androidx.annotation.ColorRes;
import androidx.collection.ArrayMap;

import com.ty.common.R;
import com.ty.common.ui.ABBaseFragment;
import com.ty.common.view.magicindicator.FragmentContainerHelper;
import com.ty.common.view.magicindicator.MagicIndicator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.CommonNavigator;
import com.ty.common.view.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import com.ty.utils.LogUtils;


/**
 * create by Dale
 * create on 2019/5/30
 * description: Tab 基类
 */
public abstract class ABMainTabFragment extends ABBaseFragment implements TabAdapter.OnTabClickListener {
    TabAdapter commonAdapter;
    FragmentContainerHelper tabHelper = new FragmentContainerHelper();
    MagicIndicator mainTabView;
    MainTab[] mainTabs;
    ABBaseFragment[] fragments;
    ArrayMap<Integer, ABBaseFragment> supportFragments;
    protected int currentIndex = 0;

    protected abstract MainTab[] getMainTabs();

    protected abstract ABBaseFragment[] getFragments();

    protected abstract ColorStateList getTextColor();

    @Override
    protected int getLayoutId() {
        return R.layout.x_activity_tab_main;
    }

    @Override
    protected void initViewsAndEvents() {
        mainTabView = rootView.findViewById(R.id.mainTabView);
        mainTabs = getMainTabs();
        fragments = getFragments();
        supportFragments = new ArrayMap<>(mainTabs.length);
        showFragment(0);
        initMagicIndicators();
    }

    private void initMagicIndicators() {
        CommonNavigator commonNavigator = new CommonNavigator(mContext);
        commonNavigator.setAdjustMode(true);
        commonAdapter = new TabAdapter(mContext, mainTabs);
        commonAdapter.setTextColor(getTextColor());
        commonAdapter.setTabClickListener(this);
        commonNavigator.setAdapter(commonAdapter);
        mainTabView.setNavigator(commonNavigator);
        tabHelper.attachMagicIndicator(mainTabView);
        tabHelper.handlePageSelected(currentIndex, false);
    }

    @Override
    public void onClick(CommonNavigatorAdapter adapter, View view, int postion) {
        selectFragment(postion);
    }

    public void selectFragment(int postion) {
        if (postion == currentIndex) {
            return;
        }
        currentIndex = postion;
        showFragment(postion);
        tabHelper.handlePageSelected(currentIndex, false);
    }


    private void showFragment(Integer index) {
        ABBaseFragment fragment;
        if(supportFragments.containsKey(index)){
            fragment = supportFragments.get(index);
            showHideFragment(fragment);
        }else {
            fragment = fragments[index];
            supportFragments.put(index,fragment);
            loadMultipleRootFragment(R.id.fragment_content, 0, fragment);
        }
    }
}
