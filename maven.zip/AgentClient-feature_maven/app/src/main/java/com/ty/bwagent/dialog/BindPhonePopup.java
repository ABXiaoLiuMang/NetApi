package com.ty.bwagent.dialog;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupAnimation;
import com.lxj.xpopup.impl.ConfirmPopupView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.bwagent.utils.UserInfoCache;
import com.ty.bwagent.utils.VerifyUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.viewmodel.BindViewModel;
import com.ty.common.util.AlphaAnimator;
import com.ty.net.callback.NetObserver;
import com.ty.tysite.view.LoadingPopView;
import com.ty.utils.InputResultCalculator;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;
import com.ty.utils.ToastUtils;
import com.ty.view.ClearEditText;

import java.util.Arrays;

/**
 * 绑定电话弹窗
 */
public class BindPhonePopup extends ConfirmPopupView {

    ClearEditText et_input_code;
    ClearEditText et_input;
    TextView btn_getCode;//获取验证码
    String bindText;//输入框内容（可能是邮箱或者电话）
    BindViewModel bindViewModel;
    BasePopupView progressDialog;
    Fragment fragment;
    boolean timerStart = false;//倒计时是否开始

    public BindPhonePopup(Fragment fragment) {
        super(fragment.getContext());
        this.fragment = fragment;
        this.title = "绑定手机号";
        bindViewModel = new BindViewModel();
    }


    @Override
    protected int getImplLayoutId() {
        return R.layout.custom_dialog_bindphone;
    }

    @Override
    protected void initPopupContent() {
        super.initPopupContent();
        et_input_code = findViewById(R.id.et_input_code);
        et_input = findViewById(R.id.et_input);
        btn_getCode = findViewById(R.id.btn_bind);


        btn_getCode.setOnClickListener(v -> {
            bindText = et_input.getText().toString().trim();
            bindViewModel.getPhoneCode(bindText);
        });
        setListener(() -> {

            bindText = et_input.getText().toString().trim();
            String verifyCode = et_input_code.getText().toString().trim();
            tv_content.setText("");
            bindViewModel.bindPhone(bindText,verifyCode);

        },null);
        initViewsAndEvents();

    }

    /**
     * 一系列监听回调
     */
    private void initViewsAndEvents(){
        //监听验证码
        bindViewModel.codeLivedata.observeForever(new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if(baseEntity ==null){
                    return;
                }
                bindViewModel.startTimer(null);
            }
            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }
            @Override
            protected void onError(int code, String errMsg) {
                tv_content.setText(errMsg);
            }
        });

        //监听绑定结果
        bindViewModel.bindLiveData.observeForever(new NetObserver<BaseEntity>(){
            @Override
            protected void onSuccess(BaseEntity baseEntity) {
                if(baseEntity != null){
                    ToastUtils.showLong("绑定成功");
                    UserInfo userInfo = UserInfoCache.getInstance().getUserInfo();
                    userInfo.setPhone(bindText);
                    UserInfoCache.getInstance().saveUserInfo(userInfo);
                    XLiveDataManager.getInstance().userInfo.postNext(userInfo);
                }
                dismiss();
            }

            @Override
            protected void onLoading(boolean show) {
                if(show){
                    showProgressDialog();
                }else {
                    dismissProgressDialog();
                }
            }

            @Override
            protected void onError(int code, String errMsg) {
                tv_content.setText(errMsg);
                tv_content.setVisibility(View.VISIBLE);
            }

        });

        //验证码倒计时
        bindViewModel.timerLiveData.observeForever(aLong -> {
            if(aLong == 0){
                timerStart = false;
                btn_getCode.setText(ResUtils.getString(R.string.generic_reset_code));
                btn_getCode.setEnabled(true);
            }else {
                timerStart = true;
                btn_getCode.setText(StringUtils.getFormatString(ResUtils.getString(R.string.generic_down_time),aLong));
                btn_getCode.setEnabled(false);
            }
        });
        onVerification();
    }

    @Override
    public void dismiss() {
        bindViewModel.timerLiveData.removeObservers(fragment);
        bindViewModel.codeLivedata.removeObservers(fragment);
        bindViewModel.bindLiveData.removeObservers(fragment);
        bindViewModel.cancelTimer();
        super.dismiss();
    }


    private void showProgressDialog() {
        if (progressDialog == null) {
            LoadingPopView dialog = new LoadingPopView(fragment.getContext());
            progressDialog = new XPopup.Builder(fragment.getContext())
                    .isRequestFocus(false)  //loading不要焦点
                    .hasShadowBg(false)
                    .customAnimator(new AlphaAnimator(dialog.getPopupContentView(), PopupAnimation.ScaleAlphaFromCenter))
                    .dismissOnBackPressed(false)
                    .dismissOnTouchOutside(true)
                    .asCustom(dialog);
        }
        progressDialog.show();
    }

    private void dismissProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    /**
     * 验证输入
     */
    private void onVerification(){
        new InputResultCalculator(Arrays.asList(et_input), ok -> {
            if(timerStart){
                btn_getCode.setEnabled(false);
                return;
            }

            String inputText = et_input.getText().toString().trim();
            if(!ParameterVerification.isPhoneNumber(inputText)){
                btn_getCode.setEnabled(false);
                return;
            }
            btn_getCode.setEnabled(ok);
        });
        verifyPhone(et_input,tv_content);
        VerifyUtils.verifyCode(et_input_code,tv_content);
        et_input.setWarnTv(tv_content);
    }


    /**
     * 电话号码验证
     * @param etPhone 密码输入框
     * @param tvWarn 提示文案控件
     */
    private void verifyPhone(EditText etPhone, TextView tvWarn){
        etPhone.setOnFocusChangeListener((v, hasFocus) -> {
            String phone;

            if(hasFocus){//获的焦点
                tvWarn.setText("");
            }else {//失去焦点
                phone = etPhone.getText().toString().trim();
                if (!ParameterVerification.isPhoneNumber(phone) && StringUtils.length(phone) > 0) {
                    tvWarn.setText(ResUtils.getString(R.string.generic_phone_warn));
                }
            }
        });
    }
}
