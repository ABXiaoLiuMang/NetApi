package com.ty.bwagent.utils;

import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;

import com.ty.utils.ToastUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * https://blog.csdn.net/wuyinlei/article/details/78631043
 *
 * @function 方案设置的返佣返水方案的设置   用于过滤输入   防止输入大于maxValue还有就是限制小数点之后两位
 */

public class EditRateInputFilter implements InputFilter {

    /**
     * 最大数字
     */
    public double maxValue = 500;

    /**
     * 小数点后的数字的位数
     */
    public int pointerLength = 2;

    private static final String POINTER = ".";

    Pattern p;

    public EditRateInputFilter() {
        //用于匹配输入的是0-9  .  这几个数字和字符
        p = Pattern.compile("([0-9]|\\.)*");
    }


    /**
     * 设置小数点几位
     *
     * @param pointerLength
     * @return
     */
    public EditRateInputFilter setPointerLength(int pointerLength) {
        this.pointerLength = pointerLength;
        return this;
    }

    /**
     * 设置最大的比例数
     *
     * @param maxValue
     */
    public EditRateInputFilter setMaxValue(double maxValue) {
        this.maxValue = maxValue;
        return this;
    }

    /**
     * source    新输入的字符串
     * start    新输入的字符串起始下标，一般为0
     * end    新输入的字符串终点下标，一般为source长度-1
     * dest    输入之前文本框内容
     * dstart    原内容起始坐标，一般为0
     * dend    原内容终点坐标，一般为dest长度-1
     */

    @Override
    public CharSequence filter(CharSequence source, int start, int end,
                               Spanned dest, int dstart, int dend) {

        String sourceText = source.toString();
        String destText = dest.toString();
        //验证删除等按键
        if (TextUtils.isEmpty(sourceText)) {
            if (dstart == 0 && destText.indexOf(POINTER) == 1) {//保证小数点不在第一个位置
                return "0";
            }
            return "";
        }
        Matcher matcher = p.matcher(source);
        //已经输入小数点的情况下，只能输入数字
        if (destText.contains(POINTER)) {
            if (!matcher.matches()) {
                return "";
            } else {
                if (POINTER.equals(source)) { //只能输入一个小数点
                    return "";
                }
            }
            //验证小数点精度，保证小数点后只能输入两位
            int index = destText.indexOf(POINTER);
            int length = destText.trim().length() - index;
            if (length > pointerLength && dstart > index) {
                return "";
            }
        } else {
            //没有输入小数点的情况下，只能输入小数点和数字，但首位不能输入小数点和0
            if (!matcher.matches()) {
                return "";
            } else {
                if ((POINTER.equals(source)) && dstart == 0) {//第一个位置输入小数点的情况
                    return "0.";
                }
//                else if ("0".equals(source) && dstart == 0) {
//                    //用于修复能输入多位0
//                    return "";
//                }
            }
        }
//        dstart
        //修复当光标定位到第一位的时候 还能输入其他的    这个是为了修复以下的情况
        String first = destText.substring(0, dstart);

        String second = destText.substring(dstart, destText.length());
        String sum = first + sourceText + second;

        double sumText = Double.parseDouble(sum);

        if (!isNumber(sum)) {
            return dest.subSequence(dstart, dend);
        }

        //这里得到输入完之后需要计算的金额  如果这个金额大于了事先设定的金额,那么久直接返回  不需要加入输入的字符
        if (sumText > maxValue) {
            ToastUtils.showToast("请输入0~" + maxValue + "之间的数字");
            return dest.subSequence(dstart, dend);
        }
        //如果输入的金额小于事先规定的金额
        return dest.subSequence(dstart, dend) + sourceText;
    }

    /**
     * 判断是不是正确的数字
     *
     * @param str
     * @return
     */
    public boolean isNumber(String str) {
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("^(([1-9]{1}\\d*)|([0]{1}))(\\.(\\d){0," + pointerLength + "})?$"); // 判断小数点后几位位的数字的正则表达式
        java.util.regex.Matcher match = pattern.matcher(str);
        if (match.matches() == false) {
            return false;
        } else {
            return true;
        }
    }
}
