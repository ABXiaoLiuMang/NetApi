package com.ty.bwagent.fragment.finance.bean;

/**
 * 描述:  账户调整月度明细
 * <p>
 * author:Dale
 */
public class FinanceAccount {

    /**
     * category : 红利补发
     * money : 0.0
     */

    private String category;//分类 1 typay, 2: 后台手动上分 , 3 佣金钱包转入充值
    private double money;//金额

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }
}
