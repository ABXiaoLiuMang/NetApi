package com.ty.common.util;

import android.view.View;
import android.view.animation.LinearInterpolator;

import com.lxj.xpopup.animator.PopupAnimator;
import com.lxj.xpopup.enums.PopupAnimation;

public class AlphaAnimator extends PopupAnimator {
    public AlphaAnimator(View target, PopupAnimation popupAnimation) {
        super(target, popupAnimation);
    }

    @Override
    public void initAnimator() {
        targetView.setAlpha(0);
    }

    @Override
    public void animateShow() {
        targetView.setAlpha(0);
        targetView.animate().alpha(1f)
                .setDuration(500)
                .setInterpolator(new LinearInterpolator())
                .start();
    }

    @Override
    public void animateDismiss() {
        targetView.animate().alpha(0f).setDuration(500)
                .setInterpolator(new LinearInterpolator())
                .start();
    }

}