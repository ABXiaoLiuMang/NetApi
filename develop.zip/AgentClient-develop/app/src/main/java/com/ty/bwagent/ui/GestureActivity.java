package com.ty.bwagent.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import com.ty.bwagent.R;
import com.ty.bwagent.bean.Data;
import com.ty.bwagent.bean.ProInfoEntity;
import com.ty.bwagent.exchange.ExchangeActivity;
import com.ty.bwagent.utils.CacheKey;
import com.ty.bwagent.utils.GoUtils;
import com.ty.bwagent.utils.XLiveDataManager;
import com.ty.bwagent.view.lock.LockPatternIndicator;
import com.ty.bwagent.view.lock.LockPatternUtil;
import com.ty.bwagent.view.lock.LockPatternView;
import com.ty.bwagent.viewmodel.SystemModel;
import com.ty.common.ui.ABBaseActivity;
import com.ty.common.util.ABConfig;
import com.ty.common.view.TitleBar;
import com.ty.net.callback.SimpleObserver;
import com.ty.net.utils.JsonUtils;
import com.ty.utils.ExitUtils;
import com.ty.utils.MMKVUtil;
import com.ty.utils.ResUtils;
import com.ty.utils.ToastUtils;
import com.ty.utils.TopActivityManager;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class GestureActivity extends ABBaseActivity {

    @BindView(R.id.xTitle)
    TitleBar xTitle;
    @BindView(R.id.lockPatterIndicator)
    LockPatternIndicator lockPatterIndicator;
    @BindView(R.id.lockPatternView)
    LockPatternView lockPatternView;
    @BindView(R.id.tvreset)
    TextView tvreset;
    @BindView(R.id.messageTv)
    TextView messageTv;
    Status currentStatus;


    private byte [] mLoginPattern = null;//登录之前保存密码

    boolean isGoFinish;// ture：结束当前界面(无逻辑判断等)，false : 也结束当前界面，有跳转登录判断
    boolean processFirst;//ture：需要判断第一次挂警告的处理，false:忽略警告处理
    int code = -1;


    /**
     * 启动activity
     * @param isGoFinish  ture：结束当前界面(无逻辑判断等)，false : 也结束当前界面，有跳转登录判断
     * @param processFirst ture：需要判断第一次挂警告的处理，false:忽略警告处理
     */
    public static void startGestureActivity(boolean isGoFinish,boolean processFirst){
        Activity activity = TopActivityManager.getInstance().getCurActivity();
        Bundle bundle = new Bundle();
        bundle.putBoolean(ABConfig.KEY_TAG,isGoFinish);
        bundle.putBoolean(ABConfig.KEY_OBJECT,processFirst);
        Intent intent = new Intent();
        intent.setClass(activity, GestureActivity.class);
        intent.putExtras(bundle);
        activity.startActivity(intent);
        activity.overridePendingTransition(com.ty.common.R.anim.x_push_left_in, com.ty.common.R.anim.x_push_left_out);
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_set_gesture;
    }

    @Override
    protected void createProvider() {
        isGoFinish = bundle.getBoolean(ABConfig.KEY_TAG,false);
        processFirst = bundle.getBoolean(ABConfig.KEY_OBJECT,false);

        XLiveDataManager.getInstance().proInfoLiveData.observe(this,new SimpleObserver<ProInfoEntity>(){
            @Override
            protected void onSuccess(ProInfoEntity proInfoEntity) {
                if(proInfoEntity != null && proInfoEntity.getData() != null){
                    Data dataBean =  proInfoEntity.getData();
                    if(dataBean.getMaintainConfig().getStatus() == 0){
                        code = 10401;
                    }else if(proInfoEntity.getCode() == 10402){
                        code = 10402;
                    }else if(proInfoEntity.getCode() == 10403 && processFirst){
                        code = 10403;
                    }
                }
            }
        });
    }

    @Override
    protected void initViewsAndEvents() {
        mLoginPattern = MMKVUtil.decodeBytes(CacheKey.GUSTURE_PASSWORD);
        if(mLoginPattern == null){//第一次绘制
            currentStatus = Status.DEFAULT;
            xTitle.setTiteTextView("绘制手势密码");
        }else{//设置过登录
            currentStatus = Status.LOGIN;
            tvreset.setVisibility(View.VISIBLE);
            xTitle.setTiteTextView("解锁图案");
        }
        setGestureText(currentStatus);
        lockPatternView.setOnPatternListener(patternListener);


        tvreset.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG); //下划线
        tvreset.getPaint().setAntiAlias(true);//抗锯齿
    }

    @OnClick(R.id.tvreset)
    public void onViewClicked() {
        tvreset.setVisibility(View.GONE);
        MMKVUtil.removeValueForKey(CacheKey.GUSTURE_PASSWORD);
        resetLockPattern();
    }

    LockPatternView.OnPatternListener patternListener = new LockPatternView.OnPatternListener() {
        @Override
        public void onPatternStart() {
            lockPatternView.removePostClearPatternRunnable();
            lockPatternView.setPattern(LockPatternView.DisplayMode.DEFAULT);
            if(mLoginPattern == null){//没有登录过（之前没有设置过密码）
                messageTv.setTextColor(ResUtils.getColor(R.color.color_414655));
                messageTv.setText(ResUtils.getString(R.string.create_gesture_default));
            }else {
                messageTv.setTextColor(ResUtils.getColor(R.color.color_414655));
                messageTv.setText(ResUtils.getString(R.string.create_gesture_login));
            }
        }

        @Override
        public void addSelectedCell(List<LockPatternView.Cell> cells, LockPatternView.Cell addCell) {
            lockPatterIndicator.setIndicator(cells);
        }

        @Override
        public void onPatternComplete(List<LockPatternView.Cell> pattern) {
            if (pattern.size() >= 4) {
                checkResult(pattern);
            } else{//绘制错误，少于4个点
                setGestureText(Status.LESSERROR);//少于4个点
                lockPatternView.setPattern(LockPatternView.DisplayMode.DEFAULT);
            }
            lockPatterIndicator.removerIndicator();
        }
    };

    private void checkResult(List<LockPatternView.Cell> pattern) {
        /**
         * 注意一个条件，不是二次设置密码才触发
         */
        if(LockPatternUtil.checkSwitch(pattern)){
            ToastUtils.showToast("解锁成功");
            if(code != -1){//维护状态
                SystemModel.areaWarnResult.postValue(code);
                return;
            }
            if(isGoFinish){
                finish();
            }else {
                GoUtils.checkSwitch(this,processFirst);
            }
            return;
        }
        byte[] patternByte = LockPatternUtil.patternToHash(pattern);
        switch (currentStatus) {
            case LOGIN://设置个手势密码，登录绘制
                if (LockPatternUtil.checkPattern(pattern, mLoginPattern)) {
                    setLockPatternSuccess();
                }else {
                    lockPatternView.setPattern(LockPatternView.DisplayMode.DEFAULT);
                    messageTv.setTextColor(ResUtils.getColor(R.color.color_f4333c));
                    messageTv.setText("手势错误");
                }
                break;
            case DEFAULT://第一次绘制（或重置）
                MMKVUtil.put(CacheKey.GUSTURE_PASSWORD,patternByte);
                ToastUtils.showLong("设置手势密码成功");
                setLockPatternSuccess();
                break;
        }
    }

    /**
     * 设置提示文字
     * @param status
     */
    private void setGestureText(Status status){
        messageTv.setTextColor(ResUtils.getColor(status.colorId));
        messageTv.setText(ResUtils.getString(status.strId));
    }


    /**
     * 成功设置了手势密码(跳到首页)
     */
    private void setLockPatternSuccess() {
        goActivity(ExchangeActivity.class);
        finish();
    }

    /**
     * 重新设置手势
     */
    private void resetLockPattern() {
        mLoginPattern = null;
        currentStatus = Status.DEFAULT;
        setGestureText(currentStatus);
        lockPatterIndicator.setDefaultIndicator();
        lockPatternView.setPattern(LockPatternView.DisplayMode.DEFAULT);
        xTitle.setTiteTextView("绘制手势密码");
    }


    public enum Status {
        DEFAULT(R.string.create_gesture_default, R.color.color_414655),//没有设置过第一次设置
        LESSERROR(R.string.create_gesture_less_error, R.color.color_f4333c),//最少连接4个点，请重新绘制
        LOGIN(R.string.create_gesture_login, R.color.color_414655);//请绘制手势，至少绘制4个点
        // 成员变量
        private int strId;
        private int colorId;


        Status(int strId, int colorId) {
            this.strId = strId;
            this.colorId = colorId;
        }
    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            exit();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void exit() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if (count > 1) {
            pop();
        } else {
            ExitUtils.getInstance().finishAll();
        }
    }

}
