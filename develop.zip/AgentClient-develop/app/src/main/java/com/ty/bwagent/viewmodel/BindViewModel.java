package com.ty.bwagent.viewmodel;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.MutableLiveData;

import com.ty.bwagent.R;
import com.ty.bwagent.api.Api;
import com.ty.bwagent.bean.BaseEntity;
import com.ty.bwagent.bean.BindInfoEntity;
import com.ty.bwagent.bean.UserInfo;
import com.ty.net.NetSdk;
import com.ty.net.bean.NetLiveData;
import com.ty.utils.DownTimerHelper;
import com.ty.utils.ParameterVerification;
import com.ty.utils.ResUtils;
import com.ty.utils.StringUtils;

/**
 * 因为是对话框，不用绑定生命周期了，自己维护生命周期
 * 绑定邮箱或电话
 */
public class BindViewModel {

    /**
     * 绑定结果
     */
    public NetLiveData<BaseEntity<BindInfoEntity>> bindLiveData = new NetLiveData<>();

    /**
     * 验证码(数字验证码)
     */
    public NetLiveData<BaseEntity> codeLivedata = new NetLiveData<>();

    public MutableLiveData<Long> timerLiveData = new MutableLiveData<>();

    public DownTimerHelper mTimer;

    /**
     * 绑定电话
     *
     * @param phone
     */
    public void bindPhone(String phone, String code) {
        if (!ParameterVerification.isPhoneNumber(phone)) {
            bindLiveData.postError(0, ResUtils.getString(R.string.phone_input_err));
            return;
        }

        if (!StringUtils.isEmpty(code) && StringUtils.length(code) < 4) {
            bindLiveData.postError(0, ResUtils.getString(R.string.code_input_err));
            return;
        }


        NetSdk.create(Api.class)
                .bindPhone()
                .params("code", code)
                .params("phone", phone)
                .asJSONType()
                .send(bindLiveData);
    }

    /**
     * 绑定邮箱
     *
     * @param email
     */
    public void bindEmail(String email, String code) {

        if (!ParameterVerification.isEmail(email)) {
            bindLiveData.postError(0, "请输入正确的邮箱");
            return;
        }

        if (!StringUtils.isEmpty(code) && StringUtils.length(code) < 4) {
            bindLiveData.postError(0, ResUtils.getString(R.string.code_input_err));
            return;
        }

        NetSdk.create(Api.class)
                .bindEmail()
                .params("code", code)
                .params("email", email)
                .asJSONType()
                .send(bindLiveData);
    }

    /**
     * 绑定QQ
     */
    public void bindQq(String qq) {

        if (StringUtils.isEmpty(qq)) {
            bindLiveData.postError(0, "请输入正确的QQ号码");
            return;
        }

        if (qq.length()<5) {
            bindLiveData.postError(0, "请输入正确的QQ号码");
            return;
        }

        NetSdk.create(Api.class)
                .bindQq()
                .params("qq", qq)
                .asJSONType()
                .send(bindLiveData);
    }

    public void startTimer(Lifecycle lifecycle) {
        createTimer(60);
        mTimer.start(lifecycle);
    }

    public void startTimer(Lifecycle lifecycle, long totalTime) {
        createTimer(totalTime);
        mTimer.start(lifecycle);
    }

    private void createTimer(long totalTime) {
        if (mTimer == null) {
            //第二个参数 是倒计时间隔
            mTimer = new DownTimerHelper(totalTime * 1000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    timerLiveData.setValue(millisUntilFinished);
                }

                @Override
                public void onFinish() {
                    cancelTimer();
                    timerLiveData.setValue(0L);
                }
            };
        } else {
            mTimer.setTotalTime(totalTime * 1000);
        }
    }

    public void cancelTimer() {
        if (mTimer != null) {
            mTimer.cancel();
        }
    }

    /**
     * 获取验证码
     */
    public void getPhoneCode(String phone) {
        if (!ParameterVerification.isPhoneNumber(phone)) {
            codeLivedata.postError(0, ResUtils.getString(com.ty.view.R.string.phone_input_err));
            return;
        }

        NetSdk.create(Api.class)
                .getCode()
                .params("phone", phone)
                .asJSONType()
                .send(codeLivedata);
    }

    /**
     * 获取验证码
     */
    public void getEmailCode(String email) {
        if (!ParameterVerification.isEmail(email)) {
            codeLivedata.postError(0, "请输入正确的邮箱");
            return;
        }

        NetSdk.create(Api.class)
                .getEmailCode()
                .params("email", email)
                .asJSONType()
                .send(codeLivedata);
    }

}
